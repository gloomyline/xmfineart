import Vue from 'vue'
import LoadScript from 'vue-plugin-load-script'
import { CACHE_ADDRESS } from 'assets/data/constants.js'

const urlPrefix = CACHE_ADDRESS

Vue.use(LoadScript)

const treeGoodsCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-goods-category.js`
const treeAreaUrl = `${urlPrefix}/admin/scripts/lib/tree-area.js`
const treeBuildingCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-building-category.js`
const treeMapMarkerCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-map-marker-category.js`
const treeResourceCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-resource-category.js`
const treeStoreCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-store-category.js`
/**
 * 获取js格式文件数据
 * @param  {String}  opts.url               js文件的路径
 * @param  {String}  opts.name              属性名
 * @return {Promise}
 */
export const fetchScriptFile = (url, name) => {
  return new Promise((resolve, reject) => {
    Vue.loadScript(url)
      .then(() => {
        resolve(window[name])
      }).catch((error) => {
        reject(error)
        console.log('ERROR')
      })
  })
}
const find = (arr, value) => {
  const arrVal = arr.find(item => item.label === value || item.value === value)
  return arrVal
}
/**
 * 获取指定分类的指定字段值和父辈分类的指定字段值组成的数组
 * @param arr {Array}       指定的分类列表
 * @param value {String}     指定的值，取值范围 id 或 name
 * @return {Array}         指定分类的指定字段值和父辈分类的指定字段值组成的数组
 */
const findValue = (arr, value) => {
  let category = []
  let cate = []
  const forCate = (cateArr, cateVal) => {
    for (let i = 0, max = cateArr.length; i < max; i++) {
      if (cateArr[i].value === cateVal || cateArr[i].label === cateVal) {
        cate.push(cateArr[i])
        category.push(cateArr[i].value)
        // 再一次在原数组中查找父级id
        forCate(arr, cate[cate.length - 1].parent_id)
      } else if (cateArr[i].children) {
        // 第一层查找没有相对应的id 则继续查找下一层的id
        forCate(cateArr[i].children, cateVal)
      }
    }
  }
  forCate(arr, value)
  return category.reverse()
}

const getArray = (obj) => {
  if (Object.keys(obj).length === 0) return
  let arr = []
  for (let key in obj) {
    if (Object.keys(obj[key].son).length === 0) {
      arr.push({
        value: obj[key].id,
        label: obj[key].name,
        parent_id: obj[key].parent_id,
        depth: obj[key].depth
      })
    } else {
      arr.push({
        value: obj[key].id,
        label: obj[key].name,
        parent_id: obj[key].parent_id,
        depth: obj[key].depth,
        children: getArray(obj[key].son)
      })
    }
  }
  return arr
}

// 获取商品分类js文件数据
const getGoodsCategory = async () => {
  const response = await fetchScriptFile(treeGoodsCategoryUrl, 'jTreeGoodsCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}

// 获取省市区js文件数据
const getArea = async () => {
  const response = await fetchScriptFile(treeAreaUrl, 'jTreeArea')
  const aTreeArea = getArray(response.son['1'].son)
  return aTreeArea
}

// 获取建筑分类js文件数据
const getBuildingCategory = async () => {
  const response = await fetchScriptFile(treeBuildingCategoryUrl, 'jTreeBuildingCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}

// 获取地图分类js文件数据
const getMapMarkerCategory = async () => {
  const response = await fetchScriptFile(treeMapMarkerCategoryUrl, 'jTreeMapMarkerCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}

// 获取资源分类js文件数据
const getResourceCategory = async () => {
  const response = await fetchScriptFile(treeResourceCategoryUrl, 'jTreeResourceCategory')
  let jTreeResourceCategory = response.son
  let aTreeResourceCategory = {
    company: {id: 200, mode: '200', name: '优秀公司', son: {}},
    person: {id: 100, mode: '100', name: '优秀个人', son: {}},
    brand: {id: 400, mode: '400', name: '优秀品牌', son: {}},
    supplier: {id: 300, mode: '300', name: '优秀供应商', son: {}},
    decorator: {id: 500, mode: '500', name: '装修师', son: {}}
  }
  for (let key in jTreeResourceCategory) {
    let mode = jTreeResourceCategory[key].mode
    let name = ''
    switch (mode) {
    case '100':
      name = 'person'
      break
    case '200':
      name = 'company'
      break
    case '400':
      name = 'brand'
      break
    case '300':
      name = 'supplier'
      break
    case '500':
      name = 'decorator'
      break
    }
    aTreeResourceCategory[name]['son'][jTreeResourceCategory[key].id] = jTreeResourceCategory[key]
  }
  const aTreeCategory = getArray(aTreeResourceCategory)
  return aTreeCategory
}

// 获取店铺分类js文件
const getStoreCategory = async () => {
  const response = await fetchScriptFile(treeStoreCategoryUrl, 'jTreeStoreCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}
export {
  find,
  findValue,
  getArray,
  getArea,
  getGoodsCategory,
  getBuildingCategory,
  getMapMarkerCategory,
  getResourceCategory,
  getStoreCategory
}
