import qs from 'querystring'

/**
 * 深复制对象
 * @param obj {Object} 被拷贝的对象
 * @returns {Object}
 */
export function deepClone (obj) {
  if (!isObject(obj)) {
    throw new Error('obj 不是一个对象！')
  }

  let isArray = Array.isArray(obj)
  let cloneObj = isArray ? [] : {}
  for (let key in obj) {
    cloneObj[key] = isObject(obj[key]) ? deepClone(obj[key]) : obj[key]
  }
  return cloneObj
}

// 判断是否为对象
export function isObject (o) {
  return (typeof o === 'object' || typeof o === 'function') && o !== null
}

// 获取页面 location query 参数
export function getQuery (name, url = window.location.hash) {
  const queries = url.substr(url.indexOf('?') + 1)
  const params = qs.parse(queries)
  return name ? params[name] : params
}

// scrollTop animation
/**
 * 滚动到窗口顶部动画
 * @param el          滚动元素
 * @param from        起始位置，距顶部距离，卷曲距离 scrollTop
 * @param to          终止位置，距顶部距离，卷曲距离 scrollTop
 * @param duration    动画持续时间
 * @param endCallback 动画执行完毕回调
 */
export function scrollTop (el, from = 0, to, duration = 500, endCallback) {
  // requestAnimationFrame 兼容
  if (!window.requestAnimationFrame) {
    window.requestAnimationFrame = (
      window.webkitRequestAnimationFrame ||
      window.mozRequestAnimationFrame ||
      window.msRequestAnimationFrame ||
      function (callback) {
        return window.setTimeout(callback, 1000 / 60)
      }
    )
  }
  const difference = Math.abs(from - to)
  const step = Math.ceil(difference / duration * 50)

  function scroll (start, end, step) {
    if (start === end) {
      endCallback && endCallback()
      return
    }

    let d = (start + step > end) ? end : start + step
    if (start > end) {
      d = (start - step < end) ? end : start - step
    }

    if (el === window) {
      window.scrollTo(d, d)
    } else {
      el.scrollTop = d
    }
    window.requestAnimationFrame(() => scroll(d, end, step))
  }
  scroll(from, to, step)
}
