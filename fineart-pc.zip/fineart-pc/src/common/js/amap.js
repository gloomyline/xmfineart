import store from '@/store/index.js'
import { A_MAP_Key } from 'assets/data/constants.js'
let AMap
let map
let positionMarker
let geocoder
const zoomIndex = 16

// 初始化地图
// @param elementId [String] -- 元素id
const initMap = (elementId) => {
  return new Promise((resolve) => {
    const url = `https://webapi.amap.com/maps?v=1.3&key=${A_MAP_Key}&callback=onApiLoaded`
    let jsApi = document.createElement('script')
    jsApi.charset = 'utf-8'
    jsApi.src = url
    jsApi.id = 'map-script'
    document.head.appendChild(jsApi)
    window.onApiLoaded = () => {
      AMap = window.AMap
      const map = new AMap.Map(elementId, {
        zoom: zoomIndex,
        resizeEnable: true
      })
      resolve(map)
    }
  })
}
// 定位地图
// @param userPoint [Array] -- 经纬度
const mapGeoLocal = (userPoint) => {
  let point = userPoint
  // 设置当前位置的marker
  if (positionMarker) {
    map.remove(positionMarker) // 确保地图上只有一个点
  }
  positionMarker = new AMap.Marker({
    map: map,
    bubble: true
  })
  // 定位当前位置
  map.plugin('AMap.Geolocation', () => {
    let geoLocation = new AMap.Geolocation()
    geoLocation.getCurrentPosition()
    AMap.event.addListener(geoLocation, 'complete', onComplete)
    function onComplete (data) {
      // 获取当前位置的经纬度
      if (!point[0] || !point[1]) {
        point = [data.position.lng, data.position.lat]
      }
      // 设置当前位置的marker点的位置
      positionMarker.setPosition(point)
      // 设置地址信息
      map.plugin('AMap.Geocoder', function () {
        geocoder = new AMap.Geocoder({
          radius: 1000,
          batch: false,
          extensions: 'all'
        })
        store.commit('MAP_SAVE_POINT', {lng: point[0], lat: point[1]})
        getAddress(point)
        map.setZoomAndCenter(zoomIndex, point)
      })
    }

    AMap.event.addListener(geoLocation, 'error', onError)
    function onError (data) {
      // 定位出错
    }
  })
}

/**
 * 根据地址名称 获取相对应的经纬度
 *
 * @param address {String} 地址
 */
const getLocation = (address) => {
  map.plugin('AMap.Geocoder', () => {
    if (!geocoder) {
      geocoder = new AMap.Geocoder({
        radius: 1000,
        batch: false,
        extensions: 'all'
      })
    }
    geocoder.getLocation(address, function (status, result) {
      if (status === 'complete' && result.geocodes.length) {
        mapGeoLocal([result.geocodes[0].location.lng, result.geocodes[0].location.lat])
      }
    })
  })
}

/**
 * 格式化简单地址（去掉省市区）
 *
 * @param addressData {Object}
 */
const formatSimpleAddress = (addressData) => {
  if (!addressData.address || !addressData.province || !addressData.city || !addressData.district) {
    console.log('formatSimpleAddress NG')
    return addressData
  }
  addressData.address = addressData.address.replace(addressData.province, '')
  addressData.address = addressData.address.replace(addressData.city, '')
  addressData.address = addressData.address.replace(addressData.district, '')
  return addressData
}

// 根据经纬度获取相对应的地址名称
// @param lngLat [Array] -- 经纬度数组
const getAddress = (lngLat) => {
  map.plugin('AMap.Geocoder', () => {
    if (!geocoder) {
      geocoder = new AMap.Geocoder({
        radius: 1000,
        batch: false,
        extensions: 'all'
      })
    }
    geocoder.getAddress(lngLat, function (status, result) {
      if (status === 'complete') {
        const addressData = {
          province: result.regeocode.addressComponent.province,
          // 如果没有城市则说明是直辖市
          city: result.regeocode.addressComponent.city || result.regeocode.addressComponent.province,
          district: result.regeocode.addressComponent.district,
          address: result.regeocode.formattedAddress,
          fullAddress: result.regeocode.formattedAddress
        }
        store.commit('MAP_SAVE_ADDRESS', formatSimpleAddress(addressData))
      }
    })
  })
}

// 根据关键字搜索
// @param keywords [String]
const autoInput = (keywords) => {
  AMap.plugin('AMap.Autocomplete', function () {
    let autoComplete = new AMap.Autocomplete()
    autoComplete.search(keywords, function (status, result) {
      if (status === 'complete') {
        store.commit('MAP_SAVE_INFO', result.tips)
      }
    })
  })
}

// 点击地图事件
const showInfoClick = (data) => {
  mapGeoLocal([data.lnglat.lng, data.lnglat.lat])
}

const mapPlugin = async (elementId, userPoint) => {
  map = await initMap(elementId)
  map.on('click', showInfoClick)
  mapGeoLocal(userPoint)
}

// 销毁地图
const mapDestroy = () => {
  map.destroy()
  const jsMap = document.getElementById('map-script')
  jsMap.parentNode.removeChild(jsMap)
  store.commit('MAP_CLEAR_MAP_ADDRESS')
}
export {
  mapPlugin,
  autoInput,
  mapDestroy,
  getAddress,
  mapGeoLocal,
  getLocation
}
