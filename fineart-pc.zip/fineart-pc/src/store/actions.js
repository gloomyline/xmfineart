/*
* @Author: Alan
* @Date:   2018-09-18 17:19:41
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 17:39:11
*/
import memberApi from 'modules/member/api'
import * as MSG from 'assets/data/message.js'

/**
 * 根 action 注册
 * @param ctx     ctx.commit
 * @param payload payload.data
 * @param payload payload.cb
 * @returns {Promise<void>}
 */
export const register = async ({ commit }, { data, cb }) => {
  const response = await memberApi.register(data)
  if (response.code === 200) {
    commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_REGISTER_SUCCESS'], type: 'success' })
    cb && cb()
  }
}

export const login = async ({ commit, dispatch }, { data, cb }) => {
  const response = await memberApi.login(data)
  if (response.code === 200) {
    cb && cb()
    commit('LOGIN')
    dispatch('member/fetchAccountProfile')
  }
}

export const qrLogin = async ({ commit, dispatch }, { code, cb }) => {
  const response = await memberApi.qrLogin({ code })
  if (response.code === 200) {
    cb && cb()
    commit('LOGIN')
    dispatch('member/fetchAccountProfile')
  }
}

export const logout = async ({ commit }, { cb }) => {
  const response = await memberApi.logout()
  if (response.code === 200) {
    commit('LOGOUT')
    cb && cb()
  }
}

export const resetPassword = async ({ commit }, { data, cb }) => {
  const response = await memberApi.resetPassword(data)
  if (response.code === 200) {
    commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_RESET_PW_SUCCESS'], type: 'success' })
    cb && cb()
  }
}
