/*
* @Author: Alan
* @Date:   2018-09-18 17:20:35
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 17:27:55
*/
export const currentCount = state => Number.parseInt(state.count)
export const mapAddress = state => state.mapAddress
