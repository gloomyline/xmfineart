/*
* @comment: store 全局状态
* @Author: Alan
* @Date:   2018-09-18 17:19:34
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 17:22:13
*/
import { LocalStorage } from '@/common/js/LocalStorage.js'

const ls = new LocalStorage()
const user = ls.getUser()
const isLogin = user ? user.isLogin : false

export default {
  count: 0,
  isLoading: false, // 请求是否正在加载，true -> 加载中，false -> 为加载或已加载完成
  isLogin, // 用户是否登录, true -> 登录，false -> 未登录
  showLogin: false, // 是否显示登录 modal, true -> 显示，false -> 不显示
  message: { // 用户操作 message
    msg: '', // 具体文言
    type: '', // 操作类型 'info', 'success', 'warning', 'error'
    cb: null, // message 显示完成回调
    timestamp: null // 生成 message 时间戳
  },
  mapAddress: {
    addressData: {}, // 省、市、区、详细地址 {province, city, district, address, fullAddress}
    sysAreaId: '', // 地区ID
    point: {}, // {lng, lat}
    info: [] // 关键字检索推荐信息
  }
}
