/**
 * @comment: resource 模块的 store
 * @author: alan_wang
 * @date: 10/10/2018
 * @time: 11:25:23
 */
const state = {
  resourcePrice: [
    {value: '100', name: '100元/m²内'},
    {value: '200', name: '100~200元/m²'},
    {value: '300', name: '200~400元/m²'},
    {value: '400', name: '400~600元/m²'},
    {value: '500', name: '600~800元/m²'},
    {value: '600', name: '800元/m²以上'}
  ]
}
const getters = {}
const actions = {}
const mutations = {}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
