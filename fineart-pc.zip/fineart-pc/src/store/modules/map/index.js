/**
 * @comment: map 模块的 store
 * @comment: map 模块的 store
 * @author: alan_wang
 * @date: 10/10/2018
 * @time: 11:25:23
 */
const state = {}
const getters = {}
const actions = {}
const mutations = {}

export default {
  state,
  getters,
  actions,
  mutations
}
