/**
 * @comment: mall 模块的 store
 * @author: alan_wang
 * @date: 10/10/2018
 * @time: 11:25:23
 */
import * as types from '@/store/mutation-types.js'
import api from 'modules/mall/api'

const state = {
  cartGoodsCount: 0,
  cartItemIdArr: [],
  category: {}
}

const getters = {
  cartGoodsCount: state => state.cartGoodsCount // 购物车中商品种类数量
}

const actions = {
  async fetchCartGoodsCount ({ commit }) {
    const response = await api.fetchCartGoodsCount()
    if (response.code === 200) {
      commit(types.MALL_RECEIVE_CART_GOODS_COUNT, { count: response.results.count })
    }
  }
}

const mutations = {
  [types.MALL_CART_ITEM_ID_ARR] (state, cartItemIdArr) {
    state.cartItemIdArr = cartItemIdArr
  },
  [types.MALL_RECEIVE_CART_GOODS_COUNT] (state, { count }) {
    state.cartGoodsCount = count
  },
  [types.MALL_SAVE_CATEGORY] (state, arr) {
    const _arr = {}
    arr.forEach((item, index) => {
      _arr[index] = item
    })
    state.category = _arr
  },
  [types.MALL_CLEAR_CATEGORY] (state) {
    state.category = []
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
