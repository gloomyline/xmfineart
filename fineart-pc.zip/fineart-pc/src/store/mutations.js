/*
* @Author: Alan
* @Date:   2018-09-18 17:19:49
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 17:30:29
*/
import * as types from './mutation-types.js'

export default {
  [types.INCREMENT] (state) {
    ++state.count
  },
  [types.ADD] (state, { delta }) {
    state.count += state.delta
  },
  [types.SEND_REQUEST] (state) { // 发起请求，开始加载
    state.isLoading = true
  },
  [types.REQUEST_SUCCEED] (state) { // 请求成功，结束加载
    state.isLoading = false
  },
  [types.REQUEST_FAILED] (state) { // 请求失败，结束加载
    state.isLoading = false
  },
  [types.SHOW_LOGIN_MODAL] (state) {
    state.showLogin = true
  },
  [types.CLOSE_LOGIN_MODAL] (state) {
    state.showLogin = false
  },
  [types.LOGIN] (state) {
    state.isLogin = true
  },
  [types.LOGOUT] (state) {
    state.isLogin = false
    // 清空用户在 store 中缓存的数据
    state.mall.cartGoodsCount = 0
  },
  [types.ADD_MESSAGE] (state, { msg, type, cb }) {
    state.message = {
      msg,
      type,
      cb,
      timestamp: Date.now()
    }
  },
  [types.MAP_SAVE_POINT] (state, {lng, lat}) {
    state.mapAddress.point.lng = lng
    state.mapAddress.point.lat = lat
  },
  [types.MAP_SAVE_ADDRESS] (state, addressData) {
    state.mapAddress.addressData = addressData
  },
  [types.MAP_SAVE_AREA_ID] (state, sysAreaId) {
    state.mapAddress.sysAreaId = sysAreaId
  },
  [types.MAP_SAVE_INFO] (state, info) {
    state.mapAddress.info = info
  },
  [types.MAP_SAVE_PROVINCES] (state, area) {
    // province, city, district
    state.mapAddress.addressData.province = area[0]
    state.mapAddress.addressData.city = area[1]
    state.mapAddress.addressData.district = area[2]
  },
  [types.MAP_SAVE_DETAIL_ADDRESS] (state, val) {
    state.mapAddress.addressData.address = val
  },
  [types.MAP_CLEAR_MAP_ADDRESS] (state) {
    state.mapAddress.addressData = {}
    state.mapAddress.sysAreaId = ''
    state.mapAddress.info = []
    state.mapAddress.point = {}
  }
}
