/*
* @Author: Alan
* @Date:   2018-09-18 18:00:00
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 18:53:49
*/
import axios from 'axios'
import { LOGIN_FIRST_PLZ } from 'assets/data/message.js'
import { MESSAGE_DURATION } from 'assets/data/constants.js'
import { LocalStorage } from '@/common/js/LocalStorage.js'

const ls = new LocalStorage()

export default function createHttpInterceptor (opts = {}) {
  /* eslint-disable no-unused-vars */
  let blacklistedUrl = []
  blacklistedUrl = opts.blacklistedUrl ? [...blacklistedUrl, ...opts.blacklistedUrl] : blacklistedUrl
  return (store) => {
    axios.interceptors.request.use(config => {
      store.commit('SEND_REQUEST')
      return config
    }, error => {
      return Promise.reject(error)
    })

    axios.interceptors.response.use(response => {
      store.commit('REQUEST_SUCCEED')
      // 拦截所有的请求响应，处理 token 失效过期不合法，用户登录状态过期未登录情况
      if (response.data.code === 401) {
        if (store.state.member.memberIsLogin) { // 判断是否在会员中心 -- 在会员中心未登录跳转至首页
          store.commit('member/MEMBER_SHOW_LOGIN') // 未登录跳转到首页
          ls.setUser({ token: null, isLogin: false, memberIsLogin: false })
        } else {
          store.commit('ADD_MESSAGE', { msg: LOGIN_FIRST_PLZ, type: 'warning' })
          setTimeout(() => {
            store.commit('SHOW_LOGIN_MODAL')
          }, MESSAGE_DURATION)
        }
        if (ls.get('MEMBER_CUR_STORE')) { // 过期如果有 store 则清空
          ls.remove('MEMBER_CUR_STORE')
        }
        store.commit('member/MEMBER_CLEAR_INFO') // 清空用户信息
      } else if (response.data.code !== 200) {
        store.commit('ADD_MESSAGE', { msg: response.data.msg, type: 'error' })
      }
      return response
    }, error => {
      store.commit('REQUEST_FAILED')
      return Promise.reject(error)
    })
  }
}
