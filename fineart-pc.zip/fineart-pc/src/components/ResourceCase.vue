<template>
  <i-modal title="编辑案例"
           width="595"
           class="resource-case"
           :value="isShowed"
           @on-visible-change="changeHandler">
    <i-form class="edit-case-form"
            ref="caseEdit"
            label-position="top"
            :model="caseEdit"
            :rules="recordRule">
      <i-form-item label="服务类型" prop="service_type">
        <i-input class="service-type"
                 v-model="caseEdit.service_type"
                 placeholder="请输入您的服务类型，如建筑设计"></i-input>
      </i-form-item>
      <i-form-item class="service-time" label="服务时间" prop="start_date">
        <i-form-item prop="start_date">
          <i-date-picker type="month"
                         v-model="caseEdit.start_date"
                         @on-change="handleChangeStartAt(caseEdit.start_date)" :options="startDateOption"></i-date-picker>
        </i-form-item>
        <span class="divided-word">至</span>
        <i-form-item prop="end_date">
          <i-date-picker type="month"
                         v-model="caseEdit.end_date"
                         @on-change="handleChangeEndAt(caseEdit.end_date)" :options="endDateOption"></i-date-picker>
        </i-form-item>
      </i-form-item>
      <i-form-item class="edit-cell" label="服务详情" prop="content">
        <fineart-editor v-if="isShowed"
                        :catch-data="catchEditor"
                        :editor-content="caseEdit.content"></fineart-editor>
      </i-form-item>
    </i-form>
    <div slot="footer">
      <i-button type="default" class="del-btn" size="large" @click="deleteItem">删除本条</i-button>
      <div>
        <i-button type="text" size="large" @click="cancelModel">取消</i-button>
        <i-button type="primary" size="large" @click="saveInfo">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>

import { Form, FormItem, Select, Option, DatePicker, Input, Row, Col, Modal } from 'iview'
import FineartEditor from './FineartEditor.vue'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resource/api'

export default {
  name: 'ResourceWorks',
  data () {
    return {
      caseEdit: {
        resource_id: '', // 主页资源ID
        service_type: '', // <string>必须，服务类型
        content: '', // <string>必须，服务内容
        building_code: '', // 建筑code
        start_date: '',
        end_date: '',
        start_at: '', // <string>必须，开始时间
        end_at: ''// <string>必须，结束时间
      },
      recordRule: {
        service_type: [
          { required: true, message: '请填写服务类型' }
        ],
        content: [
          { required: true, message: '请填写服务内容' }
        ]
      }
    }
  },
  computed: {
    startDateOption () {
      let endMonth = this.caseEdit.end_date
      return {
        disabledDate (date) {
          if (endMonth) {
            return date && date.valueOf() > endMonth
          }
        }
      }
    },
    endDateOption () {
      let startMonth = this.caseEdit.start_date
      return {
        disabledDate (date) {
          return date && date.valueOf() < startMonth
        }
      }
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    },
    case: {
      type: Object,
      required: true
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    deleteItem () {
      this.$emit('delete-item', this.case.id) // 返回删除数据
    },
    // 获取富文本编辑框的数据
    catchEditor (html) {
      this.caseEdit.content = html
    },
    changeHandler (isShowed) {
      this.caseEdit = this.case
      if (this.case.start_at) {
        this.caseEdit.start_date = new Date(this.case.start_at)
        this.handleChangeStartAt(this.caseEdit.start_date)
      } else {
        this.caseEdit.start_at = ''
      }
      if (this.case.end_at) {
        this.caseEdit.end_date = new Date(this.case.end_at)
        this.handleChangeEndAt(this.caseEdit.end_date)
      } else {
        this.caseEdit.end_at = ''
      }
      this.$emit('change-show', isShowed)
    },
    cancelModel () {
      this.$emit('change-show', false) // 关闭弹窗
    },
    handleChangeStartAt (date) {
      if (date) {
        let dt = new Date(date)
        let month = dt.getMonth() + 1
        this.caseEdit.start_at = dt.getFullYear() + '-' + (month >= 10 ? month : `0${month}`)
      } else {
        this.caseEdit.start_at = ''
      }
    },
    handleChangeEndAt (date) {
      if (date) {
        let dt = new Date(date)
        let month = dt.getMonth() + 1
        this.caseEdit.end_at = dt.getFullYear() + '-' + (month >= 10 ? month : `0${month}`)
      } else {
        this.caseEdit.end_at = ''
      }
    },
    // 编辑资源参与案例
    async saveInfo () {
      this.result = await api.editResourceCase(this.case)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_CASE_EDIT_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    }
  },
  components: {
    FineartEditor,
    'i-col': Col,
    'i-row': Row,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-select': Select,
    'i-option': Option,
    'i-date-picker': DatePicker,
    'i-input': Input,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.resource-case
  .ivu-form-item
    .ivu-form-item-label
      padding: 0
      margin-right: 30px
      font-size: 16px
      height: 42px
      line-height: 42px
      color: $black
    .ivu-form-item-content
      .choice-home, .service-type
        width: 470px
      .ivu-date-picker
        width: 208px
      .divided-word
        padding: 0 21px
    &.toolbox
      display: flex
      justify-content: flex-end
      .ivu-btn
        width: 120px
        height: 40px
        font-size: 18px
        &.cancel-btn
          width: 80px
    &:last-child
      margin-bottom: 0
    &.service-time
      .ivu-form-item-content
        display: flex
        .ivu-form-item-content
          padding-left: 0
    .ivu-form-item-error-tip
      left: auto
    .ivu-select-dropdown
      z-index: 10002
  .ivu-btn.del-btn
    color: $orange
</style>
