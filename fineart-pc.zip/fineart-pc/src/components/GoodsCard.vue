<template>
  <div class="goods-card" :style="{width: size + 'px'}">
    <router-link :to="route" v-if="route" target="_blank">
      <div class="goods-img" :style="{height: size + 'px', backgroundColor: color}">
        <img :src="imgSrc | imgFilter">
      </div>
      <slot></slot>
    </router-link>
    <a :href="href" v-else>
      <div class="goods-img" :style="{height: size + 'px', backgroundColor: color}">
        <img :src="imgSrc | imgFilter">
      </div>
      <slot></slot>
    </a>
  </div>
</template>
<script>
export default {
  name: 'GoodsCard',
  props: {
    route: {
      type: String
    },
    href: {
      type: String
    },
    imgSrc: {
      type: String
    },
    size: {
      type: String,
      default: '290'
    },
    color: {
      type: String,
      default: '#f8f8f8'
    }
  },
  filters: {
    imgFilter: (value) => {
      if (!value) {
        return require('assets/logo-copy.png')
      } else {
        return value
      }
    }
  }
}
</script>

<style lang="stylus" scoped>
  .goods-card
    .goods-img
      position: relative
      margin-bottom: 20px
      img
        absolute: left 50% top 50%
        max-width: 100%
        max-height: 100%
        transform: translate(-50%, -50%)
</style>
