<template lang="html">
  <div class="fineart-page">
    <div class="page-container"><slot></slot></div>
    <fineart-foot></fineart-foot>
  </div>
</template>

<script>
import FineartFoot from './FineartFoot.vue'

export default {
  name: 'page',
  data () {
    return {}
  },
  components: {
    FineartFoot
  }
}
</script>

<style lang="stylus">
.fineart-page
  position: relative
  padding-top: 80px
  padding-bottom: 60px
  min-height: 100%
  z-index: 1
</style>
