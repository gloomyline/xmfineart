<template>
  <!--收费标准-->
  <i-modal class="resource-price-edit"
           width="595"
           :title="title"
           :value="isShowed"
           @on-ok="handleSubmit"
           @on-visible-change="changeHandler">
    <i-form>
      <i-form-item>
        <i-select clearable placeholder="收费标准" v-model="design_price">
          <i-option
            :key="index"
            :value="item.value"
            v-for="(item, index) in resourceDesignPrice">{{ item.name }}</i-option>
        </i-select>
      </i-form-item>
    </i-form>
  </i-modal>
</template>

<script>
import { Modal, Select, Option, Form, FormItem } from 'iview'

export default {
  name: 'ResourcePrice',
  data () {
    return {
      design_price: ''
    }
  },
  props: {
    title: {
      type: String,
      default: '设置收费标准'
    },
    isShowed: {
      type: Boolean,
      default: false
    },
    designPrice: {
      type: String
    }
  },
  computed: {
    // 收费标准数组
    resourceDesignPrice () {
      return this.$store.state.resource.resourcePrice
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    changeHandler (isShowed) {
      this.design_price = this.designPrice
      this.$emit('change-show', isShowed)
    },
    handleSubmit () {
      this.$emit('handle-submit', this.design_price) // 返回保存数据
    }
  },
  components: {
    'i-modal': Modal,
    'i-form': Form,
    'i-select': Select,
    'i-option': Option,
    'i-form-item': FormItem
  }
}
</script>

<style lang="stylus">
.resource-price-edit .ivu-modal-content .ivu-modal-body
  overflow: unset!important
</style>
