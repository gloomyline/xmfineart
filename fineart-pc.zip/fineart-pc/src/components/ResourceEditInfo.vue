<template>
  <!--姓名、性别、公司名称-->
  <i-modal class="edit-info"
           :value="isShowed"
           :title="title"
           width="595"
           @on-visible-change="changeHandler">
    <div v-if="resourceMode == 100">
      <label class="attribute-text">姓名</label>
      <div class="attribute-val">
        <i-input placeholder="请填写您的姓名"
                 v-model="edit.name"></i-input>
      </div>
      <label class="attribute-text">性别</label>
      <div class="attribute-val sex-choose">
        <i-button :class="{'isActive': edit.gender === '200'}"
                  @click="changeGender('200')"><i class="fy-icon-male"></i>男</i-button>
        <i-button :class="{'isActive': edit.gender === '100'}"
                  @click="changeGender('100')"><i class="fy-icon-female"></i>女</i-button>
      </div>
    </div>
    <div v-else>
      <div class="attribute-val">
        <i-input placeholder="请填写公司名称" v-model="edit.name"></i-input>
      </div>
    </div>
    <p class="tip" v-if="tipsShow">
      <span class="fy-icon-notes"><span class="path1"></span><span class="path2"></span></span>
      <span>{{ tipText }}</span>
    </p>
    <div slot="footer">
      <div class="save-btn-group">
        <i-button type="text"
                  class="cancel"
                  @click="cancelModel">取消</i-button>
        <i-button class="save-btn"
                  type="primary"
                  size="large"
                  @click="saveInfo">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal, Input } from 'iview'
export default {
  name: 'ResourceDetailModal',
  data () {
    return {
      tipsShow: false, // 是否显示错误提示信息
      edit: {
        name: '',
        gender: ''
      },
      tipText: '请填写公司名称'
    }
  },
  props: {
    title: {
      type: String,
      default: '编辑基本信息'
    },
    name: {
      type: String
    },
    gender: {
      type: String
    },
    resourceMode: {
      type: String,
      require: true
    },
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  components: {
    'i-modal': Modal,
    'i-input': Input
  },
  created () {
    if (this.resourceMode === '100') {
      this.tipText = '请填写姓名'
    }
  },
  methods: {
    changeHandler (isShowed) {
      if (isShowed) {
        this.edit = {
          name: this.name,
          gender: this.gender
        }
      }
      this.$emit('change-show', isShowed)
    },
    cancelModel () {
      this.$emit('change-show', false)
    },
    saveInfo () {
      if (this.edit.name === '') {
        this.tipsShow = true
      } else {
        this.tipsShow = false
        this.$emit('change-show', false)
        this.$emit('save-edit', this.edit) // 返回保存数据
      }
    },
    changeGender (sex) {
      this.edit.gender = sex
    }
  }
}
</script>

<style lang="stylus">
.edit-info
  .attribute-text
    display: block
    font-size: 14px
    color: $black1
    padding: 10px 0
  .attribute-val
    padding-bottom: 8px
    &.sex-choose,&.classify-choose,&.experience-date
      display: flex
      justify-content: space-between
      .ivu-btn,.ivu-select,.ivu-input-wrapper
        color: $grey-high
        width: 257px
        &.isActive
          color: $black
  .tip
    font-size: 16px
    color: $red
</style>
