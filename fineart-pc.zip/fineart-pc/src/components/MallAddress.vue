<template>
  <i-modal class-name="mall-address"
           width="590"
           :value="isShowed"
           :title="titleWord"
           ok-text="保存"
           @on-ok="saveAddress"
           @on-visible-change="changeHandler">
    <!--添加地址-->
    <div class="add-address" v-if="typeShow === 'add'">
      <i-form ref="addressForm"
              :model="addressAddItem"
              :rules="ruleInput">
        <i-form-item label="地区" prop="areaVal">
        <fineart-cascader label=""
                          width="440"
                          :data="areaList"
                          placeholder="请选择地区"
                          v-model="addressAddItem.areaVal"
                          @change-category="changeArea"></fineart-cascader>
        </i-form-item>
        <i-form-item label="地址" prop="address">
          <i-input style="width: 440px"
                   v-model.trim="addressAddItem.address"
                   placeholder="请输入收货地址"></i-input>
        </i-form-item>
        <i-form-item label="邮政编码" prop="zip_code">
          <i-input style="width: 440px"
                   placeholder="请输入邮政编码"
                   v-model.trim="addressAddItem.zip_code"></i-input>
        </i-form-item>
        <i-form-item label="收货人" prop="name">
          <i-input style="width: 440px"
                   placeholder="请输入收货人姓名"
                   v-model.trim="addressAddItem.name"></i-input>
        </i-form-item>
        <i-form-item label="手机号码" prop="mobile">
          <i-input style="width: 440px"
                   placeholder="请输入手机号码"
                   v-model.trim.number="addressAddItem.mobile"></i-input>
        </i-form-item>
      </i-form>
    </div>
    <!--选择地址-->
    <div class="choice-address" v-else>
      <ul class="address-list">
        <li class="address-item"
            v-for="item in addressList" :key="item.id"
            :class="{'is-address': isAddress === item.id}"
            @click="getIsAddress(item)">
          <p class="address-cell">
            <span class="span-label">收货人</span>:
            <span class="cell-content">{{ item.name }}</span>
          </p>
          <p class="address-cell">
            <span class="span-label">联系电话</span>:
            <span class="cell-content">{{ item.mobile }}</span>
          </p>
          <p class="address-cell">
            <span class="span-label">收货地址</span>:
            <span class="cell-content">{{ item.address }}</span>
          </p>
          <i-icon type="ios-checkmark" class="icon-check" size="24"/>
        </li>
      </ul>
    </div>
    <div slot="footer" v-if="typeShow === 'add'">
      <div class="address">
        <i-checkbox class="default-address" v-model="addressAddItem.default" @on-change="checkDefaultBox"><span>默认地址</span></i-checkbox>
        <i-button class="save-btn" type="primary" size="large" @click="handleSubmit('addressForm')">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal, Form, FormItem, Input, Select, Option, Button, Checkbox, Icon } from 'iview'
import FineartCascader from './FineartCascader.vue'
import { getArea, findValue } from '@/common/js/loadScript.js'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'

export default {
  name: 'MallAddress',
  data () {
    const mobileValidator = (rule, value, callback) => {
      if (!(/^1\d{9}\d$/.test(value))) {
        callback(new Error('手机号格式不正确！'))
      } else {
        callback()
      }
    }
    return {
      areaList: [],
      ruleInput: {
        address: [
          {
            required: true,
            message: '收货地址不能为空!'
          }
        ],
        name: [
          {
            required: true,
            message: '收货人姓名不能为空！'
          }
        ],
        areaVal: [
          {
            required: true,
            message: '地区没有选择！'
          }
        ],
        mobile: [
          {
            required: true,
            message: '手机号不可为空！'
          },
          {
            // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
            validator: mobileValidator
          }
        ]
      },
      addressAddItem: {
        id: '',
        address: '',
        name: '',
        mobile: '',
        zip_code: '',
        sys_area_id: '',
        default: false,
        areaVal: [],
        is_default: 200
      },
      addressItem: {}, // 选中的地址
      addressList: {
        list: [
          {
            id: 1,
            name: '溢于言表',
            mobile: '1456677788',
            address: '福建厦门湖里海富中心'
          },
          {
            id: 2,
            name: '溢于言表',
            mobile: '1456677788',
            address: '福建厦门湖里海富中心'
          }
        ]
      },
      isAddress: ''
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change'
  },
  props: {
    typeShow: {
      type: String,
      default: 'add'
    },
    isShowed: {
      type: Boolean,
      default: false
    },
    titleWord: {
      type: String,
      default: '添加收货地址'
    }
  },
  created () {
    this.init()
  },
  methods: {
    // 编辑地址的时候赋默认值
    refsDefaultData (address) {
      let addressVal = JSON.parse(JSON.stringify(address))
      if (addressVal.is_default) {
        addressVal.default = true
        addressVal.is_default = 100
      } else {
        addressVal.default = false
        addressVal.is_default = 200
      }
      this.addressAddItem = addressVal
      this.addressAddItem.areaVal = findValue(this.areaList, this.addressAddItem.sys_area_id)
    },
    refsResetData () {
      this.$refs['addressForm'].resetFields()
      this.addressAddItem.id = ''
      this.addressAddItem.default = false
    },
    // 初始化地区选择器
    async init () {
      this.areaList = await getArea()
    },
    // 选择地区 addressAddItem => area_id
    changeArea (value) {
      if (value) {
        this.addressAddItem.sys_area_id = value
      } else {
        this.addressAddItem.sys_area_id = ''
      }
    },
    async changeHandler (isShowed) {
      if (this.typeShow === 'add') {
        this.$emit('change', isShowed)
      } else {
        this.addressList = await api.addressFetchList()
        for (let i = 0, max = this.addressList.length; i < max; i++) {
          if (this.addressList[i].is_default) {
            this.isAddress = this.addressList[i].id
            break
          } else {
            this.isAddress = this.addressList[0].id
          }
        }
        this.$emit('change', isShowed)
      }
    },
    saveAddress () {
      this.$emit('select-address', this.addressItem)
    },
    getIsAddress (item) {
      this.isAddress = item.id
      this.addressItem = item
    },
    checkDefaultBox (val) {
      this.addressAddItem.is_default = val ? 100 : 200
    },
    // 编辑地址提交
    handleSubmit (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          if (this.addressAddItem.id) {
            this.result = await api.addressEdit(this.addressAddItem)
          } else {
            this.result = await api.addressAdd(this.addressAddItem)
          }
          if (this.result.code === 200) {
            this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_SAVE_ADDRESS_SUCCESS'], type: 'success' })
            // 触发父组件的change事件，刷新父组件的数据
            this.$emit('change')
          }
        }
      })
    }
  },
  components: {
    FineartCascader,
    'i-form': Form,
    'i-icon': Icon,
    'i-modal': Modal,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-button': Button,
    'i-checkbox': Checkbox,
    'i-form-item': FormItem
  }
}
</script>

<style lang="stylus">
.mall-address
  display: flex
  align-items: center
  justify-content: center
  .ivu-form-item
    display: flex
  .ivu-form-item-label
    padding: 0
    width: 64px
    height: 40px
    color: $black
    font-size: 16px
    margin-right: 20px
    line-height: 40px
    text-align: justify
    /*实现文字两端对齐*/
    &:after
      content: ''
      display: inline-block
      padding-left: 100%
    &:before
      display: none
  .address-area
    width: 160px
    height: 40px
    margin-right: 20px
    &:last-child
      margin-right: 0
  .address
    display: flex
    width: 100%
    justify-content: flex-end
    align-items: center
    .default-address
      display: flex
      align-items: center
      color: $black1
      font-size: 16px
      margin-right: 30px
      .ivu-checkbox, .ivu-checkbox-inner
        width: 24px
        height: 24px
        margin-right: 10px
        border-radius: 4px
        &:after
          left: 7px
          width: 7px
          height: 14px
    .save-btn
      width: 120px
      height: 40px
  .choice-address
    height: 440px
    width: 100%
    .address-item
      margin-bottom: 14px
      padding: 18px 20px 0 20px
      border: 1px solid $grey-light2
      border-radius: 4px
      .icon-check
        display: none
      &.is-address
        position: relative
        border: 2px solid $orange
        &:after
          position: absolute
          bottom: 0
          right: 0
          content: ''
          width: 0
          height: 0
          border-bottom: 20px solid $orange
          border-right: 0 solid transparent
          border-top: 0 solid transparent
          border-left: 20px solid transparent
        .icon-check
          display: block
          position: absolute
          bottom: -6px
          right: -6px
          z-index: 2
          color: $white
      .address-cell
        display: flex
        height: 22px
        margin-bottom: 18px
        color: $grey-high
        font-size: 16px
        .span-label
          width: 70px
          margin-bottom: 16px
          color: $grey-high
          text-align: justify
          /*实现文字两端对齐*/
          &:after
            content: ''
            display: inline-block
            padding-left: 100%
        .cell-content
          margin-left: 16px
          color: $black
  .fineart-cascade
    margin-bottom: 0
</style>
