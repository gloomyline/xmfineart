<template>
  <i-back-top :height="250" :bottom="60" :right="60" :duration="300">
    <span class="fy-icon-top top"><span class="path1"></span><span class="path2"></span></span>
  </i-back-top>
</template>

<script>
import { BackTop } from 'iview'
export default {
  data () {
    return {}
  },
  components: {
    'i-back-top': BackTop
  }
}
</script>

<style lang="stylus" scoped>
.top
  font-size: 50px
</style>
