<template>
  <!--个人-简介,公司简介-->
  <i-modal :title="title"
           width="595"
           class="resource-intro"
           :value="isShowed"
           @on-visible-change="changeHandler">
    <div class="attribute-val">
      <i-input type="textarea"
               v-model="introduce"
               :autosize="{ minRows: 7,maxRows: 20 }"
               :placeholder="`${resourceMode==='100'?'请填写个人技能及特长':'请填写公司简介'}`"></i-input>
    </div>
    <p class="tip" v-show="tipShow">
      <span class="fy-icon-notes"><span class="path1"></span><span class="path2"></span></span>
      <span>请填写简介</span>
    </p>
    <div slot="footer">
      <div class="save-btn-group">
        <i-button type="text"
                  class="cancel"
                  @click="cancelModel">取消</i-button>
        <i-button class="save-btn"
                  type="primary"
                  size="large"
                  @click="saveInfo">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal } from 'iview'
import FineartEditor from './FineartEditor.vue'
export default {
  name: 'ResourceIntro',
  props: {
    title: {
      type: String,
      default: '编辑个人简介'
    },
    resourceMode: {
      type: String,
      default: '100'
    },
    isShowed: {
      type: Boolean,
      default: false
    },
    intro: {
      type: String
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  data () {
    return {
      tipShow: false,
      introduce: ''
    }
  },
  methods: {
    changeHandler (isShowed) {
      if (isShowed) {
        this.introduce = this.intro.replace(/<br \/>|<br>/g, '\r\n')
      }
      this.$emit('change-show', isShowed)
    },
    cancelModel () {
      this.$emit('change-show', false) // 关闭弹窗
    },
    saveInfo () {
      if (!this.introduce) {
        this.tipShow = true
      } else {
        this.tipShow = false
        this.$emit('change-show', false) // 关闭弹窗
        this.$emit('save-edit', this.introduce) // 返回保存数据
      }
    },
    catchEditor (html) {
      this.introduce = html
    }
  },
  components: {
    FineartEditor,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.resource-intro
  .tip
    margin-top: 20px
    font-size: 16px
    color: $red
</style>
