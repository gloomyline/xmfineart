<template lang="html">
  <i-modal
    width="450"
    :value="isShowed"
    @on-visible-change="changeHandler"
    class-name="vertical-center-modal">
    <div class="header" slot="header">
      <ul class="tabs" v-show="selected < 2">
        <li class="tab-item login" :class="{active: selected === 0}" @click="showForm(0)">登录</li>
        <li class="tab-item register" :class="{active: selected === 1}" @click="showForm(1)">注册</li>
      </ul>
      <ul class="tabs reset-tab" v-show="selected === 2">
        <li class="tab-item">重置密码</li>
      </ul>
    </div>
    <div class="content">
      <!-- login form -->
      <i-form ref="loginForm"
              class="login"
              :model="loginForm"
              :show-message="false"
              v-show="selected === 0"
              :rules="loginRules">
        <i-form-item class="mobile" prop="mobile">
          <i-input v-model.trim.number="loginForm.mobile" placeholder="请输入手机号码"><i-icon slot="prefix" custom="fy-icon-phone"></i-icon></i-input>
          <i-divider></i-divider>
        </i-form-item>
        <i-form-item class="password" prop="password">
          <i-input v-model.trim="loginForm.password" type="password" placeholder="请输入密码" @on-keyup.enter="login"><i-icon slot="prefix" custom="fy-icon-password"></i-icon></i-input>
          <i-divider></i-divider>
          <i-button class="reset-pwd-btn" type="text" @click="showForm(2)">重置密码</i-button>
        </i-form-item>

        <div class="login-btn-wrap text-center">
          <i-button class="login-btn" type="primary" @click="login"><i-icon custom="fy-icon-nextstep"></i-icon></i-button>
        </div>
        <div class="wx-login-wrap text-center">
          <i-button class="wx-login-btn" type="text" @click="showForm(3)">
            <img class="wx-icon" src="../assets/icon-wechat.png" width="32" height="32" />
            <span class="label">微信扫码登录</span>
          </i-button>
        </div>
      </i-form>
      <!-- register form -->
      <i-form ref="registerForm" class="register" :model="registerForm" :rules="registerRules" v-show="selected === 1">
        <i-form-item class="mobile" prop="mobile">
          <i-input v-model.trim.number="registerForm.mobile" placeholder="请输入手机号码"><i-icon slot="prefix" custom="fy-icon-phone"></i-icon></i-input>
          <i-divider></i-divider>
        </i-form-item>
        <i-form-item class="code" prop="code">
          <div class="sms-code-wrap">
            <i-input class="input-sms-code" v-model.trim="registerForm.code" placeholder="请输入验证码">
              <i-icon slot="prefix" custom="fy-icon-code"></i-icon>
            </i-input>
            <i-button class="send-code-btn" @click="fetchCode" type="primary" ghost :disabled="isCodeBtnDisabled">{{ codeBtnLabel }}</i-button>
          </div>
          <i-divider></i-divider>
        </i-form-item>
        <i-form-item class="password" prop="password">
          <i-input v-model.trim="registerForm.password" type="password" @on-keyup.enter="register" placeholder="输入登录密码（6-15位数字+字母）"><i-icon slot="prefix" custom="fy-icon-password"></i-icon></i-input>
          <i-divider></i-divider>
        </i-form-item>
        <div class="register-btn-wrap text-center">
          <i-button class="register-btn" type="primary" @click="register"><i-icon custom="fy-icon-nextstep"></i-icon></i-button>
        </div>
        <i-form-item class="protocol">
          <i-checkbox v-model="isAgree">已阅读且同意遵守<a class="link-protocol" href="index.html#/protocol" target="_blank">《斐艺平台用户协议》</a></i-checkbox>
        </i-form-item>
      </i-form>
      <!-- reset password form -->
      <i-form ref="resetForm" class="reset" :model="resetForm" :rules="resetRules" v-show="selected === 2">
        <i-form-item class="mobile" prop="mobile">
          <i-input v-model.trim.number="resetForm.mobile" placeholder="输入手机号码"><i-icon slot="prefix" custom="fy-icon-phone"></i-icon></i-input>
          <i-divider></i-divider>
        </i-form-item>
        <i-form-item class="code" prop="code">
          <div class="sms-code-wrap">
            <i-input class="input-sms-code" v-model.trim="resetForm.code" placeholder="请输入验证码">
              <i-icon slot="prefix" custom="fy-icon-code"></i-icon>
            </i-input>
            <i-button class="send-code-btn" @click="fetchCode" type="primary" ghost :disabled="isCodeBtnDisabled">{{ codeBtnLabel }}</i-button>
          </div>
          <i-divider></i-divider>
        </i-form-item>
        <i-form-item class="password" prop="password">
          <i-input v-model.trim="resetForm.password" type="password" placeholder="输入新密码（6-15位数字+字母）"><i-icon slot="prefix" custom="fy-icon-password"></i-icon></i-input>
          <i-divider></i-divider>
        </i-form-item>
        <i-form-item class="password" prop="password_confirm">
          <i-input v-model.trim="resetForm.password_confirm" type="password" @on-keyup.enter="resetPassword" placeholder="再次输入新密码"><i-icon slot="prefix" custom="fy-icon-password"></i-icon></i-input>
          <i-divider></i-divider>
        </i-form-item>
        <i-form-item class="reset-pw-wrap">
          <i-button class="go-to-reset-pw-btn" type="primary" @click="resetPassword">确认重置</i-button>
        </i-form-item>
        <div class="pw-login-wrap text-center">
          <i-button class="pw-login-btn" type="text" @click="showForm(0)">密码登录</i-button>
        </div>
      </i-form>
      <!-- Scan QR -->
      <div class="scan-qr text-center" v-show="selected === 3">
        <p class="scan-qr-tip text-center">打开微信，扫码登录</p>
        <div class="qr-img-wrap text-center">
          <div id="qr-login" class="qr-login" v-show="!isQRTimeout"></div>
          <div class="invalid-tip" v-show="isQRTimeout">
            <p>二维码已失效</p>
            <i-button type="text" slot="append" @click="refreshQR"><i-icon type="ios-sync"/>点击刷新</i-button>
          </div>
        </div>
        <div class="go-back-btn">
          <i-button class="go-to-login-btn" type="text" @click="showForm(0)">密码登录</i-button>
          <i-button class="go-to-reset-pw-btn" type="text" @click="showForm(2)">重置密码</i-button>
        </div>
      </div>
    </div>
    <div class="footer" slot="footer"></div>
  </i-modal>
</template>

<script>
import { Modal, Form, FormItem, Input, Checkbox, Icon, Divider } from 'iview'

import api from 'modules/member/api'

import * as MSG from 'assets/data/message.js'
import { mapActions } from 'vuex'

import { getQuery } from '@/common/js/utils.js'
import { fetchScriptFile } from '@/common/js/loadScript.js'
import { WX_QR_URL, WX_APP_ID, WX_GETTING_CODE_INTERVAL, WX_GETTING_CODE_TIMEOUT } from '@/assets/data/constants.js'

// 表单名称
const FORMS = ['login', 'register', 'reset']

export default {
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{10}$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    const passwordValidator = (rule, value, cb) => {
      if (!(/^[\w!@#$%^&*.,]+$/.test(value))) {
        cb(new Error('密码只能由英文字母、数字、!@#$%^&*.,组成！'))
      } else {
        cb()
      }
    }
    const passwordConfirmValidator = (rule, value, cb) => {
      if (String(value) !== String(this.resetForm.password)) {
        cb(new Error('两次输入的密码不一致！'))
      } else {
        cb()
      }
    }
    return {
      // 当前选中表单的状态值：0(default) => 密码登录，1 => 注册，2 => 重置密码，3 => 扫码登录
      selected: 0,
      // 登录表单字段
      loginForm: {
        // 用户手机
        mobile: null,
        // 用户密码
        password: ''
      },
      // 登录表单校验规则
      loginRules: {
        mobile: [{
          required: true,
          message: '手机号不可为空！'
        }, {
          // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
          validator: mobileValidator
        }],
        password: [{
          required: true,
          message: '密码不可为空！'
        }, {
          type: 'string',
          min: 6,
          max: 15,
          message: '密码长度必需小于15个字符，且大于6个字符！'
        }, {
          validator: passwordValidator
        }]
      },
      // 注册表单字段
      registerForm: {
        // 注册手机号
        mobile: null,
        // 短信验证码
        code: '',
        // 用户设定的登录密码
        password: ''
      },
      // 注册表单校验规则
      registerRules: {
        mobile: [{
          required: true,
          message: '手机号不可为空！'
        }, {
          // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
          validator: mobileValidator
        }],
        password: [{
          required: true,
          message: '密码不可为空！'
        }, {
          type: 'string',
          min: 6,
          max: 15,
          message: '密码长度必需小于15个字符，且大于6个字符！'
        }, {
          validator: passwordValidator
        }],
        code: [{
          required: true,
          message: '短信验证码不可为空！'
        }]
      },
      // 重置密码表单字段
      resetForm: {
        // 用户手机号
        mobile: null,
        // 短信验证码
        code: null,
        // 新登录密码
        password: '',
        // 再次输入密码
        password_confirm: ''
      },
      resetRules: {
        mobile: [{
          required: true,
          message: '手机号不可为空！'
        }, {
          // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
          validator: mobileValidator
        }],
        smsCode: [{
          required: true,
          message: '短信验证码不可为空！'
        }],
        password: [{
          required: true,
          message: '密码不可为空！'
        }, {
          type: 'string',
          min: 6,
          max: 15,
          message: '密码长度必需小于15个字符，且大于6个字符！'
        }, {
          validator: passwordValidator
        }],
        passwordConfirm: [{
          required: true,
          message: '密码不可为空！'
        }, {
          validator: passwordConfirmValidator
        }]
      },
      isAgree: true,
      // 动态二维码 URL (暂时使用静态资源替代)
      qrImage: require('@/assets/image-qr-login.png'),
      initCount: 60, // 获取短信验证码按钮初始冷却计数
      count: 60, // 获取短息验证码当前冷却计数
      counter: null, // 计数器
      isQRTimeout: false // 登录二维码是否失效
    }
  },
  destroyed () {
    this.stopCount() // 停止当前获取验证码冷却的计数器
    this.clearQrTimer() // 停止当前计算微信扫码登录二维码有效期计时器
  },
  model: {
    prop: 'isShowed',
    event: 'change'
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    isCodeBtnDisabled () {
      return this.count < 60
    },
    codeBtnLabel () {
      // 当计时器工作时，即获取短信验证码处于冷却中，显示当前计数
      return this.isCodeBtnDisabled ? `${this.count}s` : '获取验证码'
    }
  },
  watch: {
    isShowed (newVal) {
      // Reset selected status, default to select login form.
      if (newVal) {
        this.$nextTick(() => {
          this.selected = 0
        })
      }
    },
    // 选中表单后，重置字段并移除已经校验的结果
    selected (newVal, oldVal) {
      this.stopCount()
      // 微信扫码登录无需重置表单
      if (newVal === 3 || oldVal === 3) return
      // 重置前一个表单
      this.$refs[`${FORMS[oldVal]}Form`].resetFields()
      this.$nextTick(() => {
        // 重置选中表单
        this.$refs[`${FORMS[newVal]}Form`].resetFields()
      })
    }
  },
  methods: {
    ...mapActions('member', ['fetchAccountProfile']),
    changeHandler (isShowed) {
      this.$emit('change', isShowed)
    },
    // 清除二维码定时器
    clearQrTimer () {
      this.timerId && clearInterval(this.timerId)
      this.timerId = null
    },
    // 开启间隔获取url上的code计时器
    startGettingCode () {
      this.qrTimeout = WX_GETTING_CODE_TIMEOUT
      this.timerId = setInterval(() => {
        this.qrTimeout -= WX_GETTING_CODE_INTERVAL
        const code = getQuery('code')
        if (code) {
          const vm = this
          // 发送扫码登录请求
          this.$store.dispatch('qrLogin', {
            code,
            cb () { vm.$emit('change', false) } // 关闭登录模态弹框
          })
          this.clearQrTimer()
        }
        if (this.qrTimeout <= 0) {
          this.isQRTimeout = true
        }
      }, WX_GETTING_CODE_INTERVAL)
    },
    // 刷新微信绑定二维码
    refreshQR () {
      this.createQr()
    },
    // 创建微信二维码
    async createQr () {
      const WxLogin = this.WxLogin || await fetchScriptFile(WX_QR_URL, 'WxLogin')
      const currentUri = window.location
      // 将当前二维码置为有效，显示二维码。
      this.isQRTimeout = false
      this.$nextTick(() => {
        /* eslint-disable no-unused-vars */
        const qrObj = new WxLogin({
          id: 'qr-login',
          appid: WX_APP_ID,
          scope: 'snsapi_login',
          href: 'https://static.xmfineart.com/static/wx-qr-style.css',
          redirect_uri: encodeURIComponent(currentUri)
        })
        // 开始二维码扫码计时
        this.startGettingCode()
      })
    },
    showForm (index) {
      this.selected = Number.parseInt(index)
      // wx 扫码登录
      if (index === 3) {
        this.isQRTimeout = true
        this.$nextTick(() => {
          this.createQr()
        })
      } else {
        this.clearQrTimer()
      }
    },
    startCount () {
      this.counter = setInterval(() => {
        --this.count
        if (this.count <= 0) {
          this.stopCount()
        }
      }, 1000)
    },
    stopCount () {
      this.count = this.initCount
      clearInterval(this.counter)
    },
    // 获取短信验证码
    fetchCode () {
      const cb = async (result) => {
        if (!result) { // 校验错误信息为空，即注册手机号校验成功，获取短信验证码 code
          let type = this.selected === 1 ? 201 : 202
          let mobile = this.selected === 1 ? this.registerForm.mobile : this.resetForm.mobile
          const response = await api.fetchCode({ type: type, mobile: mobile })
          if (response.code === 200) {
            this.$store.commit('ADD_MESSAGE', { msg: MSG['SEND_CODE_SUCCESS'], type: 'success' })
            this.startCount()
          }
        }
      }
      if (this.selected === 1) {
        this.$refs.registerForm.validateField('mobile', cb)
      } else {
        this.$refs.resetForm.validateField('mobile', cb)
      }
    },
    // 提交注册表单
    async register () {
      if (!this.isAgree) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_REGISTER_AGREE_TIP'], type: 'error' })
        return false
      }
      const vm = this
      const result = await this.$refs.registerForm.validate()
      if (result) {
        this.$store.dispatch('register', {
          data: this.registerForm,
          cb () { vm.showForm(0) } // 注册成功后显示登录表单
        })
      }
    },
    // 提交登录表单
    async login () {
      const vm = this
      const result = await this.$refs.loginForm.validate()
      if (result) {
        this.$store.dispatch('login', {
          data: this.loginForm,
          cb () {
            vm.$emit('change', false) // 关闭登录模态弹框
            // vm.fetchAccountProfile() // 登录成触发获取用户信息事件
          }
        })
      } else {
        let mobileReg = /^1\d{10}$/
        let passwordReg = /^[\w!@#$%^&*.,]+$/
        if (!(this.loginForm.mobile && this.loginForm.password)) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['REG_REQUIRE_ERROR'], type: 'error' })
        } else if (!mobileReg.test(this.loginForm.mobile)) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['REG_MOBILE_ERROR'], type: 'error' })
        } else if (!passwordReg.test(this.loginForm.password)) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['REG_PASSWORD_ERROR'], type: 'error' })
        }
      }
    },
    // 提交重置密码表单
    async resetPassword () {
      const vm = this
      const result = await this.$refs.resetForm.validate()
      if (result) {
        this.$store.dispatch('resetPassword', {
          data: this.resetForm,
          cb () { vm.showForm(0) } // 重置成功后显示登录表单
        })
      }
    }
  },
  components: {
    'i-modal': Modal,
    'i-icon': Icon,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-input': Input,
    'i-checkbox': Checkbox,
    'i-divider': Divider
  }
}
</script>

<style lang="stylus">
.vertical-center-modal
  display: flex
  align-items: center
  justify-content: center
  .ivu-modal
    top: 0
    .ivu-modal-content
      width: 100%
      height: 540px
      .ivu-modal-close .ivu-icon-ios-close
        font-size: 38px
      .ivu-modal-header
        margin-bottom: 0
        border-bottom: 0
        .header
          padding: 3px 120px
          .tabs
            display: flex
            justify-content: space-between
            height: 30px
            line-height: 30px
            font-size: 22px
            .tab-item
              width: 44px
              text-align: center
              color: $grey-high1
              cursor: pointer
              &.active
                position: relative
                font-weight: bold
                color: $black
                &:after
                  content: ''
                  absolute: bottom -14px
                  left: 50%
                  width: 20px
                  height: 4px
                  transform: translateX(-50%)
                  background-color: $orange
          .reset-tab
            justify-content: space-around
            .tab-item
              width:auto
              color: $black
              font-size: 18px
          h3
            height: 30px
            line-height: 30px
            font-size: 22px
            margin-top: 0
      .ivu-modal-body
        height: 454px
        .content
          padding: 0 20px
          .ivu-form-item
            margin-bottom: 17px
            .ivu-divider
              width: 350px
              margin: 0
              background-color: #d7d7d7
            .ivu-input-wrapper
              padding: 12px 0
              .ivu-input
                padding: 4px 12px 4px 50px
                height: 30px
                font-size: 16px
                color: $black
                border: 0
                &:focus
                  box-shadow: none
              .ivu-input-prefix
                height: 30px
                top: 12px
                i
                  font-size: 22px
                  height: 30px
                  line-height: 30px
            .ivu-form-item-error-tip
              padding: 0
              font-size: 14px
              margin-top: 10px
          .sms-code-wrap
            font-size: 0
            .send-code-btn
              position: absolute
              top: 12px
              right: 0
              width: 100px
              height: 30px
              font-size: 14px
              padding: 0 10px
              text-align: center
          /* login form */
          .login
            margin-top: 40px
            .reset-pwd-btn
              position: absolute
              top: 100%
              right: 0
              line-height: 20px
              height: 20px
              margin-top: 10px
              padding: 0
              font-size: 14px
              border: none
              color: $grey-light
            .login-btn-wrap
              margin-top: 125px
              .login-btn
                width: 350px
                height: 54px
                box-shadow: 0 4px 12px rgba(247,181,44,0.5)
                .fy-icon-nextstep
                  font-size: 32px
            .wx-login-wrap
              margin-top: 18px
              .wx-login-btn:focus
                box-shadow: none
              .ivu-btn>span
                display: inline-block
                font-size: 0
                .wx-icon
                  display: inline-block
                  vertical-align: middle
                  margin-right: 8px
                .label
                  display: inline-block
                  vertical-align: middle
                  font-size: 16px
                  line-height: 22px
                  color: $grey-light
          /* register form */
          .register
            margin-top: 10px
            .register-btn-wrap
              margin-top: 83px
              .register-btn
                width: 350px
                height: 54px
                box-shadow: 0 4px 12px rgba(247,181,44,0.5)
                .fy-icon-nextstep
                  font-size: 32px
            .protocol
              margin-top: 12px
              margin-bottom: 0
              .ivu-checkbox-wrapper
                font-size: 14px
                color: $grey-high1
                .ivu-checkbox
                  top: -2px
                  .ivu-checkbox-inner
                    width: 16px
                    height: 16px
                    margin-right: 2px
                    border-radius: 50%
                    &:after
                      top: 2px
                      left: 5px
              .link-protocol
                color: $grey-high1
          /* reset password form */
          .reset
            margin-top: 0
            .reset-pw-wrap
              margin-top: 30px
              text-align: center
              .ivu-btn
                width: 350px
                height: 54px
                font-size: 18px
                box-shadow: 0 4px 12px rgba(247,181,44,0.5)
            .pw-login-btn
              padding: 10px 0
              color: $black1
              font-size: 16px
          .scan-qr
            .qr-img-wrap
              font-size: 0
              height: 300px !important
              .qr-login
                pointer-events: none
              .invalid-tip
                width: 100%
                text-align: center
                padding-top: 100px
                font-size: 18px
                color: $grey-high
                .ivu-btn-text
                  color: $black1
                  font-size: 20px
                  margin-top: 10px
                  &:focus
                    box-shadow: none
                  &:hover
                    background-color: transparent
            .scan-qr-tip
              height: 54px
              line-height: 54px
              font-size: 18px
              color: $grey-high
          .go-back-btn
            margin-top: 20px
            .ivu-btn
              width: 160px
              height: 54px
              font-size: 20px
              color: $orange
              &:first-child
                margin-right: 20px
      .ivu-modal-footer
        padding: 0
</style>
