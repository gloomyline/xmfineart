<template>
  <!--一句话介绍自己-->
  <i-modal :value="isShowed"
           class="resource-recommend"
           title="编辑一句话介绍"
           width="595"
           @on-visible-change="changeHandler">
    <div class="attribute-val">
      <i-input placeholde="请填写一句话介绍您的业务类型" v-model="subtitleVal"></i-input>
    </div>
    <p class="tip" v-show="tipShow">
      <span class="fy-icon-notes"><span class="path1"></span><span class="path2"></span></span>
      <span>编辑一句话介绍</span>
    </p>
    <div slot="footer">
      <div class="save-btn-group">
        <i-button type="text"
                  class="cancel"
                  @click="cancelModel">取消</i-button>
        <i-button class="save-btn"
                  type="primary"
                  size="large"
                  @click="saveInfo">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal } from 'iview'
export default {
  name: 'ResourceRecommend',
  props: {
    resourceMode: {
      type: String,
      default: '100'
    },
    isShowed: {
      type: Boolean,
      default: false
    },
    subtitle: {
      type: String
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  data () {
    return {
      tipShow: false,
      subtitleVal: ''
    }
  },
  methods: {
    changeHandler (isShowed) {
      if (isShowed) {
        this.subtitleVal = this.subtitle
      } else {
        this.tipShow = false
      }
      this.$emit('change-show', isShowed)
    },
    cancelModel () {
      this.$emit('change-show', false) // 关闭弹窗
    },
    saveInfo () {
      if (!this.subtitleVal) {
        this.tipShow = true
      } else {
        this.tipShow = false
        this.$emit('change-show', false) // 关闭弹窗
        this.$emit('save-edit', this.subtitleVal) // 返回保存数据
      }
    }
  },
  components: {
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.resource-recommend
  .tip
    margin-top: 20px
    font-size: 16px
    color: $red
</style>
