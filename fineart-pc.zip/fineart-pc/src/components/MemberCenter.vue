<template lang="html">
  <Page>
    This is page Member Center.
  </Page>
</template>

<script>
import Page from './Page.vue'

export default {
  data () {
    return {}
  },
  components: {
    Page
  }
}
</script>

<style lang="stylus" scoped>
</style>
