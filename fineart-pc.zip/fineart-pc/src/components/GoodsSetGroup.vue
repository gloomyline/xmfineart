<template>
  <i-modal title="设置商品标签"
           class="set-goods-group"
           width="595"
           :value="isTagEdit"
           @on-visible-change="changeHandler">
    <ul class="set-goods-wrap">
      <li class="choice-goods-item"
          v-for="(item, index) in tags"
          :key="index">
        <span>{{ item.name }}</span>
        <i class="fy-icon-add-orange" @click="del(item)"></i>
      </li>
    </ul>
    <div class="filter-keyword">
      <i-input placeholder="输入标签内容" v-model="inputValue">
        <i-button slot="append"
                  class="search-btn"
                  type="primary"
                  @click="input(inputValue)">添加</i-button>
      </i-input>
    </div>
    <ul class="set-goods-wrap">
      <li class="set-goods-item"
          v-for="(item, index) in storeTagsNotUsed"
          :key="index"
          v-show="!hasUsed(item.name)"
          @click="add(item)">{{ item.name }}</li>
    </ul>
  </i-modal>
</template>

<script>
import { Input, Modal } from 'iview'
import api from 'modules/member/api/index.js'

export default {
  name: 'GoodsSetGroup',
  data () {
    return {
      storeTagsAll: [],
      storeTagsNotUsed: [],
      inputValue: ''
    }
  },
  props: {
    goodsId: {
      type: String,
      require: true
    },
    goodsTagsAll: {
      type: Object,
      require: true
    },
    isTagEdit: {
      type: Boolean,
      require: false
    }
  },
  model: {
    prop: 'isTagEdit',
    event: 'change-show'
  },
  computed: {
    tags () {
      let goodsTag = this.turnToArray(this.goodsTagsAll)
      return goodsTag
    }
  },
  created () {
    this.init()
  },
  methods: {
    turnToArray (obj) {
      let arr = []
      for (let key in obj) {
        arr.push({
          id: key,
          name: obj[key]
        })
      }
      return arr
    },
    async init () {
      if (this.storeTagsAll.length === 0) {
        const storeTag = await api.goodsTagList('', true)
        this.storeTagsAll = this.turnToArray(storeTag)
      }
      this.storeTagsNotUsed = this.storeTagsAll
    },
    hasUsed (val) {
      for (let key in this.tags) {
        if (this.tags[key] === val) {
          return true
        }
      }
    },
    changeHandler (isTagEdit) {
      this.$emit('change-show', isTagEdit)
    },
    // 删除
    async del (item) {
      let res = await api.goodsTagDel(item.id)
      if (res.code === 200) {
        this.tags.splice(this.tags.indexOf(item), 1)
        if (this.storeTagsNotUsed.indexOf(item) === -1) {
          this.storeTagsNotUsed.push(item)
        }
      }
    },
    // 输入新标签
    async input (val) {
      let res = await api.goodsTagAdd(this.goodsId, val)
      if (res.code === 200) {
        let obj = {
          id: res.results.id,
          name: res.results.tag
        }
        this.tags.push(obj)
        if (this.storeTagsAll.indexOf(obj) === -1) {
          this.storeTagsAll.push(obj)
          this.storeTagsNotUsed.splice(this.storeTagsNotUsed.indexOf(obj), 1)
        }
        this.inputValue = ''
      }
    },
    // 点击标签添加
    async add (item) {
      let res = await api.goodsTagAdd(this.goodsId, item.name)
      if (res.code === 200) {
        this.tags.push({
          id: res.results.id,
          name: res.results.tag
        })
        this.storeTagsNotUsed.splice(this.storeTagsNotUsed.indexOf(item), 1)
      }
    }
  },
  components: {
    'i-input': Input,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.set-goods-group
  .filter-keyword
    height: 50px
    margin-bottom: 30px
    .ivu-input-wrapper
      width: 530px
      .ivu-input
        font-size: 16px
        border-color: $orange
      .ivu-input-group-append
        border: 1px solid $orange
        background-color: $orange
        border-radius:0px 4px 4px 0px
      .search-btn
        width: 112px
        font-size: 16px
        color: $white
  .set-goods-wrap
    display: flex
    flex-flow: wrap
    margin-bottom: 20px
    .set-goods-item
      height: 36px
      padding: 0 20px
      margin: 0 20px 10px 0
      font-size: 14px
      color: $grey-high
      line-height: 36px
      background-color: $grey-high2
      border-radius: 4px
      cursor: pointer
    .choice-goods-item
      display: flex
      justify-content: space-between
      align-items: center
      min-width: 96px
      height: 36px
      margin: 0 20px 10px 0
      padding: 0 12px 0 20px
      border: 1px solid $orange
      color: $orange
      font-size: 16px
      line-height: 36px
      background-color: $orange2
      border-radius: 4px
      cursor: pointer
      &>.fy-icon-add-orange
        font-size: 16px
        cursor: pointer
        transform: rotate(45deg)
</style>
