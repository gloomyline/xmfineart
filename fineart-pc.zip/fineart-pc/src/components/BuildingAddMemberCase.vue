<template>
  <i-form class="add-case-form"
          ref="recordModel"
          :model="recordModel"
          :rules="recordRule">
    <i-form-item label="选择主页" prop="resource_id">
      <i-select class="choice-home"
                v-model="recordModel.resource_id"
                placeholder="请选择您的主页">
        <i-option v-for="(item, index) in serviceHomeList"
                  :key="index"
                  :value="item.id">{{ item.mode_name }}</i-option>
      </i-select>
    </i-form-item>
    <i-form-item label="服务类型" prop="service_type">
      <i-input class="service-type"
               v-model="recordModel.service_type"
               placeholder="请输入您的服务类型，如建筑设计"></i-input>
    </i-form-item>
    <i-form-item class="service-time" label="服务时间" prop="start_date">
      <i-form-item prop="start_date">
        <i-date-picker type="month"
                       v-model="recordModel.start_date"
                       @on-change="handleChangeStartAt(recordModel.start_date)" :options="startDateOption"></i-date-picker>
      </i-form-item>
      <span class="divided-word">至</span>
      <i-form-item prop="end_date">
        <i-date-picker type="month"
                       v-model="recordModel.end_date"
                       @on-change="handleChangeEndAt(recordModel.end_date)" :options="endDateOption"></i-date-picker>
      </i-form-item>
    </i-form-item>
    <i-form-item class="edit-cell" label="服务详情" prop="content">
      <fineart-editor :catch-data="catchEditor"></fineart-editor>
    </i-form-item>
    <i-form-item class="toolbox" >
      <i-button class="cancel-btn"
                @click="close()"
                type="text">取消</i-button>
      <i-button class="save-btn"
                type="primary"
                @click="handleSubmit('recordModel')">保存</i-button>
    </i-form-item>
  </i-form>
</template>

<script>
import { Form, FormItem, Select, Option, DatePicker, Input } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resource/api'
import buildingApi from 'modules/building/api'
import FineartEditor from './FineartEditor.vue'

export default {
  data () {
    return {
      recordModel: {
        resource_id: '', // 主页资源ID
        service_type: '', // <string>必须，服务类型
        content: '', // <string>必须，服务内容
        building_code: '', // 建筑code
        start_date: '',
        end_date: '',
        start_at: '', // <string>必须，开始时间
        end_at: ''// <string>必须，结束时间
      },
      recordRule: {
        resource_id: [
          { required: true, message: '请选择主页' }
        ],
        service_type: [
          { required: true, message: '请填写服务类型' }
        ],
        content: [
          { required: true, message: '请填写服务内容' }
        ]
      },
      serviceHomeList: []
    }
  },
  props: {
    buildingCode: {
      type: String
    },
    isShowed: {
      type: Boolean
    }
  },
  created () {
    this.recordModel.building_code = this.buildingCode
    this.initServiceHomeList()
  },
  methods: {
    // 获取富文本编辑框的数据
    catchEditor (html) {
      this.recordModel.content = html
    },
    close () {
      // 触发父组件的事件，关闭子组件弹框
      this.$emit('close')
    },
    handleChangeStartAt (date) {
      let dt = new Date(date)
      let month = dt.getMonth() + 1
      this.recordModel.start_at = dt.getFullYear() + '-' + (month >= 10 ? month : `0${month}`)
    },
    handleChangeEndAt (date) {
      let dt = new Date(date)
      let month = dt.getMonth() + 1
      this.recordModel.end_at = dt.getFullYear() + '-' + (month >= 10 ? month : `0${month}`)
    },
    async handleSubmit (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          // 检测会员是否已经添加过相应的资源案例
          let result = await buildingApi.fetchBuildingResourceCaseCount({
            resource_id: this.recordModel.resource_id,
            building_code: this.recordModel.building_code
          })
          if (Number.parseInt(result.count) !== 0) {
            this.$emit('change-resource')
            return false
          }

          // 生成资源案例
          this.result = await api.insertResourceCase(this.recordModel)
          if (this.result.code === 200) {
            this.$store.commit('ADD_MESSAGE', { msg: MSG['BUILDING_ADD_CASE_SUCCESS'], type: 'success' })
            // 触发父组件的change事件，刷新父组件的数据
            this.$emit('change')
          } else {
            this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'error' })
          }
        }
      })
    },
    async initServiceHomeList () {
      let resourceList = await api.fetchServiceHomeList()
      for (let index in resourceList) {
        if (resourceList[index].status === '300') {
          resourceList[index].mode_name = resourceList[index].mode_name + '：' + resourceList[index].name
          this.serviceHomeList.push(resourceList[index])
        }
      }
    }
  },
  computed: {
    startDateOption () {
      let endMonth = this.recordModel.end_date
      return {
        disabledDate (date) {
          if (endMonth) {
            return date && date.valueOf() > endMonth
          }
        }
      }
    },
    endDateOption () {
      let startMonth = this.recordModel.start_date
      return {
        disabledDate (date) {
          return date && date.valueOf() < startMonth
        }
      }
    }
  },
  components: {
    FineartEditor,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-select': Select,
    'i-option': Option,
    'i-date-picker': DatePicker,
    'i-input': Input
  }
}
</script>

<style lang="stylus">
.add-case-form
  padding: 30px
  margin-bottom: 40px
  border: 1px solid $grey-high4
  .ivu-form-item
    display: flex
    align-items: baseline
    .ivu-form-item-label
      padding: 0
      margin-right: 30px
      font-size: 16px
      height: 42px
      line-height: 42px
      color: $black
    .ivu-form-item-content
      .choice-home, .service-type
        width: 470px
      .ivu-date-picker
        width: 208px
      .divided-word
        padding: 0 21px
    &.toolbox
      display: flex
      justify-content: flex-end
      .ivu-btn
        width: 120px
        height: 40px
        font-size: 18px
        &.cancel-btn
          width: 80px
          color: #999
    &:last-child
      margin-bottom: 0
    &.service-time
      .ivu-form-item-content
        display: flex
        .ivu-form-item-content
          padding-left: 0
    &.edit-cell
      .ivu-form-item-content
        width: 1040px
    .ivu-form-item-error-tip
      left: auto
    .ivu-select-dropdown
      z-index: 10002
</style>
