<template>
  <i-modal title="设置标签"
           class="set-resource-tag"
           width="595"
           :value="isShowed"
           @on-ok="handleSubmit"
           @on-visible-change="changeHandler">
    <!-- 选中的标签-->
    <ul class="set-resource-wrap">
      <li class="choice-resource-item"
          v-for="(item, index) in usedTagsData"
          :key="index">
        <span>{{ item.name }}</span>
        <i class="fy-icon-add-orange" @click="deleteTag(item, index)"></i>
      </li>
    </ul>
    <!-- 添加标签，输入框 -->
    <div class="filter-keyword">
      <i-input style="width:400px"
               placeholder="输入标签内容"
               v-model="inputValue"></i-input>
      <i-button class="search-btn"
                type="primary"
                ghost
                @click="inputTag()">添加</i-button>
    </div>
    <!-- 未选中的标签 -->
    <ul class="set-resource-wrap">
      <li class="set-resource-item"
          v-for="(item, index) in notUsedTagsData"
          :key="index"
          @click="setTag(item, index)">{{ item.tag }}</li>
    </ul>
  </i-modal>
</template>

<script>
import * as MSG from '@/assets/data/message.js'
import { deepClone } from '@/common/js/utils'
import { Input, Modal } from 'iview'

export default {
  name: 'ResourceSetTag',
  data () {
    return {
      inputValue: '',
      allTagsData: [], // 资源所有标签列表（用于编辑、渲染）
      usedTagsData: [] // 选中的标签（用于编辑、渲染）
    }
  },
  props: {
    // 资源所有标签列表
    allTags: {
      type: Array,
      default () {
        return []
      }
    },
    // 选中的标签
    usedTags: {
      type: Array,
      default () {
        return []
      }
    },
    isShowed: {
      type: Boolean,
      require: false
    }
  },
  watch: {
    allTags () {
      this.modifyData()
    },
    usedTags () {
      this.usedTagsData = deepClone(this.usedTags)
      this.modifyData()
    }
  },
  computed: {
    // 未使用的标签
    notUsedTagsData () {
      return this.allTagsData.filter(item => item.isUsed === false)
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    // 更新数据
    modifyData () {
      this.allTagsData = []
      for (let item of this.allTags) {
        for (let obj of this.usedTagsData) {
          if (item.id === obj.id) {
            this.allTagsData.push({
              ...item,
              isUsed: true
            })
          }
        }
        if (this.allTagsData.length < this.allTags.indexOf(item) + 1) {
          this.allTagsData.push({
            ...item,
            isUsed: false
          })
        }
      }
    },
    changeHandler (isShowed) {
      this.$emit('change-show', isShowed)
    },
    // 取消选中标签
    deleteTag (item, index) {
      this.usedTagsData.splice(index, 1)
      for (let obj of this.allTagsData) {
        if (obj.id === item.id) {
          obj.isUsed = false
        }
      }
    },
    // 添加标签
    inputTag () {
      this.$emit('add-tag', this.inputValue)
      this.inputValue = ''
    },
    // 选中标签
    setTag (item, index) {
      if (this.usedTagsData.length >= 3) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_TAG_SET_NUMBER_ERROR'], type: 'error'})
        return false
      }
      item.isUsed = true
      this.usedTagsData.push({
        id: item.id,
        name: item.tag
      })
    },
    // 提交修改
    handleSubmit () {
      this.$emit('handle-submit', this.usedTagsData)
    }
  },
  components: {
    'i-input': Input,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.set-resource-tag
  .filter-keyword
    height: 40px
    font-size: 0
    margin-bottom: 30px
    .search-btn
      padding: 0
      width: 120px
      height: 40px
      font-size: 18px
      margin-left: 14px
  .set-resource-wrap
    display: flex
    flex-flow: wrap
    margin-bottom: 20px
    .set-resource-item
      height: 36px
      padding: 0 20px
      margin: 0 20px 10px 0
      font-size: 14px
      color: $black2
      line-height: 36px
      background-color: $grey-high6
      border-radius: 4px
      cursor: pointer
    .choice-resource-item
      display: flex
      justify-content: space-between
      align-items: center
      min-width: 96px
      height: 36px
      margin: 0 20px 10px 0
      padding: 0 12px 0 20px
      border: 1px solid $orange
      color: $orange
      font-size: 16px
      line-height: 36px
      background-color: $orange2
      border-radius: 4px
      cursor: pointer
      &>.fy-icon-add-orange
        font-size: 16px
        cursor: pointer
        transform: rotate(45deg)
</style>
