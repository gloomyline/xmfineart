/*
* @Author: Alan
* @Date:   2018-09-14 13:53:37
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-21 14:29:16
*/
import Page from './Page.vue'
import JumpTop from './JumpTop.vue'
import Pagination from './Pagination.vue'
import FineartHead from './FineartHead.vue'
import FineartFoot from './FineartFoot.vue'
import ListNothing from './ListNothing.vue'
import FineartNumber from './FineartNumber.vue'
import FineartSubtitle from './FineartSubtitle.vue'
import LoginRegisterModal from './LoginRegisterModal.vue'
import FineartCascader from './FineartCascader.vue'
import FineartEditor from './FineartEditor.vue'

import MallHead from './MallHead.vue'
import GoodsCard from './GoodsCard.vue'
import GoodsSetGroup from './GoodsSetGroup'
import MallAddress from './MallAddress.vue'
import MallCarousel from './MallCarousel.vue'

import ResourceDetailInfo from './ResourceDetailInfo.vue'
import ResourceEditInfo from './ResourceEditInfo.vue'
import ResourceIntro from './ResourceIntro.vue'
import ResourceClassify from './ResourceClassify.vue'
import ResourceRecommend from './ResourceRecommend.vue'
import ResourceExperience from './ResourceExperience.vue'
import ResourceCase from './ResourceCase.vue'
import ResourceWorks from './ResourceWorks.vue'
import ResourceSetTag from './ResourceSetTag.vue'
import ResourcePrice from './ResourcePrice.vue'
import FaMap from './FaMap.vue'

import BuildingAddMemberCase from './BuildingAddMemberCase.vue'

export {
  Page,
  FaMap,
  JumpTop,
  MallHead,
  GoodsCard,
  Pagination,
  FineartHead,
  FineartFoot,
  ListNothing,
  MallAddress,
  MallCarousel,
  ResourceIntro,
  FineartNumber,
  FineartEditor,
  ResourceCase,
  ResourcePrice,
  ResourceWorks,
  ResourceSetTag,
  GoodsSetGroup,
  FineartSubtitle,
  FineartCascader,
  ResourceEditInfo,
  ResourceClassify,
  ResourceRecommend,
  LoginRegisterModal,
  ResourceDetailInfo,
  ResourceExperience,
  BuildingAddMemberCase
}
