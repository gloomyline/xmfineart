<template>
  <div ref="editorEle" class="fineart-edit"></div>
</template>

<script>
import Editor from 'wangeditor'
import { API_ADDRESS } from 'assets/data/constants.js'

export default {
  name: 'FineartEditor',
  data () {
    return {
      editorBox: null
    }
  },
  props: ['catchData', 'editorContent'],
  watch: {
    editorContent (newVal) {
      // 有内容时赋值给富文本编辑器
      if (this.editorBox && !this.editorBox.txt.text()) {
        // 有内容时赋值给富文本编辑器
        this.editorBox.txt.html(newVal)
      }
    }
  },
  mounted () {
    this.editorBox = this.editorBox || new Editor(this.$refs.editorEle)
    // 编辑器改变即保存数据
    this.editorBox.customConfig.onchange = (html) => {
      // html => 即编辑器中的内容
      this.catchData(html)
    }
    this.editorBox.customConfig.onchangeTimeout = 800 // 单位 ms
    // 隐藏“网络图片”tab
    this.editorBox.customConfig.showLinkImg = false
    // 上传接口
    this.editorBox.customConfig.uploadImgServer = `${API_ADDRESS}/sys/upload/rich_text_img/image_file`
    // 自定义字段名
    this.editorBox.customConfig.uploadFileName = 'image_file'
    // 最多能上传 10张
    this.editorBox.customConfig.uploadImgMaxLength = 10
    const user = this.$localStorage.getUser()
    const token = user && user.token
    // 自定义请求头配置
    this.editorBox.customConfig.uploadImgHeaders = {
      'auth-token': token
    }
    // 菜单配置
    this.editorBox.customConfig.menus = [
      'head',
      'list', // 列表
      'justify', // 对齐方式
      'bold',
      'fontName',
      'fontSize', // 字号
      'italic',
      'underline',
      'table',
      'image', // 插入图片
      'foreColor', // 文字颜色
      'undo', // 撤销
      'redo' // 重复
    ]
    this.editorBox.customConfig.uploadImgHooks = {
      // 图片上传成功之后插入富文本框
      customInsert: function (insertImg, result) {
        const url = result.data.file_url_cdn
        insertImg(url)
      }
    }
    this.editorBox.create()
    // 赋值给富文本编辑器
    this.editorBox.txt.html(this.editorContent)
  }
}
</script>

<style lang="stylus">
.fineart-edit
  height: 100%
  img
    max-width: 100%
</style>
