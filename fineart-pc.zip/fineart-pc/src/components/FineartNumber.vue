<template lang="html">
  <div class="increase-decrease-number">
    <input-number
      ref="inputNumber"
      :element-id="elementId"
      :max="max"
      :min="min"
      :step="step"
      :disabled="disabled"
      :editable="editable"
      :value="currentCount"
      :active-change="false"
      @on-change="changeHandler"></input-number>
  </div>
</template>

<script>
import { InputNumber } from 'iview'
import { addClass } from 'iview/src/utils/assist.js'

export default {
  name: 'FineartNumber',
  data () {
    return {
      currentCount: 0
    }
  },
  created () {
    this._initData()
  },
  mounted () {
    this._resetIconName()
  },
  model: {
    prop: 'currentCount',
    event: 'number-change'
  },
  props: {
    itemKey: {
      type: Number
    },
    max: {
      type: Number,
      default: Infinity
    },
    min: {
      type: Number,
      default: 1
    },
    step: {
      type: Number,
      default: 1
    },
    count: {
      type: Number,
      default: 0
    },
    disabled: {
      type: Boolean,
      default: false
    },
    editable: {
      type: Boolean,
      default: true
    },
    elementId: {
      type: String
    }
  },
  methods: {
    _initData () {
      this.currentCount = this.count
    },
    _resetIconName () {
      const inputNumberELe = this.$refs.inputNumber.$el
      const decreaseIconEle = inputNumberELe.querySelector('.ivu-input-number-handler-down-inner')
      const increaseIconELe = inputNumberELe.querySelector('.ivu-input-number-handler-up-inner')
      decreaseIconEle.className = ''
      addClass(decreaseIconEle, 'fy-icon-reduce')
      increaseIconELe.className = ''
      addClass(increaseIconELe, 'fy-icon-add-thick-gray')
    },
    changeHandler (curVal) {
      curVal = Number.parseInt(curVal)
      if (this.editable && Number.isNaN(curVal)) { // 当在可编辑数量的情况下，输入框中为空的情况，置为最小值
        curVal = this.currentCount = this.min
      }
      this.$emit('number-change', curVal, this.itemKey)
    }
  },
  components: {
    InputNumber
  }
}
</script>

<style lang="stylus">
.increase-decrease-number
  display: inline-block
  .ivu-input-number
    width: 126px
    height: 36px
    border-radius: 0
    border-left: 0
    border-right: 0
    border-color: $grey-high1
    &.ivu-input-number-focused
      border-color: $grey-high1
    &.ivu-input-number-disabled
      background-color: $white
      opacity: 0.7
      .ivu-input-number-handler-wrap
        display: block
    &:hover
      border-color: $grey-high1
      box-shadow: none
    .ivu-input-number-handler-wrap
      absolute: left top
      width: 100%
      height: 100%
      opacity: 1
      border: 0
      pointer-events: none /* 虚化，让其下方可点击 */
      background-color: transparent
      .ivu-input-number-handler
        absolute: top
        width: 39px
        height: 100%
        border-left: 1px solid $grey-high1
        border-right: 1px solid $grey-high1
        pointer-events: all
        &.ivu-input-number-handler-down
          left: 0
          padding-top: 8px
          font-size: 16px
          border-top: 0
          &:hover
            color: $orange
        &.ivu-input-number-handler-up
          padding-top: 10px
          right: 0
          font-size: 16px
          &:hover
            color: $orange
    .ivu-input-number-input-wrap
      height: 100%
      .ivu-input-number-input
        height: 100%
        line-height: 34px
        text-align: center
        font-size: 18px
        color: $black1
        &[disabled]
          background-color: transparent
</style>
