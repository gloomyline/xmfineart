<template>
  <div class="resource-info">
    <div class="info-head">
      <div class="resource-logo">
        <img :src="resourceDetail.logo_cdn"/>
        <!-- 编辑头像 -->
        <i-upload ref="upload"
                  v-if="isMaster"
                  :show-upload-list="false"
                  :max-size="ossThumbnail.max_size"
                  type="select"
                  :data="ossThumbnail.data"
                  :action="ossThumbnail.host"
                  :format="ossThumbnail.format"
                  :accept="ossThumbnail.accept"
                  :on-exceeded-size="exceededSize"
                  :on-format-error="formatError"
                  :before-upload="beforeUploadThumb"
                  :on-success="successThumb">
          <div class="edit-img">
            <span class="fy-icon-upload"></span>
          </div>
        </i-upload>
      </div>
      <div class="resource-name">
        <div class="resource-name-wrap">
          <span :class="{'resource-name-text': isMaster}">{{ resourceDetail.name }}</span>
          <!-- 性别 -->
          <span class="resource-gender" v-if="resourceMode == 100">
            <span class="fy-icon-male-round" v-if="resourceDetail.gender == '200'"><span class="path1"></span><span class="path2"></span></span>
            <span class="fy-icon-female-round" v-if="resourceDetail.gender == '300'"><span class="path1"></span><span class="path2"></span></span>
          </span>
        </div>
        <div class="edit-box" v-if="isMaster">
          <i-button type="text" @click="showModal('name')"><i class="fy-icon-edit"></i>编辑</i-button>
        </div>
      </div>
      <div class="resource-subtitle">
        <div class="resource-subtitle-text">{{ resourceDetail.subtitle }}</div>
        <div class="edit-box" v-if="isMaster">
          <i-button type="text" @click="showModal('subtitle')"><i class="fy-icon-edit"></i>编辑</i-button>
        </div>
      </div>
      <div class="button-box">
        <i-button class="focus-btn"
                  :class="{ 'is-focus': resourceDetail.collection_status }"
                  @click="changeIsCollect(resourceDetail.id)"
                  v-if="!resourceDetail.is_master">
          <span v-if="!resourceDetail.collection_status"><span class="fy-icon-nor-follow"></span>关注TA</span>
          <span v-else><span class="fy-icon-sel-follow"></span>已关注</span>
        </i-button>
        <i-button v-if="isSelf && !isMaster" @click="changeEditStatus()"><span class="fy-icon-fill"></span>编辑资料</i-button>
        <i-button v-if="isSelf && isMaster" @click="changeEditStatus()"><span class="fy-icon-see"></span>查看主页</i-button>
      </div>
    </div>
    <div class="info-body">
      <!-- 简介 -->
      <div class="info-item">
        <div class="info-item-name">
          <span>{{ mode }}</span>
          <div class="edit-box" v-if="isMaster">
            <i-button type="text" @click="showModal('resource_intro')"><i class="fy-icon-edit"></i>编辑</i-button>
          </div>
        </div>
        <div class="info-item-content introduction-content" v-html="resourceDetail.introduction"></div>
      </div>
      <!-- 标签 -->
      <div class="info-item">
        <div class="info-item-name">
          <em>标签</em>
          <div class="edit-box" v-if="isMaster">
            <i-button type="text" @click="showModal('tag')"><i class="fy-icon-edit"></i>编辑</i-button>
          </div>
        </div>
        <div class="info-item-content tags">
          <span class="tag-item"
                v-for="(item, index) in resourceDetail.tags"
                :key="index">{{ item.name }}</span>
          <span v-if="!resourceDetail.tags || !resourceDetail.tags.length > 0">无</span>
        </div>
      </div>
      <!-- 收费标准、 地区、 资源类型、 分类 -->
      <div class="info-item">
        <div class="info-item-name" v-if="resourceDetail.hasOwnProperty('design_price')">
          <em>收费标准</em>
          <div class="edit-box" v-if="isMaster">
            <i-button type="text" @click="showModal('price')"><i class="fy-icon-edit"></i>编辑</i-button>
          </div>
        </div>
        <div class="info-item-content" v-if="resourceDetail.hasOwnProperty('design_price')">{{ resourceDetail.design_price_desc || '—'}}</div>
        <div class="info-item-name">
          <em>地区</em>
          <div class="edit-box" v-if="isMaster">
            <i-button type="text" @click="showModal('address')"><i class="fy-icon-edit"></i>编辑</i-button>
          </div>
        </div>
        <div class="info-item-content">
          <span v-for="(item, index) in resourceDetail.area_line" :key="index">{{item}}</span>
        </div>
        <div class="info-item-name">类型</div>
        <div class="info-item-content">{{ resourceDetail.mode_desc }}</div>
        <div class="info-item-name">
          <em>分类</em>
          <div class="edit-box" v-if="isMaster">
            <i-button type="text" @click="showModal('category')"><i class="fy-icon-edit"></i>编辑</i-button>
          </div>
        </div>
        <div class="info-item-content">
          <span v-for="(item, index) in resourceDetail.category_line"
                :key="index">{{item}}<i class="fy-icon-arrow"></i> </span>
        </div>
      </div>
      <!-- 工作经历 -->
      <div class="info-item" v-if="resourceMode === '100'">
        <div class="info-item-name">
          <em>工作经历</em>
          <div class="edit-box" v-if="isMaster">
            <i-button type="text"
                      @click="showModal('experience')"><i class="fy-icon-add-round-orange"></i>添加</i-button>
          </div>
        </div>
        <div class="info-item-content" v-if="experience">
          <div class="" v-for="( item, index ) in experience" :key="index">
            <div class="sub-name">
              <span>{{ item.company }}</span>
              <div class="edit-box" v-if="isMaster">
                <i-button type="text" @click="editExperience(index)"><i class="fy-icon-edit"></i>编辑</i-button>
              </div>
            </div>
            <div class="sub-content">
              <span>{{ item.job }}</span>
              <span>{{ item.start_date | dateFix }}-{{ item.end_date | dateFix }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Upload } from 'iview'
import api from 'modules/resource/api'
import memberApi from 'modules/member/api/index.js'
import { COLLECT_MESSAGE_DURATION } from 'assets/data/constants.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'ResourceDetailInfo',
  data () {
    return {
      ossThumbnail: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      apiProcessing: false, // API请求处理中
      isMaster: false // 是否是编辑状态
    }
  },
  props: {
    mode: {
      type: String,
      default: '个人简介'
    },
    resourceId: {
      type: String
    },
    isSelf: { // 是否是本人登录
      type: Boolean,
      default: false
    },
    resourceDetail: { // 资源信息
      type: Object,
      require: true
    },
    experience: {
      type: Array
    },
    resourceMode: { // 是否是个人主页
      type: String,
      require: true
    }
  },
  computed: {
    // 实时获取登录状态
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  filters: {
    dateFix: (val) => {
      return val.substring(0, 7).replace('-', '.')
    }
  },
  methods: {
    showModal (modalName) {
      this.$emit('toggle-modal', modalName)
    },
    editExperience (index) {
      this.$emit('edit-index-experience', index)
    },
    changeEditStatus () {
      this.isMaster = !this.isMaster
      this.$emit('change-edit', this.isMaster)
    },
    async changeIsCollect (id) {
      if (!this.isLogin) {
        this.$store.commit('SHOW_LOGIN_MODAL')
        return false
      }

      if (this.apiProcessing) {
        return false
      }

      this.apiProcessing = true
      this.result = await memberApi.handleResourceCollect({ object_type: 100, object_id: this.resourceId })
      if (this.result.code === 200) {
        this.resourceDetail.collection_status = !this.resourceDetail.collection_status
        // 提示关注成功或取消关注成功
        if (this.resourceDetail.collection_status) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await memberApi.ossParamsCreate(file, 'resource_logo', this.ossThumbnail)
    },
    async successThumb (res) {
      if (res.code === 200) {
        this.resourceDetail.logo = res.results.file_url
        this.resourceDetail.logo_cdn = res.results.file_url_cdn
        let params = {
          resource_id: this.resourceDetail.id,
          resource_mode: this.resourceDetail.mode,
          logo: this.resourceDetail.logo
        }
        this.result = await api.resourceLogoUpload(params)
        if (this.result.code === 200) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_LOGO_UPLOAD_SUCCESS'], type: 'success' })
        }
      }
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    }
  },
  components: {
    'i-upload': Upload
  }
}
</script>

<style lang="stylus">
.resource-info
  .edit-box .ivu-btn
    height: 28px
  .info-head
    text-align center
    margin: 30px 0
    .resource-logo
      position: relative
      width: 120px
      height: 120px
      margin: 10px auto
      border-radius: 50%
      &>img
        width: 100%
        height: 100%
        border-radius: 50%
        box-shadow: 1px 3px 12px rgba(0,0,0,0.12)
      .edit-img
        absolute: left top
        display: flex
        justify-content: center
        align-items: center
        width: 100%
        height: 100%
        cursor: pointer
        background-color: rgba(51, 51, 51, 0.8)
        border-radius: 50%
        &>span.fy-icon-upload
          font-size: 40px
          margin: 0
    .resource-name
      font-size: 18px
      min-height: 28px
      text-align: center
      font-weight: 500
      color: $orange
      margin: 10px 0
      .resource-name-wrap
        display: flex
        flex-wrap: wrap
        padding: 0 70px
        justify-content: center
        align-items: center
      .resource-name-text
        max-width: 250px
        display: inline-block
      .resource-gender
        font-size: 0
        margin-left: 10px
    .resource-subtitle
      text-align: left
      min-height: 32px
      margin: 16px 0
      font-size: 16px
      color: $black1
      .resource-subtitle-text
        text-align: center
        display: inline-block
        width: 280px
        padding-left: 70px
        height: 28px
        line-height: 28px
  .button-box
    padding-top: 16px
    .ivu-btn
      width: 120px
      height: 40px
      color: $black1
      font-size: 16px
      margin: 0 10px
    .focus-btn
      &.is-focus
        color: $orange
        background: #FDF2DA
        border: 1px solid $orange
  .info-item
    padding: 20px 0
    .info-item-name
      margin-bottom: 12px
      font-size: 16px
      color: $black
      &>span, &>em
        height: 28px
        line-height: 28px
        display: inline-block
    .info-item-content
      font-size: 14px
      line-height: 28px
      min-height: 28px
      color: $black1
      padding-bottom: 20px
      &>span:last-child .fy-icon-arrow
        display: none
      .fy-icon-arrow
        display: inline-block
        font-size: 12px
        vertical-align: middle
      .sub-name
        &>span
          line-height: 32px
      .sub-content
        color: $grey-high
        display: flex
        padding-bottom: 10px
        justify-content: space-between
      &.introduction-content
        min-height: 196px
        word-wrap: break-word
      &.tags
        padding-bottom: 0
        .tag-item
          color: $black2
          font-size: 12px
          line-height: 22px
          padding: 0 6px
          margin-right: 10px
          border-radius: 4px
          display: inline-block
          background: $grey-high7
</style>
