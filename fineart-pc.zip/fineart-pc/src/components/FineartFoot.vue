<template lang="html">
  <div class="fineart-foot">
    <div class="fineart-foot-container">
      <ul class="nav">
        <li class="nav-item" v-for="(link, index) in links" :key="index"><a class="nav-link" :href="link.route">{{ link.label }}</a></li>
      </ul>
      <p class="copyright">@ 2018 Fine Art. All Rights Reserved. 闽ICP备15003414号</p>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {}
  },
  props: {
    links: {
      type: Array,
      default () {
        return [
          {
            label: '关于我们',
            route: 'index.html#/about-us'
          },
          {
            label: '常见问题',
            route: 'index.html#/common-faq'
          },
          {
            label: '平台公告',
            route: 'index.html#/notice-list'
          },
          {
            label: '联系我们',
            route: 'index.html#/contact-us'
          }
        ]
      }
    }
  }
}
</script>

<style lang="stylus" scoped>
.fineart-foot
  absolute: left bottom
  width: 100%
  height: 60px
  z-index: 2 /* avoid to display on the top of memeber pull down list */
  background-color: $white
  &:before
    content: ''
    absolute: left top
    width: 100%
    height: 1px
    background-color: $grey
  .fineart-foot-container
    display: flex
    justify-content: space-between
    width: 1200px
    margin: 0 auto
    color: $grey-high
    .nav
      height: 100%
      font-size: 0
      .nav-item
        display: inline-block
        vertical-align: top
        width: 94px
        .nav-link
          display: block
          width: 100%
          line-height: 60px
          text-align: center
          font-size: 14px
          color: $grey-high
    .copyright
      line-height: 60px
      font-size: 14px
</style>
