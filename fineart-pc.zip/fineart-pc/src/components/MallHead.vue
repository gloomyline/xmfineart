<template>
    <div class="mall-head">
      <div class="mall-nav-wrap">
        <!-- 照需求隐藏全部分类 -->
        <!--<div class="mall-classify" @mouseenter="showClassify" @mouseleave="hideClassify">-->
          <!--<div class="classify-btn">-->
            <!--<span class="fy-icon-more"></span>-->
            <!--<p>全部分类</p>-->
          <!--</div>-->
          <!--<transition name="slide-up">-->
            <!--<ul class="mall-classify-list" v-show="classifyOpened">-->
              <!--<li class="classify-item"-->
                  <!--:class="{ 'is-classify' : categoryIndex === item.value }"-->
                  <!--@mouseenter="showCategory(item)"-->
                  <!--@click="goToGoodsList(0, item.value)"-->
                  <!--v-for="(item, index) in classifyList"-->
                  <!--:key="index">{{ item.label }}</li>-->
            <!--</ul>-->
          <!--</transition>-->
          <!--<i-affix :offset-top="80">-->
            <!--<div class="classify-sub-item" v-show="categoryOpened">-->
              <!--<ul class="classify-sub-wrap">-->
                <!--<li class="category-list" v-for="(item, index) in isCategory" :key="index">-->
                  <!--<p class="category-name" @click="goToGoodsList(1, item.value)">-->
                    <!--<span>{{ item.label }}</span>-->
                    <!--<span v-if="item.children" class="fy-icon-arrow-thick"></span>-->
                  <!--</p>-->
                  <!--<ul class="category-item">-->
                    <!--<li class="category" v-for="(category, index) in item.children"-->
                        <!--:key="index"-->
                        <!--@click="goToGoodsList(2, item.value, category.value)">{{ category.label }}</li>-->
                  <!--</ul>-->
                <!--</li>-->
              <!--</ul>-->
            <!--</div>-->
          <!--</i-affix>-->
        <!--</div>-->
        <router-link class="mall-nav" :class="{ 'is-mall-nav': Number.parseInt(activeNav) === index }" v-for="(item, index) in navLink" :to="item.route" :key="index">{{ item.label }}</router-link>
        <div class="shopping-card" @click="goToCart">
          <i-badge :count="cartGoodsCount" type="primary" :show-zero="false">
            <span class="fy-icon-shop"></span>
          </i-badge>
        </div>
      </div>
    </div>
</template>

<script>
import { Affix, Badge } from 'iview'
import { getGoodsCategory } from '@/common/js/loadScript.js'
import { mapState, mapGetters, mapActions } from 'vuex'

export default {
  data () {
    return {
      classifyOpened: false,
      categoryOpened: false,
      categoryIndex: '',
      classifyList: [],
      isCategory: [],
      category: []
    }
  },
  created () {
    // 用户未登录，不获取购物车中商品数量
    if (!this.isLogin) return
    this.fetchCartGoodsCount()
  },
  computed: {
    ...mapState(['isLogin']),
    ...mapGetters('mall', ['cartGoodsCount'])
  },
  watch: {
    isLogin (newVal) {
      if (newVal) {
        this.fetchCartGoodsCount()
      }
    }
  },
  props: {
    dataArr: {
      type: Array,
      default () {
        return []
      }
    },
    activeNav: {
      type: Number
    },
    navLink: {
      type: Array,
      default () {
        return [
          {
            label: '商城首页',
            route: '/'
          },
          {
            label: '商品/服务',
            route: '/goods-list'
          },
          {
            label: '新品预告',
            route: '/fore-show'
          },
          {
            label: '同城建材',
            route: '/store'
          }
        ]
      }
    }
  },
  methods: {
    ...mapActions('mall', ['fetchCartGoodsCount']),
    async initCategory () {
      if (this.dataArr.length === 0) {
        this.classifyList = await getGoodsCategory()
      } else {
        this.classifyList = this.dataArr
      }
    },
    showClassify () {
      this.initCategory()
      this.classifyOpened = true
    },
    hideClassify () {
      this.categoryIndex = ''
      this.classifyOpened = false
      this.categoryOpened = false
    },
    showCategory (item) {
      this.category.length = 1
      this.category[0] = item.value
      this.categoryIndex = item.value
      this.categoryOpened = true
      this.isCategory = item.children
    },
    goToGoodsList (index, id, item) {
      if (index === 1) {
        this.category.length = 2
        this.category[1] = id
      }
      if (index === 2) {
        this.category[1] = id
        this.category[2] = item
      }
      this.$store.commit('mall/MALL_SAVE_CATEGORY', this.category)
      this.$router.push({ path: '/goods-list' })
    },
    goToCart () { // 判断用户是否登录，未登录显示登录弹窗
      if (this.isLogin) {
        this.$router.push({path: '/mall-cart'})
      } else {
        this.$store.commit('SHOW_LOGIN_MODAL')
      }
    }
  },
  components: {
    'i-affix': Affix,
    'i-badge': Badge
  }
}
</script>

<style lang="stylus" scoped>
.mall-head
  position: relative
  width: 100%
  height: 60px
  background-color: $white
  z-index: 12
  &:after
    content: ''
    absolute: left bottom -1px
    width: 100%
    height: 1px
    background-color: $grey
  .mall-nav-wrap
    position: relative
    display: flex
    width: 1200px
    margin: 0 auto
    .mall-classify
      position: relative
      width: 152px
      height: 60px
      background-color: $orange
      .classify-btn
        display: flex
        justify-content: center
        align-items: center
        font-size: 16px
        color: $white
        line-height: 60px
        cursor: pointer
        span
          color: $white
          margin-right: 12px
      .mall-classify-list
        absolute: left top 100%
        width: 152px
        height: 334px
        padding-bottom: 12px
        background-color: $orange
        box-shadow: 0 2px 9px 0 rgba(0, 0, 0, 0.2)
        z-index: 11
        .classify-item
          height: 46px
          padding-left: 20px
          line-height: 46px
          cursor: pointer
          color: $white
          font-size: 14px
          &.is-classify
            color: $orange
            background-color: $white
      .classify-sub-item
        absolute: left 100% top 100%
        width: 736px
        height: 334px
        padding: 14px 20px
        background-color: $white
        box-shadow: 0 4px 16px 0 rgba(0, 0, 0, 0.06)
        z-index: 11
        .classify-sub-wrap
          width: 100%
          height: 100%
          overflow-y: auto
          .category-list
            display: flex
            margin-bottom: 18px
            .category-name
              display: flex
              justify-content: space-between
              align-items: center
              width: 130px
              height: 20px
              font-size: 14px
              color: $black1
              line-height: 20px
              cursor: pointer
              &:hover
                color: $orange
            .category-item
              display: flex
              flex-wrap: wrap
              overflow: hidden
              width: 636px
              .category
                padding: 0 14px
                margin-left: -1px
                font-size: 14px
                cursor: pointer
                color: $black1
                border-left: 1px solid $grey-high3
                &:hover
                  color: $orange
    .mall-nav
      height: 60px
      text-align: center
      line-height: 60px
      font-size: 16px
      color: $black1
      margin-right: 55px
      &.is-mall-nav, &:hover
        color: $orange
    .shopping-card
      absolute: right 20px top 50%
      width: 28px
      height: 24px
      font-size: 24px
      cursor: pointer
      transform: translateY(-50%)
</style>
