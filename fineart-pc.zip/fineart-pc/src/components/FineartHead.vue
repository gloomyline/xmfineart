<template lang="html">
  <div class="fineart-head">
    <div class="head-container">
      <div class="logo-wrap" @click="GoHome">
        <span class="logo"></span>
      </div>
      <div class="nav-wrap">
        <i-menu class="nav" mode="horizontal" theme="light" :active-name="activeName">
          <i-menu-item name="1"><a class="link" href="index.html">首页</a></i-menu-item>
          <i-menu-item name="2"><a class="link" href="map.html">斐艺地图</a></i-menu-item>
          <i-menu-item name="3"><a class="link" href="mall.html">斐艺购</a></i-menu-item>
          <i-menu-item name="4"><a class="link" href="building.html">斐艺建筑</a></i-menu-item>
          <i-menu-item name="5"><a class="link" href="resource.html">斐艺资源</a></i-menu-item>
        </i-menu>
        <div class="member-link-wrap" @mouseleave="hidePullDown">
          <div class="member-avatar" @mouseenter="showPullDown" ><img v-if="!!avatar_cdn" :src="avatar_cdn" width="36" height="36"><span v-else class="fy-icon-head"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span></div>
          <div class="triangle"></div>
          <transition name="slide-up">
            <drop v-show="pullDownOpened">
              <div class="pull-down-list-wrap">
                <ul class="pull-down-list">
                  <li class="pull-down-item" v-for="(item, index) in pullDownList" :key="index"><a @click="item.handler">{{ item.label }}</a></li>
                </ul>
              </div>
            </drop>
          </transition>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Menu, MenuItem, Dropdown } from 'iview'
import CollapseTransition from 'iview/src/components/base/collapse-transition.js'
import { mapState } from 'vuex'

export default {
  data () {
    return {
      pullDownOpened: false,
      pullDownList: [],
      memberCenter: {
        label: '会员中心',
        handler: this.goToMemberCenter
      },
      signInBtn: {
        label: '登录/注册',
        handler: this.signIn
      },
      signOutBtn: {
        label: '退出登录',
        handler: this.signOut
      },
      avatar_cdn: ''
    }
  },
  created () {
    this._initPullDownList()
    this.avatar_cdn = this.memberInfo.avatar_cdn
  },
  props: {
    activeName: {
      type: String
    }
  },
  computed: {
    isLogin () {
      return this.$store.state.isLogin
    },
    ...mapState('member', ['memberInfo'])
  },
  watch: {
    isLogin () { // watch store 中用户的登录状态，更新下拉菜单内容
      this.updatePullDownList()
    },
    memberInfo: {
      handler (newVal) {
        this.avatar_cdn = newVal.avatar_cdn
      },
      deep: true
    }
  },
  methods: {
    _initPullDownList () {
      const user = this.$localStorage.getUser()
      if (user && user.isLogin) { // 用户已登录
        this.pullDownList = [this.memberCenter, this.signOutBtn]
      } else { // 用户未登录
        this.pullDownList = [this.memberCenter, this.signInBtn]
      }
    },
    updatePullDownList () {
      this._initPullDownList()
    },
    GoHome () {
      window.location = 'index.html'
    },
    showPullDown () {
      this.pullDownOpened = true
    },
    hidePullDown () {
      this.pullDownOpened = false
    },
    goToMemberCenter () {
      const user = this.$localStorage.getUser()
      if (user && user.isLogin) {
        window.location = 'member.html'
      } else {
        this.signIn()
      }
    },
    signIn () {
      this.$store.commit('SHOW_LOGIN_MODAL')
    },
    async signOut () {
      this.$store.dispatch('logout', {})
      this.$localStorage.setUser({ token: null, isLogin: false })
      if (this.$localStorage.get('MEMBER_CUR_STORE')) {
        this.$localStorage.remove('MEMBER_CUR_STORE') // 退出如果有 store 则清空
      }
      this.$store.commit('member/MEMBER_CLEAR_INFO') // 清空会员信息
      this.$store.commit('member/MEMBER_SHOW_LOGIN') // 退出返回首页
    }
  },
  components: {
    'i-menu': Menu,
    'i-menu-item': MenuItem,
    'drop': Dropdown,
    CollapseTransition
  }
}
</script>

<style lang="stylus" scoped>
.fineart-head
  fixed: left top
  width: 100%
  height: 80px
  background-color: $white
  z-index: 3
  &:after
    content: ''
    absolute: left bottom -1px
    width: 100%
    height: 1px
    background-color: $grey
  .head-container
    display: flex
    justify-content: space-between
    align-items: center
    width: 1200px
    height: 100%
    margin: 0 auto
    .logo-wrap
      width: 136px
      height: 35px
      .logo
        display: inline-block
        width: 100%
        height: 100%
        cursor: pointer
        background-image: url('../assets/fineart-logo.png')
        background-size: 100%
        background-repeat: no-repeat
        &:hover
          background-image: url('../assets/fineart-logo-orange.png')
    .nav-wrap
      height: 100%
      .nav
        display: inline-block
        vertical-align: top
        height: 100%
        margin-right: 24px
        background-color: transparent !important
        &:after
          display: none
        .ivu-menu-item
          height: 100%
          line-height: 80px
          background-color: transparent
          padding: 0
          border: none
          border-top: 2px solid transparent
          .link
            display: block
            width: 100%
            padding: 0 30px
            font-size: 16px
            color: $black
          &.ivu-menu-item-selected, &:hover
            border-color: $orange
            .link
              color: $orange
      .member-link-wrap
        position: relative
        display: inline-block
        vertical-align: top
        height: 100%
        padding-top: 18px
        font-size: 0
        .member-avatar
          display: inline-block
          vertical-align: top
          width: 36px
          height: 36px
          cursor: pointer
          margin: 0 24px
          font-size: 36px
          &>img
            border-radius: 50%
        .triangle
          position: relative
          display: inline-block
          vertical-align: top
          margin-top: 22px
          &:after
            content: ''
            absolute: left -8px top
            width: 0
            height: 0
            border-top: 4px solid $black
            border-right: 4px solid transparent
            border-left: 4px solid transparent
        .pull-down-list-wrap
          absolute: left -140px top 54px
          width: 136px
          border-radius: 4px
          box-shadow: 0 2px 9px 0 rgba(0, 0, 0, 0.2)
          z-index: 999
          &:before /* pull down list triangle */
            content: ''
            absolute: top -5px right 32px
            width: 0
            height: 0
            border: 6px solid $white
            transform: rotate(45deg)
            box-shadow: 0 2px 9px 0 rgba(0, 0, 0, 0.2)
            z-index: -1
          .pull-down-list
            list-style: none
            border-radius: 4px 4px
            background-color: $white
            .pull-down-item
              position: relative
              height: 50px
              line-height: 50px
              text-align: center
              font-size: 14px
              a
                display: block
                width: 100%
                height: 100%
                color: $black
                &:hover
                  color: $orange
              &:after
                content: ''
                absolute: left bottom
                width: 100%
                height: 1px
                background-color: $grey
              &:last-child::after
                display: none
</style>
