<template>
  <div class="mall-carouse">
    <ul class="carousel-list">
      <li class="carousel-item"
          v-for="(item, index) in list"
          :class="{'is-choice': isChangeIndex === index}"
          :key="index">
        <img :src="item" alt="">
      </li>
    </ul>
    <ul class="dots-list">
      <li class="dots-item" v-for="(item, index) in list"
          :class="{'is-choice': isChangeIndex === index}"
          @mouseenter="onShow(index)"
          :key="index">
        <img :src="item" alt="">
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'MallCarousel',
  props: {
    list: {
      type: Array
    }
  },
  data () {
    return {
      isChangeIndex: 0
    }
  },
  methods: {
    onShow (index) {
      this.isChangeIndex = index
    }
  }
}
</script>

<style lang="stylus" scoped>
.mall-carouse
  .carousel-list
    position: relative
    width: 750px
    height: 420px
    overflow: hidden
    margin-bottom: 20px
    .carousel-item
      absolute: top left
      width: 100%
      height: 100%
      opacity: 0
      transition: all .2s ease-in-out
      &>img
        display: block
        width: 100%
        height: auto
      &.is-choice
        opacity: 1
  .dots-list
    display: flex
    width: 750px
    .dots-item
      width: 118px
      height: 66px
      margin-right: 14px
      overflow: hidden
      cursor: pointer
      &>img
        display: block
        width: 100%
        height: auto
      &.is-choice
        box-shadow: 0 0 3px 2px $orange
</style>
