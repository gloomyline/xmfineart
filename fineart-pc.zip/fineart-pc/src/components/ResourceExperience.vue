<template>
  <!--个人工作经历-->
  <i-modal class="resource-experience"
           width="595"
           :title="title"
           :value="isShowed"
           @on-visible-change="changeHandler">
    <i-form class="experience-form"
            label-position="left"
            ref="experienceVal"
            :model="experienceVal"
            :rules="experienceRule">
      <i-form-item v-show="false">
        <i-input v-model="experienceVal.id"></i-input>
      </i-form-item>
      <i-form-item label="公司名称" prop="company">
        <i-input placeholder="请填写公司名称" v-model="experienceVal.company"></i-input>
      </i-form-item>
      <i-form-item label="职务" prop="job">
        <i-input placeholder="请填写职务" v-model="experienceVal.job"></i-input>
      </i-form-item>
      <i-form-item class="experience-time" label="在职时间" prop="start_date">
        <i-form-item prop="v_start_date">
          <i-date-picker type="month"
                         style="width: 257px"
                         placement="top"
                         placeholder="请选择开始年月"
                         v-model="experienceVal.v_start_date"
                         @on-change="handleChangeStartAt(experienceVal.v_start_date)"
                         :options="startDateOption"></i-date-picker>
        </i-form-item>
        <i-form-item prop="v_end_date">
          <i-date-picker type="month"
                         placement="top"
                         style="width: 257px"
                         placeholder="请选择结束年月"
                         v-model="experienceVal.v_end_date"
                         @on-change="handleChangeEndAt(experienceVal.v_end_date)"
                         :options="endDateOption"></i-date-picker>
        </i-form-item>
      </i-form-item>
    </i-form>
    <div slot="footer">
      <i-button type="default"
                size="large"
                v-show="Object.keys(this.experience).length" @click="deleteItem(experienceVal.id)">删除本条</i-button>
      <div class="save-btn-group">
        <i-button type="text"
                  class="cancel"
                  @click="cancelModel">取消</i-button>
        <i-button class="save-btn"
                  type="primary"
                  size="large"
                  @click="saveInfo('experienceVal')">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal, DatePicker, Form, FormItem } from 'iview'
import { deepClone } from '@/common/js/utils'

export default {
  name: 'ResourceExperience',
  data () {
    return {
      title: '编辑工作经历',
      experienceVal: {
        id: '',
        company: '',
        job: '',
        start_date: '',
        end_date: '',
        v_start_date: '',
        v_end_date: ''
      },
      experienceRule: {
        company: [
          { required: true, message: '请填写公司名称' }
        ],
        job: [
          { required: true, message: '请填写职务' }
        ],
        v_start_date: [
          { required: true, type: 'date', message: '请选择开始年月' }
        ]
      }
    }
  },
  props: {
    resourceMode: {
      type: String,
      default: '100'
    },
    isShowed: {
      type: Boolean,
      default: false
    },
    experience: {
      type: Object
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  computed: {
    startDateOption () {
      let endMonth = this.experienceVal.v_end_date
      return {
        disabledDate (date) {
          if (endMonth) {
            return date && date.valueOf() > endMonth
          }
        }
      }
    },
    endDateOption () {
      let startMonth = this.experienceVal.v_start_date
      return {
        disabledDate (date) {
          return date && date.valueOf() < startMonth
        }
      }
    }
  },
  methods: {
    changeHandler (isShowed) {
      this.title = '添加工作经历'
      if (isShowed && Object.keys(this.experience).length !== 0) {
        this.title = '编辑工作经历'
        this.experienceVal = deepClone(this.experience)
        this.experienceVal.v_start_date = this.experienceVal.start_date
        this.experienceVal.v_end_date = this.experienceVal.end_date
        this.handleChangeStartAt(new Date(this.experienceVal.start_date))
        if (this.experienceVal.end_date !== '' && this.experienceVal.end_date !== '至今') {
          this.handleChangeEndAt(new Date(this.experienceVal.end_date))
        }
      } else {
        this.experienceVal = {
          id: '',
          company: '',
          job: '',
          start_date: '',
          end_date: '',
          v_start_date: '',
          v_end_date: ''
        }
        this.$refs['experienceVal'].resetFields()
      }
      this.$emit('change-show', isShowed)
    },
    handleChangeStartAt (date) {
      let dt = new Date(date)
      let month = dt.getMonth() + 1
      this.experienceVal.start_date = dt.getFullYear() + '-' + (month >= 10 ? month : `0${month}`)
    },
    handleChangeEndAt (date) {
      let dt = new Date(date)
      let month = dt.getMonth() + 1
      this.experienceVal.end_date = dt.getFullYear() + '-' + (month >= 10 ? month : `0${month}`)
    },
    cancelModel () {
      this.$emit('change-show', false) // 关闭弹窗
    },
    saveInfo (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.$emit('change-show', false) // 关闭弹窗
          this.experienceVal.end_date = this.experienceVal.v_end_date === '' || this.experienceVal.end_date === '至今' ? '' : this.experienceVal.end_date
          this.$emit('save-edit', this.experienceVal) // 返回保存数据
        }
      })
    },
    deleteItem (id) {
      this.$emit('delete-confirm', id) // 返回保存数据
    }
  },
  components: {
    'i-modal': Modal,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-date-picker': DatePicker
  }
}
</script>

<style lang="stylus">
.resource-experience
  .ivu-form-item
    display: flex
    margin-bottom: 26px
    &:last-child
      margin-bottom: 0
    .ivu-form-item-label
      font-size: 14px
    flex-direction: column
    .ivu-form-item-content
      display: flex
      justify-content: space-between
    .ivu-select-dropdown
      position: absolute
    .ivu-date-picker-cells
      margin: 0 10px
</style>
