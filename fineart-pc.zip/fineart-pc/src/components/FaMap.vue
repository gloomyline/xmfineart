<template>
  <i-modal class="fa-map"
           :value="isShowed"
           title="地图定位"
           width="595"
           @on-visible-change="changeHandler">
    <div class="map" id="map-container">高德地图</div>
    <div class="input-box">
      <label class="attribute-text">搜索</label>
      <i-input v-model="keywords" prefix="ios-search"
               placeholder="请填写地址搜索，或点击地图选择"
               @on-keyup="showDrop"></i-input>
      <i-dropdown trigger="custom" :visible="visible">
        <i-dropdown-menu slot="list" v-if="areaInfo.length !== 0">
          <li class="address-list"
              v-for="(item, index) in areaInfo"
              :key="index"
              @click="changeKeyword(item)"><p>{{ item.name }}</p><em>{{ item.district }}</em></li>
        </i-dropdown-menu>
      </i-dropdown>
    </div>
    <fineart-cascader label='地区'
                      width="451"
                      labelColor="#666"
                      :data="areaList"
                      v-model="areaVal"
                      placeholder="请选择地区"
                      @change-name="changeAreaName"></fineart-cascader>
    <div class="input-box">
      <label class="attribute-text">详细地址</label>
      <i-input v-model="mapData.address"
               placeholder="请填写详细地址"></i-input>
    </div>
    <div class="tips">
      <span>提示:</span>
      <div class="tips-content">
        <p>先使用[搜索]或点击地图标记您的位置；</p>
        <p>如[详细地址]有误，可手动修改；</p>
        <p>提供准确的位置，有助于获取更多业务机会，</p>
      </div>
    </div>
    <div slot="footer">
      <div class="save-btn-group">
        <i-button type="text"
                  class="cancel"
                  @click="cancelModel">取消</i-button>
        <i-button class="save-btn"
                  type="primary"
                  size="large"
                  @click="saveInfo">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal, Dropdown, DropdownMenu, Input } from 'iview'
import FineartCascader from './FineartCascader'
import {
  getArea,
  findValue
} from '@/common/js/loadScript.js'
import * as aMap from '@/common/js/amap.js'
import { mapGetters } from 'vuex'
export default {
  name: 'FaMap',
  props: {
    resourceMode: {
      type: String,
      default: '100'
    },
    sysAreaId: {
      type: String
    },
    address: {
      type: String
    },
    lat: '',
    lng: '',
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  data () {
    return {
      visible: false,
      mapData: {},
      areaList: [],
      areaInfo: [],
      areaVal: [],
      keywords: ''
    }
  },
  watch: {
    keywords (newValue) {
      aMap.autoInput(newValue)
    },
    mapAddress: {
      handler (newValue) {
        this.areaInfo = newValue.info // 搜索关键词的推荐地址下拉列表
        this.mapData.address = newValue.addressData.address
        this.$store.commit('MAP_SAVE_DETAIL_ADDRESS', this.mapData.address)
        this.getAreaAddress(newValue.addressData)
      },
      deep: true
    },
    mapData: {
      handler (newValue) {
        this.$store.commit('MAP_SAVE_DETAIL_ADDRESS', newValue.address)
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters(['mapAddress'])
  },
  created () {
    this.init()
  },
  methods: {
    async init () {
      this.areaList = await getArea()
    },
    changeHandler (isShowed) {
      if (isShowed) {
        this.mapData = {
          lng: this.lng,
          lat: this.lat,
          sys_area_id: this.sysAreaId,
          address: this.address
        }
        aMap.mapPlugin('map-container', [this.lng, this.lat])
      } else {
        this.keywords = ''
        aMap.mapDestroy()
      }
      this.$emit('change-show', isShowed)
    },
    cancelModel () {
      this.$emit('change-show', false)
    },
    saveInfo () {
      this.$emit('change-show', false)
      this.$emit('save-edit', this.$store.state.mapAddress) // 返回保存数据
    },
    // 给地区组件赋值--显示相对的省市区
    getAreaAddress (addressData) {
      let areaArr = []
      areaArr = findValue(this.areaList, addressData.district)
      this.areaVal = areaArr
      this.mapData.sys_area_id = this.areaVal[this.areaVal.length - 1]
      // 存入缓存
      this.$store.commit('MAP_SAVE_AREA_ID', this.mapData.sys_area_id)
    },
    // 选中地址
    changeKeyword (item) {
      this.visible = false
      this.keywords = item.name
      if (typeof item !== 'object') return
      aMap.mapGeoLocal([item.location.lng, item.location.lat])
    },
    showDrop () {
      if (this.keywords) {
        this.visible = true
      }
    },
    // 根据选择的地区显示地图对应的点
    changeAreaName (param) {
      param.map((item, index) => {
        param[index] = item.label
      })
      this.$store.commit('MAP_SAVE_PROVINCES', param)
      const area = param.join('')
      aMap.getLocation(area)
    }
  },
  components: {
    FineartCascader,
    'i-input': Input,
    'i-modal': Modal,
    'i-dropdown': Dropdown,
    'i-dropdown-menu': DropdownMenu
  }
}
</script>

<style lang="stylus">
.fa-map
  .map
    width: 100%
    height: 213px
    margin-bottom: 10px
  .ivu-modal-body
    max-height: 520px !important
  .input-box
    display: flex
    font-size: 0
    margin-bottom: 30px
    .attribute-text
      width: 64px
      height: 40px
      margin-right: 20px
      font-size: 16px
      line-height: 40px
      text-align: justify
      /*实现文字两端对齐*/
      &:after
        content: ''
        display: inline-block
        padding-left: 100%
    .ivu-input-wrapper
      width: 451px
  .ivu-dropdown
    display: block
    font-size: 14px
    color: $black1
    .ivu-select-dropdown
      top: 330px !important
      left: 115px !important
      padding: 10px
      .ivu-dropdown-menu
        overflow-y: auto
        height: 300px
  .tips
    display: flex
    color: $grey-high
    font-size: 14px
    &>span
      margin-right: 5px
  .address-list
    width: 415px
    padding: 5px 20px
    cursor: pointer
    &>p
      font-size: 16px
    &>em
      font-size: 14px
      color: $grey-high
</style>
