<template lang="html">
  <div class="pagination" v-if="total > 0">
    <i-page
      :total="total"
      :page-size="pageSize"
      ref="iPage"
      :current="page"
      size="small"
      show-elevator
      @on-change="pageChangeHandler"></i-page>
    <i-button type="text" @click="confirmClickHandler">确定</i-button>
  </div>
</template>
<script>
import { Page, Button } from 'iview'
export default {
  data () {
    return {
    }
  },
  props: {
    total: {
      type: Number,
      default: 0
    },
    page: {
      type: Number,
      default: 1
    },
    pageSize: {
      type: Number,
      default: 12
    }
  },
  methods: {
    pageChangeHandler (page) {
      this.$emit('page-confirm', { page })
    },
    confirmClickHandler () {
      const pageInputEle = this.$refs.iPage.$el.querySelector('input')
      let currentPage = Number.parseInt(pageInputEle.value)
      if (Number.isNaN(currentPage)) {
        pageInputEle.value = '1'
        currentPage = 1
      }
      this.$refs.iPage.changePage(currentPage)
    }
  },
  components: {
    'i-page': Page,
    'i-button': Button
  }
}
</script>

<style lang="stylus">
.pagination
  display: flex
  justify-content: center
  align-items: center
  width: 100%
  margin: 40px 0
  .ivu-page
    font-size: 16px
    &.mini .ivu-page-options-elevator
      height: 26px
      input
        font-size: 16px
        text-align: center
  .ivu-btn
    padding: 0 12px
    font-size: 16px
    &:focus
      box-shadow: none
</style>
