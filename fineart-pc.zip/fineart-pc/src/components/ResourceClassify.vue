<template>
  <!--分类编辑-->
  <i-modal class="classify-wrap"
           width="595"
           title="设置分类"
           :value="isShowed"
           @on-visible-change="changeHandler">
    <div class="classify-choose">
      <fineart-cascader class="classify-cascader"
                        :data="list"
                        width="450"
                        v-model="categoryVal"
                        @change-category="changeClassify"></fineart-cascader>
    </div>
    <div slot="footer">
      <div class="save-btn-group">
        <i-button type="text"
                  class="cancel"
                  @click="cancelModel">取消</i-button>
        <i-button class="save-btn"
                  type="primary"
                  size="large"
                  @click="saveInfo">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal } from 'iview'
import FineartCascader from './FineartCascader'
import {
  find,
  findValue,
  getResourceCategory
} from '@/common/js/loadScript.js'

export default {
  name: 'ResourceClassify',
  props: {
    resourceMode: {
      type: String,
      default: '100'
    },
    isShowed: {
      type: Boolean,
      default: false
    },
    categoryId: {
      type: String
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  data () {
    return {
      list: [],
      category: '',
      categoryVal: []
    }
  },
  created () {
    this.init()
  },
  methods: {
    changeHandler (isShowed) {
      this.categoryVal = findValue(this.list, this.categoryId)
      this.$emit('change-show', isShowed)
    },
    changeClassify (data) {
      this.category = data
    },
    async init () {
      const category = await getResourceCategory()
      this.list = find(category, parseInt(this.resourceMode)).children
    },
    cancelModel () {
      this.$emit('change-show', false)
    },
    saveInfo () {
      this.$emit('change-show', false)
      this.$emit('save-edit', this.category) // 返回保存数据
    }
  },
  components: {
    FineartCascader,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.classify-wrap
  .classify-choose
    overflow: hidden
    .classify-cascader
      margin: 0
</style>
