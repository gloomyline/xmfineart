<template>
  <div class="fineart-cascade">
    <label class="classify-select-label" :style="{ color: `${labelColor}` }">{{ label }}</label>
    <i-cascader :style="{ width: `${width}px` }"
                :data="data"
                :value="category"
                :change-on-select="changeOnSelect"
                :placeholder="placeholder"
                @on-change="handleChange"></i-cascader>
  </div>
</template>

<script>
import { Cascader } from 'iview'
export default {
  name: 'FineartCascader',
  props: {
    width: {
      type: String,
      default: '364'
    },
    labelColor: {
      type: String,
      default: '#333'
    },
    label: {
      type: String,
      default: '分类'
    },
    data: {
      type: Array,
      default () {
        return []
      }
    },
    placeholder: {
      type: String,
      default: '请选择分类'
    },
    category: {
      type: Array,
      default () {
        return []
      }
    },
    changeOnSelect: {
      type: Boolean,
      default: true
    }
  },
  model: {
    prop: 'category',
    event: 'change-array'
  },
  data () {
    return {
    }
  },
  methods: {
    handleChange (value, selectData) {
      const len = value.length - 1
      this.$emit('change-category', value[len]) // 返回最后一个id
      this.$emit('change-name', selectData) // 返回选中的数组
      this.$emit('change-array', value) // 返回id数组
    }
  },
  components: {
    'i-cascader': Cascader
  }
}
</script>

<style lang="stylus">
.fineart-cascade
  display: flex
  margin-bottom: 30px
  .classify-select-label
    width: 64px
    height: 40px
    margin-right: 20px
    font-size: 16px
    color: $black
    line-height: 40px
    text-align: justify
    &:empty
      display: none
    /*实现文字两端对齐*/
    &:after
      content: ''
      display: inline-block
      padding-left: 100%
.ivu-input-wrapper
  font-size: 16px
  .ivu-input
    font-size: 16px
</style>
