<template>
  <div class="nothing">
    <span class="fy-icon-full">
      <span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span><span class="path9"></span><span class="path10"></span><span class="path11"></span><span class="path12"></span>
     </span>
    <p class="nothing-word">空空如也~</p>
  </div>
</template>

<script>
export default {
  name: 'ListNothing',
  data () {
    return {
    }
  }
}
</script>

<style lang="stylus" scoped>
.nothing
  padding-top: 80px
  padding-bottom: 40px
  font-size: 215px
  text-align: center
  line-height: 12px
  .nothing-word
    font-size: 16px
    color: $grey-high
    line-height: 22px
</style>
