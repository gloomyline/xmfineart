<template>
  <Page>
    <section class="page-content page403">
      <div class="text-box">
        <p>403错误<br>被拒绝访问了～</p>
        <router-link :to="{path: '/'}" class="home-button">返回首页</router-link>
      </div>
      <img src="../assets/fineart/403.png">
    </section>
  </Page>
</template>
<script>
import { Page } from 'components'
export default{
  data () {
    return {}
  },
  components: {
    Page
  }
}
</script>

<style lang="stylus">
.page403
  display:flex
  align-items: center
  padding:178px 100px
  justify-content: space-between
  .text-box
    padding-left: 100px
    font-size: 18px
    line-height: 32px
    color: $grey-high
  .home-button
    cursor:pointer
    margin-top:28px
    display: block
    text-align: center
    font-size: 18px
    color: $white
    width:230px
    height:44px
    line-height: 44px
    background: $orange
    border-radius: 4px
    border:1px solid rgba(247,181,44,1)
</style>
