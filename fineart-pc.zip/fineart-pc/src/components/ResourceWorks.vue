<template>
  <i-modal :title="modalTitle"
           width="595"
           class="resource-works"
           :value="isShowed"
           @on-visible-change="changeHandler">
    <label class="attribute-text">{{ subTitleText }}名称</label>
    <div class="attribute-val">
      <i-input :placeholder="`请填写${subTitleText}名称`" v-model="worksVal.title"></i-input>
    </div>
    <label class="attribute-text">{{ subTitleText }}{{ coverTitleText }}</label>
    <div class="attribute-val cover-box">
      <div class="attribute-val achievment-img">
        <div class="uploaded-img" v-if="worksVal.thumbnail_cdn">
          <img :src="worksVal.thumbnail_cdn"/>
          <div class="img-edit-cover">
            <span class="fy-icon-delete-round" @click="goDelThumb()"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
          </div>
        </div>
        <i-upload ref="upload"
                  :show-upload-list="false"
                  :max-size="ossThumbnail.max_size"
                  type="select"
                  :data="ossThumbnail.data"
                  :action="ossThumbnail.host"
                  :format="ossThumbnail.format"
                  :accept="ossThumbnail.accept"
                  :on-exceeded-size="exceededSize"
                  :on-format-error="formatError"
                  :before-upload="beforeUploadThumb"
                  :on-success="successThumb">
          <div class="upload-box" v-if="!worksVal.thumbnail_cdn">
            <span class="fy-icon-upload"></span>
            <em>点击上传</em>
          </div>
        </i-upload>
      </div>
      <div class="cover-upload-tip">
        <p>图片尺寸：最小300*300</p>
        <p>上传正方形图片视觉效果更佳</p>
      </div>
    </div>
    <label class="attribute-text">{{ subTitleText }}图片</label>
    <div class="attribute-val achievment-img">
      <!--上传到服务器的图片-->
      <div class="uploaded-img" v-for="(item, index) in worksVal.image_url_cdn" :key="index">
        <img :src="item">
        <div class="img-edit-cover">
          <span class="fy-icon-delete-round" @click="goDelImage(index)"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
        </div>
      </div>
      <!--上传按键-->
      <i-upload ref="upload"
                v-if="worksVal.image_url_cdn !== undefined && worksVal.image_url_cdn.length < 3"
                :show-upload-list="false"
                :max-size="ossImage.max_size"
                type="drag"
                :data="ossImage.data"
                :action="ossImage.host"
                :format="ossImage.format"
                :accept="ossImage.accept"
                :on-exceeded-size="exceededSize"
                :on-format-error="formatError"
                :before-upload="beforeUploadImage"
                :on-success="successImage">
        <div class="upload-box">
          <span class="fy-icon-add-thin-gray"></span>
          <em>点击上传</em>
        </div>
      </i-upload>
    </div>
    <label class="attribute-text">{{ subTitleText }}介绍</label>
    <div class="attribute-val">
      <i-input type="textarea"
               v-model="worksVal.content"
               :rows="7"></i-input>
    </div>
    <div slot="footer" :class="{'btn-group': !worksVal.id}">
      <i-button type="default" v-show="worksVal.id" size="large" @click="deleteItem">删除本条</i-button>
      <div>
        <i-button type="text" size="large" @click="cancelModel">取消</i-button>
        <i-button type="primary" size="large" @click="saveInfo">保存</i-button>
      </div>
    </div>
  </i-modal>
</template>

<script>
import { Modal, Upload } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resource/api'
import memberApi from 'modules/member/api/index.js'

export default {
  name: 'ResourceWorks',
  props: {
    modalTitle: {
      type: String,
      default: '编辑作品集'
    },
    resourceMode: {
      type: String,
      default: '100'
    },
    isShowed: {
      type: Boolean,
      default: false
    },
    works: {
      type: Object
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  data () {
    return {
      ossThumbnail: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      worksVal: {
        resource_id: '',
        id: '',
        title: '',
        thumbnail: '',
        thumbnail_cdn: '',
        image_url: [],
        image_url_cdn: [],
        content: ''
      }
    }
  },
  computed: {
    subTitleText () {
      switch (this.resourceMode) {
      case '400':
        return '产品'
      case '300':
        return '品牌'
      case '200':
      case '100':
        return '作品'
      }
    },
    coverTitleText () {
      switch (this.resourceMode) {
      case '400':
        return 'logo'
      default:
        return '封面图'
      }
    }
  },
  methods: {
    changeHandler (isShowed) {
      if (isShowed) {
        this.worksVal = this.works
        // 将p及br，替换成换行
        let content = this.works.content.replace(/<br \/>|<br>|<\/p>/g, '\r\n')
        // 去除所有其余html标签
        this.worksVal.content = content.replace(/<\/?[^>]*>/g, '')
      }
      this.$emit('change-show', isShowed)
    },
    cancelModel () {
      this.$emit('change-show', false) // 关闭弹窗
    },
    saveInfo () {
      switch (this.resourceMode) {
      case '400':
        if (this.worksVal.id) {
          // 编辑产品
          this.editResourceProduct()
        } else {
          // 添加产品
          this.addResourceProduct()
        }
        break
      case '300':
        if (this.worksVal.id) {
          // 编辑代理商品
          this.editResourceAgentBrand()
        } else {
          // 添加代理商品
          this.addResourceAgentBrand()
        }
        break
      case '200':
      case '100':
        if (this.worksVal.id) {
          // 编辑作品
          this.editResourceAchievement()
        } else {
          // 添加作品
          this.addResourceAchievement()
        }
        break
      }
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await memberApi.ossParamsCreate(file, 'achievement_thumbnail', this.ossThumbnail)
    },
    successThumb (res) {
      if (res.code === 200) {
        this.worksVal.thumbnail = res.results.file_url
        this.worksVal.thumbnail_cdn = res.results.file_url_cdn
      }
    },
    goDelThumb () {
      this.worksVal.thumbnail = ''
      this.worksVal.thumbnail_cdn = ''
    },
    async beforeUploadImage (file) {
      this.ossImage = await memberApi.ossParamsCreate(file, 'achievement_image', this.ossImage)
    },
    successImage (res) {
      if (res.code === 200) {
        this.worksVal.image_url_cdn.push(res.results.file_url_cdn)
        this.worksVal.image_url.push(res.results.file_url)
      }
    },
    goDelImage (key) {
      this.$delete(this.worksVal.image_url_cdn, key)
      this.$delete(this.worksVal.image_url, key)
    },
    deleteItem () {
      this.$emit('delete-item', this.worksVal.id) // 返回删除数据
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    },
    // 添加资源作品
    async addResourceAchievement () {
      let params = {
        resource_id: this.worksVal.resource_id,
        title: this.worksVal.title,
        introduction: this.worksVal.content,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      this.result = await api.addResourceAchievement(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_ACHIEVEMENT_ADD_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 编辑资源作品
    async editResourceAchievement () {
      let params = {
        achievement_id: this.worksVal.id,
        title: this.worksVal.title,
        introduction: this.worksVal.content,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      this.result = await api.editResourceAchievement(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_ACHIEVEMENT_EDIT_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 添加资源代理品牌
    async addResourceAgentBrand () {
      let params = {
        resource_id: this.worksVal.resource_id,
        title: this.worksVal.title,
        introduction: this.worksVal.content,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      this.result = await api.addResourceAgentBrand(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_AGENT_BRAND_ADD_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 编辑资源代理品牌
    async editResourceAgentBrand () {
      let params = {
        agent_brand_id: this.worksVal.id,
        title: this.worksVal.title,
        introduction: this.worksVal.content,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      this.result = await api.editResourceAgentBrand(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_AGENT_BRAND_EDIT_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 添加资源产品
    async addResourceProduct () {
      let params = {
        resource_id: this.worksVal.resource_id,
        title: this.worksVal.title,
        introduction: this.worksVal.content,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      this.result = await api.addResourceProduct(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_PRODUCT_ADD_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 编辑资源产品
    async editResourceProduct () {
      let params = {
        product_series_id: this.worksVal.id,
        title: this.worksVal.title,
        introduction: this.worksVal.content,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      this.result = await api.editResourceProduct(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_PRODUCT_EDIT_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    }
  },
  components: {
    'i-modal': Modal,
    'i-upload': Upload
  }
}
</script>

<style lang="stylus">
.resource-works
  .attribute-text
    display: block
    font-size: 14px
    color: $black1
    padding: 10px 0
  .attribute-val
    padding-bottom: 8px
    textarea.ivu-input,.ivu-input
      font-size: 16px
    &.achievment-img
      display: flex
      flex-wrap: wrap
      flex-direction: row
      &>div
        margin-right: 13px
      img
        width: 120px
        height: 120px
    &.cover-box
      display:flex
      .cover-img-upload
        position relative
        .cover-img
          absolute top left
          img
            width: 120px
            height: 120px
        &>div
          width: 120px
          height: 120px
          overflow: hidden
        .ivu-upload-drag
          display:none
        &:hover .ivu-upload-drag
          display: block
          background-color: rgba(0,0,0,0.7)
      .cover-upload-tip
        padding: 30px 20px
        line-height: 32px
        font-size: 14px
        color: $grey-high
  .ivu-modal-content .ivu-modal-footer .btn-group
    justify-content: flex-end
  .ivu-btn-default
    color: $orange
    padding-left: 0
</style>
