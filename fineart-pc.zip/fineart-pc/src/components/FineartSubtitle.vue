<template>
    <div class="sub-title" :style="{ backgroundImage: `url(${ titleBg })` }">
      <h3 class="ch-title" >{{ titleCh }}</h3>
      <h5 class="en-title">{{ titleEn }}</h5>
    </div>
</template>

<script>
export default {
  data () {
    return {}
  },
  props: {
    titleBg: {
      type: String
    },
    titleCh: {
      type: String
    },
    titleEn: {
      type: String
    }
  }
}
</script>

<style lang="stylus" scoped>
  .sub-title
    display: flex
    flex-direction: column
    justify-content: center
    align-items: center
    width: 100%
    height: 160px
    background-position: center center
    background-repeat: no-repeat
    background-size: cover
    .ch-title
      font-size: 30px
      color: $white
    .en-title
      font-size: 16px
      color: $white
</style>
