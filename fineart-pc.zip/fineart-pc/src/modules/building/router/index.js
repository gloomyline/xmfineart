import Vue from 'vue'
import Router from 'vue-router'
import Home from 'modules/building/pages/Home.vue'
import BuildingDetail from 'modules/building/pages/BuildingDetail.vue'
import BuildingAdd from 'modules/building/pages/BuildingAdd.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/building-detail/:id',
      name: 'BuildingDetail',
      component: BuildingDetail,
      props: true
    },
    {
      path: '/building-add',
      name: 'BuildingAdd',
      component: BuildingAdd,
      meta: {
        requiresAuth: true
      }
    }
  ]
})
