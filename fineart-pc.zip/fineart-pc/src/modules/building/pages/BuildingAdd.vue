<template lang="html">
  <Page>
    <section class="page-content">
      <i-breadcrumb separator="<span class='fy-icon-arrow-thin'></span>">
        <i-breadcrumb-item>
          <i-button class="index-page-link" type="text"
                    custom-icon="fy-icon-home"
                    @click="goToIndex">首页</i-button>
        </i-breadcrumb-item>
        <i-breadcrumb-item to="/">斐艺建筑</i-breadcrumb-item>
        <i-breadcrumb-item>添加建筑</i-breadcrumb-item>
      </i-breadcrumb>
      <i-form class="building-add-form"
              :label-width="64"
              ref="buildingAddForm"
              :model="buildingAddForm"
              :rules="buildingFormRule">
        <i-form-item class="building-add-item build-name" prop="name" label="建筑名称">
          <i-input v-model="buildingAddForm.name"
                   placeholder="请输入建筑名称"
                   @on-blur="checkBuildingName"></i-input>
          <span class="exist-tip"
                @click="goToBuildingDetail"
                v-show="isExist.id || isExist.name">该建筑已存在，去查看&gt;&gt;</span>
        </i-form-item>
        <!-- 上传封面图 -->
        <i-form-item class="building-add-item" label="封面图">
          <!--展示封面图-->
          <div class="thumbnail-show" v-if="thumbnailPicture.file_url_cdn">
            <img :src="thumbnailPicture.file_url_cdn">
            <div class="img-edit-cover">
                <span class="fy-icon-delete-round"
                      @click.stop="deleteThumbnail()"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
            </div>
          </div>
          <i-upload
            v-show="coverUploadShow"
            class="cover-upload"
            ref="upload"
            :show-upload-list="false"
            :max-size="ossThumbnail.max_size"
            type="drag"
            v-if="!thumbnailPicture.file_url_cdn"
            :data="ossThumbnail.data"
            :action="ossThumbnail.host"
            :format="ossImage.format"
            :accept="ossImage.accept"
            :on-exceeded-size="exceededSize"
            :on-format-error="formatError"
            :before-upload="beforeUploadThumb"
            :on-success="successThumb">
            <div class="cover-upload-text">
              <span class="fy-icon-upload"></span>
              <p>点击上传</p>
            </div>
          </i-upload>
          <p class="upload-tip">图片尺寸：最小300*300px，大小不超过10MB；<br/>上传正方形图片视觉效果更佳</p>
        </i-form-item>
        <i-form-item class="building-add-item img-add" label="建筑图片">
          <div>
            <!--展示图片-->
            <div class="uploaded-img"
                 v-for="(item, index) in buildingImage"
                 :key="index">
              <img :src="item.file_url_cdn">
              <div class="img-edit-cover">
                <span class="fy-icon-delete-round"
                      @click.stop="deleteImg(index)"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
              </div>
            </div>
            <i-upload
              class="building-img-upload"
              ref="upload"
              v-if="buildingImage.length < 9"
              :show-upload-list="false"
              :max-size="ossImage.max_size"
              type="drag"
              :data="ossImage.data"
              :action="ossImage.host"
              :format="ossImage.format"
              :accept="ossImage.accept"
              :on-exceeded-size="exceededSize"
              :on-format-error="formatError"
              :before-upload="beforeUploadImage"
              :on-success="successImage">
              <div class="cover-upload-text">
                <span class="fy-icon-add-thin-gray"></span>
                <p>点击上传</p>
              </div>
            </i-upload>
          </div>
          <div>建议尺寸：750*420px，大小不超过10MB；最多上传9张</div>
        </i-form-item>
        <fineart-cascader label="建筑类型"
                          width="640"
                          :data="categoryList"
                          @change-category="setBuildingCate"></fineart-cascader>
        <i-form-item class="building-add-item" label="建筑设计">
          <i-input v-model="buildingAddForm.design"
                   :maxlength="128"
                   placeholder="请填写建筑设计单位"></i-input>
        </i-form-item>
        <i-form-item class="building-add-item" label="开发商">
          <i-input v-model="buildingAddForm.developer"
                   :maxlength="128"
                   placeholder="请填写开发商或者投资方，如未知请忽略"></i-input>
        </i-form-item>
        <!--地区-->
        <i-form-item class="building-add-item" label="地区">
          <i-input v-model="buildingArea" @on-focus="showFaMap" placeholder="请选择地区"></i-input>
        </i-form-item>
        <i-form-item class="building-add-item" label="详细地址">
          <i-input v-model="buildingAddForm.address"
                   placeholder="请通过选择地区来获取地址，如果不够准确可以自行修改"></i-input>
        </i-form-item>
        <i-form-item class="building-add-item" label="简介">
          <i-input v-model="buildingAddForm.introduction"
                   placeholder="简要介绍该建筑" type="textarea" :rows="5"></i-input>
        </i-form-item>
        <i-form-item class="building-add-item">
          <i-button class="commit-btn" type="primary" @click="saveBuilding">保存</i-button>
        </i-form-item>
      </i-form>
    </section>
    <!-- 编辑地区 -->
    <fa-map v-model="showFaMapModal"
            :lng="buildingAddForm.lng"
            :lat="buildingAddForm.lat"
            :address="buildingAddForm.address"
            :sysAreaId="buildingAddForm.sys_area_id"
            @save-edit="setArea"></fa-map>
  </Page>
</template>

<script>
import { Page, JumpTop, FineartCascader, FaMap } from 'components'
import {
  Breadcrumb,
  BreadcrumbItem,
  Dropdown,
  DropdownMenu,
  Form,
  FormItem,
  Input,
  Upload,
  Select,
  Option
} from 'iview'
import { getBuildingCategory } from '@/common/js/loadScript.js'
import { mapState } from 'vuex'
import * as MSG from 'assets/data/message.js'
import api from 'modules/building/api'
export default {
  name: 'BuildingAdd',
  data () {
    return {
      coverUploadShow: true,
      categoryList: [], // 建筑分类列表
      category: [], // 建筑分类选中的值
      buildingArea: '', // 仅仅用于显示用的省市区
      buildingAddForm: {
        name: '', // 建筑名称 建筑名称，必须
        thumbnail: '', // 建筑封面图，必须
        image_urls: [], // 建筑图片信息，必须，最多添加9张
        design: '', // 设计公司
        developer: '', // 开发商
        building_category_id: '', // 建筑类型
        lng: '', // 经度信息，必须
        lat: '', // 纬度信息，必须
        sys_area_id: '', // 建筑地区 地区ID最后一级
        address: '', // 详细信息
        introduction: '' // 简介
      },
      buildingFormRule: {
        name: [
          {
            required: true,
            message: '请填写建筑名称'
          }, {
            type: 'string',
            min: 4,
            max: 64,
            message: '建筑名称长度限制为4-128个字'
          }
        ],
        thumbnail: [
          {
            required: true,
            message: '请上传建筑封面'
          }
        ],
        image_urls: [
          {
            required: true,
            message: '请上传建筑图片'
          }
        ],
        design: [
          {
            required: true,
            message: '请填写建筑设计单位'
          }, {
            type: 'string',
            min: 4,
            max: 64,
            message: '建筑设计单位名称长度限制为4-64个字'
          }
        ],
        developer: [
          {
            required: true,
            message: '请填写建筑开发商'
          }, {
            type: 'string',
            min: 4,
            max: 64,
            message: '建筑开发商长度限制为4-64个字'
          }
        ],
        building_category_id: [
          {
            required: true,
            message: '请选择建筑类型'
          }
        ],
        lng: [
          {
            required: true,
            message: '请选择建筑的地区'
          }
        ],
        lat: [
          {
            required: true,
            message: '请选择建筑的地区'
          }
        ],
        sys_area_id: [
          {
            required: true,
            message: '请选择建筑的地区'
          }
        ],
        address: [
          {
            required: true,
            message: '请填写建筑的详细地址'
          }
        ]
      },
      isExist: {},
      ossThumbnail: { // 上传封面图片的参数
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      thumbnailPicture: {}, // 封面图上传成功返回的参数
      ossImage: { // 上传封面图片的参数
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      buildingImage: [], // 封面图上传成功返回的参数
      showFaMapModal: false // 显示地区定位
    }
  },
  watch: {
    isLogin (newVal) { // 判断是否登录， 否 -- 显示登录弹窗
      if (!newVal) {
        this.$store.commit('SHOW_LOGIN_MODAL')
      }
    }
  },
  computed: {
    ...mapState(['isLogin'])
  },
  created () {
    this.init()
  },
  methods: {
    goToIndex () {
      window.location = '/index.html'
    },
    async init () {
      this.categoryList = await getBuildingCategory()
    },
    // 建筑名称唯一性验证
    async checkBuildingName () {
      if (this.buildingAddForm.name) {
        const response = await api.buildingUnique({ name: this.buildingAddForm.name })
        if (response.code === 200) {
          if (response.results.id || response.results.name) {
            this.isExist = response.results
          } else {
            this.isExist = {}
          }
        }
      }
    },
    // 当填写的建筑名称已存在时 点击 跳转到建筑详情页面
    goToBuildingDetail () {
      this.$router.push({ path: `/building-detail/${this.isExist.id}` })
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await api.ossParamsCreate(file, 'building_thumbnail', this.ossThumbnail)
    },
    successThumb (res) {
      if (res.code === 200) {
        this.thumbnailPicture = res.results
        this.buildingAddForm.thumbnail = res.results.file_url
        this.coverUploadShow = false
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'building_image', this.ossImage)
    },
    successImage (res) {
      if (res.code === 200) {
        this.buildingImage.push(res.results) // 存储上传成功图片到本地
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    // 删除封面图
    deleteThumbnail () {
      this.thumbnailPicture = {}
      this.buildingAddForm.thumbnail = ''
      this.coverUploadShow = true
    },
    // 删除建筑图片
    deleteImg (index) {
      this.buildingImage.splice(index, 1)
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    },
    // 设置建筑类型
    setBuildingCate (cateId) {
      this.buildingAddForm.building_category_id = cateId
    },
    // 显示地图定位弹窗组件
    showFaMap () {
      this.showFaMapModal = true
    },
    // 地图弹窗组件回调
    setArea (mapAddress) {
      this.buildingAddForm.lng = mapAddress.point.lng
      this.buildingAddForm.lat = mapAddress.point.lat
      this.buildingAddForm.sys_area_id = mapAddress.sysAreaId
      this.buildingAddForm.address = mapAddress.addressData.address
      this.buildingArea = `${mapAddress.addressData.province} / ${mapAddress.addressData.city} / ${mapAddress.addressData.district}`
    },
    async saveBuilding () {
      this.checkBuildingName()
      if (this.isExist.id || this.isExist.name) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['BUILDING_ADD_EXIST_TIP'], type: 'warning' })
        return false
      }
      this.buildingAddForm.image_urls = []
      this.buildingImage.map((item) => {
        this.buildingAddForm.image_urls.push(item.file_url)
      })
      const result = await this.$refs.buildingAddForm.validate()
      if (!result) {
        return false
      }
      let response = await api.buildingAdd(this.buildingAddForm)
      if (response.code === 200) {
        this.$router.push({ path: `/building-detail/${response.results.id}` })
      }
    }
  },
  components: {
    Page,
    JumpTop,
    FineartCascader,
    FaMap,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-input': Input,
    'i-upload': Upload,
    'i-select': Select,
    'i-option': Option,
    'i-dropdown': Dropdown,
    'i-dropdown-menu': DropdownMenu
  }
}
</script>

<style lang="stylus">
.page-content [class^="fy-icon"]
  font-size: 16px
  display: inline-block
  vertical-align: middle
  margin-right: 7px
.building-add-form
  padding: 14px 0
  .build-name
    margin-bottom: 30px
  .building-add-item
    display:flex;
    align-items: center
    margin-bottom: 30px
    .ivu-form-item-label
      width: 64px
      height: 22px
      padding: 0
      color: $black
      line-height: 22px
      font-size: 16px
      overflow: hidden
      margin-right: 20px
      text-align: justify
      &:after
        content: ''
        height: 0
        width: 100%
        display: inline-block
    .ivu-form-item-content
      display: flex
      font-size: 14px
      color: $grey-high
      align-items: center
      margin-left: 0!important
      .ivu-input-wrapper, .ivu-select, .ivu-input
        width: 640px
        margin-right: 20px
      .ivu-select-selection, .ivu-input
        font-size: 16px
        border: 1px solid $grey-high4
      .ivu-form-item-error-tip
        display: block
        color: $red
      .commit-btn
        width: 140px
        height: 40px
        font-size: 18px
        margin-left: 94px
      .exist-tip
        color: $orange
        cursor: pointer
      .cover-upload
        .ivu-upload-drag
          width: 120px
          height: 120px
          border: 1px solid $grey-high4
        .cover-upload-text
          width: 120px
          height: 120px
          .fy-icon-upload
            font-size: 32px
            margin: 33px 0 0 0
      .upload-tip
        width: 341px
        height: 59px
        line-height: 32px
        padding-left: 20px
    &.img-add, &.map-position-add
      .ivu-form-item-content
        flex-direction: column
        align-items: normal
    &.img-add
      .ivu-form-item-content>div
        max-width: 1100px
        display: flex
        flex-wrap: wrap
      .uploaded-img
        width: 200px
        height: 112px
        margin: 0 20px 20px 0
        position: relative
      .building-img-upload
        .ivu-upload-drag
          width: 200px
          height: 112px
          border: 1px solid $grey-high4
          margin-bottom: 20px
        .cover-upload-text
          width: 200px
          height: 112px
          .fy-icon-add-thin-gray
            font-size: 32px
            margin: 25px 0 0 0
    &.map-position-add
      align-items: baseline
      .ivu-input-prefix i
        color: $grey-high1
  .map-plugin
    width: 1100px
    height: 438px
    margin: 0 0 30px 84px
  .address-list
    width: 620px
    padding: 5px 20px
    cursor: pointer
  .thumbnail-show
    position: relative
    width: 120px
    height: 120px
    border: 1px solid $grey-high4
    &>img
      width: 100%
      height: 100%
    .img-edit-cover
      absolute: top -18px right -8px
      width: 18px
      height: 18px
      cursor: pointer
      &>span
        font-size: 18px
</style>
