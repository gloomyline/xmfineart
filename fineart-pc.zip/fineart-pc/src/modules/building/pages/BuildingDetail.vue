<template>
  <Page>
    <section class="page-content">
      <i-breadcrumb separator="<span class='fy-icon-arrow'></span>">
        <i-breadcrumb-item><a href="index.html">首页</a></i-breadcrumb-item>
        <i-breadcrumb-item to="/">斐艺建筑</i-breadcrumb-item>
        <i-breadcrumb-item>{{ buildingDetail.name}}</i-breadcrumb-item>
      </i-breadcrumb>
      <div class="building-detail">
        <i-carousel class="building-carousel" arrow="always" radius-dot loop>
          <i-carousel-item v-for="(item, index) in buildingDetail.images" :key="index">
            <div class="building-img">
              <img :src="item.url">
            </div>
          </i-carousel-item>
        </i-carousel>
        <div class="building-info">
          <p class="building-name">{{ buildingDetail.name}}</p>
          <p class="building-attr">
            <i-row>
              <i-col :span="12">
                <label class="attr-label">建筑设计</label>
                <span class="attr-value">{{ buildingDetail.design }}</span>
              </i-col>
              <i-col :span="12">
                <label class="attr-label">开发商</label>
                <span class="attr-value">{{ buildingDetail.developer }}</span>
              </i-col>
            </i-row>
            <i-row>
              <i-col :span="12">
                <label class="attr-label">类型</label>
                <span class="attr-value attr-category" v-for="(item, index) in buildingDetail.category" :key="index">{{ item }}</span>
              </i-col>
              <i-col :span="12">
                <label class="attr-label">地址</label>
                <div class="attr-value">
                  <span v-for="(item, index) in buildingDetail.region" :key="index" v-if="index !== '1'">{{ item }}</span><span>{{ buildingDetail.address }}</span>
                </div>
              </i-col>
            </i-row>
            <i-row>
              <i-col :span="24">
                <label class="attr-label">简介</label>
                <span class="attr-value" v-html="buildingDetail.introduction"></span>
              </i-col>
            </i-row>
          </p>
          <p class="edit-box">
            <i-button class="focus-btn" @click="changeIsCollect()" :class="{'is-focus': buildingDetail.my_collect_status}">
              <span v-if="!buildingDetail.my_collect_status"><span class="fy-icon-nor-follow"></span>关注建筑</span>
              <span v-else><span class="fy-icon-sel-follow"></span>已关注</span>
            </i-button>
            <i-button @click="joinRecord()"
                      v-show="!isShowed"><span class="fy-icon-fill"></span>我有参与</i-button>
          </p>
        </div>
        <!-- 我有参与 编辑 -->
        <building-add-member-case ref="addMemberCase" :buildingCode="buildingDetail.code" v-if="isShowed" @close="isShowed = false" @change-resource="changeResource" @change="initBuilding"></building-add-member-case>
        <!-- 参与记录列表 -->
        <div class="building-member-record">
          <i-menu class="member-record-nav" mode="horizontal" active-name="1">
            <i-menu-item name="1">参与记录</i-menu-item>
          </i-menu>
          <div class="member-record-card" v-for="(item, index) in buildingDetail.case" :key="index" :id="`anchor${item.resource_id}`">
            <div class="member-logo">
              <img :src="item.resource_logo">
            </div>
            <div class="member-info">
              <div>
                <a class="member-name" :href="routes(item)" target="_blank">{{ item.resource_name}}</a>
                <span class="member-address">{{ item.area_desc }}</span>
              </div>
              <div>
                <span class="service-type">
                  <span class="fy-icon-type"></span>
                  <span>服务类型</span>
                  <span>{{ item.service_type }}</span>
                </span>
                <span class="service-date" v-if="item.start_at && item.end_at">
                  <span class="fy-icon-time"></span>
                  <span>服务时间</span>
                  <span>{{item.start_at}}至{{item.end_at}}</span>
                </span>
              </div>
              <div class="service-content">
                <div v-show="!item.showDetail">
                  <p class="content-text" v-if="item.content_text">{{ item.content_text }}</p>
                  <div class="content-images" v-if="item.content_image.length > 0">
                    <div class="img-cell" v-for="(val, i) in item.content_image" :key="i">
                      <img :src="val">
                    </div>
                  </div>
                  <i-button class="show-more" type="text" @click="showMore(index)" v-if="item.textMore || item.content_image.length">
                    展开更多
                    <i-icon type="ios-arrow-down" />
                  </i-button>
                </div>
                <div v-show="item.showDetail">
                  <div class="content-html" v-html="item.content"></div>
                  <i-button class="hide-more" type="text" @click="hideMore(index)" >
                    收起
                    <i-icon type="ios-arrow-up" />
                  </i-button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <list-nothing class="building-record-nothing" v-if="buildingDetail.case&&!buildingDetail.case.length"></list-nothing>
      </div>
    </section>
    <jump-top></jump-top>
    <!-- 弹窗 用户未开通主页或未实名认证-->
    <i-modal class="tip-modal"
             title="温馨提示"
             width="595"
             v-model="realNameTipModal">
      <p>目前仅接受已开通主页的用户参与。</p><br/>
      <p>您需要先<em>实名认证</em>，然后开通<em>主页</em>，再前来参与</p>
      <div slot="footer">
        <div class="save-btn-group">
          <i-button type="text"
                    class="cancel"
                    @click="realNameTipModal = false">下次再说</i-button>
          <i-button class="save-btn"
                    type="primary"
                    size="large"
                    v-if="isAuth !== '200'"
                    @click="goToPage('/member.html#/real-name')">去认证</i-button>
          <i-button class="save-btn"
                    type="primary"
                    size="large"
                    v-if="isAuth === '200' && !openResourceHome "
                    @click="goToPage('/member.html#/home-manage/choice-home')">去开通主页</i-button>
        </div>
      </div>
    </i-modal>
    <!--弹窗 用户无未绑定该建筑资源-->
    <i-modal class="tip-modal"
             title="温馨提示"
             width="595"
             v-model="homeTipModal">
      <p>您账号当前主页在该建筑已经参与过了，不能重复参与。</p><br/>
      <p>如果要编辑某个案例，可前往主页，点击<em>案例编辑</em>按钮</p>
      <div slot="footer">
        <div class="save-btn-group">
          <i-button class="save-btn"
                    type="primary"
                    size="large"
                    @click="homeTipModal = false">我知道了</i-button>
        </div>
      </div>
    </i-modal>
  </Page>
</template>

<script>
import { Page, JumpTop, BuildingAddMemberCase, ListNothing } from 'components'
import { Breadcrumb, BreadcrumbItem, Carousel, CarouselItem, Col, Row, Menu, MenuItem, Icon, Modal } from 'iview'
import { COLLECT_MESSAGE_DURATION } from 'assets/data/constants.js'
import * as MSG from 'assets/data/message.js'
import api from 'modules/building/api'
import Vue from 'vue'
import { mapState } from 'vuex'

export default {
  name: 'BuildingDetail',
  data () {
    return {
      isShowed: false,
      buildingDetail: {},
      realNameTipModal: false,
      homeTipModal: false,
      // 用户审核通过主页
      openResourceHome: false,
      apiProcessing: false // API请求处理中
    }
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  computed: {
    ...mapState(['isLogin']),
    isAuth () {
      return this.$store.state.member.memberInfo.is_auth
    }
  },
  watch: {
    isLogin (newVal) {
      if (!newVal) {
        this.isShowed = false
        this.openResourceHome = false
      }
    }
  },
  created () {
    this.initBuilding()
  },
  methods: {
    goToPage (pagePath) {
      window.location = pagePath
    },
    routes (item) {
      let path = ''
      switch (item.resource_mode) {
      case '100':
        path = 'person'
        break
      case '200':
        path = 'company'
        break
      case '300':
        path = 'supplier'
        break
      case '400':
        path = 'brand'
        break
      case '500':
        path = 'decorator'
        break
      }
      return `/resource.html#/${path}-home/${item.resource_id}`
    },
    showMore (index) {
      this.buildingDetail.case[index].showDetail = true
    },
    hideMore (index) {
      this.buildingDetail.case[index].showDetail = false
      let anchorId = '#anchor' + this.buildingDetail.case[index].resource_id
      this.goAnchor(anchorId)
    },
    joinRecord () {
      if (this.isLogin) {
        // 用户主页判断
        this.checkHome()
      } else {
        this.$store.commit('SHOW_LOGIN_MODAL')
      }
    },
    goAnchor (selector) {
      let anchor = this.$el.querySelector(selector)
      document.documentElement.scrollTop = anchor.offsetTop - 80 // 补偿头部遮挡部分
    },
    async changeIsCollect () {
      // 判断是否登陆
      if (!this.isLogin) {
        this.$store.commit('SHOW_LOGIN_MODAL')
        return false
      }
      if (this.apiProcessing) {
        return false
      }
      this.apiProcessing = true
      this.result = await api.buildingCollect(this.id)
      if (Number.parseInt(this.result.code) === 200) {
        this.buildingDetail.my_collect_status = !this.buildingDetail.my_collect_status
        // 提示关注成功或取消关注成功
        if (this.buildingDetail.my_collect_status) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    },
    async initBuilding () {
      this.isShowed = false
      this.buildingDetail = await api.fetchBuildingDetail(this.id)
      this.buildingDetail.design = this.buildingDetail.design ? this.buildingDetail.design : '-'
      this.buildingDetail.developer = this.buildingDetail.developer ? this.buildingDetail.developer : '-'
      if (this.buildingDetail.case.length > 0) {
        for (let item in this.buildingDetail.case) {
          this.buildingDetail.case[item].content_image.splice(5)
          if (this.buildingDetail.case[item].content_text.length >= 170) {
            this.buildingDetail.case[item].content_text = this.buildingDetail.case[item].content_text.substr(0, 170) + '...'
            this.buildingDetail.case[item].textMore = true
          }
          if ((this.buildingDetail.case[item].content_text && this.buildingDetail.case[item].content_text.length >= 170) || this.buildingDetail.case[item].content_image.length) {
            Vue.set(this.buildingDetail.case[item], 'showDetail', true)
          } else {
            Vue.set(this.buildingDetail.case[item], 'showDetail', false)
          }
        }
      }
      if (!this.$route.hash.substring(1)) return
      let anchorId = '#anchor' + this.$route.hash.substring(1)
      this.$nextTick(() => {
        this.goAnchor(anchorId)
      })
    },
    changeResource () {
      this.homeTipModal = true
    },
    async checkHome () {
      // 检测会员是否有开通主页
      let accountResourceList = await api.fetchAccountResourceList()
      for (let item in accountResourceList) {
        if (accountResourceList[item].status === '300') {
          this.openResourceHome = true
          break
        }
      }

      if (this.openResourceHome) {
        this.isShowed = true
      } else {
        this.realNameTipModal = true
      }
    }
  },
  components: {
    Page,
    JumpTop,
    ListNothing,
    BuildingAddMemberCase,
    'i-row': Row,
    'i-col': Col,
    'i-icon': Icon,
    'i-menu': Menu,
    'i-modal': Modal,
    'i-menu-item': MenuItem,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem,
    'i-carousel': Carousel,
    'i-carousel-item': CarouselItem
  }
}
</script>

<style lang="stylus">
.page-content [class^="fy-icon"]
  font-size: 16px
  display: inline-block
  vertical-align: middle
  margin-right: 7px
.building-detail
  .building-carousel
    min-height: 670px
    background: $grey-high2
    .building-img
      width: 1200px
      height: 670px
      overflow: hidden
      img
        width: 100%
    .ivu-carousel-arrow
      width: 57px
      height: 57px
      .ivu-icon
        font-size: 30px
    .ivu-carousel-dots
      &.ivu-carousel-dots-inside
        bottom 30px
      li
        margin: 5px
        .radius
          width: 11px
          height: 11px
          background: transparent
          border: 1px solid $white
          &:after
            content: ''
            width: 7px
            height: 7px
            display: block
            z-index: -1
            opacity: 0.3
            absolute bottom 4px right 0
            background: transparent
            border-radius: 16px 0
            transition: all 0.5s;
        &.ivu-carousel-active .radius
          background: $orange
          border: 1px solid $orange
          &:after
            opacity: 1
            background: $orange
  .building-info
    margin: 40px 0
    p
      margin-bottom: 30px
    .building-name
      height: 32px
      line-height: 32px
      font-size: 20px
      font-weight: 500
      color: $black
    .building-attr
      .ivu-row
        font-size: 16px
        margin-bottom 20px
        .ivu-col
          display: flex
        &:last-child
          margin-bottom: 0
        .attr-label
          width: 64px
          height: 32px
          line-height: 32px
          margin-right: 30px
          text-align: justify
          display: inline-block
          overflow: hidden
          &:after
            content: ''
            width: 100%
            display: inline-block
        .attr-value
          line-height: 32px
          color: $black1
          max-width: 1098px
          display: inline-block
          &.attr-category
            margin-right: 15px
    .edit-box
      .ivu-btn
        width: 120px
        height: 40px
        color: $black1
        font-size: 16px
        margin-right: 20px
        &:hover
          color: $orange
      .focus-btn
        &.is-focus
          color: $orange
          background: #FDF2DA
          border: 1px solid $orange
  .building-member-record
    .member-record-nav
      height: 50px
      line-height: 50px
      .ivu-menu-item
        font-size: 16px
    .member-record-card
      display: flex
      padding: 30px 0
      border-bottom: 1px solid $grey-high4
      &:last-child
        border-bottom-color: transparent
      .member-logo
        width: 70px
        height: 70px
        margin-right: 20px
        overflow: hidden
        display: block
        border-radius: 50%
        box-shadow: 1px 3px 12px rgba(0,0,0,0.12)
        img
          width: 70px
      .member-info
        width: 1100px
        &>div
          margin-bottom: 15px
          &:first-child
            margin-top: 12px
          .member-name
            color: $black
            font-size: 16px
            margin-right: 20px
          .member-address
            color: $grey-high
            font-size: 14px
          .service-type,.service-date
            font-size: 14px
            color: $grey-high
            min-width: 181px
            display: inline-block
            span
              height: 20px
              font-size: 14px
              line-height: 20px
              padding-right: 5px
              vertical-align: middle
            .fy-icon-type, .fy-icon-time
              padding-right: 0
              margin-right: 0
          &.service-content
            font-size: 14px
            color: $black1
            margin-bottom: 0
            transition: 0.6s ease-in-out
            .content-text
              max-height: 58px
              overflow: hidden
              line-height: 28px
              position: relative
              display: -webkit-box
              -webkit-line-clamp: 2
              -webkit-box-orient: vertical
            .content-images
              width: 1000px
              display: flex
              overflow: hidden
              .img-cell
                height: 120px
                width: 120px
                margin-right: 17px
                background-color: $grey-high2
                img
                  height: 120px
                  width: 120px
            .content-text + .content-images
              margin-top: 20px
            .show-more, .hide-more
              padding: 0
              margin-top: 10px
              color: $black
              font-size: 14px
              font-weight: 500
              background: $white
              &:focus
                box-shadow: none
            .content-html
              img
                max-width: 1100px
                margin-top: 20px
  .building-record-nothing
    margin: 50px 0
    .fy-icon-full
      font-size: 215px
.tip-modal .ivu-modal-body em
  color: $black
</style>
