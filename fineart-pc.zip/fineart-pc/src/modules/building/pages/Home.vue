<template>
<Page>
  <section class="page-content building-list">
    <div class="building-filter">
      <div class="building-attr-box">
        <label class="filter-label">建筑类型</label>
        <ul class="building-attribute">
          <li class="attribute-item"
              :class="{'is-attribute': item.value === pageConfig.category_id}"
              v-for="item in categoryList"
              :key="item.value"
              @click="changeIsAttribute(item.value)">{{ item.label }}</li>
        </ul>
      </div>
      <div>
        <fineart-cascader label="地区"
                          :data="areaList"
                          placeholder="请选择地区"
                          v-model="areaVal"
                          @change-category="changeArea"></fineart-cascader>
        <i-button  class="filter-select" long :class="{'is-foreign': '1' == pageConfig.foreign}" @click="changeIsForeign(`${pageConfig.foreign}`)">只看国外</i-button>
      </div>
      <div>
        <label class="filter-label">搜索</label>
        <i-input class="filter-keyword" v-model="keyword" search placeholder="输入关键词" @on-search="searchBuilding">
          <i-button slot="append" class="classify-search-btn" type="primary" @click="searchBuilding(keyword)"><span class="fy-icon-search"></span>搜一下</i-button>
        </i-input>
        <div @click="goToAddBuilding" class="add-building"><i class="fy-icon-add-thick-orange"></i>添加建筑</div>
      </div>
    </div>
    <i-menu class="building-order" mode="horizontal" active-name="default" @on-select="changeSort">
      <i-menu-item name="default">综合排序</i-menu-item>
      <i-menu-item name="false" disabled class="nav-divider"><i-divider type="vertical"></i-divider></i-menu-item>
      <i-menu-item name="views_desc">查看次数</i-menu-item>
    </i-menu>
    <div class="building-content" v-if="!!buildingInfo.total">
      <router-link :to="`/building-detail/${item.id}`" v-for="item in buildingInfo.data" :key="item.id" class="building-item-box" target="_blank">
        <div class="building-pic-wrap">
          <img class="building-pic" :src="item.thumbnail">
        </div>
        <p class="building-title">{{ item.name }}</p>
        <p class="building-category">
          <span>{{ item.category[item.building_category_id] }}</span>
        </p>
        <p class="building-region">
          <span class="fy-icon-address"></span>
          <span class="attr-value">{{ item.area_desc }}</span>
        </p>
      </router-link>
    </div>
    <list-nothing v-else></list-nothing>
    <pagination class="building-pagination"
                @page-confirm="goToCurrentPage"
                v-if="!!buildingInfo.total"
                :total="buildingInfo.total"
                :page="buildingInfo.current_page"
                :page-size="buildingInfo.per_page"></pagination>
  </section>
  <jump-top></jump-top>
</Page>
</template>

<script>
import { Page, JumpTop, Pagination, ListNothing, FineartCascader } from 'components'
import { Select, Option, Menu, MenuItem, Divider } from 'iview'
import api from 'modules/building/api'
import { getArea, getBuildingCategory } from '@/common/js/loadScript.js'
import { scrollTop } from '@/common/js/utils'

export default {
  name: 'home',
  data () {
    return {
      isAttribute: 1,
      keyword: '',
      areaVal: [],
      categoryList: [], // 建筑类型
      areaList: [],
      buildingInfo: {},
      pageConfig: {
        page: 1,
        keyword: '',
        category_id: '',
        foreign: '0',
        area_id: '',
        sort: 'default'
      }
    }
  },
  watch: {
    pageConfig: {
      handler: function (newVal) {
        this.fetchBuildingList(newVal)
      },
      deep: true
    }
  },
  components: {
    Page,
    JumpTop,
    Pagination,
    ListNothing,
    FineartCascader,
    'i-select': Select,
    'i-option': Option,
    'i-menu': Menu,
    'i-divider': Divider,
    'i-menu-item': MenuItem
  },
  created () {
    this.fetchBuildingList(this.pageConfig)
    this.init()
  },
  methods: {
    async init () {
      this.areaList = await getArea()
      this.categoryList = await getBuildingCategory()
      this.categoryList.unshift({
        value: '',
        label: '全部'
      })
    },
    changeIsForeign (foreign) {
      this.pageConfig.page = 1
      this.pageConfig.foreign = foreign === '1' ? '0' : '1'
      this.pageConfig.area_id = ''
      this.areaVal = []
    },
    changeIsAttribute (CategoryId) {
      this.pageConfig.page = 1
      this.pageConfig.category_id = CategoryId
    },
    goToCurrentPage (page) {
      this.pageConfig.page = page.page
      this.$nextTick(() => {
        const sTop = document.documentElement.scrollTop || document.body.scrollTop
        scrollTop(window, sTop, 0, 800)
      })
    },
    searchBuilding (keyword) {
      this.pageConfig.page = 1
      this.pageConfig.keyword = keyword
    },
    // 选择地区 pageConfig => area_id
    changeArea (param) {
      this.pageConfig.page = 1
      this.pageConfig.foreign = '0'
      if (param) {
        this.pageConfig.area_id = param
      } else {
        this.pageConfig.area_id = ''
      }
    },
    changeSort (name) {
      if (name === 'false') return
      this.pageConfig.page = 1
      this.pageConfig.sort = name
    },
    async fetchBuildingList (params) {
      this.buildingInfo = await api.fetchBuildingList(params)
    },
    goToAddBuilding () { // 判断是否登录 否显示登录弹窗
      const user = this.$localStorage.getUser()
      if (user && user.isLogin) {
        this.$router.push({ path: '/building-add' })
      } else {
        this.$store.commit('SHOW_LOGIN_MODAL')
      }
    }
  }
}
</script>

<style lang="stylus">
.building-list
  padding-top: 30px
  .ivu-select-placeholder,
  .ivu-select-selected-value,
  .ivu-input-wrapper .ivu-input
    font-size: 14px
  .building-filter
    margin-bottom: 30px
    &>div
      display: flex
      align-items: center
      position: relative
      &.building-attr-box
        margin-bottom: 30px
        align-items: baseline
      .filter-label
        width: 64px
        height: 40px
        font-size: 16px
        line-height: 40px
        text-align: justify
        margin-right: 20px
        &:after
          content: ''
          width: 100%
          height: 0
          display inline-block
          overflow: hidden
      .building-attribute
        font-size: 0
        width: 1110px
        .attribute-item
          color: $black1
          font-size: 14px
          cursor: pointer
          line-height: 40px
          padding-right: 40px
          display: inline-block
          &:last-child
            padding-right: 0
          &:hover, &.is-attribute
            color: $orange
      .filter-select
        margin: 0 0 30px 20px
        &:hover, &.is-foreign
          border: 1px solid $orange
          color: $orange
      .filter-select, .filter-keyword
        width: 364px
        margin-right: 20px
        &:last-child
          margin-right: 0
        .classify-search-btn
          width: 112px
          height: 40px
          padding: 0
          color: $white
          font-size: 14px
          background-color: $orange
          border-radius: 0 4px 4px 0
          &>span
            display: flex
            justify-content: center
            align-items: center
            width: 100%
            height: 40px
          .fy-icon-search
            margin-right: 5px
            font-size: 20px
            color: $white
      .add-building
        position: absolute
        right: 0
        width: 120px
        height: 40px
        border: 1px solid $orange
        line-height: 40px
        color: $orange
        font-size: 14px
        text-align: center
        cursor: pointer
        border-radius:4px
        .fy-icon-add-thick-orange
          margin-right: 7px
    .ivu-btn
      font-size: 14px
      height: 40px
  .building-order
    height: 40px;
    margin-bottom: 30px;
    line-height: 40px;
    z-index: 1;
    .ivu-menu-item
      width: auto
      padding: 0
      color: $black1
      font-size: 16px
      &:hover, &.ivu-menu-item-active
        color: $orange
    .nav-divider
      display: flex
      justify-content: center
      align-items: center
      width: 55px
      padding: 0 10px
      cursor: default
      &:hover, &.ivu-menu-item-active
        color: $black1
        border-bottom: none
  .building-content
    display: flex
    flex-wrap: wrap
    margin-right: -60px
    .building-item-box
      margin: 10px 60px 0 0
      width: 254px
      height: 400px
      .building-pic-wrap
        width: 254px
        height: 254px
        overflow: hidden
        background: $grey-high2
        .building-pic
          width: 100%
      .building-title
        padding: 10px 0
        font-size: 18px
        color: $black
        text-align: center
        {ellipse}
      .building-category
        text-align: center
        span
          width:50px
          height:24px
          color: $orange
          padding: 0 5px
          font-size:14px
          border-radius:4px
          border:1px solid $orange
          &:empty
            border: none
      .building-region
        display: flex
        align-items: center
        justify-content: center
        height:19px
        line-height:20px
        font-size:14px
        color: $grey-high
        margin: 20px 0
        .fy-icon-address
          font-size: 16px
        .attr-value
          {ellipse}
  .building-pagination
    margin: 52px
</style>
