import {BaseApi} from '@/common/js/BaseApi'
import initHome from './initialHome.js'
import buildingCommonApi from './buildingCommonApi'
import ossApi from '@/modules/member/api/ossApi'

class BuildingApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    BuildingApi.updateToken(BuildingApi.readTokenFromLocalStorage())
    initHome(BuildingApi)
    buildingCommonApi(BuildingApi)
    ossApi(BuildingApi)
  }
}

const _instance = new BuildingApi()

export default _instance
