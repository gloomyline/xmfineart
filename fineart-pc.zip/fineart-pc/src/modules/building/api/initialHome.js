/**
 * @comment:
 * @author: alan_wang
 * @date: 08/10/2018
 * @time: 17:24:24
 */

export default function (cls) {
  /**
   * 获取建筑列表
   *
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param category_id {Integer} 建筑类别ID
   * @param foreign {Integer} 是否查看国外标志
   * @param area_id {Integer} 建筑地区ID
   * @param sort {String} 建筑code
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchBuildingList = async function ({ page, keyword, category_id, foreign, area_id, sort }) {
    const response = await cls.request({
      url: '/building/search',
      query: {
        page,
        keyword,
        category_id,
        foreign,
        area_id,
        sort
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取建筑详情
   *
   * @param id {Integer} 建筑ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchBuildingDetail = async function (id) {
    const response = await cls.request({
      url: '/building/detail/${id}',
      params: { id }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 关注或者取消关注建筑
   *
   * @param id {Integer} 建筑ID
   * @returns {Promise<*>}
   */
  cls.prototype.buildingCollect = async function (id) {
    const response = await cls.request({
      url: '/building/collect/building/${id}',
      params: { id }
    })
    return response
  }

  /**
   * 获取会员的已开通的资源列表
   *
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchAccountResourceList = async function () {
    const response = await cls.request({
      url: '/resource/member/index'
    })

    return response.results
  }

  /**
   * 获取建筑指定资源的参与案例
   *
   * @param code {String} 建筑code
   * @param resource_id {Integer} 资源ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchBuildingResourceCaseCount = async function ({building_code, resource_id}) {
    const response = await cls.request({
      url: '/resource/case/count/${building_code}/${resource_id}',
      params: {
        building_code,
        resource_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
}
