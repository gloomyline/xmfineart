export default function (cls) {
  // 建筑添加
  cls.prototype.buildingAdd = async function ({name, thumbnail, image_urls, building_category_id, design, developer, lat, lng, sys_area_id, address, introduction}) {
    const response = await cls.request({
      method: 'post',
      url: '/building/add',
      data: {
        name,
        thumbnail,
        'image_urls[]': image_urls,
        building_category_id,
        design,
        developer,
        lat,
        lng,
        sys_area_id,
        address,
        introduction
      }
    })

    return response
  }
  // 判断建筑名称的唯一性
  cls.prototype.buildingUnique = async function ({ name }) {
    const response = await cls.request({
      url: '/building/unique',
      query: {
        name
      }
    })
    return response
  }
  // 上传图片
  cls.prototype.uploadPicture = async function ({ module }) {
    const response = await cls.request({
      url: '/sys/oss/policy/${module}',
      params: {
        module
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
}
