/*
* @Author: Alan
* @Date:   2018-09-07 10:53:06
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-07 10:59:22
*/
import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from 'modules/mall/pages/Home.vue'
import ForeShow from 'modules/mall/pages/ForeShow.vue'
import MallCart from 'modules/mall/pages/MallCart.vue'
import GoodsList from 'modules/mall/pages/GoodsList.vue'
import GoodsDetail from 'modules/mall/pages/GoodsDetail.vue'
import Store from 'modules/mall/pages/Store.vue'
import ForeShowDetail from 'modules/mall/pages/ForeShowDetail.vue'
import StoreDetail from 'modules/mall/pages/StoreDetail.vue'
import MallOrder from 'modules/mall/pages/MallOrder.vue'
import PayHome from 'modules/mall/pages/PayHome.vue'
import Payment from 'modules/mall/pages/Payment.vue'
import GoPay from 'modules/mall/pages/GoPay.vue'
import PayResult from 'modules/mall/pages/PayResult.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/goods-list',
    name: 'GoodsList',
    component: GoodsList
  },
  {
    path: '/goods-detail/:id/:store_id',
    name: 'GoodsDetail',
    component: GoodsDetail,
    props: true
  },
  {
    path: '/fore-show',
    name: 'ForeShow',
    component: ForeShow
  },
  {
    path: '/fore-show-detail/:id',
    name: 'ForeShowDetail',
    props: true,
    component: ForeShowDetail
  },
  {
    path: '/store',
    name: 'Store',
    component: Store
  },
  {
    path: '/store-detail/:store_id',
    name: 'StoreDetail',
    props: true,
    component: StoreDetail
  },
  {
    path: '/mall-cart',
    name: 'MallCart',
    component: MallCart,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/mall-order',
    name: 'MallOrder',
    component: MallOrder,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/pay-home',
    name: 'PayHome',
    component: PayHome,
    redirect: {
      name: 'Payment'
    },
    meta: {
      requiresAuth: true
    },
    children: [
      {
        path: 'payment/:orderCode',
        name: 'Payment',
        component: Payment,
        meta: {
          requiresAuth: true
        }
      },
      {
        path: 'go-pay/:orderCode/:channel/:paymentCode',
        name: 'GoPay',
        component: GoPay,
        meta: {
          requiresAuth: true
        }
      },
      {
        path: 'pay-result/:orderCode/:status',
        name: 'PayResult',
        component: PayResult,
        meta: {
          requiresAuth: true
        }
      }
    ]
  }
]

export default new VueRouter({ routes })
