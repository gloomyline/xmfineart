import {BaseApi} from '@/common/js/BaseApi'
import mallHomeApi from './mallHomeApi.js'
import foreShow from './foreShow.js'
import goodsApi from './goodsApi.js'
import storeApi from './storeApi.js'
import cartApi from './cartApi.js'
import orderApi from './orderApi'
import paymentApi from './paymentApi'
import wechatApi from './wechatApi'

class MallApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    MallApi.updateToken(MallApi.readTokenFromLocalStorage())
    mallHomeApi(MallApi)
    foreShow(MallApi)
    goodsApi(MallApi)
    storeApi(MallApi)
    cartApi(MallApi)
    orderApi(MallApi)
    paymentApi(MallApi)
    wechatApi(MallApi)
  }
}

const _instance = new MallApi()

export default _instance
