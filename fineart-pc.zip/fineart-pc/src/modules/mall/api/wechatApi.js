export default function (cls) {
  // 生成微信支付二维码
  cls.prototype.wechatQrcode = async function (paymentCode) {
    const response = await cls.request({
      method: 'post',
      url: '/sys/payment/wx/qrcode',
      data: {
        'payment_code': paymentCode
      }
    })

    return response.results
  }
}
