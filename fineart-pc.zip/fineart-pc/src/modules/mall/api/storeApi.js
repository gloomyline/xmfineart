
export default function (cls) {
  cls.prototype.fetchStoreList = async function ({ page, keywords, category_id, area_id, sort }) {
    const response = await cls.request({
      url: '/mall/store/search',
      query: {
        page,
        keywords,
        category_id,
        area_id,
        sort
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchStoreDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/store/detail/${id}',
      params: { id }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.collectStore = async function (id) {
    const response = await cls.request({
      url: '/mall/collect/store/${id}',
      params: { id }
    })
    return response.code
  }

  cls.prototype.fetchStoreTagGoods = async function ({ page, store_id, tag }) {
    const response = await cls.request({
      url: '/mall/goods/search/store',
      query: {
        page,
        store_id,
        tag
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.tagList = async function (store_id, is_all) {
    const response = await cls.request({
      url: '/mall/goods/tag/list',
      query: {
        store_id,
        is_all
      }
    })

    return response.results
  }
}
