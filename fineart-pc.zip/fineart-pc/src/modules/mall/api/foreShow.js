/**
 * @comment:
 * @author: alan_wang
 * @date: 08/10/2018
 * @time: 17:24:24
 */

export default function (cls) {
  cls.prototype.fetchForeShowList = async function ({ page, keywords, sort }) {
    const response = await cls.request({
      url: '/mall/foreshow/index',
      query: {
        page,
        keywords,
        sort
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchForeShowDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/foreshow/${id}',
      params: { id }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchForeShowReservation = async function ({ id, operation }) {
    const response = await cls.request({
      url: '/mall/foreshow/reservation/${id}/${operation}',
      params: {
        id,
        operation
      }
    })

    return response
  }

  // 获取我的预约新品
  cls.prototype.foreShowMyReservation = async function (page) {
    const response = await cls.request({
      url: '/mall/foreshow/reservation/list',
      query: { page }
    })

    return response.results
  }
}
