export default function (cls) {
  // 支付预览
  cls.prototype.paymentPreview = async function (orderCode) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/payment/preview',
      data: {
        order_code: orderCode
      }
    })

    return response.results
  }

  // 支付记录生成
  cls.prototype.paymentAdd = async function (orderCode, channel) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/payment/add',
      data: {
        order_code: orderCode,
        channel: channel
      }
    })

    return response
  }

  // 支付结果查询
  cls.prototype.paymentVerification = async function (payment_code) {
    const response = await cls.request({
      url: '/sys/payment/verification/${payment_code}',
      params: {
        payment_code
      }
    })

    return response
  }
}
