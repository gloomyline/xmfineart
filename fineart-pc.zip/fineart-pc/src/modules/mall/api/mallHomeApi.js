/**
 * @comment:
 * @author: alan_wang
 * @date: 08/10/2018
 * @time: 17:24:24
 */

export default function (cls) {
  cls.prototype.fetchAdsList = async function () {
    const response = await cls.request({
      url: '/sys/ads/${type}',
      params: { type: 20 }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchRecommend = async function ({ position, limit = 4 }) {
    const response = await cls.request({
      url: '/sys/recommend/${position}/${limit}',
      params: {
        position,
        limit
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
}
