<template>
  <div class="pay-result">
    <div class="table-title"></div>
    <div class="content-box">
      <div class="result-box" v-if="success">
        <p class="result-word">
          <span class="word-icon fy-icon-complete"><span class="path1"></span><span class="path2"></span></span>
          支付成功</p>
        <i-button class="look-order" @click="goOrderList">查看该订单</i-button>
      </div>
      <div class="result-box" v-else>
        <p class="result-word">
          <span class="word-icon fy-icon-notes"><span class="path1"></span><span class="path2"></span></span>
          很抱歉，您的订单未成功支付！</p>
        <i-button class="look-order">查看该订单</i-button>
        <i-button type="primary" class="look-order again-pay" @click="goRepay">重新支付</i-button>
      </div>
    </div>
  </div>
</template>

<script>
import { Button, Icon } from 'iview'

export default {
  name: 'PayResult',
  data () {
    return {
      success: this.$route.params.status === '100',
      orderCode: this.$route.params.orderCode
    }
  },
  methods: {
    goOrderList () {
      window.location = 'member.html#/my-order'
    },
    goRepay () {
      this.$router.push({path: `/pay-home/payment/${this.orderCode}`})
    }
  },
  components: {
    'i-icon': Icon,
    'i-button': Button
  }
}
</script>

<style lang="stylus">
.pay-result
  .table-title
    width: 100%
    height: 52px
    margin: 30px 0 0 0
    border: 1px solid $grey-high4
    background-color: $grey-high5
  .content-box
    display: flex
    justify-content: center
    align-items: center
    width: 100%
    height: 495px
    margin-bottom: 45px
    border: 1px solid $grey-high4
    .result-box
      .result-word
        font-size: 28px
        color: $black1
        margin-bottom: 40px
        .word-icon
          vertical-align: middle
      .look-order
        width: 182px
        height: 46px
        margin-right: 30px
        color: $black1
        font-size: 20px
        &.again-pay
          color: $white
</style>
