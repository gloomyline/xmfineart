<template>
    <page>
      <mall-head></mall-head>
      <section class="page-content fore-detail">
        <i-breadcrumb class="goods-crumb" separator="<span class='fy-icon-arrow'></span>">
          <i-breadcrumb-item><a href="index.html">首页</a></i-breadcrumb-item>
          <i-breadcrumb-item to="/">斐艺购</i-breadcrumb-item>
          <i-breadcrumb-item>{{ foreShowDetail.name }}</i-breadcrumb-item>
        </i-breadcrumb>
        <div class="goods-detail-info">
          <div class="detail-picture">
            <!--<img :src="foreShowDetail.thumbnail">-->
            <mall-carousel :list="foreShowDetail.images"></mall-carousel>
          </div>
          <div class="detail-info">
            <h3 class="goods-name"> {{ foreShowDetail.name }} </h3>
            <p class="goods-tag">{{ foreShowDetail.subtitle }}</p>
            <div class="cart-attention">
              <i-button type="primary" size="large" ghost class="add-cart" @click="changeIsReservation(foreShowDetail.my_reservation_status)">
                <span v-if="!foreShowDetail.my_reservation_status">立即预约</span>
                <span v-else>取消预约</span>
              </i-button>
              <p class="goods-order"><em>{{ foreShowDetail.reservations }}人</em>已预约</p>
            </div>
          </div>
        </div>
        <div class="goods-grid">
          <i-tabs>
            <i-tab-pane label="详情">
              <div class="goods-detail-intro" v-html="foreShowDetail.introduction"></div>
            </i-tab-pane>
          </i-tabs>
        </div>
      </section>
      <jump-top></jump-top>
    </page>
</template>

<script>
import { Page, MallHead, FineartNumber, MallCarousel, JumpTop } from 'components'
import { Breadcrumb, BreadcrumbItem, Button, Tabs, TabPane } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/mall/api'

export default {
  data () {
    return {
      isReservation: false,
      foreShowDetail: {},
      result: {
        code: 200,
        msg: 'ok',
        results: []
      }
    }
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  created () {
    this.initForeShow()
  },
  methods: {
    async changeIsReservation (reservation_status) {
      let params = {id: this.id, operation: reservation_status ? 200 : 100}
      this.result = await api.fetchForeShowReservation(params)
      if (Number.parseInt(this.result.code) === 200) {
        this.foreShowDetail.my_reservation_status = !this.foreShowDetail.my_reservation_status
        // 提示预约成功或取消预约成功
        if (this.foreShowDetail.my_reservation_status) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_FORESHOW_RESERVATION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_FORESHOW_CANCEL_RESERVATION_SUCCESS'], type: 'success' })
        }
      }
    },
    async initForeShow () {
      this.foreShowDetail = await api.fetchForeShowDetail(this.id)
    }
  },
  components: {
    Page,
    JumpTop,
    MallHead,
    FineartNumber,
    MallCarousel,
    'i-tabs': Tabs,
    'i-button': Button,
    'i-tab-pane': TabPane,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem
  }
}
</script>

<style lang="stylus">
.fore-detail
  .goods-detail-info
    display: flex
    justify-content: space-between
    width: 1200px
    margin-bottom: 60px
    .detail-picture
      width: 750px
      &>img
        width: 100%
        height: 420px
    .detail-info
      position: relative
      width: 415px
      height: 420px
      .goods-name
        margin-bottom: 16px
        font-size: 28px
        color: $black
      .goods-tag
        margin-bottom: 40px
        font-size: 18px
        color: $black1
      .goods-price
        display: flex
        width: 415px
        margin-bottom: 20px
        &>span
          margin-right: 24px
          font-size: 18px
          line-height: 54px
          color: $black1
        .price
          font-size: 36px
          color: $orange
          &>em
            font-size: 24px
      .goods-count
        display: flex
        width: 415px
        margin-bottom: 50px
        &>span
          margin-right: 24px
          font-size: 18px
          line-height: 36px
          color: $black1
      .cart-attention
        absolute: left bottom
        display: flex
        .add-cart
          width: 198px
          height: 60px
          margin-right: 10px
          font-size: 20px
        .goods-order
          text-align: center
          color: $grey-high
          font-size: 16px
          line-height: 60px
          &>em
            color: $orange
  .goods-grid
    position: relative
    width: 1200px
    min-height: 250px
    border-right: 1px solid $grey
    border-left: 1px solid $grey
    .ivu-tabs-bar
      margin-bottom: 10px
    .ivu-tabs-nav-wrap
      height: 50px
      background-color: $grey-high2
    .ivu-tabs-ink-bar
      top: 0
      height: 4px
    .ivu-tabs-tabpane
      padding-bottom: 60px
    .ivu-tabs-tab
      width: 138px
      height: 50px
      color: $black1
      font-size: 16px
      line-height: 34px
      text-align: center
      &.ivu-tabs-tab-active
        color: $orange
        background-color: $white
    .goods-detail-intro
      overflow: hidden
      width: 1200px
      padding: 40px 80px
      img
        display: block
        margin: 0 auto
        max-width: 100%
    .goods-store
      absolute: right 17px top
      height: 50px
      font-size: 18px
      line-height: 50px
      color: $black1
      &>span
        margin-left: 10px
        vertical-align: middle
</style>
