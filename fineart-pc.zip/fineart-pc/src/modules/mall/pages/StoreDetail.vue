<template>
  <page>
    <mall-head></mall-head>
    <section class="page-content offline-store-detail">
      <i-breadcrumb class="goods-crumb" separator="<span class='fy-icon-arrow'></span>">
        <i-breadcrumb-item><a href="index.html">首页</a></i-breadcrumb-item>
        <i-breadcrumb-item to="/">斐艺购</i-breadcrumb-item>
        <i-breadcrumb-item>{{ storeDetail.name }}</i-breadcrumb-item>
      </i-breadcrumb>
      <div class="goods-detail-info">
        <div class="detail-picture">
          <mall-carousel :list="storeImageList"></mall-carousel>
        </div>
        <div class="detail-info">
          <h3 class="goods-name"> {{ storeDetail.name }} </h3>
          <p class="store-tag">{{ storeDetail.attribute_name }}</p>
          <p class="goods-subtitle">{{ storeDetail.subtitle }}</p>
          <p class="store-address"><span class="fy-icon-address-gray"></span>{{ storeDetail.address_desc }}</p>
          <div class="cart-attention">
            <div class="attention" :class="{ 'has-collected': hasCollected }" @click="changeCollection">
              <span :class="{ 'fy-icon-star-fill-gray' : hasCollected, 'fy-icon-star-plain-angle-gray': !hasCollected }"></span>
              <p>{{ collectionText }}</p>
            </div>
          </div>
        </div>
      </div>
      <i-divider type="horizontal"></i-divider>
      <h3 class="store-common-title">介绍</h3>
      <div class="store-introduce">
        <p class="intro-content">{{ storeDetail.introduction }}</p>
      </div>
      <h3 class="store-common-title">店长</h3>
      <div class="store-introduce">
        <p class="intro-content">{{ storeDetail.manager }} {{ storeDetail.mobile }}</p>
      </div>
      <h3 class="store-common-title">在售商品</h3>
      <ul class="store-classify-list">
        <li class="classify-item" :class="{'is-cur-tag': pageConfig.tag === ''}" @click="changeTag('')">全部</li>
        <li class="classify-item"
            v-for="(tagName, id) in tagList" :key="id"
            :class="{'is-cur-tag': tagName === pageConfig.tag}"
            @click="changeTag(tagName)">{{ tagName }}</li>
      </ul>
      <div class="goods-list-wrap" v-if="goodsList && goodsList.data && goodsList.data.length !== 0">
        <div class="popular-goods">
          <goods-card class="goods-item" v-for="item in goodsList.data"
            :key="item.id"
            :route="`/goods-detail/${item.id}/${pageConfig.store_id}`"
            :img-src="item.thumbnail">
            <h3>
              <p class="goods-name">{{ item.name }}</p>
              <p class="goods-price">&yen;{{ item.price_norm }}</p>
            </h3>
          </goods-card>
        </div>
      </div>
      <list-nothing v-else></list-nothing>
      <pagination
        :total="goodsList.total"
        :page-size="goodsList.per_page"
        @page-confirm="changePage"></pagination>
    </section>
    <jump-top></jump-top>
  </page>
</template>

<script>
import { Page, MallHead, JumpTop, GoodsCard, Pagination, ListNothing, MallCarousel } from 'components'
import { Breadcrumb, BreadcrumbItem, Divider } from 'iview'
import api from 'modules/mall/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'StoreDetail',
  data () {
    return {
      storeDetail: {},
      storeImageList: [],
      hasCollected: false,
      collectionText: '关注',
      apiProcessing: false,
      tagList: {},
      goodsList: {},
      pageConfig: {
        page: 1,
        store_id: '',
        tag: ''
      }
    }
  },
  props: {
    store_id: {
      type: String,
      required: true
    }
  },
  watch: {
    pageConfig: {
      handler (config) {
        this.fetchStoreTagGoods(config)
      },
      deep: true
    },
    // 监听登录结果，登录成功则更新店铺详情数据
    isLogin (newVal) {
      if (newVal) {
        this.fetchStoreDetail()
      }
    }
  },
  computed: {
    // 实时获取登录状态
    isLogin: function () {
      return this.$store.state.isLogin
    }
  },
  created () {
    // 默认显示在最顶部
    window.scrollTo(0, 0)
    this.init()
    this.fetchStoreDetail()
    this.tagUsedList()
    this.fetchStoreTagGoods()
  },
  methods: {
    init () {
      this.pageConfig.store_id = this.store_id
    },
    async fetchStoreDetail () {
      this.storeDetail = await api.fetchStoreDetail(this.store_id)
      this.changeCollectionBtn(this.storeDetail.has_collected)
      this.storeImageList = this.storeDetail.store_images_cdn
    },
    // 变更标签和页码时，加载店铺标签分类对应的商品
    async fetchStoreTagGoods () {
      this.goodsList = await api.fetchStoreTagGoods(this.pageConfig)
    },
    async tagUsedList () {
      this.tagList = await api.tagList(this.store_id, false)
    },
    // 变更分页
    changePage ({ page }) {
      this.pageConfig.page = page
    },
    // 变更标签
    changeTag (tag) {
      this.pageConfig.tag = tag
    },
    // 变更关注状态
    async changeCollection () {
      if (!this.isLogin) {
        this.$store.commit('SHOW_LOGIN_MODAL')
        return false
      }
      if (this.apiProcessing) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.GLOBAL_PROCESSING, type: 'info' })
        return false
      }
      this.apiProcessing = true
      let code = await api.collectStore(this.store_id)
      if (code === 200) {
        this.changeCollectionBtn(!this.hasCollected)
        if (this.hasCollected) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
      }
      this.apiProcessing = false
    },
    changeCollectionBtn (status) {
      this.hasCollected = status
      this.collectionText = status ? '已关注' : '关注'
    }
  },
  components: {
    Page,
    JumpTop,
    MallHead,
    GoodsCard,
    Pagination,
    ListNothing,
    MallCarousel,
    'i-divider': Divider,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem
  }
}
</script>

<style lang="stylus">
.offline-store-detail
  .store-common-title
    margin-bottom: 10px
    color: $black
    font-size: 20px
  .goods-detail-info
    display: flex
    justify-content: space-between
    width: 1200px
    margin-bottom: 60px
    .detail-picture
      width: 750px
    .detail-info
      position: relative
      width: 415px
      height: 420px
      .goods-name
        margin-bottom: 16px
        font-size: 28px
        color: $black
      .store-tag
        display: inline-block
        height: 22px
        padding: 0 6px
        margin-bottom: 20px
        border: 1px solid $grey-high
        line-height: 22px
        color: $grey-high
        text-align: center
        &:empty
          display: none
      .goods-subtitle
        margin-bottom: 20px
        font-size: 16px
        color: $black1
      .store-address
        color: $grey-high
        font-size: 16px
        &>span
          font-size: 18px
          vertical-align: middle
      .cart-attention
        absolute: left bottom
        display: flex
        .add-cart
          width: 198px
          height: 60px
          margin-right: 10px
          font-size: 24px
        .attention
          display: flex
          flex-wrap: wrap
          justify-content: center
          align-items: center
          width: 82px
          height: 60px
          border: 1px solid $grey-high1
          cursor: pointer
          text-align: center
          font-size: 14px
          color: $grey-high
          border-radius: 4px
          &>span
            font-size: 18px
          .fy-icon-star-fill-gray
            color: $white
          &>p
            width: 100%
          &.has-collected
            border: 1px solid $orange
            color: $white
            background-color: $orange
  .store-introduce
    margin-bottom: 40px
    font-size: 16px
    color: $black1
    line-height: 28px
  .store-classify-list
    display: flex
    flex-flow: wrap
    margin-bottom: 30px
    .classify-item
      padding: 2px 16px
      margin: 0 10px 10px 0
      border: 1px solid $grey-high
      color: $grey-high
      font-size: 14px
      text-align: center
      border-radius: 4px
      cursor: pointer
      &:hover, &.is-cur-tag
        color: $orange
        border-color: $orange
  .goods-list-wrap
    overflow: hidden
    width: 1200px
    margin-top: 30px
    .popular-goods
      display: flex
      justify-content: flex-start
      flex-flow: row wrap
      margin-right: -13px
      margin-bottom: 74px
      .goods-card
        margin: 0 13px 40px 0
        .goods-name
          text-align: center
          font-weight: normal
          font-size: 18px
          color: $black
          {ellipse}
        .goods-price
          text-align center
          font-size: 16px
          color: $orange
</style>
