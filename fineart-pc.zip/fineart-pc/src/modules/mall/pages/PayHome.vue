<template>
  <page>
    <mall-head></mall-head>
    <section class="page-content payment-home">
      <div class="order-detail">
        <p class="order-title">订单信息</p>
        <div class="goods-info">
          <span>商品名称：</span>
          <p>{{ order.abstract }}</p>
        </div>
        <p class="account-price">实付: <em>&yen;{{ order.pay_total }}</em></p>
      </div>
      <router-view></router-view>
    </section>
  </page>
</template>

<script>
import { Page, MallHead } from 'components'
import { Row, Col, Button } from 'iview'
import api from 'modules/mall/api/index.js'

export default {
  name: 'PaymentHome',
  data () {
    return {
      order: {}
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.orderCode = this.$route.params.orderCode
      this.order = await api.paymentPreview(this.orderCode)
    }
  },
  components: {
    Page,
    MallHead,
    'i-row': Row,
    'i-col': Col,
    'i-button': Button
  }
}
</script>

<style lang="stylus">
.payment-home
  padding-top: 80px
  .order-detail
    display: flex
    justify-content: space-between
    flex-flow: wrap
    margin-bottom: 35px
    .order-title
      width: 100%
      margin-bottom: 20px
      font-size: 20px
      font-weight: 600
    .goods-info
      display: flex
      width: 900px
      color: $black1
      font-size: 18px
      &>span
        width: 90px
      &>p
        width: 800px
    .account-price
      color: $black1
      font-size: 20px
      font-weight: 600
      &>em
        color: $orange
        font-size: 26px
        font-weight: 600
</style>
