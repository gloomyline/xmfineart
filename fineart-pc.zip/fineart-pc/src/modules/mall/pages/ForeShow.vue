<template>
    <page>
      <mall-head :active-nav="2"></mall-head>
      <section class="page-content fore-show">
        <div class="select-box">
          <label class="classify-select-label">搜索</label>
          <i-input v-model="keywords" search placeholder="输入关键词" class="classify-search" @on-search="searchGoods">
            <i-button slot="append" class="classify-search-btn" type="primary" @click="searchGoods(keywords)"><span class="fy-icon-search"></span>搜一下</i-button>
          </i-input>
        </div>
        <i-divider class="divider-line"></i-divider>
        <div class="goods-list-wrap" v-if="goods.data !== undefined && goods.data.length > 0">
          <div class="popular-goods">
            <goods-card class="goods-item" v-for="item in goods.data"
              :key="item.id"
              :route="`/fore-show-detail/${item.id}`"
              :img-src="item.thumbnail">
              <h3>
                <p class="goods-name">{{ item.name }}</p>
                <p class="goods-order"><em>{{ item.reservations }}人</em>已预约</p>
              </h3>
            </goods-card>
          </div>
          <pagination @page-confirm="goToCurrentPage"
                      v-if="!!goods.total"
                      :page="goods.current_page"
                      :total="goods.total"
                      :page-size="goods.per_page"></pagination>
        </div>
        <list-nothing v-else></list-nothing>
      </section>
      <jump-top></jump-top>
    </page>
</template>

<script>
import { Page, MallHead, Pagination, JumpTop, ListNothing, GoodsCard } from 'components'
import { Breadcrumb, BreadcrumbItem, Button, Tabs, TabPane, Input, Divider } from 'iview'
import { scrollTop } from '@/common/js/utils'
import api from 'modules/mall/api'

export default {
  data () {
    return {
      keywords: '',
      goods: {},
      pageConfig: {
        page: 1,
        keywords: '',
        sort: 'id_desc'
      }
    }
  },
  watch: {
    pageConfig: {
      handler: function (newVal) {
        this.fetchForeShowList(newVal)
      },
      deep: true
    }
  },
  created () {
    this.fetchForeShowList(this.pageConfig)
  },
  methods: {
    goToCurrentPage (page) {
      this.pageConfig.page = page.page
    },
    searchGoods (keywords) {
      this.pageConfig.page = 1
      this.pageConfig.keywords = keywords
      this.$nextTick(() => {
        this._scrollTop()
      })
    },
    async fetchForeShowList (params) {
      this.goods = await api.fetchForeShowList(params)
    },
    _scrollTop () {
      const sTop = document.documentElement.scrollTop || document.body.scrollTop
      scrollTop(window, sTop, 0, 800)
    }
  },
  components: {
    Page,
    JumpTop,
    MallHead,
    GoodsCard,
    Pagination,
    ListNothing,
    'i-tabs': Tabs,
    'i-input': Input,
    'i-button': Button,
    'i-divider': Divider,
    'i-tab-pane': TabPane,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem
  }
}
</script>

<style lang="stylus">
.fore-show
  .ivu-select-placeholder,
  .ivu-select-selected-value,
  .ivu-input-wrapper .ivu-input
    font-size: 14px
  .goods-crumb
    margin: 20px 0 30px 0
    .fy-icon-arrow
      vertical-align: middle
    a
      color: $black1
    & > span:last-child
      font-weight: normal
      color: $black1
  .select-box
    display: flex
    margin-top: 30px
    margin-bottom: 30px
    .classify-select-label
      width: 64px
      height: 40px
      margin-right: 20px
      font-size: 16px
      color: $black
      line-height: 40px
      text-align: justify
      /*实现文字两端对齐*/
      &:after
        content: ''
        display: inline-block
        padding-left: 100%
    .classify-search
      width: 360px
      height: 40px
    .classify-search-btn
      width: 112px
      height: 40px
      padding: 0
      color: $white
      font-size: 14px
      background-color: $orange
      border-radius: 0 4px 4px 0
      &>span
        display: flex
        justify-content: center
        align-items: center
        width: 100%
        height: 40px
      .fy-icon-search
        margin-right: 5px
        font-size: 20px
        color: $white
  .divider-line
    margin: 44px 0 27px 0
  .goods-list-wrap
    overflow: hidden
    width: 1200px
    margin-top: 30px
    .popular-goods
      display: flex
      justify-content: flex-start
      flex-flow: row wrap
      margin-right: -13px
      .goods-item
        margin: 0 13px 40px 0
        .goods-name
          text-align: center
          font-weight: normal
          font-size: 18px
          color: $black
          {ellipse}
        .goods-order
          text-align: center
          color: $grey-high
          font-size: 16px
          &>em
            color: $orange
</style>
