<template>
  <div class="payment">
    <i-row class="table-title">
      <i-col span="12">支付方式</i-col>
    </i-row>
    <i-radio-group class="choice-payment" v-model="payment">
      <i-radio label="wechat">
        <img src="@/assets/mall/wechat-pay.png">
      </i-radio>
      <!--<i-radio label="alipay">-->
        <!--<img src="@/assets/mall/alipay.png">-->
      <!--</i-radio>-->
      <!--<i-radio label="bank">-->
        <!--<img src="@/assets/mall/union-pay.png">-->
      <!--</i-radio>-->
    </i-radio-group>
    <i-button class="go-pay" type="primary" size="large" @click="goPay">去付款</i-button>
  </div>
</template>

<script>
import { Row, Col, Button, Radio, RadioGroup } from 'iview'
import api from 'modules/mall/api/index.js'

export default {
  name: 'Payment',
  data () {
    return {
      payment: 'wechat',
      orderCode: this.$route.params.orderCode
    }
  },
  methods: {
    async goPay () {
      let channel
      switch (this.payment) {
      case 'wechat':
        channel = 100
        break
      }
      let response = await api.paymentAdd(this.orderCode, channel)
      if (response.code === 200) {
        this.$router.push({ path: `/pay-home/go-pay/${this.orderCode}/${channel}/${response.results.code}` })
      }
    }
  },
  components: {
    'i-row': Row,
    'i-col': Col,
    'i-radio': Radio,
    'i-button': Button,
    'i-radio-group': RadioGroup
  }
}
</script>

<style lang="stylus">
.payment
  overflow: auto
  .table-title
    height: 52px
    margin: 30px 0 0 0
    border: 1px solid $grey-high4
    background-color: $grey-high5
    .ivu-col
      height: 52px
      color: $grey-high
      line-height: 52px
      font-size: 16px
      padding-left: 20px
      text-align: left
  .choice-payment
    display: flex
    justify-content: space-between
    align-items: center
    width: 100%
    height: 210px
    margin-bottom: 90px
    border: 1px solid $grey-high4
    .ivu-radio-wrapper
      display: flex
      justify-content: center
      align-items: center
      width: 33.33%
    .ivu-radio-inner
      width: 24px
      height: 24px
      &:after
        left: 4px
        top: 4px
        width: 14px
        height: 14px
  .go-pay
    float: right
    width: 180px
    height: 60px
    margin-bottom: 45px
    font-weight: 600
    font-size: 20px
</style>
