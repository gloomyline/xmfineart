<template>
    <page>
      <mall-head></mall-head>
      <section class="page-content goods-detail">
        <i-breadcrumb class="goods-crumb" separator="<span class='fy-icon-arrow'></span>">
          <i-breadcrumb-item><a href="index.html">首页</a></i-breadcrumb-item>
          <i-breadcrumb-item to="/">斐艺购</i-breadcrumb-item>
          <i-breadcrumb-item>{{ goodsDetail.name }}</i-breadcrumb-item>
        </i-breadcrumb>
        <div class="goods-detail-info">
          <div class="detail-picture">
            <mall-carousel :list="goodsDetail.goods_medias"></mall-carousel>
          </div>
          <div class="detail-info">
            <h3 class="goods-name"> {{ goodsDetail.name }} </h3>
            <p class="goods-tag">{{ goodsDetail.subtitle }}</p>
            <div class="goods-price">
              <span>价格</span>
              <div>
                <p class="discount-price" v-if="goodsDetail.price_discount"><em>&yen;</em> {{ goodsDetail.price_discount }}</p>
                <p class="price" :class="{'del-price': goodsDetail.price_discount}"><em>&yen;</em> {{ goodsDetail.price_norm }}</p>
              </div>
            </div>
            <div class="goods-count">
              <span>数量</span>
              <fineart-number
                :item-key="0"
                :count="cartNumber"
                :max="goodsDetail.stock"
                @number-change="editCartNumber"></fineart-number>
            </div>
            <div class="cart-attention">
              <i-button type="primary" size="large" ghost class="add-cart" @click="addToCart">加入购物车</i-button>
              <div class="attention" :class="{ 'has-collected': hasCollected }" @click="changeCollection">
                <span :class="{ 'fy-icon-star-fill-gray': hasCollected, 'fy-icon-star-plain-angle-gray': !hasCollected }"></span>
                <p>{{ collectionText }}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="goods-grid">
          <i-tabs>
            <i-tab-pane label="详情">
              <div class="goods-detail-intro" v-html="goodsDetail.introduction"></div>
            </i-tab-pane>
            <i-tab-pane label="评价">
              <div class="evaluation-wrap" v-if="goodsComments && goodsComments.data && goodsComments.data.length !== 0">
                <div class="evaluation" v-for="(item, pIndex) in goodsComments.data" :key="item.id">
                  <div class="user-info">
                    <div class="user-avatar">
                      <img v-if="!!item.avatar" :src="item.avatar">
                      <span v-else class="fy-icon-head"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>
                    </div>
                    <p class="user-name">{{ item.nickname }}</p>
                  </div>
                  <div class="evaluation-content">
                    <div class="evaluation-level">
                      <i-rate disabled v-model="item.star" custom-icon="fy-icon-star5"></i-rate>
                    </div>
                    <p class="user-evaluation">{{ item.content }}</p>
                    <div class="evaluation-img" :class="['images' + pIndex]" v-viewer="{movable: false, title: [4, () => {return item.content}]}">
                      <ul class="evaluation-img-list">
                        <li class="evaluation-img-item" v-for="(imgUrl, index) in item.images_big" :key="index" @click="show(pIndex)">
                          <img :src="imgUrl">
                        </li>
                      </ul>
                    </div>
                    <p class="evaluation-time">{{ item.created_at }}</p>
                    <p class="store-reply" v-if="item.reply">商家回复：{{ item.reply }}</p>
                  </div>
                </div>
              </div>
              <list-nothing v-else></list-nothing>
              <pagination
                :total="goodsComments.total"
                :page-size="goodsComments.per_page"
                @page-confirm="changePage"></pagination>
            </i-tab-pane>
          </i-tabs>
          <!-- 推广店显示店名，点击不跳转 -->
          <div class="goods-store" v-if="goodsDetail.goods_type === '300'">{{ goodsDetail.store_name }}</div>
          <!-- 其他类型，显示店名，并且能点击跳转 -->
          <router-link
            v-else
            class="goods-store"
            :to="`/store-detail/${goodsDetail.store_id}`">
            {{ goodsDetail.store_name }}
            <span class="fy-icon-arrow-thick"></span>
          </router-link>
        </div>
      </section>
      <jump-top></jump-top>
    </page>
</template>

<script>
import { Page, MallHead, FineartNumber, Pagination, JumpTop, MallCarousel, ListNothing } from 'components'
import { Breadcrumb, BreadcrumbItem, Button, Tabs, TabPane, Rate } from 'iview'
import api from 'modules/mall/api'
import * as MSG from 'assets/data/message.js'

export default {
  props: {
    id: {
      type: String
    },
    store_id: {
      type: String
    }
  },
  data () {
    return {
      apiProcessing: false,
      displayStoreId: '', // 页面显示的店铺ID
      displayStoreName: '', // 页面显示的店铺名称
      hasCollected: false, // 收藏状态
      collectionText: '关注',
      goodsDetail: {},
      cartNumber: 1,
      goodsComments: {},
      commentPageConfig: {
        page: 1,
        goods_id: '',
        store_id: ''
      }
    }
  },
  watch: {
    commentPageConfig: {
      handler (config) {
        this.fetchGoodsComments(config)
      },
      deep: true
    },
    // 监听登录结果，登录成功则更新数据
    isLogin (newVal) {
      if (newVal) {
        this.initGoodsDetail()
      }
    }
  },
  computed: {
    // 实时获取登录状态
    isLogin: function () {
      return this.$store.state.isLogin
    }
  },
  created () {
    // 默认显示在最顶部
    window.scrollTo(0, 0)
    this.initGoodsDetail({
      goods_id: this.id,
      store_id: this.store_id
    })
  },
  methods: {
    show (pIndex) {
      const viewer = this.$el.querySelector('.images' + pIndex).$viewer
      viewer.show()
    },
    async initGoodsDetail (params) {
      this.commentPageConfig.goods_id = this.id
      this.commentPageConfig.store_id = this.store_id
      this.goodsDetail = await api.fetchGoodsDetail(params)
      if (!this.goodsDetail) {
        return false
      }
      this.changeCollectionBtn(this.goodsDetail.has_collected)
      this.goodsDetail.stock = Number.parseInt(this.goodsDetail.stock)
    },
    editCartNumber (itemNum, itemKey) {
      this.cartNumber = itemNum
    },
    // 加入购物车
    async addToCart () {
      if (!this.isLogin) {
        this.$store.commit('SHOW_LOGIN_MODAL')
        return false
      }
      if (this.apiProcessing) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.GLOBAL_PROCESSING, type: 'info' })
        return false
      }
      this.apiProcessing = true
      let response = await api.addToCart({ goodsId: this.id, storeId: this.store_id, num: this.cartNumber })
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_GOODS_ADD_CART_OK, type: 'success' })
        // 更新购物车图标的数量
        this.$store.dispatch('mall/fetchCartGoodsCount')
      }
      this.apiProcessing = false
      return true
    },
    // 变更关注状态
    async changeCollection () {
      if (!this.isLogin) {
        this.$store.commit('SHOW_LOGIN_MODAL')
        return false
      }
      if (this.apiProcessing) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.GLOBAL_PROCESSING, type: 'info' })
        return false
      }
      this.apiProcessing = true
      let code = await api.collectGoods(this.id, this.store_id)
      if (code === 200) {
        this.changeCollectionBtn(!this.hasCollected)
        if (this.hasCollected) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
      }
      this.apiProcessing = false
      return true
    },
    changeCollectionBtn (status) {
      this.hasCollected = status
      this.collectionText = status ? '已关注' : '关注'
    },
    // 变更分页
    changePage (page) {
      this.commentPageConfig.page = page
    },
    // 获取商品的评论列表
    async fetchGoodsComments () {
      this.goodsComments = await api.fetchGoodsComments(this.commentPageConfig)
      if (this.goodsComments && this.goodsComments.data && this.goodsComments.data.length > 0) {
        for (let key in this.goodsComments.data) {
          this.goodsComments.data[key].star = this.calculateStar(this.goodsComments.data[key].score)
        }
      }
    },
    // 评价分数转化成星数
    calculateStar (score) {
      return Number.parseInt(score / 20) + 1
    }
  },
  components: {
    Page,
    JumpTop,
    MallHead,
    Pagination,
    MallCarousel,
    FineartNumber,
    ListNothing,
    'i-tabs': Tabs,
    'i-rate': Rate,
    'i-tab-pane': TabPane,
    'i-button': Button,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem
  }
}
</script>

<style lang="stylus">
.goods-detail
  .goods-detail-info
    display: flex
    justify-content: space-between
    width: 1200px
    margin-bottom: 60px
    .detail-picture
      width: 750px
    .detail-info
      position: relative
      width: 415px
      height: 420px
      .goods-name
        margin-bottom: 16px
        font-size: 28px
        color: $black
      .goods-tag
        margin-bottom: 40px
        font-size: 16px
        color: $black1
      .goods-price
        display: flex
        width: 415px
        margin-bottom: 20px
        &>span
          margin-right: 24px
          font-size: 16px
          line-height: 54px
          color: $black1
        .price, .discount-price
          font-size: 36px
          color: $orange
          &>em
            font-size: 24px
          &.del-price
            font-size: 18px
            text-decoration: line-through
            color: $grey-high1
      .goods-count
        display: flex
        width: 415px
        margin-bottom: 50px
        &>span
          margin-right: 24px
          font-size: 16px
          line-height: 36px
          color: $black1
      .cart-attention
        absolute: left bottom
        display: flex
        .add-cart
          width: 198px
          height: 60px
          margin-right: 10px
          font-size: 20px
        .attention
          display: flex
          flex-wrap: wrap
          justify-content: center
          align-items: center
          width: 82px
          height: 60px
          border: 1px solid $grey-high1
          cursor: pointer
          text-align: center
          font-size: 14px
          color: $grey-high
          border-radius: 4px
          &>span
            font-size: 18px
          .fy-icon-star-fill-gray
            color: $white
          &>p
            width: 100%
          &.has-collected
            border: 1px solid $orange
            color: $white
            background-color: $orange
  .goods-grid
    position: relative
    width: 1200px
    border-right: 1px solid $grey
    border-left: 1px solid $grey
    .ivu-tabs-bar
      margin-bottom: 10px
    .ivu-tabs-nav-wrap
      height: 50px
      background-color: $grey-high2
    .ivu-tabs-ink-bar
      top: 0
      height: 4px
    .ivu-tabs-tab
      width: 138px
      height: 50px
      color: $black1
      font-size: 16px
      line-height: 34px
      text-align: center
      &.ivu-tabs-tab-active
        color: $orange
        background-color: $white
    .goods-detail-intro
      overflow: hidden
      width: 1200px
      padding: 40px 80px
      img
        display: block
        max-width: 100%
        margin: 0 auto
        & + br
          display: none
    .goods-store
      absolute: right 17px top
      display: flex
      align-items: center
      height: 50px
      font-size: 16px
      line-height: 50px
      color: $black1
      &>span
        margin-left: 10px
        vertical-align: middle
    .evaluation
      display: flex
      padding: 20px 0
      border-bottom: 1px solid $grey
      .ivu-rate-star-chart.ivu-rate-star-full .ivu-rate-star-second
        color: $yellow
      &:last-child
        border-bottom: 0
      .user-info
        display: flex
        flex-direction: column
        align-items: center
        width: 126px
        .user-avatar
          width: 50px
          height: 50px
          margin-bottom: 10px
          border-radius: 100px
          &>img
            width: 100%
            height: 100%
            border-radius: 100px
          &>span
            font-size: 50px
        .user-name
          text-align: center
          color: $black1
          font-size: 14px
      .evaluation-content
        width: 948px
        .evaluation-level
          width: 100%
          margin-bottom: 10px
          font-size: 16px
        .user-evaluation
          color: $black
          font-size: 16px
        .evaluation-time
          margin: 10px 0
          color: $grey-high
          font-size: 14px
        .store-reply
          padding: 14px
          background-color: $grey-high2
        .evaluation-img
          width: 948px
          margin-top: 20px
          overflow: hidden
          .evaluation-img-list
            display: flex
            flex-flow: wrap
            margin-right: -21.6px
            .evaluation-img-item
              position: relative
              width: 140px
              height: 140px
              margin-right: 21.6px
              border: 1px solid $border-grey
              img
                absolute: left  50% top 50%
                max-width: 100%
                max-height: 100%
                width: 80px
                height: 80px
                transform: translate(-50%, -50%)
</style>
