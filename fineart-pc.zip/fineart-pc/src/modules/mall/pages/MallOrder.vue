<template>
  <page>
    <mall-head></mall-head>
    <section class="page-content mall-order">
      <i-row class="table-title">
        <i-col span="12" class="goods-info">收货信息</i-col>
      </i-row>
      <div class="address-info">
        <div class="address-choice" v-if="address">
          <div class="address-cell">
            <span class="span-label">收货人</span>:
            <span class="cell-content">{{ address.name }}</span>
          </div>
          <div class="address-cell">
            <span class="span-label">联系方式</span>:
            <span class="cell-content">{{ address.mobile }}</span>
          </div>
          <div class="address-cell">
            <span class="span-label">收货地址</span>:
            <span class="cell-content">{{ address.address_desc }}</span>
          </div>
        </div>
        <div class="address-selected">
          <i-button type="primary" ghost class="choice-address" @click="showModal('choice')">选择地址</i-button>
          <i-button class="add-address" @click="showModal('add')">添加新地址</i-button>
        </div>
      </div>
      <i-row class="table-title">
        <i-col span="12" class="goods-info">商品信息</i-col>
        <i-col span="3">单价</i-col>
        <i-col span="3">数量</i-col>
        <i-col span="3">小计</i-col>
      </i-row>
      <div class="shopping-list margin-no" v-show="shoppingCart.data">
        <i-row v-for="item in shoppingCart.data" :key="item.id">
          <i-col span="12" class="goods-intro">
            <router-link class="goods-img" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">
              <img :src="item.thumbnail_cdn" alt="">
            </router-link>
            <router-link class="goods-name" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">{{ item.name }}</router-link>
          </i-col>
          <i-col span="3">
            <span class="unit-price">&yen;{{ item.price_discount ? item.price_discount : item.price_norm }}</span>
          </i-col>
          <i-col span="3"><span>{{ item.number }}</span></i-col>
          <i-col span="3">
            <span>&yen;{{ item.number * parseFloat(item.price_discount ? item.price_discount : item.price_norm) }}</span>
          </i-col>
        </i-row>
      </div>
      <div class="account">
        <div class="account-step">
          <p>合计金额: &yen;{{ shoppingCart.price_total }}</p>
          <p>运费: &yen;{{ shoppingCart.freight }}</p>
          <i-divider class="account-divider" type="horizontal" :dashed="true"></i-divider>
          <p class="amount-price">实付: <em>&yen;{{ shoppingCart.price_pay }}</em></p>
          <i-button class="go-pay" type="primary" size="large" @click="goPay">去付款</i-button>
        </div>
      </div>
    </section>
    <mall-address :type-show="modal.typeShow"
                  v-model="modal.isShowed"
                  @select-address="changeAddress"
                  @change="addAddress"
                  :title-word="modal.title"></mall-address>
  </page>
</template>

<script>
import { Page, MallHead, MallAddress } from 'components'
import { Row, Col, Button, Divider } from 'iview'
import api from 'modules/mall/api/index.js'
import memberApi from 'modules/member/api/index.js'

export default {
  name: 'MallOrder',
  data () {
    return {
      modal: {
        isShowed: false,
        typeShow: 'add',
        title: '添加收货地址'
      },
      shoppingCart: {},
      address: {},
      cartIds: []
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.cartIds = this.$store.state.mall.cartItemIdArr
      this.address = await memberApi.addressFetchDefault()
      if (!this.address) {
        this.modal.isShowed = true
      }
      this.shoppingCart = await api.cartCheckout(this.cartIds)
    },
    // 添加完地址 触发地址事件
    async addAddress () {
      this.address = await memberApi.addressFetchDefault()
    },
    showModal (type) {
      this.modal = {
        isShowed: true,
        typeShow: type
      }
      if (type === 'add') {
        this.modal.title = '添加收货地址'
      } else {
        this.modal.title = '选择地址'
      }
    },
    async goPay () {
      let response = await api.orderAdd(this.cartIds, this.address.id)
      if (response.code === 200) {
        this.$router.push({ path: `/pay-home/payment/${response.results.code}` })
      }
    },
    async changeAddress (item) {
      this.address = item
    }
  },
  components: {
    Page,
    MallHead,
    MallAddress,
    'i-row': Row,
    'i-col': Col,
    'i-button': Button,
    'i-divider': Divider
  }
}
</script>

<style lang="stylus">
.mall-order
  padding-top: 40px
  .table-title
    height: 52px
    margin: 30px 0 0 0
    border: 1px solid $grey-high4
    background-color: $grey-high5
    .ivu-col
      height: 52px
      color: $grey-high
      line-height: 52px
      text-align: center
      font-size: 16px
      &.goods-info
        padding-left: 20px
        text-align: left
  .shopping-list
    margin-bottom: 20px
    border-bottom: 1px solid $grey-high4
    border-right: 1px solid $grey-high4
    border-left: 1px solid $grey-high4
    &.margin-no
      margin: 0
    .ivu-row
      height: 140px
    .ivu-col
      display: flex
      justify-content: center
      align-items: center
      height: 140px
      font-size: 18px
      &.goods-intro
        justify-content: flex-start
    .goods-img
      width: 100px
      height: 100px
      padding-left: 20px
      margin-right: 40px
      &>img
        width: 100px
        height: 100px
    .goods-name
      color: $black
      line-height: 25px
    .unit-price
      color: $black1
    .opera-delete
      color: $grey-high1
      font-size: 16px
      &:focus
        box-shadow: none
    .lose-tag
      padding: 1px 10px
      font-size: 14px
      color: $white
      background-color: $grey-light1
      border-radius: 4px
  .address-info
    display: flex
    justify-content: center
    width: 1200px
    height: 158px
    padding: 30px
    border: 1px solid $grey-high4
    border-top: none
    position: relative
    top: -1px
    .address-choice
      width: 844px
      border-right: 1px dashed $grey-high4
    .address-cell
      display: flex
      height: 22px
      margin-bottom: 16px
      color: $grey-high
      font-size: 16px
      .span-label
        width: 70px
        margin-bottom: 16px
        color: $grey-high
        text-align: justify
        /*实现文字两端对齐*/
        &:after
          content: ''
          display: inline-block
          padding-left: 100%
      .cell-content
        margin-left: 16px
        color: $black
    .address-selected
      display: flex
      flex-direction: column
      justify-content: center
      align-items: center
      align-content: center
      width: 326px
      .choice-address
        width: 116px
        margin-bottom: 13px
        color: $orange
        font-size: 16px
        &:focus
          box-shadow: none
      .add-address
        width: 116px
        border: 1px solid $grey-high1
        font-size: 16px
  .account
    display: flex
    justify-content: flex-end
    width: 1200px
    margin-bottom: 30px
    padding: 30px
    border-bottom: 1px solid $grey-high4
    border-right: 1px solid $grey-high4
    border-left: 1px solid $grey-high4
    background-color: $grey-high5
    .account-step
      font-size: 16px
      .account-divider
        width: 180px
        height: 2px
        border-color: $grey-light2
      &>p
        text-align: right
        color: $black1
        margin-bottom: 10px
        &.amount-price
          font-size: 20px
          margin: 18px 0
          font-weight: 600
          &>em
            font-weight: 600
            color: $orange
      .go-pay
        width: 180px
        height: 60px
        font-weight: 600
        font-size: 20px
</style>
