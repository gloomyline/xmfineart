<template>
  <page class="mall-pages">
    <mall-head :active-nav="0"></mall-head>
    <i-carousel v-model="carouselIndex" loop autoplay :autoplay-speed="4000"  arrow="always" class="swiper-wrap">
      <i-carousel-item v-for="(item, index) in adsList" :key="index">
        <a :href="item.link_url" class="carousel-banner" :style="{backgroundImage: `url(${item.image_url})`}"></a>
      </i-carousel-item>
    </i-carousel>
    <!--推荐商品-->
    <section class="page-content">
      <div class="common-subtitle">
        <h3>推荐商品<span>品质材料和服务在线市场</span></h3>
        <router-link class="more" to="/goods-list">更多 <span class="fy-icon-arrow-thick"></span></router-link>
      </div>
      <!--推荐商品-->
      <div class="popular-goods">
        <goods-card class="goods-item" v-for="item in recommendGoods"
          :key="item.object_id"
          :route="`/goods-detail/${item.object_id}/${item.store_id}`"
          :img-src="item.thumbnail">
          <h3>
            <p class="goods-name">{{ item.name }}</p>
          </h3>
        </goods-card>
      </div>
      <div class="common-subtitle">
        <h3>新品预告<span>建筑行业新科技</span></h3>
        <router-link to="/fore-show" class="more">更多 <span class="fy-icon-arrow-thick"></span></router-link>
      </div>
      <!--新品预告-->
      <div class="popular-goods">
        <goods-card class="goods-item" v-for="item in recommendFore"
          color="#fff"
          :key="item.object_id"
          :route="`/fore-show-detail/${item.object_id}`"
          :img-src="item.thumbnail">
          <h3>
            <p class="goods-name">{{ item.name }}</p>
          </h3>
        </goods-card>
      </div>
      <div class="common-subtitle">
        <h3>优秀店铺<span>严选行业优秀店铺</span></h3>
        <router-link to="/store" class="more">更多 <span class="fy-icon-arrow-thick"></span></router-link>
      </div>
      <!--优秀店铺-->
      <div class="popular-store">
        <div class="store-card" v-for="item in recommendStore" :key="item.object_id">
          <router-link :to="`/store-detail/${item.object_id}`">
            <div class="store-img">
              <img :src="item.thumbnail | imgFilter">
              <h3>
                <p class="store-name">{{ item.name }}</p>
              </h3>
            </div>
          </router-link>
        </div>
      </div>
    </section>
    <jump-top></jump-top>
  </page>
</template>

<script>
import { MallHead, Page, JumpTop, GoodsCard } from 'components'
import { Carousel, CarouselItem } from 'iview'

import api from 'modules/mall/api/index.js'

export default {
  data () {
    return {
      classify: '',
      carouselIndex: 0,
      adsList: [],
      recommendGoods: [],
      recommendFore: [],
      recommendStore: []
    }
  },
  filters: {
    imgFilter: (value) => {
      if (!value) {
        return require('assets/logo-copy.png')
      } else {
        return value
      }
    }
  },
  created () {
    this.initAdsList()
    this.initRecommendGoods()
    this.initRecommendFore()
    this.initRecommendStore()
  },
  methods: {
    getCategory (index) {
      this.classify = index
    },
    async initAdsList () {
      this.adsList = await api.fetchAdsList()
    },
    async initRecommendGoods () {
      this.recommendGoods = await api.fetchRecommend({ position: 100 })
    },
    async initRecommendFore () {
      this.recommendFore = await api.fetchRecommend({ position: 300 })
    },
    async initRecommendStore () {
      this.recommendStore = await api.fetchRecommend({ position: 200 })
    }
  },
  components: {
    Page,
    JumpTop,
    MallHead,
    GoodsCard,
    'i-carousel': Carousel,
    'i-carousel-item': CarouselItem
  }
}
</script>

<style lang="stylus">
.mall-pages
  .swiper-wrap
    width: 100%
    height: 500px
    margin-bottom: 90px
    text-align center
    background-color: rgba(0, 0, 0, 0.02)
    .ivu-carousel-arrow
      width: 56px
      height: 56px
      opacity: 0.7
      z-index: 4
      &.left
        left: 170px
      &.right
        right: 170px
      .ivu-icon
        font-size: 34px
    .ivu-carousel-dots li button
      width: 26px
      height: 4px
      background: rgba(255, 255, 255, 0.6)
    .ivu-carousel-dots .ivu-carousel-active button
      background-color: $orange
    .carousel-banner
      display: block
      width: 100%
      height: 500px
      background-position: center center
      background-repeat: no-repeat
      background-size: cover
  .common-subtitle
    display: flex
    justify-content: space-between
    h3
      color: $black
      font-size: 22px
      span
        color: $black1
        font-size: 14px
        margin-left: 30px
    .more
      color: $black1
      font-size: 18px
  .popular-goods
    display: flex
    justify-content: space-between
    margin: 40px 0 90px 0
    .goods-fore
      background-color: $white
    .goods-name
      text-align: center
      font-weight: normal
      font-size: 18px
      color: $black
      {ellipse}
  .popular-store
    display: flex
    justify-content: space-between
    margin: 40px 0 90px 0
    .store-card
      width: 254px
      .store-img
        position: relative
        height: 254px
        margin-bottom: 20px
        img
          absolute: left 50% top 50%
          max-width: 100%
          max-height: 100%
          transform: translate(-50%, -50%)
          z-index: 1
        .store-name
          absolute: left bottom
          width: 100%
          height: 44px
          padding: 0 14px
          text-align: center
          font-weight: normal
          font-size: 18px
          color: $white
          line-height: 44px
          background-color: rgba(51, 51, 51, 0.5)
          z-index: 2
          {ellipse}
</style>
