<template>
  <page>
    <mall-head></mall-head>
    <section class="page-content mall-cart">
      <i-row class="table-title">
        <i-col span="12" class="goods-info">商品信息</i-col>
        <i-col span="3">单价</i-col>
        <i-col span="3">数量</i-col>
        <i-col span="3">小计</i-col>
        <i-col span="3">操作</i-col>
      </i-row>
      <div class="shopping-list">
        <i-row v-for="(item, index) in okCartItems" :key="index" :data-item-id="item.id" :data-index="index">
          <i-col span="2">
            <i-checkbox class="shopping-checked" v-model="item.isChecked"></i-checkbox>
          </i-col>
          <i-col span="10" class="goods-intro">
            <router-link class="goods-img" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">
              <img :src="item.thumbnail_cdn">
            </router-link>
            <router-link class="goods-name" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">{{ item.name }}</router-link>
          </i-col>
          <i-col span="3" class="price-box">
            <span class="discount-price" v-show="item.price_discount">&yen;{{ item.price_discount }}</span>
            <span class="unit-price" :class="{'del-price': item.price_discount}">&yen;{{ item.price_norm }}</span>
          </i-col>
          <i-col span="3">
            <fineart-number
              :item-key="index"
              :count="item.number"
              :max="item.stock"
              :disabled="item.disabled"
              :editable="true"
              @number-change="editItemNumber"></fineart-number>
          </i-col>
          <i-col span="3">
            <span class="amount-price">&yen;{{ item.subPayTotal }}</span>
          </i-col>
          <i-col span="3">
            <i-button type="text" ghost class="opera-delete"  @click="deleteOkItem(index)">删除</i-button>
          </i-col>
        </i-row>
      </div>
      <h3 class="lose-text" v-show="ngCartItems.length > 0">以下商品已失效</h3>
      <div class="shopping-list" v-show="ngCartItems.length > 0">
        <i-row v-for="(item, index) in ngCartItems" :key="index" :data-item-id="item.id" :data-index="index">
          <i-col span="2">
            <span class="lose-tag">下架</span>
          </i-col>
          <i-col span="10" class="goods-intro">
            <router-link class="goods-img" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">
              <img :src="item.thumbnail_cdn">
            </router-link>
            <router-link class="goods-name"  :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">{{ item.name }}</router-link>
          </i-col>
          <i-col span="3" class="price-box">
            <span class="discount-price" v-if="item.price_discount">&yen;{{ item.price_discount }}</span>
            <span class="unit-price" :class="{'del-price': item.price_discount}">&yen;{{ item.price_norm }}</span>
          </i-col>
          <i-col span="3">
            <fineart-number
              :item-key="index"
              :count="item.number"
              :max="item.stock"
              :disabled="true"></fineart-number>
          </i-col>
          <i-col span="3">
            <span class="amount-price">&yen;{{ item.subPayTotal }}</span>
          </i-col>
          <i-col span="3">
            <i-button type="text" ghost class="opera-delete" @click="deleteNgItem(index)">删除</i-button>
          </i-col>
        </i-row>
      </div>
      <div class="footer-fixed" ref="point"
           v-show="okCartItems.length > 0 || ngCartItems.length > 0">
        <i-row class="table-footer" :style="fixStyle">
          <i-col span="3" class="is-all-checked">
            <i-checkbox class="shopping-checked" v-model="isAllChecked"><span class="is-all-text">全选</span></i-checkbox>
          </i-col>
          <i-col span="3"><i-button type="text" ghost class="ghost-btn" @click="deleteOkItemList">删除已选</i-button></i-col>
          <i-col span="18" class="account-wrap">
            <p class="total-price">总计: &yen;{{ total }}</p>
            <p class="out-of-price">实付: <em>&yen;{{ payTotal }}</em></p>
            <i-button class="go-order-confirm" @click="goOrderConfirm">去结算</i-button>
          </i-col>
        </i-row>
      </div>
      <list-nothing v-if="okCartItems.length === 0 && ngCartItems.length == 0"></list-nothing>
    </section>
  </page>
</template>

<script>
import { Page, MallHead, FineartNumber, ListNothing } from 'components'
import { Col, Row, Checkbox, Button, Affix } from 'iview'
import { on, off } from 'iview/src/utils/dom.js'
import api from 'modules/mall/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'MallCart',
  data () {
    return {
      fixStyle: {},
      isAllChecked: true,
      apiProcessing: false, // API请求处理中
      total: 0, // 总计
      payTotal: 0, // 实付
      // 有效商品
      okCartItems: [],
      // 失效商品
      ngCartItems: []
    }
  },
  mounted () {
    on(window, 'scroll', this.handleScroll)
    on(window, 'resize', this.handleScroll)
    this.handleScroll()
  },
  beforeDestroy () {
    off(window, 'scroll', this.handleScroll)
    off(window, 'resize', this.handleScroll)
  },
  created () {
    if (this.isLogin) {
      this.fetchCartItemList()
    } else {
      this.$store.commit('SHOW_LOGIN_MODAL')
    }
  },
  watch: {
    okCartItems: {
      handler () {
        this.calculateTotalAndChecked()
      },
      deep: true
    },
    isAllChecked (newVal) {
      if (newVal) {
        this.checkAll(newVal)
      } else {
        let flag = 0
        for (let key in this.okCartItems) {
          flag += this.okCartItems[key].isChecked
        }
        if (flag === this.okCartItems.length) {
          this.checkAll(newVal)
        }
      }
    },
    // 监听登录结果
    isLogin (newVal) {
      if (newVal) {
        this.fetchCartItemList()
      }
    }
  },
  computed: {
    // 实时获取登录状态
    isLogin: function () {
      return this.$store.state.isLogin
    }
  },
  methods: {
    // 加载购物车商品
    async fetchCartItemList () {
      let cartItemList = await api.fetchCartItemList()
      if (!cartItemList || !cartItemList.data || cartItemList.data.length === 0) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_EMPTY, type: 'info' })
        return false
      }
      let cartItems = cartItemList.data
      for (let key in cartItems) {
        cartItems[key].disabled = false
        cartItems[key].delete = false // 是否要被删除
        cartItems[key].number = Number.parseInt(cartItems[key].number)
        cartItems[key].stock = Number.parseInt(cartItems[key].stock)
        cartItems[key].price_norm = Number.parseFloat(cartItems[key].price_norm)
        cartItems[key].price_discount = Number.parseFloat(cartItems[key].price_discount)
        // 正常价格小计
        cartItems[key].subTotal = cartItems[key].number * cartItems[key].price_norm
        // 实际价格（折扣价）小计
        if (cartItems[key].price_discount) {
          cartItems[key].subPayTotal = cartItems[key].number * cartItems[key].price_discount
        } else {
          cartItems[key].subPayTotal = cartItems[key].subTotal
        }
        // 以ID作为数组索引，分别放入有效和无效的商品数组
        if (cartItems[key].status === '300' && cartItems[key].stock > 0) {
          cartItems[key].isChecked = true
          this.okCartItems.push(cartItems[key])
        } else {
          cartItems[key].isChecked = false
          this.ngCartItems.push(cartItems[key])
        }
      }
    },
    // 计算总计、实付、选中状态、全选状态
    calculateTotalAndChecked () {
      this.total = 0
      this.payTotal = 0
      this.isAllChecked = true
      for (let key in this.okCartItems) {
        if (this.okCartItems[key].isChecked) {
          this.total += this.okCartItems[key].subTotal
          this.payTotal += this.okCartItems[key].subPayTotal
        } else {
          this.isAllChecked = false
        }
      }
    },
    // 全选/反选
    checkAll (val) {
      for (let key in this.okCartItems) {
        this.okCartItems[key].isChecked = val
      }
    },
    // 单个商品编辑数量
    async editItemNumber (itemNum, itemKey) {
      let curItem = this.okCartItems[itemKey]
      if (this.apiProcessing) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.GLOBAL_PROCESSING, type: 'info' })
        this.okCartItems[itemKey] = curItem
        return false
      }
      this.apiProcessing = true
      // 先把数据变化反馈到页面上
      this.okCartItems[itemKey].disabled = true
      this.okCartItems[itemKey].number = itemNum
      this.okCartItems[itemKey].subTotal = itemNum * curItem.price_norm
      if (curItem.price_discount) {
        this.okCartItems[itemKey].subPayTotal = itemNum * curItem.price_discount
      } else {
        this.okCartItems[itemKey].subPayTotal = this.okCartItems[itemKey].subTotal
      }
      // 发起API请求
      let response = await api.editCartItem({id: curItem.id, num: itemNum})
      if (response.code !== 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_EDIT_FAILED, type: 'error' })
        // 请求失败，数据复原
        this.okCartItems[itemKey] = curItem
      }
      this.okCartItems[itemKey].disabled = false
      this.apiProcessing = false
      return true
    },
    // 删除单个有效商品
    async deleteOkItem (itemKey) {
      this.okCartItems[itemKey].disabled = true
      this.okCartItems[itemKey].delete = true
      // 发起API请求
      let result = await this.sendDeleteItem()
      if (result) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_DELETE_OK, type: 'success' })
      } else {
        this.okCartItems[itemKey].disabled = false
      }
      return result
    },
    // 删除多个有效商品
    async deleteOkItemList () {
      for (let key in this.okCartItems) {
        if (this.okCartItems[key].isChecked) {
          this.okCartItems[key].disabled = true
          this.okCartItems[key].delete = true
        }
      }
      // 发起API请求
      let result = await this.sendDeleteItem()
      if (result) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_DELETE_OK, type: 'success' })
      } else {
        for (let key in this.okCartItems) {
          if (this.okCartItems[key].isChecked) {
            this.okCartItems[key].disabled = false
          }
        }
      }
      return result
    },
    // 删除单个无效商品
    async deleteNgItem (itemKey) {
      this.ngCartItems[itemKey].delete = true
      // 发起API请求
      let result = await this.sendDeleteItem()
      if (result) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_DELETE_OK, type: 'success' })
      }
      return true
    },
    // 发送删除商品请求
    async sendDeleteItem () {
      if (this.apiProcessing) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.GLOBAL_PROCESSING, type: 'info' })
        return false
      }
      this.apiProcessing = true
      // 获取要删除有效的商品ID
      let okIdArr = this.getItemIdArr(this.okCartItems)
      let ngIdArr = this.getItemIdArr(this.ngCartItems)
      let deleteIdArr = okIdArr.concat(ngIdArr)
      let response = await api.delCartItem(deleteIdArr)
      if (response.code === 200) {
        // 本地删除有效的商品
        this.okCartItems = this.clearDeletedItems(this.okCartItems)
        // 本地删除无效的商品
        this.ngCartItems = this.clearDeletedItems(this.ngCartItems)
        this.apiProcessing = false
        // 更新 store mall 模块中购物车商品种类数量
        this.$store.dispatch('mall/fetchCartGoodsCount')
        return true
      } else {
        // 恢复商品的删除状态
        for (let key in this.okCartItems) {
          this.okCartItems[key].delete = false
        }
        for (let key in this.ngCartItems) {
          this.ngCartItems[key].delete = false
        }
        this.apiProcessing = false
        return false
      }
    },
    // 清除商品数组中要被删除的商品
    clearDeletedItems (items) {
      let itemList = []
      for (let key in items) {
        if (items[key].delete === false) {
          itemList.push(items[key])
        }
      }
      return itemList
    },
    // 获取商品的ID数组
    getItemIdArr (items) {
      let idArr = []
      for (let key in items) {
        if (items[key].delete) {
          idArr.push(items[key].id)
        }
      }
      return idArr
    },
    // 去确认订单(把当前选中的商品放入确认订单用的购物车ID数组)
    goOrderConfirm () {
      let cartItemIdArr = []
      for (let key in this.okCartItems) {
        if (this.okCartItems[key].isChecked) {
          cartItemIdArr.push(this.okCartItems[key].id)
        }
      }
      if (cartItemIdArr.length === 0) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_CHECKOUT_EMPTY, type: 'error' })
        return false
      }
      this.$store.commit('mall/MALL_CART_ITEM_ID_ARR', cartItemIdArr)
      this.$router.push({ path: '/mall-order' })
    },
    // 底部菜单栏固定效果
    getScroll (target, top) {
      const prop = top ? 'pageYOffset' : 'pageXOffset'
      const method = top ? 'scrollTop' : 'scrollLeft'
      let ret = target[prop]
      if (typeof ret !== 'number') {
        ret = window.document.documentElement[method]
      }
      return ret
    },
    getOffset (element) {
      const rect = element.getBoundingClientRect()
      const scrollTop = this.getScroll(window, true)
      const docEl = window.document.body
      const clientTop = docEl.clientTop || 0
      return {
        top: rect.top + scrollTop - clientTop
      }
    },
    handleScroll () {
      const scrollTop = this.getScroll(window, true)
      const elOffset = this.getOffset(this.$refs.point)
      const windowHeight = window.innerHeight
      const elHeight = this.$refs.point.offsetHeight
      // Fixed Bottom
      if ((elOffset.top + elHeight) > (scrollTop + windowHeight)) {
        this.fixStyle = {
          position: 'fixed',
          bottom: '0px'
        }
      } else if ((elOffset.top + elHeight) < (scrollTop + windowHeight)) {
        this.fixStyle = null
      }
    }
  },
  components: {
    Page,
    MallHead,
    ListNothing,
    FineartNumber,
    'i-col': Col,
    'i-row': Row,
    'i-affix': Affix,
    'i-button': Button,
    'i-checkbox': Checkbox
  }
}
</script>

<style lang="stylus">
.mall-cart
  .table-title
    height: 52px
    margin: 30px 0 16px 0
    border: 1px solid $grey-high4
    background-color: $grey-high5
    .ivu-col
      height: 52px
      color: $black
      line-height: 52px
      text-align: center
      font-size: 16px
      &.goods-info
        padding-left: 165px
        text-align: left
  .shopping-list
    margin-bottom: 30px
    border-top: 1px solid $grey-high5
    border-right: 1px solid $grey-high5
    border-left: 1px solid $grey-high5
    .ivu-row
      height: 140px
      border-bottom: 1px solid $grey-high5
    .ivu-col
      display: flex
      justify-content: center
      align-items: center
      height: 140px
      &.price-box
        flex-direction: column
      &.goods-intro
        justify-content: flex-start
    .goods-img
      width: 100px
      height: 100px
      margin-right: 40px
      &>img
        width: 100px
        height: 100px
    .goods-name
      color: $black
      font-size: 18px
      line-height: 25px
    .unit-price
      display: block
      color: $black1
      font-size: 18px
      &.del-price
        text-decoration: line-through
        color: $grey-high1
        font-size: 16px
    .discount-price
      display: block
      color: $black1
      font-size: 18px
    .amount-price
      color: $orange
      font-size: 18px
    .opera-delete
      color: $grey-high1
      font-size: 16px
      &:focus
        box-shadow: none
    .lose-tag
      padding: 1px 10px
      font-size: 14px
      color: $white
      background-color: $grey-light1
      border-radius: 4px
  .shopping-checked
    display: flex
    align-items: center
    .ivu-checkbox, .ivu-checkbox-inner
      width: 24px
      height: 24px
      border-radius: 4px
      &:after
        left: 7px
        width: 7px
        height: 14px
  .lose-text
    margin-bottom: 16px
    font-size: 16px
    color: $grey-high
  .table-footer
    display: flex
    align-items: center
    width: 1200px
    height: 60px
    border: 1px solid $grey-high4
    background-color: $grey-high5
    transition: all .4s esae-in-out
    z-index: 11
    &.fixed-bottom
      bottom: -1px
    .is-all-checked
      display: flex
      justify-content: center
      .is-all-text
        margin-left: 16px
        color: $black
        font-size: 16px
        line-height: 24px
    .ghost-btn
      color: $black
      font-size: 16px
      &:focus
        box-shadow: none
    .account-wrap
      display: flex
      justify-content: flex-end
      align-items: center
      .total-price
        margin-right: 30px
        color: $black1
        font-size: 16px
      .out-of-price
        margin-right: 20px
        color: $black1
        font-size: 20px
        & > em
          color: $orange
      .go-order-confirm
        width: 180px
        height: 60px
        font-size: 20px
        color: $white
        text-align: center
        border: none
        border-radius: 0
        background-color: $orange
</style>
