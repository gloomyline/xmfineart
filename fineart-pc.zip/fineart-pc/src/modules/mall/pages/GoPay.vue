<template>
  <div class="go-pay-page">
    <i-row class="table-title">
      <i-col span="12">{{ payment }}</i-col>
    </i-row>
    <div class="content-box">
      <div class="scan-qr" @click="refreshQrcode">
        <img :src="qrcode" alt="">
        <p class="tips-word">扫一扫支付</p>
        <p class="tips-due">(如提示二维码过期，请点击刷新)</p>
      </div>
      <div class="tips-picture">
        <img src="@/assets/mall/scan.png" alt="">
      </div>
    </div>
    <i-button class="go-choice" type="text" size="large" @click="goChoice">选择其他支付方式 >></i-button>
  </div>
</template>

<script>
import { Row, Col, Button } from 'iview'
import api from 'modules/mall/api/index.js'

export default {
  name: 'GoPay',
  data () {
    return {
      payment: '',
      qrcode: '',
      orderCode: this.$route.params.orderCode,
      channel: this.$route.params.channel,
      paymentCode: this.$route.params.paymentCode
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      switch (this.channel) {
      case '100':
        this.payment = '微信支付'
        break
      }
      this.refreshQrcode()
      this.checker = setInterval(() => {
        this.checkPayResult()
      }, 2000)
    },
    async refreshQrcode () {
      let results = await api.wechatQrcode(this.paymentCode)
      this.qrcode = results.qrcode
    },
    async checkPayResult () {
      let response = await api.paymentVerification(this.paymentCode)
      if (response.code === 200) {
        switch (response.results.status) {
        case '300':
          this.$router.push({path: `/pay-home/pay-result/${this.orderCode}/100`})
          clearInterval(this.checker)
          break
        case '400':
          this.$router.push({path: `/pay-home/pay-result/${this.orderCode}/200`})
          clearInterval(this.checker)
          break
        }
      }
    },
    goChoice () {
      this.$router.push({path: `/pay-home/payment/${this.orderCode}`})
    }
  },
  components: {
    'i-row': Row,
    'i-col': Col,
    'i-button': Button
  }
}
</script>

<style lang="stylus">
.go-pay-page
  overflow: auto
  .table-title
    height: 52px
    margin: 30px 0 0 0
    border: 1px solid $grey-high4
    background-color: $grey-high5
    .ivu-col
      height: 52px
      color: $grey-high
      line-height: 52px
      text-align: center
      font-size: 16px
      padding-left: 20px
  .content-box
    display: flex
    justify-content: center
    align-items: center
    width: 100%
    height: 495px
    margin-bottom: 45px
    border: 1px solid $grey-high4
    .scan-qr
      display: flex
      flex-direction: column
      align-items: center
      margin-right: 160px
      &>img
        width: 182px
        height: 182px
        margin-bottom: 26px
      .tips-word
        margin-bottom: 12px
        color: $black1
        font-size: 20px
        text-align: center
      .tips-due
        color: $grey-high
        font-size: 16px
        text-align: center
    .tips-picture
      width: 280px
      &>img
        width: 100%
  .go-choice
    float: right
    margin-bottom: 45px
    font-weight: 600
    font-size: 20px
    color: $black1
</style>
