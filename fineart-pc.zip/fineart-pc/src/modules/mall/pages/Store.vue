<template>
 <page>
   <mall-head :active-nav="3"></mall-head>
   <section class="page-content offline-store">
     <div class="classify-select">
       <div class="select-box">
         <label class="classify-select-label">店铺类型</label>
         <ul class="goods-attribute">
           <li class="attribute-item"
               :class="{'is-attribute': item.value === pageConfig.category_id}"
               v-for="(item, index) in categoryList"
               :key="index"
               @click="changeCategory(item.value)">{{ item.label }}</li>
         </ul>
       </div>
       <fineart-cascader label="地区"
                         :data="areaList"
                         placeholder="请选择地区"
                         @change-category="changeArea"></fineart-cascader>
       <div class="select-box">
         <label class="classify-select-label">搜索</label>
         <i-input search placeholder="输入关键词" class="classify-search" @on-search="searchStore" v-model="keywords">
           <i-button slot="append" class="classify-search-btn" type="primary" @click="searchStore(keywords)"><span class="fy-icon-search"></span>搜一下</i-button>
         </i-input>
       </div>
     </div>
     <i-menu mode="horizontal" active-name="default" @on-select="changeSort" class="goods-list-nav">
       <i-menu-item name="default">综合排序</i-menu-item>
       <i-menu-item name="false" disabled class="nav-divider"><i-divider type="vertical"></i-divider></i-menu-item>
       <i-menu-item name="views_desc">查看次数</i-menu-item>
     </i-menu>
     <div class="store-wrap" v-if="storeList.data && storeList.data.length !== 0">
       <div class="store-list">
         <goods-card class="store-item" v-for="item in storeList.data"
           :key="item.id"
           :route="`/store-detail/${item.id}`"
           :img-src="item.thumbnail"
           size="254">
           <div class="store-info">
             <p class="store-name">{{ item.name }}</p>
             <span class="subtitle">{{ item.subtitle }}</span>
             <p class="store-tag">{{ item.category_line }}</p>
             <i-divider class="store-info-line"></i-divider>
             <p class="address"><span class="fy-icon-address"></span>{{ item.area_line }}</p>
           </div>
         </goods-card>
       </div>
       <pagination :total="storeList.total"
                   :page="storeList.current_page"
                   @page-confirm="changePage"
                   :page-size="storeList.per_page"></pagination>
     </div>
     <list-nothing v-else></list-nothing>
   </section>
   <jump-top></jump-top>
 </page>
</template>

<script>
import { Select, Option, Input, Button, Menu, MenuItem, Divider } from 'iview'
import { Page, MallHead, JumpTop, Pagination, ListNothing, GoodsCard, FineartCascader } from 'components'
import { getStoreCategory, getArea } from '@/common/js/loadScript.js'
import { scrollTop } from '@/common/js/utils'
import api from 'modules/mall/api'

export default {
  name: 'store',
  data () {
    return {
      keywords: '',
      categoryList: [],
      areaList: [],
      storeList: {},
      pageConfig: {
        page: 1,
        keywords: '',
        category_id: '',
        area_id: 1,
        sort: 'default'
      }
    }
  },
  created () {
    this.init()
    this.fetchStoreList(this.pageConfig)
  },
  watch: {
    pageConfig: {
      handler (config) {
        this.fetchStoreList(config)
      },
      deep: true
    }
  },
  methods: {
    async init () {
      // 初始化分类
      this.categoryList = await getStoreCategory()
      this.categoryList.unshift({
        value: '',
        label: '全部'
      })
      // 初始化地区
      this.areaList = await getArea()
    },
    // 变更分类
    changeCategory (id) {
      this.pageConfig.page = 1
      if (id) {
        this.pageConfig.category_id = id
      } else {
        this.pageConfig.category_id = ''
      }
    },
    changePage (page) {
      this.pageConfig.page = page.page
      this.$nextTick(() => {
        this._scrollTop()
      })
    },
    // 变更地区
    changeArea (value) {
      this.pageConfig.page = 1
      if (value) {
        this.pageConfig.area_id = value
      } else {
        this.pageConfig.area_id = 0
      }
    },
    // 搜索
    searchStore (value) {
      this.pageConfig.page = 1
      this.pageConfig.keywords = value
    },
    // 变更排序
    changeSort (sort) {
      this.pageConfig.page = 1
      this.pageConfig.sort = sort
    },
    async fetchStoreList (config) {
      this.storeList = await api.fetchStoreList(config)
    },
    _scrollTop () {
      const sTop = document.documentElement.scrollTop || document.body.scrollTop
      scrollTop(window, sTop, 0, 800)
    }
  },
  components: {
    Page,
    JumpTop,
    MallHead,
    GoodsCard,
    Pagination,
    ListNothing,
    FineartCascader,
    'i-menu': Menu,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-button': Button,
    'i-divider': Divider,
    'i-menu-item': MenuItem
  }
}
</script>

<style lang="stylus">
.offline-store
  padding: 30px 0 0 0
  .ivu-select-placeholder,
  .ivu-select-selected-value,
  .ivu-input-wrapper .ivu-input
    font-size: 14px
  .classify-select
    margin-bottom: 14px
    .select-box
      display: flex
      margin-bottom: 30px
      .ivu-select
        width: 364px
        margin-right: 10px
        .ivu-select-selected-value, .ivu-select-placeholder
          padding-left: 12px
          font-size: 16px
      .classify-select-label
        width: 64px
        height: 40px
        margin-right: 20px
        font-size: 16px
        color: $black
        line-height: 40px
        text-align: justify
        /*实现文字两端对齐*/
        &:after
          content: ''
          display: inline-block
          padding-left: 100%
      .goods-attribute
        display: flex
        flex-flow: wrap
        width: 1116px
        .attribute-item
          padding: 0 20px
          color: $black1
          font-size: 14px
          line-height: 40px
          cursor: pointer
          &:hover, &.is-attribute
            color: $orange
      .classify-search
        width: 360px
        height: 40px
      .classify-search-btn
        width: 112px
        height: 40px
        padding: 0
        color: $white
        font-size: 14px
        background-color: $orange
        border-radius: 0 4px 4px 0
        &>span
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 40px
        .fy-icon-search
          margin-right: 5px
          font-size: 20px
          color: $white
  .goods-list-nav
    height: 40px
    margin-bottom: 30px
    line-height: 40px
    z-index: 1
    .ivu-menu-item
      width: auto
      padding: 0
      color: $black1
      font-size: 16px
      &:hover, &.ivu-menu-item-active
        color: $orange
    .nav-divider
      display: flex
      justify-content: center
      align-items: center
      width: 55px
      padding: 0 10px
      cursor: default
      &:hover, &.ivu-menu-item-active
        color: $black1
        border-bottom: none
  .store-wrap
    width: 1200px
    overflow: hidden
    .store-list
      display: flex
      flex-flow: wrap
      margin-right: -61px
      .store-item
        margin: 0 61px 30px 0
        .store-info
          padding-left: 15px
          .store-name
            margin-bottom: 10px
            font-size: 20px
            color: $black
            {ellipse}
          .subtitle
            display: inline-block
            height: 22px
            margin-bottom: 10px
            padding: 0 6px
            text-align: center
            font-size: 14px
            color: $grey-high
            line-height: 22px
            border: 1px solid $grey-high
            border-radius: 4px
          .store-tag
            font-size: 14px
            color: $black1
            {ellipse}
          .store-info-line
            width: 130px
            margin: 12px 0
          .address
            font-size: 14px
            color: $grey-high
            line-height: 20px
            {ellipse}
            .fy-icon-address
              font-size: 16px
              vertical-align: middle
</style>
