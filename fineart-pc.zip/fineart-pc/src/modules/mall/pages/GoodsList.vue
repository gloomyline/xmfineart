<template>
    <page>
      <mall-head :data-arr="categoryList" :active-nav="1"></mall-head>
      <section class="page-content goods-list">
        <div class="classify-select">
          <fineart-cascader :data="categoryList"
                            v-model="categoryVal"
                            @change-category="getSearchCategory"></fineart-cascader>
          <div class="select-box">
            <label class="classify-select-label">商品属性</label>
            <ul class="goods-attribute">
              <li class="attribute-item"
                  :class="{'is-attribute': item.id === pageConfig.attribute}" v-for="item in attribute"
                  :key="item.id"
                  @click="changeIsAttribute(item.id)">{{ item.value }}</li>
            </ul>
          </div>
          <div class="select-box">
            <label class="classify-select-label">搜索</label>
            <i-input v-model="keywords" search placeholder="输入关键词" class="classify-search" @on-search="searchGoods">
              <i-button slot="append" class="classify-search-btn" type="primary" @click="searchGoods(keywords)"><span class="fy-icon-search"></span>搜一下</i-button>
            </i-input>
          </div>
        </div>
        <i-menu mode="horizontal" active-name="default" @on-select="changeSort" class="goods-list-nav">
          <i-menu-item name="default">综合排序</i-menu-item>
          <i-menu-item name="false" disabled class="nav-divider"><i-divider type="vertical"></i-divider></i-menu-item>
          <i-menu-item name="price_asc">价格</i-menu-item>
        </i-menu>
        <div class="goods-list-wrap" v-if="goodsList.data && goodsList.data.length !== 0">
          <div class="popular-goods">
            <goods-card class="goods-item" v-for="(item, index) in goodsList.data"
              :key="index"
              :route="`/goods-detail/${item.id}/${item.store_id}`"
              :img-src="item.thumbnail">
              <h3>
                <p class="goods-name">{{ item.name }}</p>
                <p class="goods-price">&yen;{{ item.price_norm }}</p>
              </h3>
              <div class="goods-from">
                <i-divider type="horizontal" class="goods-from-divider"></i-divider>
                <p class="goods-from-store">{{ item.store_name }}</p>
              </div>
            </goods-card>
          </div>
          <pagination @page-confirm="goToCurrentPage"
                      :page="parseInt(goodsList.current_page)"
                      :total="goodsList.total"
                      :page-size="goodsList.per_page"></pagination>
        </div>
        <list-nothing v-else></list-nothing>
      </section>
      <jump-top></jump-top>
    </page>
</template>

<script>
import { Select, Option, Input, Button, Menu, MenuItem, Divider } from 'iview'
import { MallHead, Page, Pagination, JumpTop, ListNothing, GoodsCard, FineartCascader } from 'components/index.js'
import { scrollTop } from '@/common/js/utils'
import api from 'modules/mall/api'
import { getGoodsCategory } from '@/common/js/loadScript.js'
import { mapState } from 'vuex'
export default {
  data () {
    return {
      categoryList: [],
      categoryVal: [],
      keywords: '',
      attribute: [
        {
          id: 1,
          value: '全部'
        },
        {
          id: 100,
          value: '产品型'
        },
        {
          id: 200,
          value: '服务型'
        }
      ],
      goodsList: {},
      pageConfig: {
        page: 1,
        keywords: '',
        category_id: '',
        attribute: 1,
        sort: 'default'
      }
    }
  },
  watch: {
    pageConfig: {
      handler: function (newVal) {
        this.fetchGoodsList(newVal)
      },
      deep: true
    },
    category: {
      handler (newVal) {
        this.categoryVal = Object.values(newVal)
        if (this.categoryVal.length === 0) return
        this.pageConfig.category_id = this.categoryVal[this.categoryVal.length - 1]
      },
      deep: true
    }
  },
  computed: {
    ...mapState('mall', ['category'])
  },
  created () {
    this.categoryVal = Object.values(this.category)
    if (this.categoryVal.length > 0) {
      this.pageConfig.category_id = this.categoryVal[this.categoryVal.length - 1]
    }
    this.fetchGoodsList(this.pageConfig)
    this.initCategory()
  },
  methods: {
    test () {
    },
    async initCategory () {
      this.categoryList = await getGoodsCategory()
    },
    // 选择页数
    goToCurrentPage (page) {
      this.pageConfig.page = page.page
      this.$nextTick(() => {
        this._scrollTop()
      })
    },
    // 选择分类
    getSearchCategory (value) {
      if (value) {
        this.pageConfig.category_id = value
      } else {
        this.pageConfig.category_id = ''
      }
    },
    // 选择属性
    changeIsAttribute (id) {
      this.pageConfig.page = 1
      this.pageConfig.attribute = id
    },
    // 搜索
    searchGoods (keywords) {
      this.pageConfig.page = 1
      this.pageConfig.keywords = keywords
    },
    // 排序
    changeSort (name) {
      if (name === 'false') return
      this.pageConfig.page = 1
      this.pageConfig.sort = name
    },
    // 获取商品列表 api
    async fetchGoodsList (params) {
      this.goodsList = await api.fetchGoodsList(params)
    }
  },
  _scrollTop () {
    const sTop = document.documentElement.scrollTop || document.body.scrollTop
    scrollTop(window, sTop, 0, 800)
  },
  beforeDestroy () {
    if (this.categoryVal.length > 0) {
      this.$store.commit('mall/MALL_CLEAR_CATEGORY')
    }
  },
  components: {
    Page,
    JumpTop,
    MallHead,
    GoodsCard,
    Pagination,
    ListNothing,
    FineartCascader,
    'i-menu': Menu,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-button': Button,
    'i-divider': Divider,
    'i-menu-item': MenuItem
  }
}
</script>

<style lang="stylus">
.goods-list
  padding: 30px 0 0 0
  .ivu-select-placeholder,
  .ivu-select-selected-value,
  .ivu-input-wrapper .ivu-input
    font-size: 14px
  .classify-select
    margin-bottom: 14px
    .select-box
      display: flex
      margin-bottom: 30px
      .classify-select-label
        width: 64px
        height: 40px
        margin-right: 20px
        font-size: 16px
        color: $black
        line-height: 40px
        text-align: justify
        /*实现文字两端对齐*/
        &:after
          content: ''
          display: inline-block
          padding-left: 100%
      .goods-attribute
        display: flex
        .attribute-item
          padding: 0 20px
          color: $black1
          font-size: 14px
          line-height: 40px
          cursor: pointer
          &:hover, &.is-attribute
            color: $orange
      .classify-search
        width: 360px
        height: 40px
      .classify-search-btn
        width: 112px
        height: 40px
        padding: 0
        color: $white
        font-size: 14px
        background-color: $orange
        border-radius: 0 4px 4px 0
        &>span
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 40px
        .fy-icon-search
          margin-right: 5px
          font-size: 20px
          color: $white
  .goods-list-nav
    height: 40px
    margin-bottom: 30px
    line-height: 40px
    z-index: 1
    .ivu-menu-item
      width: auto
      padding: 0
      color: $black1
      font-size: 16px
      &:hover, &.ivu-menu-item-active
        color: $orange
    .nav-divider
      display: flex
      justify-content: center
      align-items: center
      width: 55px
      padding: 0 10px
      cursor: default
      &:hover, &.ivu-menu-item-active
        color: $black1
        border-bottom: none
  .goods-list-wrap
    overflow: hidden
    width: 1200px
    margin-top: 30px
    .popular-goods
      display: flex
      justify-content: flex-start
      flex-flow: row wrap
      margin-right: -13px
      .goods-item
        margin: 0 13px 40px 0
      .goods-name
        text-align: center
        font-weight: normal
        font-size: 18px
        color: $black
        {ellipse}
      .goods-price
        text-align center
        font-size: 16px
        color: $orange
      .goods-from
        margin: 0 auto
        .goods-from-divider
          width: 130px
          margin: 10px auto
        .goods-from-store
          font-size: 14px
          color: $black1
          text-align: center
          {ellipse}
</style>
