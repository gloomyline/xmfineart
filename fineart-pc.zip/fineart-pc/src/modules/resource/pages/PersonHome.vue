<template>
  <Page>
    <section class="page-content">
      <i-breadcrumb separator="<span class='fy-icon-arrow'></span>">
        <i-breadcrumb-item><a href="index.html">首页</a></i-breadcrumb-item>
        <i-breadcrumb-item to="/">斐艺资源</i-breadcrumb-item>
        <i-breadcrumb-item>{{ resourceDetail.name }}</i-breadcrumb-item>
      </i-breadcrumb>
      <div class="resource-detail">
        <!-- 主页信息组件 -->
        <resource-detail-info class="resource-detail-info"
                              mode="个人简介"
                              :resource-id="id"
                              :resource-mode="resourceDetail.mode"
                              :is-self ="isMaster"
                              :experience="experience"
                              :resource-detail="resourceDetail"
                              @toggle-modal="toggleModal"
                              @change-edit="changeEditStatus"
                              @edit-index-experience="editIndexExperience"></resource-detail-info>
        <div class="resource-detail-work">
          <i-menu mode="horizontal"
                  :active-name="activeName"
                  class="work-nav"
                  @on-select="changePanel">
            <i-menu-item name="cases">参与案例({{ resourceCaseList.total }})</i-menu-item>
            <!-- 按需求隐藏作品集入口 -->
            <!--<i-menu-item name="false" disabled class="nav-divider"><i-divider type="vertical"></i-divider></i-menu-item>-->
            <!--<i-menu-item name="achievement">作品集({{ resourceAchievementList.total }})</i-menu-item>-->
          </i-menu>
          <!-- 参与案例 -->
          <div class="case-wrap"  v-if="activeName === 'cases'">
            <div class="case-item" v-for="( item, index ) in resourceCaseList.data" :key="index">
              <div class="case-building-name">
                <a :href="`/building.html#/building-detail/${item.building_id}#${item.resource_id}`" target="_blank">{{ item.building_name}}</a>
                <div class="edit-box" v-if="isEdit">
                  <i-button type="text" @click="deleteCaseConfirm(item.id)"><i class="fy-icon-delete"></i>删除</i-button>
                  <i-button type="text" @click="showModalCases(item)"><i class="fy-icon-edit"></i>编辑</i-button>
                </div>
              </div>
              <div class="case-subInfo">
                <div><span class="fy-icon-type"></span>{{ item.service_type }}</div>
                <div v-if="item.start_at && item.end_at"><span class="fy-icon-time"></span>{{item.start_at}}至{{item.end_at}}</div>
              </div>
              <p class="case-content" v-if="item.content" v-html="item.content"></p>
            </div>
            <div class="add-more" @click="fetchMoreDataList(activeName)" v-show="resourceCaseList.has_next"><span class="fy-icon-add-round-gray"></span>点击加载更多</div>
            <!--为空的情况-->
            <list-nothing v-if="!isMaster" v-show="resourceCaseList.total === 0"></list-nothing>
            <div class="work-list-full" v-if="isMaster" v-show="resourceCaseList.total === 0">
              <span class="fy-icon-addcase"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span></span>
              <div class="full-title">如何添加案例</div>
              <div class="full-text">打开 [斐艺建筑] -> 搜索建筑 -> 点击 [我有参与]<br>如果没有找到你要的建筑，可以自己添加建筑<br>现在就去看看[<a href="/building.html" target="_blank">斐艺建筑</a>]</div>
            </div>
          </div>
          <!-- 作品集 -->
          <!--<div class="achievement-wrap" v-else>-->
            <!--<i-button type="primary" ghost class="add-achievement"-->
                      <!--v-show="isEdit"-->
                      <!--@click="toggleModal('achievement_add')"><span class="fy-icon-add-thick-orange"></span>添加作品</i-button>-->
            <!--<div class="achievement-item" v-for="( item, index ) in resourceAchievementList.data" :key="index">-->
              <!--<div class="achievement-title">-->
                <!--<em><router-link :to="`/achievement-detail/${item.id}`" class="more" target="_blank">{{ item.title }}</router-link></em>-->
                <!--<div class="edit-box" v-if="isEdit">-->
                  <!--<i-button type="text" @click="deleteAchievementConfirm(item.id)"><i class="fy-icon-delete"></i>删除</i-button>-->
                  <!--<i-button type="text" @click="showModalAchievements(item)"><i class="fy-icon-edit"></i>编辑</i-button>-->
                <!--</div>-->
              <!--</div>-->
              <!--<p class="achievement-intro" v-html="item.introduction"></p>-->
              <!--<div class="achievement-img">-->
                <!--<img :src="item.thumbnail_cdn">-->
              <!--</div>-->
            <!--</div>-->
            <!--<div class="add-more" @click="fetchMoreDataList(activeName)" v-show="resourceAchievementList.has_next"><span class="fy-icon-add-round-gray"></span>点击加载更多</div>-->
            <!--&lt;!&ndash;为空的情况&ndash;&gt;-->
            <!--<list-nothing v-if="!isMaster" v-show="resourceAchievementList.total === 0"></list-nothing>-->
          <!--</div>-->
        </div>
      </div>
    </section>
    <!-- 编辑基础信息 -->
    <resource-edit-info v-model="modalArray.name"
                        :name="resourceDetail.name"
                        :gender="resourceDetail.gender"
                        @save-edit="editName"></resource-edit-info>
    <!-- 编辑分类 -->
    <resource-classify v-model="modalArray.category"
                       :category-id="resourceDetail.resource_category_id"
                       @save-edit="editCategory"></resource-classify>
    <!-- 编辑简介 -->
    <resource-intro v-model="modalArray.resource_intro"
                    :intro="resourceDetail.introduction"
                    resourceMode="100"
                    @save-edit="editIntroduction"></resource-intro>
    <!-- 编辑标签 -->
    <resource-set-tag v-model="modalArray.tag"
                      :all-tags="allTags"
                      :used-tags="resourceDetail.tags"
                      @handle-submit="setTag"
                      @add-tag="addTag"></resource-set-tag>
    <!-- 编辑收费标准 -->
    <resource-price v-model="modalArray.price"
                    :design-price="resourceDetail.design_price"
                    @handle-submit="editPrice"></resource-price>
    <!--编辑资源副标题-->
    <resource-recommend v-model="modalArray.subtitle"
                        :subtitle="resourceDetail.subtitle"
                        @save-edit="editSubtitle"></resource-recommend>
    <!--编辑工作经历-->
    <resource-experience v-model="modalArray.experience"
                         :experience="modalExperience"
                         @delete-confirm="deleteExperienceConfirm"
                         @save-edit="editExperience"></resource-experience>
    <!--编辑作品集-->
    <!--<resource-works v-model="modalArray.achievement_edit"-->
                    <!--:modal-title="modalTitle"-->
                    <!--:works="works"-->
                    <!--resource-mode="100"-->
                    <!--@delete-item="deleteItem"-->
                    <!--@save-refresh="refreshList"></resource-works>-->
    <!--编辑案例-->
    <resource-case v-model="modalArray.case_edit"
                   :case="modalCase"
                   @delete-item="deleteItem"
                   @save-refresh="refreshList"></resource-case>
    <!-- 编辑地区 -->
    <fa-map v-model="modalArray.address"
            :lng="resourceDetail.lng"
            :lat="resourceDetail.lat"
            :address="resourceDetail.address"
            :sysAreaId="resourceDetail.sys_area_id"
            @save-edit="editArea"></fa-map>
    <!-- 删除工作经历确认 -->
    <i-modal v-model="delExperienceModal" title="删除确认" @on-ok="deleteExperienceSubmit">
      <p>确认删除工作经历吗？</p>
    </i-modal>
    <!-- 删除案例确认 -->
    <i-modal v-model="delCaseModal" title="删除确认" @on-ok="deleteCaseSubmit">
      <p>确认删除参与案例吗？</p>
    </i-modal>
    <!-- 删除作品确认 -->
    <!--<i-modal v-model="delAchievementModal" title="删除确认" @on-ok="deleteAchievementSubmit">-->
      <!--<p>确认删除作品吗？</p>-->
    <!--</i-modal>-->
    <jump-top></jump-top>
  </Page>
</template>

<script>
import {
  Page,
  JumpTop,
  ListNothing,
  ResourceDetailInfo,
  ResourceEditInfo,
  ResourceIntro,
  ResourceCase,
  ResourcePrice,
  // ResourceWorks,
  FaMap,
  ResourceRecommend,
  ResourceExperience,
  ResourceClassify,
  ResourceSetTag
} from 'components'
import { Breadcrumb, BreadcrumbItem, Menu, MenuItem, Divider, Modal } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resource/api'

export default {
  name: 'PersonHome',
  data () {
    return {
      isMaster: false, // 是否是本人
      isEdit: false, // 是否是编辑状态
      modalTitle: '编辑作品集', // 参与案例或者作品编辑弹框的标题
      // 资源详情
      resourceDetail: {},
      activeName: 'cases',
      // 控制弹窗显示数组
      modalArray: {
        name: false, // 显示编辑信息弹窗
        subtitle: false,
        resource_intro: false,
        category: false,
        experience: false,
        case_edit: false,
        achievement_edit: false,
        address: false,
        tag: false,
        price: false
      },
      modalExperience: {},
      // 编辑的作品集
      works: {
        resource_id: '',
        id: '',
        title: '',
        thumbnail: '',
        thumbnail_cdn: '',
        image_url: [],
        image_url_cdn: [],
        content: ''
      },
      // 个人-工作经验
      experience: [],
      // 资源标签
      allTags: [],
      // 参与案例列表
      resourceCaseList: {
        data: [],
        total: 0,
        current_page: 1,
        per_page: 10,
        last_page: 1,
        has_next: false
      },
      // 编辑的参与案例
      modalCase: {},
      // 作品集列表
      resourceAchievementList: {
        data: [],
        total: 0,
        current_page: 1,
        per_page: 10,
        last_page: 1,
        has_next: false
      },
      delExperienceId: '',
      delExperienceModal: false,
      delCaseModal: false,
      delCaseId: '',
      delAchievementModal: false,
      delAchievementId: ''
    }
  },
  props: ['id'],
  created () {
    this.getResourceDetail()
    this.fetchExperienceList()
    this.getResourceCaseList()
    // this.getResourceAchievementList()
  },
  methods: {
    deleteItem (id) {
      if (this.activeName === 'cases') {
        this.deleteCaseConfirm(id)
      } else {
        this.deleteAchievementConfirm(id)
      }
    },
    refreshList () {
      if (this.activeName === 'cases') {
        this.getResourceCaseList()
      } else {
        this.getResourceAchievementList()
      }
    },
    async getResourceDetail () {
      this.resourceDetail = await api.fetchResourceDetail({
        resource_id: this.id,
        resource_mode: 100
      })
      this.isMaster = this.resourceDetail.is_master
    },
    async fetchExperienceList () {
      this.experience = await api.fetchExperienceList({
        resource_id: this.id,
        type: 200
      })
    },
    async getResourceCaseList () {
      this.resourceCaseList = await api.getResourceCaseList({
        resource_id: this.id
      })
    },
    async getResourceAchievementList () {
      this.resourceAchievementList = await api.getResourceAchievementList({
        resource_id: this.id
      })
    },
    // 点击更多事件函数
    async fetchMoreDataList (activeName) {
      if (activeName === 'cases') {
        // 参与案例分页
        let dataList = await api.getResourceCaseList({
          resource_id: this.id,
          page: this.resourceCaseList.current_page + 1
        })
        for (let index in dataList.data) {
          this.resourceCaseList.data.push(dataList.data[index])
        }
        this.resourceCaseList.current_page = dataList.current_page
        this.resourceCaseList.has_next = dataList.has_next
      } else {
        // 作品集分页
        let dataList = await api.getResourceAchievementList({
          resource_id: this.id,
          page: this.resourceAchievementList.current_page + 1
        })
        for (let index in dataList.data) {
          this.resourceAchievementList.data.push(dataList.data[index])
        }
        this.resourceAchievementList.current_page = dataList.current_page
        this.resourceAchievementList.has_next = dataList.has_next
      }
    },
    // 编辑弹窗
    toggleModal (modalName) {
      if (modalName === 'achievement_add') {
        this.modalTitle = '添加作品'
        this.works = {
          resource_id: this.id,
          id: '',
          title: '',
          thumbnail: '',
          thumbnail_cdn: '',
          image_url: [],
          image_url_cdn: [],
          content: ''
        }
        this.modalArray['achievement_edit'] = true
      } else if (modalName === 'tag') {
        this.fetchTagList()
        this.modalArray[modalName] = true
      } else {
        this.modalArray[modalName] = true
      }
      this.modalExperience = {}
    },
    async editName (info) {
      let params = {
        resource_id: this.id,
        resource_mode: this.resourceDetail.mode,
        name: info.name,
        subtitle: '',
        introduction: '',
        resource_category_id: ''
      }
      this.result = await api.resourcePersonalEdit(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_NAME_EDIT_SUCCESS'], type: 'success' })
        this.resourceDetail.name = info.name
      }
    },
    async editCategory (category) {
      let params = {
        resource_id: this.id,
        resource_mode: this.resourceDetail.mode,
        name: '',
        subtitle: '',
        introduction: '',
        resource_category_id: category
      }
      this.result = await api.resourcePersonalEdit(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_CATEGORY_EDIT_SUCCESS'], type: 'success' })
        this.getResourceDetail()
      }
    },
    async editSubtitle (subtitle) {
      let params = {
        resource_id: this.id,
        resource_mode: this.resourceDetail.mode,
        name: '',
        subtitle: subtitle,
        introduction: '',
        resource_category_id: ''
      }
      this.result = await api.resourcePersonalEdit(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_TITLE_EDIT_SUCCESS'], type: 'success' })
        this.resourceDetail.subtitle = subtitle
      }
    },
    async editIntroduction (introduction) {
      let params = {
        resource_id: this.id,
        resource_mode: this.resourceDetail.mode,
        name: '',
        subtitle: '',
        introduction: introduction,
        resource_category_id: ''
      }
      this.result = await api.resourcePersonalEdit(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_INTRODUCTION_EDIT_SUCCESS'], type: 'success' })
        this.resourceDetail.introduction = introduction.replace(/\n|\r\n/g, '<br />')
      }
    },
    async editArea (mapAddress) {
      let params = {
        resource_id: this.id,
        resource_mode: this.resourceDetail.mode,
        lng: mapAddress.point.lng,
        lat: mapAddress.point.lat,
        sys_area_id: mapAddress.sysAreaId,
        address: mapAddress.addressData.address
      }
      this.result = await api.resourceAreaEdit(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_AREA_EDIT_SUCCESS'], type: 'success' })
        this.getResourceDetail()
      }
    },
    async editExperience (info) {
      let params = {}
      if (info.id) {
        params = {
          id: info.id,
          company: info.company,
          job: info.job,
          start_date: info.start_date,
          end_date: info.end_date
        }
        this.result = await api.resourceEditExperience(params)
      } else {
        params = {
          resource_id: this.id,
          type: 200,
          company: info.company,
          job: info.job,
          start_date: info.start_date,
          end_date: info.end_date
        }
        this.result = await api.resourceAddExperience(params)
      }
      if (this.result.code === 200) {
        if (info.id) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_EXPERIENCE_EDIT_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_EXPERIENCE_ADD_SUCCESS'], type: 'success' })
        }
        this.fetchExperienceList()
      }
    },
    editIndexExperience (index) {
      this.modalExperience = this.experience[index]
      this.modalArray.experience = true
    },
    // 显示编辑案例弹窗
    async showModalCases (item) {
      this.modalCase = await api.fetchCaseDetail(item.id)
      this.modalArray.case_edit = true
    },
    // 显示编辑作品弹窗
    async showModalAchievements (item) {
      this.modalTitle = '编辑作品集'
      let achievementDetail = await api.fetchAchievementDetail(item.id)
      this.works = {
        resource_id: achievementDetail.resource_id,
        id: achievementDetail.id,
        title: achievementDetail.title,
        thumbnail: achievementDetail.thumbnail,
        thumbnail_cdn: achievementDetail.thumbnail_cdn,
        image_url: achievementDetail.image_urls ? achievementDetail.image_urls : [],
        image_url_cdn: achievementDetail.image_urls_cdn ? achievementDetail.image_urls_cdn : [],
        content: achievementDetail.introduction
      }
      this.modalArray.achievement_edit = true
    },
    // 选择面板
    changePanel (name) {
      this.activeName = name
    },
    // 是否是编辑状态
    changeEditStatus (value) {
      this.isEdit = value
    },
    deleteExperienceConfirm (id) {
      this.delExperienceModal = true
      this.delExperienceId = id
    },
    // 删除工作经历
    async deleteExperienceSubmit () {
      this.result = await api.resourceExperienceDelete(this.delExperienceId)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_EXPERIENCE_DELETE_SUCCESS'], type: 'success' })
        this.fetchExperienceList()
        this.modalArray.experience = false
      }
    },
    deleteCaseConfirm (id) {
      this.delCaseModal = true
      this.delCaseId = id
    },
    // 删除案例
    async deleteCaseSubmit () {
      this.result = await api.resourceCaseDelete(this.delCaseId)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_CASE_DELETE_SUCCESS'], type: 'success' })
        this.getResourceCaseList()
        this.modalArray.case_edit = false
      }
    },
    deleteAchievementConfirm (id) {
      this.delAchievementModal = true
      this.delAchievementId = id
    },
    // 删除作品
    async deleteAchievementSubmit () {
      this.result = await api.resourceAchievementDelete(this.delAchievementId)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_ACHIEVEMENT_DELETE_SUCCESS'], type: 'success' })
        this.getResourceAchievementList()
        this.modalArray.achievement_edit = false
      }
    },
    // 获取资源的标签列表
    async fetchTagList () {
      this.allTags = await api.handleTagList({ object_type: 100 })
    },
    // 新增标签
    async addTag (val) {
      let res = await api.handleAddTag({object_type: 100, tag: val})
      if (res.code === 200) {
        this.fetchTagList()
      }
    },
    // 设置标签
    async setTag (tagArr) {
      let tagIdArr = []
      for (let item of tagArr) {
        tagIdArr.push(item.id)
      }
      let param = {
        resource_id: this.id,
        resource_mode: this.resourceDetail.mode,
        tag_id_arr: tagIdArr
      }
      this.res = await api.resourcePersonalEdit(param)
      if (this.res.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_TAG_SET_SUCCESS'], type: 'success' })
        this.resourceDetail.tags = tagArr
      }
    },
    // 设置收费标准
    async editPrice (design_price) {
      if (design_price === undefined) {
        design_price = ''
      }
      let param = {
        resource_id: this.id,
        resource_mode: this.resourceDetail.mode,
        design_price: design_price
      }
      this.res = await api.resourcePersonalEdit(param)
      if (this.res.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_PRICE_SET_SUCCESS'], type: 'success' })
        this.getResourceDetail()
      }
    }
  },
  components: {
    Page,
    JumpTop,
    ListNothing,
    ResourceIntro,
    FaMap,
    ResourceCase,
    ResourcePrice,
    // ResourceWorks,
    ResourceSetTag,
    ResourceEditInfo,
    ResourceDetailInfo,
    ResourceClassify,
    ResourceRecommend,
    ResourceExperience,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem,
    'i-menu': Menu,
    'i-menu-item': MenuItem,
    'i-divider': Divider,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
  /*editbox*/
  .info-item-name,.sub-name,.resource-name,.resource-subtitle
    position: relative
  .edit-box
    absolute: right top
    cursor: pointer
    font-size: 16px
    font-weight: 400
    .ivu-btn-text
      color: $orange
      font-size: 16px
      padding: 0 0 0 15px
      background-color: transparent
      &:focus
        box-shadow none
  /*fy-icon*/
  [class^="fy-icon"]
    vertical-align: middle
  .page-content [class^="fy-icon"]
    font-size: 17px
    display: inline-block
    margin-right: 7px
    &.fy-icon-full
      font-size: 225px
      display:block
      margin-bottom: -30px
  .resource-detail
    display: flex
    .resource-detail-info
      width: 374px
      padding-right: 28px
      border-right: 1px solid $grey
  /*resource-detail-info(参与案例、作品集)*/
  .resource-detail-work
    width: 824px
    padding-left: 28px
    .work-nav
      .ivu-menu-item
        color: $black1
        font-size: 16px
        &.ivu-menu-item-active
          color: $orange
      .nav-divider
        padding: 0 10px
        cursor: default
        &:hover, &.ivu-menu-item-active
          border-bottom: none
          color: $grey
    .add-more
      text-align: center
      padding: 15px 0 30px 0
      color: $grey-high
      font-size: 14px
      cursor: pointer
      &:hover,&:hover .fy-icon-add-round-gray:before
        color: $orange
    .work-list-full
      padding: 130px 0  340px 0
      text-align: center
      color: $grey-high
      font-size: 16px
      .fy-icon-addcase
        font-size: 112px
        margin: 10px
      .full-title
        font-size: 18px
        color: $black
        margin-bottom: 27px
      .full-text
        font-size: 16px
        color: $black1
        line-height: 37px
        &>a
          color: $orange
      .ivu-btn
        border-color: $orange
        color: $orange
        width: 98px
        height: 32px
        margin: 0 18px
  .case-item
    position relative
    padding: 25px 0
    border-bottom: 1px solid $grey
    .edit-box
      absolute: top 25px
    .case-img
      display: flex
      height: 129px
      img
        width: 129px
        height: 100%
        margin-right: 20px
    .case-building-name
      margin-bottom: 15px
      a
        color: $black
        font-size: 18px
    .case-subInfo
      font-size: 14px
      color: $grey-high
      display: flex
      div
        min-width: 180px
        span
          margin-left: -2px
    .case-content
      font-size: 14px
      color: $black1
      line-height: 28px
      overflow : hidden
      margin-top: 20px
      text-overflow: ellipsis
      display: -webkit-box
      -webkit-line-clamp: 2
      -webkit-box-orient: vertical
  .add-achievement
    width: 772px
    height: 48px
    font-size: 14px
    margin: 28px 0
  .achievement-item
    position relative
    padding: 25px 0
    border-bottom: 1px solid $grey
    .edit-box
      absolute: top 25px
    .achievement-title
      margin-bottom: 15px
      a
        color: $black
        font-size: 18px
    .achievement-intro
      font-size: 14px
      color: $black1
      line-height: 28px
      overflow : hidden
      text-overflow: ellipsis
      display: -webkit-box
      -webkit-line-clamp: 2
      -webkit-box-orient: vertical
    .achievement-img
      display: flex
      overflow: hidden
      img
        margin: 10px 20px 10px 0
        width: 130px
        height: 130px
</style>
