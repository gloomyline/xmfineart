<template>
  <Page>
    <section class="page-content resource-list">
      <div class="resource-filter">
        <fineart-cascader :data="categoryList"
                          @change-category="searchResource"></fineart-cascader>
        <div class="area-box">
          <fineart-cascader label="地区"
                            :data="areaList"
                            v-model="areaVal"
                            placeholder="请选择地区"
                            @change-category="searchArea"></fineart-cascader>
          <i-button  class="filter-select" :class="{'is-foreign': pageConfig.foreign === 1}" @click="onlyForeign" long>只看国外</i-button>
        </div>
        <div>
          <label class="filter-label">搜索</label>
          <i-input class="filter-keyword" v-model="pageConfig.keyword" search placeholder="输入关键词">
            <i-button @click="fetchResourceList()" slot="append" class="classify-search-btn" type="primary"><span class="fy-icon-search"></span>搜一下</i-button>
          </i-input>
        </div>
      </div>
      <i-menu class="resource-order"
              mode="horizontal"
              :active-name="pageConfig.order"
              @on-select="changeSort">
        <i-menu-item name="default">综合排序</i-menu-item>
        <i-menu-item name="false" disabled class="nav-divider"><i-divider type="vertical"></i-divider></i-menu-item>
        <i-menu-item name="views">查看次数</i-menu-item>
      </i-menu>
      <div class="resource-content">
        <div class="resource-item-box"
             v-for="item in resourceList.data"
             @click="goToDetail(item.id, item.mode)"
             :key="item.id">
          <div class="resource-pic-wrap">
            <img class="resource-pic" :src="item.logo">
          </div>
          <div class="resource-title">{{ item.name }}</div>
          <div class="resource-summary">{{ item.subtitle }}</div>
        </div>
      </div>
      <pagination class="resource-pagination"
                  @page-confirm="changePage"
                  v-if="resourceList.total"
                  :page="parseInt(resourceList.current_page)"
                  :total="resourceList.total"
                  :page-size="resourceList.per_page"></pagination>
      <list-nothing v-else class="list-nothing"></list-nothing>
    </section>
    <jump-top></jump-top>
  </Page>
</template>

<script>
import { Page, Pagination, JumpTop, ListNothing, FineartCascader } from 'components'
import { Select, Option, Menu, MenuItem, Divider } from 'iview'

import api from 'modules/resource/api'
import { getResourceCategory, getArea } from '@/common/js/loadScript.js'
import { scrollTop } from '@/common/js/utils'
export default {
  name: 'Home',
  data () {
    return {
      areaVal: [],
      categoryList: [],
      areaList: [],
      pageConfig: {
        page: 1,
        keyword: '',
        mode: '',
        category_id: '',
        area_id: '',
        foreign: 0,
        order: 'default'
      },
      resourceList: {}
    }
  },
  created () {
    this.initCategory()
    this.initArea()
    this.fetchResourceList()
  },
  methods: {
    async initCategory () {
      this.categoryList = await getResourceCategory()
    },
    async initArea () {
      this.areaList = await getArea()
    },
    // 调转去主页
    goToDetail (id, mode) {
      const modeVal = parseInt(mode)
      switch (modeVal) {
      case 100:
        window.open(`/resource.html#/person-home/${id}`, '_blank')
        break
      case 200:
        window.open(`/resource.html#/company-home/${id}`, '_blank')
        break
      case 300:
        window.open(`/resource.html#/supplier-home/${id}`, '_blank')
        break
      case 400:
        window.open(`/resource.html#/brand-home/${id}`, '_blank')
        break
      case 500:
        window.open(`/resource.html#/decorator-home/${id}`, '_blank')
        break
      }
    },
    /* 改变排序方式 pageConfig => order */
    changeSort (name) {
      if (name === 'false') return
      this.pageConfig.page = 1
      this.pageConfig.order = name
      this.fetchResourceList()
    },
    /* 只看国外 pageConfig => foreign */
    onlyForeign () {
      this.areaVal = []
      this.pageConfig.page = 1
      this.pageConfig.foreign = 1
      this.pageConfig.area_id = ''
      this.fetchResourceList()
    },
    // 选择分类 pageConfig => category_id
    searchResource (param) {
      this.pageConfig.page = 1
      if (param) {
        switch (param) {
        case 100 :
        case 200 :
        case 300 :
        case 400 :
        case 500 :
          this.pageConfig.mode = param
          this.pageConfig.category_id = ''
          break
        case undefined :
          this.pageConfig.category_id = ''
          break
        default :
          this.pageConfig.category_id = param
        }
      } else {
        this.pageConfig.category_id = ''
        this.pageConfig.mode = ''
      }
      this.fetchResourceList()
    },
    // 选择地区 pageConfig => area_id
    searchArea (param) {
      this.pageConfig.page = 1
      this.pageConfig.foreign = 0
      if (param) {
        this.pageConfig.area_id = param
      } else {
        this.pageConfig.area_id = ''
      }
      this.fetchResourceList()
    },
    // 选择分页 pageConfig => page
    changePage (page) {
      this.pageConfig.page = page.page
      this.fetchResourceList()
      this.$nextTick(() => {
        const sTop = document.documentElement.scrollTop || document.body.scrollTop
        scrollTop(window, sTop, 0, 800)
      })
    },
    async fetchResourceList () {
      this.resourceList = await api.fetchResourceList(this.pageConfig)
    }
  },
  components: {
    Page,
    JumpTop,
    Pagination,
    ListNothing,
    FineartCascader,
    'i-select': Select,
    'i-option': Option,
    'i-menu': Menu,
    'i-menu-item': MenuItem,
    'i-divider': Divider
  }
}
</script>

<style lang="stylus">
.resource-list
  .resource-filter
    margin-bottom: 30px
    padding-top: 30px
    .ivu-select-placeholder,
    .ivu-select-selected-value,
    .ivu-input-wrapper .ivu-input
      font-size: 14px
    &>div
      display: flex
      align-items: center
      .filter-label
        width: 64px
        height: 40px
        margin-right: 20px
        font-size: 16px
        color: $black
        line-height: 40px
        text-align: justify
        /*实现文字两端对齐*/
        &:after
          content: ''
          display: inline-block
          padding-left: 100%
      &.area-box .filter-select
        margin: 0 0 30px 20px
      .filter-select, .filter-keyword
        width: 364px
        &:last-child
          margin-right: 0
        .classify-search-btn
          width: 112px
          height: 40px
          padding: 0
          color: $white
          font-size: 14px
          background-color: $orange
          border-radius: 0 4px 4px 0
          &>span
            display: flex
            justify-content: center
            align-items: center
            width: 100%
            height: 40px
          .fy-icon-search
            margin-right: 5px
            font-size: 20px
            color: $white
        &.is-foreign
          border: 1px solid $orange
          color: $orange
    .ivu-btn
      height: 40px
      font-size:14px
  .resource-order
    height: 40px;
    margin-bottom: 30px;
    line-height: 40px;
    z-index: 1;
    .ivu-menu-item
      width: auto
      padding: 0
      color: $black1
      font-size: 16px
      &:hover, &.ivu-menu-item-active
        color: $orange
    .nav-divider
      display: flex
      justify-content: center
      align-items: center
      width: 55px
      padding: 0 10px
      cursor: default
      &:hover, &.ivu-menu-item-active
        color: $black1
        border-bottom: none
  .resource-content
    display: flex
    flex-wrap: wrap
    margin-right: -26px
    .resource-item-box
      margin: 26px 26px 0 0
      padding: 20px
      width: 280px
      height: 354px
      cursor: pointer
      background: $grey-high2
      &:hover
        box-shadow: 0 4px 16px 0 rgba(0,0,0,0.10)
      .resource-pic-wrap
        width: 240px
        height: 240px
        overflow: hidden
        .resource-pic
          width: 240px
      .resource-title
        padding: 10px 0
        font-size: 18px
        color: $black
        text-align: center
        width: 100%
        {ellipse}
      .resource-summary
        text-align: center
        width: 100%
        font-size: 14px
        color: $grey-high
        {ellipse}
  .list-nothing
    height: auto!important
    padding-bottom: 80px
  .resource-pagination
    margin: 52px
</style>
