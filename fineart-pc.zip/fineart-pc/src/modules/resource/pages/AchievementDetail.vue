<template>
  <Page>
    <section class="page-content achievement-detail">
      <i-breadcrumb separator="<span class='fy-icon-arrow'></span>">
        <i-breadcrumb-item><a href="index.html">首页</a></i-breadcrumb-item>
        <i-breadcrumb-item to="/">斐艺资源</i-breadcrumb-item>
        <i-breadcrumb-item>{{ achievementDetail.title }}</i-breadcrumb-item>
      </i-breadcrumb>
      <div class="achievement-head">
        <h1>{{ achievementDetail.title }}</h1>
        <div class="resource-info">
          <div class="resource-info-box">
            <div class="resource-logo">
              <img :src="achievementDetail.resource_logo_cdn">
            </div>
            <div>
              <router-link class="resource-name" :to="resourceHomePath">{{ achievementDetail.resource_name }}</router-link>
              <div class="resource-subtitle">{{ achievementDetail.resource_subtitle }}</div>
            </div>
          </div>
          <div class="follow-box">
            <i-button @click="handleFollow" :class="{'is-active': achievementDetail.collection_status}" >
              <span v-if="achievementDetail.collection"><span class="fy-icon-sel-follow"></span>已关注</span>
              <span v-else><span class="fy-icon-nor-follow"></span>关注TA</span>
            </i-button>
          </div>
        </div>
      </div>
      <div class="achievement-body">
        <div class="achievement-html" v-html="achievementDetail.introduction"></div>
        <div class="achievement-img">
          <div class="img-wrap" v-for="item in achievementDetail.image_urls_cdn" :key="item">
            <img :src="item">
          </div>
        </div>
      </div>
    </section>
    <jump-top></jump-top>
  </Page>
</template>

<script>
import { Page, JumpTop } from 'components'
import { Breadcrumb, BreadcrumbItem } from 'iview'
import { COLLECT_MESSAGE_DURATION } from 'assets/data/constants.js'
import api from 'modules/resource/api/index.js'
import memberApi from 'modules/member/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'AchievementDetail',
  props: {
    id: {
      type: String,
      required: true
    }
  },
  data () {
    return {
      achievementDetail: {},
      apiProcessing: false // API请求处理中
    }
  },
  created () {
    this.initPage()
  },
  computed: {
    resourceHomePath () {
      let resourceTypeText = this.achievementDetail.resource_mode === '100' ? 'person' : 'company'
      return `/${resourceTypeText}-home/${this.achievementDetail.resource_id}/`
    },
    // 实时获取登录状态
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  methods: {
    goToIndex () {
      window.location = '/index.html'
    },
    async initPage () {
      this.achievementDetail = await api.fetchAchievementDetail(this.id)
    },
    async handleFollow () {
      if (!this.isLogin) {
        this.$store.commit('SHOW_LOGIN_MODAL')
        return false
      }

      if (this.apiProcessing) {
        return false
      }

      this.apiProcessing = true
      this.result = await memberApi.handleResourceCollect({ object_type: 100, object_id: this.achievementDetail.resource_id })
      if (this.result.code === 200) {
        this.achievementDetail.collection_status = !this.achievementDetail.collection_status
        // 提示关注成功或取消关注成功
        if (this.achievementDetail.collection_status) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    }
  },
  components: {
    Page,
    JumpTop,
    'i-breadcrumb': Breadcrumb,
    'i-breadcrumb-item': BreadcrumbItem
  }
}
</script>

<style lang="stylus">
.page-content [class^="fy-icon"]
  font-size: 16px
  display: inline-block
  vertical-align: middle
  margin-right: 7px
.achievement-detail
  .achievement-head
    padding-bottom:54px
    h1
      color: $black
      font-size: 24px
      font-weight: 500
      text-align: center
      padding: 40px 0
    .resource-info
      display: flex
      justify-content: space-between
      .resource-info-box
        display: flex
        div.resource-logo
          width: 64px
          height: 64px
          border-radius: 50%
          overflow: hidden
          box-shadow: 0px 4px 12px rgba(0,0,0,0.08)
          img
            width: 100%
        .resource-name
          font-size: 16px
          color: $black1
          display: block
          padding: 8px 0 10px 12px
        div.resource-subtitle
          font-size: 14px
          color: $grey-high
          padding: 0 0 0 12px
      .follow-box
        display: flex
        flex-direction: column
        justify-content: space-around
        button
        .ivu-btn
          font-size: 16px
          color: $black1
          width:120px
          height: 40px
        .is-active
          color: $orange
          background:#FDF2DA
          border: 1px solid $orange
  .achievement-body
    padding-bottom: 20px
    .achievement-html
      color: $black1
      font-size: 16px
      line-height: 32px
      img
        width: 100%
        margin-top: 20px
    .achievement-img
      .img-wrap
        margin-top: 20px
        img
          margin: 0 auto
          max-width: 100%
          display: block
</style>
