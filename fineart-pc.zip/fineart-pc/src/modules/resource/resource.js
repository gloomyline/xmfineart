/*
* @Author: Alan
* @Date:   2018-09-06 19:49:56
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-06 20:04:38
*/
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Resource from './resource.vue'
import router from './router'
import store from '@/store'
import { VueAxios } from '@/common/js/BaseApi.js'
import { VueLocalStorage } from '@/common/js/LocalStorage'
import '@/common/styles/fineart-theme'
import * as Constants from 'assets/data/constants.js'
import {
  Row,
  Col,
  Button,
  Input,
  Message
} from 'iview'

Vue.use(VueAxios)
Vue.use(VueLocalStorage)

Vue.component('i-row', Row)
Vue.component('i-col', Col)
Vue.component('i-button', Button)
Vue.component('i-input', Input)

// global message component
Message.config({
  top: Constants['MESSAGE_TOP'],
  duration: Constants['MESSAGE_DURATION'],
  closable: true
})
Vue.prototype.$message = Message

// router global hook
router.beforeEach((to, from, next) => {
  const user = Vue.localStorage.getUser()
  if (user && user.isLogin) { // 判断是否登录 有登录就获取会员信息
    if (Object.keys(store.state.member.memberInfo).length === 0) {
      store.dispatch('member/fetchAccountProfile')
    }
  }
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // this route requires auth, check if logged in
    // if not, break route change, open login modal.
    if (user && user.isLogin) { // user status is valid, go to corresponding path
      next()
    } else { // not login or is out of date
      store.commit('SHOW_LOGIN_MODAL')
      next('/') // 跳回当前实例的首页
    }
  } else {
    next() // 确保一定要调用 next()
  }
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(Resource)
})
