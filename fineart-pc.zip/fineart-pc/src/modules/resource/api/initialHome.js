export default function (cls) {
  /**
   * 获取资源分页列表/搜索资源分页列表
   *
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param category_id {Integer} 资源分类
   * @param area_id {Integer} 地区ID
   * @param foreign {Integer} 是否查看国外资源(0：不是；1：是)
   * @param order {String} 资源排序(default: 综合排序，views: 查看次数)
   * @param mode {Integer} 资源模型：优秀个人=100，优秀公司=200，优秀供应商=300，优秀品牌=400
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchResourceList = async function ({ page, keyword, category_id, area_id, foreign, order, mode }) {
    const response = await cls.request({
      url: 'resource/search',
      query: {
        page,
        keyword,
        category_id,
        area_id,
        foreign,
        order,
        mode
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取资源详情
   *
   * @param resource_id {Integer} 资源ID
   * @param resource_mode {Integer} 资源模型：优秀个人=100，优秀公司=200，优秀供应商=300，优秀品牌=400
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchResourceDetail = async function ({ resource_id, resource_mode }) {
    const response = await cls.request({
      url: 'resource/detail/${resource_id}/${resource_mode}',
      params: {
        resource_id,
        resource_mode
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 资源详情 - 信息编辑
   *
   * @param resource_id {Integer} 资源ID
   * @param resource_mode {Integer} 资源模型：优秀个人=100，优秀公司=200，优秀供应商=300，优秀品牌=400
   * @param name {String} 资源名称
   * @param subtitle {String} 资源副标题
   * @param introduction {String} 资源介绍
   * @param resource_category_id {Integer} 资源分类ID
   * @param tags {Array} 资源标签
   * @param design_price {String} 收费标准
   * @returns {Promise<*>}
   */
  cls.prototype.resourcePersonalEdit = async function ({resource_id, resource_mode, name, subtitle, introduction, resource_category_id, tag_id_arr, design_price}) {
    let data = {}
    if (name) {
      data = {name}
    }
    if (subtitle) {
      data = {subtitle}
    }
    if (introduction) {
      data = {introduction}
    }
    if (resource_category_id) {
      data = {resource_category_id}
    }
    if (tag_id_arr) {
      // 当清空标签时， 传[0]，到后端
      if (tag_id_arr.length === 0) {
        tag_id_arr.push(0)
      }
      data = {
        'tags[]': tag_id_arr
      }
    }
    // 收费标准为可选填，当不填写design_price，传入值为''， 故通过undefined判断
    if (design_price !== undefined) {
      data = {design_price}
    }

    const response = await cls.request({
      method: 'post',
      url: '/resource/edit/${resource_id}/${resource_mode}',
      params: {
        resource_id,
        resource_mode
      },
      data: data
    })
    return response
  }

  /**
   * 资源详情 - logo图片上传
   *
   * @param resource_id {Integer} 资源ID
   * @param resource_mode {Integer} 资源模型：优秀个人=100，优秀公司=200，优秀供应商=300，优秀品牌=400
   * @param logo {String} logo图片URI地址
   * @returns {Promise<*>}
   */
  cls.prototype.resourceLogoUpload = async function ({resource_id, resource_mode, logo}) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/edit/${resource_id}/${resource_mode}',
      params: {
        resource_id,
        resource_mode
      },
      data: {
        logo
      }
    })
    return response
  }

  /**
   * 资源详情 - 地区编辑
   *
   * @param resource_id {Integer} 资源ID
   * @param resource_mode {Integer} 资源模型：优秀个人=100，优秀公司=200，优秀供应商=300，优秀品牌=400
   * @param lat {Float} 位置纬度
   * @param lng {Float} 位置经度
   * @param sys_area_id {Integer} 地区ID
   * @param address {String} 详细地址
   * @returns {Promise<*>}
   */
  cls.prototype.resourceAreaEdit = async function ({resource_id, resource_mode, lat, lng, sys_area_id, address}) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/edit/${resource_id}/${resource_mode}',
      params: {
        resource_id,
        resource_mode
      },
      data: {
        lat,
        lng,
        address,
        sys_area_id
      }
    })
    return response
  }
}
