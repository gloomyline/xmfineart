import {BaseApi} from '@/common/js/BaseApi'
import achievementApi from './achievement.js'
import caseApi from './case.js'
import experienceApi from './experience.js'
import homeApi from './initialHome.js'
import tagApi from './tag.js'

class ResourceApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    ResourceApi.updateToken(ResourceApi.readTokenFromLocalStorage())
    achievementApi(ResourceApi)
    caseApi(ResourceApi)
    experienceApi(ResourceApi)
    homeApi(ResourceApi)
    tagApi(ResourceApi)
  }
}

const _instance = new ResourceApi()

export default _instance
