export default function (cls) {
  /**
   * 获取个人/企业的资源列表
   *
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchServiceHomeList = async function () {
    const response = await cls.request({
      url: '/resource/member/index',
      params: {}
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取资源的案例列表
   *
   * @param resource_id {Integer} 资源ID
   * @param page {Integer} 分页号
   * @returns {Promise<*|Array>}
   */
  cls.prototype.getResourceCaseList = async function ({resource_id, page = 0}) {
    const response = await cls.request({
      url: '/resource/case/list/${resource_id}',
      params: {
        resource_id
      },
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取资源案例详情
   *
   * @param case_id {Integer} 案例ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchCaseDetail = async function (case_id) {
    const response = await cls.request({
      url: '/resource/case/detail/${case_id}',
      params: {
        case_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 添加资源案例
   *
   * @param resource_id {Integer} 资源ID
   * @param service_type {Integer} 服务类型
   * @param content {String} 内容
   * @param start_at {String} 开始服务时间
   * @param end_at {String} 结束服务时间
   * @param building_code {String} 建筑code
   * @returns {Promise<*>}
   */
  cls.prototype.insertResourceCase = async function ({resource_id, service_type, content, start_at, end_at, building_code}) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/case/add/${resource_id}',
      params: {
        resource_id
      },
      data: {
        resource_id,
        service_type,
        content,
        start_at,
        end_at,
        building_code
      }
    })
    return response
  }

  /**
   * 编辑资源参与案例
   *
   * @param id {Integer} 资源案例ID
   * @param service_type {Integer} 服务类型
   * @param content {String} 内容
   * @param start_at {String} 开始服务时间
   * @param end_at {String} 结束服务时间
   * @returns {Promise<*>}
   */
  cls.prototype.editResourceCase = async function ({id, service_type, content, start_at, end_at}) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/case/edit/${id}',
      params: {
        id
      },
      data: {
        service_type,
        content,
        start_at,
        end_at
      }
    })
    return response
  }

  /**
   * 删除资源参与案例
   *
   * @param id {Integer} 资源案例ID
   * @returns {Promise<*>}
   */
  cls.prototype.resourceCaseDelete = async function (id) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/case/delete/${id}',
      params: {
        id
      }
    })
    return response
  }
}
