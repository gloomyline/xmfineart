export default function (cls) {
  /**
   * [v3.1]标签-我的标签列表
   * @param object_type  100=资源， 200=作品， 300=资源动态
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleTagList = async function ({ object_type }) {
    const response = await cls.request({
      url: '/resource/member/tag/list/${object_type}',
      params: {
        object_type
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * [v3.1]标签-新增
   * @param object_type  资源对象 100=资源， 200=作品， 300=资源动态
   * @param tag  标签名, 必须，最长32个字符
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleAddTag = async function ({ object_type, tag }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/member/tag/add',
      data: {
        object_type,
        tag
      }
    })
    return response
  }
}
