export default function (cls) {
  /**
   * 获取资源的作品列表
   *
   * @param resource_id {Integer} 资源ID
   * @param page {Integer} 分页号
   * @returns {Promise<*|Array>}
   */
  cls.prototype.getResourceAchievementList = async function ({resource_id, page = 0}) {
    const response = await cls.request({
      url: '/resource/achievement/index/${resource_id}',
      params: {
        resource_id
      },
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取资源的代理品牌列表
   *
   * @param resource_id {Integer} 资源ID
   * @param page {Integer} 分页号
   * @returns {Promise<*|Array>}
   */
  cls.prototype.getResourceAgentBrandList = async function ({resource_id, page = 0}) {
    const response = await cls.request({
      url: '/resource/agent-brand/index/${resource_id}',
      params: {
        resource_id
      },
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取资源的产品列表
   *
   * @param resource_id {Integer} 资源ID
   * @param page {Integer} 分页号
   * @returns {Promise<*|Array>}
   */
  cls.prototype.getResourceProductList = async function ({resource_id, page = 0}) {
    const response = await cls.request({
      url: '/resource/product-series/index/${resource_id}',
      params: {
        resource_id
      },
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取作品详情
   *
   * @param achievement_id {Integer} 作品ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchAchievementDetail = async function (achievement_id) {
    const response = await cls.request({
      url: '/resource/achievement/detail/${achievement_id}',
      params: {
        achievement_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 添加资源作品
   *
   * @param resource_id {Integer} 资源ID
   * @param title {String} 作品名称
   * @param introduction {String} 简介
   * @param thumbnail {String} 作品封面图
   * @param image_url[] {Array} 作品图片（多张数组）
   * @returns {Promise<*>}
   */
  cls.prototype.addResourceAchievement = async function ({resource_id, title, introduction, thumbnail, image_url}) {
    const response = await cls.request({
      method: 'post',
      url: 'resource/achievement/add/${resource_id}',
      params: {
        resource_id
      },
      data: {
        title,
        introduction,
        thumbnail,
        'image_url[]': image_url
      }
    })
    return response
  }

  /**
   * 编辑资源作品
   *
   * @param achievement_id {Integer} 资源作品ID
   * @param title {String} 作品名称
   * @param introduction {String} 简介
   * @param thumbnail {String} 作品封面图
   * @param image_url[] {Array} 作品图片（多张数组）
   * @returns {Promise<*>}
   */
  cls.prototype.editResourceAchievement = async function ({achievement_id, title, introduction, thumbnail, image_url}) {
    const response = await cls.request({
      method: 'post',
      url: 'resource/achievement/edit/${achievement_id}',
      params: {
        achievement_id
      },
      data: {
        title,
        introduction,
        thumbnail,
        'image_url[]': image_url
      }
    })
    return response
  }

  /**
   * 获取代理品牌详情
   *
   * @param agent_brand_id {Integer} 代理商品ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchAgentBrandDetail = async function (agent_brand_id) {
    const response = await cls.request({
      url: '/resource/agent-brand/detail/${agent_brand_id}',
      params: {
        agent_brand_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 添加资源代理品牌
   *
   * @param resource_id {Integer} 资源ID
   * @param title {String} 作品名称
   * @param introduction {String} 简介
   * @param thumbnail {String} 作品封面图
   * @param image_url[] {Array} 作品图片（多张数组）
   * @returns {Promise<*>}
   */
  cls.prototype.addResourceAgentBrand = async function ({resource_id, title, introduction, thumbnail, image_url}) {
    const response = await cls.request({
      method: 'post',
      url: 'resource/agent-brand/add/${resource_id}',
      params: {
        resource_id
      },
      data: {
        title,
        introduction,
        thumbnail,
        'image_url[]': image_url
      }
    })
    return response
  }

  /**
   * 编辑资源代理品牌
   *
   * @param agent_brand_id {Integer} 资源代理品牌ID
   * @param title {String} 作品名称
   * @param introduction {String} 简介
   * @param thumbnail {String} 作品封面图
   * @param image_url[] {Array} 作品图片（多张数组）
   * @returns {Promise<*>}
   */
  cls.prototype.editResourceAgentBrand = async function ({agent_brand_id, title, introduction, thumbnail, image_url}) {
    const response = await cls.request({
      method: 'post',
      url: 'resource/agent-brand/edit/${agent_brand_id}',
      params: {
        agent_brand_id
      },
      data: {
        title,
        introduction,
        thumbnail,
        'image_url[]': image_url
      }
    })
    return response
  }

  /**
   * 获取产品详情
   *
   * @param product_series_id {Integer} 产品ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchProductDetail = async function (product_series_id) {
    const response = await cls.request({
      url: '/resource/product-series/detail/${product_series_id}',
      params: {
        product_series_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 添加资源产品
   *
   * @param resource_id {Integer} 资源ID
   * @param title {String} 作品名称
   * @param introduction {String} 简介
   * @param thumbnail {String} 作品封面图
   * @param image_url[] {Array} 作品图片（多张数组）
   * @returns {Promise<*>}
   */
  cls.prototype.addResourceProduct = async function ({resource_id, title, introduction, thumbnail, image_url}) {
    const response = await cls.request({
      method: 'post',
      url: 'resource/product-series/add/${resource_id}',
      params: {
        resource_id
      },
      data: {
        title,
        introduction,
        thumbnail,
        'image_url[]': image_url
      }
    })
    return response
  }

  /**
   * 编辑资源产品
   *
   * @param product_series_id {Integer} 资源产品ID
   * @param title {String} 作品名称
   * @param introduction {String} 简介
   * @param thumbnail {String} 作品封面图
   * @param image_url[] {Array} 作品图片（多张数组）
   * @returns {Promise<*>}
   */
  cls.prototype.editResourceProduct = async function ({product_series_id, title, introduction, thumbnail, image_url}) {
    const response = await cls.request({
      method: 'post',
      url: 'resource/agent-brand/edit/${product_series_id}',
      params: {
        product_series_id
      },
      data: {
        title,
        introduction,
        thumbnail,
        'image_url[]': image_url
      }
    })
    return response
  }

  /**
   * 删除作品
   *
   * @param id {Integer} 作品ID
   * @returns {Promise<*>}
   */
  cls.prototype.resourceAchievementDelete = async function (id) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/achievement/delete/${id}',
      params: {
        id
      }
    })
    return response
  }
}
