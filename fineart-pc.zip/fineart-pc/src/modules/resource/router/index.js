/*
* @Author: Alan
* @Date:   2018-09-06 20:15:17
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-14 14:08:41
*/
import Vue from 'vue'
import Router from 'vue-router'
import Home from 'modules/resource/pages/Home.vue'
import AchievementDetail from 'modules/resource/pages/AchievementDetail.vue'
import ProductDetail from 'modules/resource/pages/ProductDetail.vue'
import AgentBrandDetail from 'modules/resource/pages/AgentBrandDetail.vue'

import PersonHome from 'modules/resource/pages/PersonHome.vue'
import CompanyHome from 'modules/resource/pages/CompanyHome.vue'
import SupplierHome from 'modules/resource/pages/SupplierHome.vue'
import BrandHome from 'modules/resource/pages/BrandHome.vue'
import DecoratorHome from 'modules/resource/pages/DecoratorHome.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/achievement-detail/:id',
      name: 'AchievementDetail',
      component: AchievementDetail,
      props: true
    },
    {
      path: '/product-detail/:id',
      name: 'ProductDetail',
      component: ProductDetail,
      props: true
    },
    {
      path: '/agent-brand-detail/:id',
      name: 'AgentBrandDetail',
      component: AgentBrandDetail,
      props: true
    },
    {
      path: '/person-home/:id',
      name: 'PersonHome',
      component: PersonHome,
      props: true
    },
    {
      path: '/company-home/:id',
      name: 'CompanyHome',
      component: CompanyHome,
      props: true
    },
    {
      path: '/supplier-home/:id',
      name: 'SupplierHome',
      component: SupplierHome,
      props: true
    },
    {
      path: '/brand-home/:id',
      name: 'BrandHome',
      component: BrandHome,
      props: true
    },
    {
      path: '/decorator-home/:id',
      name: 'DecoratorHome',
      component: DecoratorHome,
      props: true
    }
  ]
})
