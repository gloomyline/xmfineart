<template lang="html">
  <div id="app">
    <fineart-head activeName="2"></fineart-head>
    <router-view></router-view>
    <login-register-modal v-model="isShowed"></login-register-modal>
  </div>
</template>

<script>
import { FineartHead, LoginRegisterModal } from 'components'
export default {
  name: 'fineartMap',
  computed: {
    globalMessage () {
      return this.$store.state.message
    },
    isShowed: {
      set (value) {
        if (value) { // value 值为 true，提交显示模态窗
          this.$store.commit('SHOW_LOGIN_MODAL')
        } else { // value 值为 false，提交关闭模态窗
          this.$store.commit('CLOSE_LOGIN_MODAL')
        }
      },
      get () {
        return this.$store.state.showLogin
      }
    }
  },
  watch: {
    globalMessage (newVal) {
      const message = newVal
      let method = message.type
      if (message.cb) { // 如果有 message 展示完成的回调
        this.$message[method]({ content: message.msg, onClose: message.cb })
      } else {
        this.$message[method]({ content: message.msg })
      }
    }
  },
  components: {
    FineartHead,
    LoginRegisterModal
  }
}
</script>

<style lang="stylus">
  #app
    font-size: 12px
    color: $black
    height: 100%
</style>
