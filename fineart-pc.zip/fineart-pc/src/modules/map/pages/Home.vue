<template lang="html">
  <Page class="map-page">
    <div class="page-content">
      <div class="phone-cell">
        <img class="phone-pic" src="../../../assets/map/phone.png"/>
        <div class="map-frame">
          <iframe src="https://m.xmfineart.com/map.html#/"></iframe>
        </div>
      </div>
      <div class="map-qr-code">
        <div class="qr-item">
          <img src="../../../assets/map/map-qr-code.png"/>
          <p>使用手机浏览地图体验更佳</p>
        </div>
      </div>
    </div>
    <jump-top></jump-top>
  </Page>
</template>

<script>
import { Page, JumpTop } from 'components'
export default {
  name: 'Home',
  components: {
    Page,
    JumpTop
  }
}
</script>

<style lang="stylus">
.map-page
  .page-content
    position: absolute
    top: 0
    right: 0
    bottom: 0
    left: 0
    .phone-cell
      absolute: top 50% left 20%
      transform: translateY(-46%)
      .phone-pic
        width: 339px
      .map-frame
        width: 248px
        height: 515px
        overflow: hidden
        border-top: 1px solid $grey-high3
        absolute: left 53px top 62px
        border-radius: 0 0 30px 30px
        iframe
          width: 100%
          height: 100%
          border: none
    .map-qr-code
      absolute top 50% right 19%
      transform: translateY(-50%)
      .qr-item
        img
          width: 200px
          height: 200px
          margin-bottom: 20px
          border: 1px solid $grey-high4
          box-shadow: 2px 2px 2px rgba(0,0,0,0.04)
        p
          color: $black1
          font-size: 16px
          text-align: center
</style>
