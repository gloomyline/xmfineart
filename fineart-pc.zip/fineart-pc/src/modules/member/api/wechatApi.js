export default function (cls) {
  // 微信扫码登录
  cls.prototype.qrLogin = async ({ code }) => {
    const response = await cls.request({
      method: 'post',
      url: '/account/wechat/login/pc',
      data: { code }
    })
    // 登录成功，获取到用户登录凭证 token 之后
    if (response.code === 200) {
      // 存储 token 到 localStorage
      const tokenData = {
        value: response.results.token,
        expired: response.results.expired_timestamp
      }
      cls.saveTokenToLocalStorage(tokenData)
      // 挂载 token 到实例上
      cls.token = response.results.token
      return response
    }
    if (response.code === 402) { // code 认证失败
      window.location = 'index.html'
    }
  }

  // 微信解绑定
  cls.prototype.wechatUnbind = async function () {
    const response = await cls.request({
      url: '/account/wechat/unbind'
    })

    return response
  }
  // 微信绑定
  cls.prototype.wechatBind = async function ({ code, type = 'site' }) {
    const response = await cls.request({
      method: 'post',
      url: '/account/wechat/bind',
      data: { code, type }
    })

    return response
  }
}
