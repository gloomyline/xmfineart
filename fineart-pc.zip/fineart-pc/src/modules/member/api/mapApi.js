export default function (cls) {
  // 搜索未被绑定的地图标记信息
  cls.prototype.fetchMapMarkerList = async function ({ mobile, code }) {
    const response = await cls.request({
      method: 'post',
      url: '/map/marker/search',
      data: { mobile, code }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  // 获取当前用户可以被地图marker绑定的资源主页列表
  cls.prototype.fetchResourceListForMarker = async function () {
    const response = await cls.request({
      url: 'resource/list-for-marker'
    })

    if (response.code === 200) {
      return response.results
    }
  }

  // 绑定资源主页和地图marker
  cls.prototype.bindResourceAndMarker = async function ({ mobile, marker_id, resource_id, store_id }) {
    const response = await cls.request({
      method: 'post',
      url: '/map/marker/bind',
      data: { mobile, marker_id, resource_id, store_id }
    })

    return response
  }

  // 获取我的地图marker
  cls.prototype.fetchMyMarkerList = async function () {
    const response = await cls.request({
      url: '/map/marker/list'
    })

    if (response.code === 200) {
      return response.results
    }
  }

  // 删除我的地图marker
  cls.prototype.deleteMyMarker = async function (markerId) {
    const response = await cls.request({
      url: '/map/marker/delete/${markerId}',
      params: { markerId }
    })

    return response
  }

  // 编辑我的地图marker
  cls.prototype.editMyMarker = async function ({ marker_id, name, mobile, resource_id, store_id }) {
    const response = await cls.request({
      method: 'post',
      url: '/map/marker/edit',
      data: { marker_id, name, mobile, resource_id, store_id }
    })

    return response
  }

  // 重新定位marker
  cls.prototype.relocationMyMarker = async function ({ marker_id, lng, lat, address }) {
    const response = await cls.request({
      method: 'post',
      url: '/map/marker/relocation',
      data: { marker_id, lng, lat, address }
    })

    return response
  }
  // 获取当前用户可以被地图marker绑定的资源主页列表
  cls.prototype.fetchStoreListForMarker = async function () {
    const response = await cls.request({
      url: '/mall/store/list-for-marker'
    })

    if (response.code === 200) {
      return response.results
    }
  }
}
