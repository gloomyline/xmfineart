export default function (cls) {
  // 结算记录 agent=代理，promotion=推广
  cls.prototype.settlementList = async function (type) {
    const response = await cls.request({
      url: '/mall/settlement/${type}',
      params: {
        type
      }
    })

    return response.results
  }
}
