export default function (cls) {
  // 获取我关注的商品列表
  cls.prototype.collectGoodsList = async function (page) {
    const response = await cls.request({
      url: '/mall/collect/goods/list',
      query: { page }
    })

    return response.results
  }

  // 获取我关注的店铺列表
  cls.prototype.collectStoreList = async function (page) {
    const response = await cls.request({
      url: '/mall/collect/store/list',
      query: { page }
    })

    return response.results
  }

  /** v3.1
   * 获取我关注的 （资源、作品）
   * @param page 页码
   * @param object_type 对象类型：100=资源，200=资源作品
   * @returns {Promise<*|Array>}
   */
  cls.prototype.collectResourceList = async function ({page, object_type}) {
    const response = await cls.request({
      url: `/resource/collect/list/${object_type}`,
      query: {page}
    })

    return response.results
  }

  // 获取我关注的建筑列表
  cls.prototype.collectBuildingList = async function (page) {
    const response = await cls.request({
      url: '/building/collect/building/list',
      query: { page }
    })

    return response.results
  }
  /**
   * [v3.1]资源作品/资源 => 收藏/取消收藏
   * @param object_type 对象类型 100=资源，200=资源作品, 300=动态
   * @param object_id 对象ID
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleResourceCollect = async function ({ object_type, object_id }) {
    const response = await cls.request({
      url: `/resource/collect/${object_type}/${object_id}`
    })
    return response
  }
}
