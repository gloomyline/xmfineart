export default function (cls) {
  /**
   * 我的店铺详情
   *
   * @param id {Integer} 店铺ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchStoreDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/store/detail/${id}',
      params: {
        id
      }
    })

    return response.results
  }

  /**
   * 店铺管理-申请开店
   *
   * @param name {String} 店铺名称
   * @param subtitle {String} 主营商品
   * @param introduction {String} 店铺介绍
   * @param thumbnail {String} 店铺封面
   * @param manager {String} 店铺主图
   * @param mobile {String} 联系电话
   * @param lng {float} 经度信息
   * @param lat {float} 纬度信息
   * @param sys_area_id {Integer} 地区ID
   * @param address {String} 详细地址
   * @param mall_store_category_id {Integer} 店铺类型
   * @param store_images {String} 店铺主图
   * @returns {Promise<*>}
   */
  cls.prototype.insertStoreInfo = async function ({ name, subtitle, introduction, thumbnail, manager, mobile, lng, lat, sys_area_id, address, mall_store_category_id, store_images }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/store/apply',
      data: {
        name,
        subtitle,
        introduction,
        thumbnail,
        manager,
        mobile,
        lng,
        lat,
        sys_area_id,
        address,
        mall_store_category_id,
        'store_images[]': store_images
      }
    })

    return response
  }

  // 获取审核中或者审核未通过的店铺信息
  cls.prototype.storeApplyInfo = async function () {
    const response = await cls.request({
      url: '/mall/store/apply'
    })

    return response.results
  }

  /**
   * 店铺管理-店铺编辑
   *
   * @param id {Integer} 店铺ID
   * @param name {String} 店铺名称
   * @param subtitle {String} 主营商品
   * @param introduction {String} 店铺介绍
   * @param thumbnail {String} 店铺封面
   * @param manager {String} 店铺主图
   * @param mobile {String} 联系电话
   * @param lng {float} 经度信息
   * @param lat {float} 纬度信息
   * @param sys_area_id {Integer} 地区ID
   * @param address {String} 详细地址
   * @param mall_store_category_id {Integer} 店铺类型
   * @param store_images {String} 店铺主图
   * @returns {Promise<*>}
   */
  cls.prototype.editStoreInfo = async function ({ id, name, subtitle, introduction, thumbnail, manager, mobile, lng, lat, sys_area_id, address, mall_store_category_id, store_images }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/store/edit/${id}',
      params: {
        id
      },
      data: {
        name,
        subtitle,
        introduction,
        thumbnail,
        manager,
        mobile,
        lng,
        lat,
        sys_area_id,
        address,
        mall_store_category_id,
        'store_images[]': store_images
      }
    })

    return response
  }

  /**
   * 我的店铺列表
   *
   * @returns {Promise<*|Array>}
   */
  cls.prototype.storeMyList = async function () {
    const response = await cls.request({
      url: '/mall/store/list'
    })

    return response.results
  }
  /**
   * 获取会员所有店铺特性
   *
   * @returns {Promise<*|Array>}
   */
  cls.prototype.storeAttributeList = async function () {
    const response = await cls.request({
      url: '/mall/store/attribute'
    })

    return response.results
  }
}
