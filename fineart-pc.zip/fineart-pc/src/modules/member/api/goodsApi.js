export default function (cls) {
  // 在售商品列表
  cls.prototype.goodsList = async function ({page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/store/goods',
      query: {
        page,
        keyword,
        status
      }
    })

    return response.results
  }

  // 获取在售商品详情
  cls.prototype.fetchGoodsDetail = async function ({goods_id, store_id}) {
    const response = await cls.request({
      url: '/mall/goods/detail/${goods_id}/${store_id}',
      params: {
        goods_id,
        store_id
      }
    })

    return response.results
  }

  // 获取在售商品详情-编辑时渲染页面使用
  cls.prototype.goodsDetailInfo = async function (goods_id) {
    const response = await cls.request({
      url: '/mall/store/goods/${goods_id}',
      params: {
        goods_id
      }
    })

    return response.results
  }

  // 代理商品列表
  cls.prototype.goodsAgentList = async function ({page, keyword}) {
    const response = await cls.request({
      url: '/mall/store/agent-goods',
      query: {
        page,
        keyword
      }
    })

    return response.results
  }

  // 推广商品列表
  cls.prototype.goodsPromotionList = async function ({page, keyword}) {
    const response = await cls.request({
      url: '/mall/promotion/goods',
      query: {
        page,
        keyword
      }
    })

    return response.results
  }

  // 商品上架，下架 status=300(上架)|400(下架)
  cls.prototype.goodsUpdateStatus = async function (goods_ids, status) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/store/goods/edit-status',
      data: {
        'goods_id[]': goods_ids,
        'status': status
      }
    })

    return response
  }

  // 商品编辑
  cls.prototype.goodsEdit = async function (goods_id, {category_id, attribute, name, subtitle, price_norm, price_discount, stock, thumbnail, introduction, goods_images}) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/store/goods/edit',
      data: {
        'id': goods_id,
        'category_id': category_id,
        'attribute': attribute,
        'name': name,
        'subtitle': subtitle,
        'price_norm': price_norm,
        'price_discount': price_discount,
        'stock': stock,
        'thumbnail': thumbnail,
        'introduction': introduction,
        'goods_images[]': goods_images
      }
    })

    return response
  }

  // 商品上传
  cls.prototype.goodsAdd = async function ({category_id, attribute, name, subtitle, price_norm, price_discount, stock, thumbnail, introduction, goods_images}) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/store/goods/add',
      data: {
        'category_id': category_id,
        'attribute': attribute,
        'name': name,
        'subtitle': subtitle,
        'price_norm': price_norm,
        'price_discount': price_discount,
        'stock': stock,
        'thumbnail': thumbnail,
        'introduction': introduction,
        'goods_images[]': goods_images
      }
    })

    return response
  }
}
