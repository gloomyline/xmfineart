export default function (cls) {
  // 申请订单售后
  cls.prototype.orderServiceApply = async function ({code, apply_operate, apply_reason}) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/service/buyer/add',
      data: {
        code,
        apply_operate,
        apply_reason
      }
    })

    return response
  }

  // 售后详情
  cls.prototype.orderServiceDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/service/buyer/${id}',
      params: {
        id
      }
    })

    return response.results
  }

  // 卖家售后列表
  cls.prototype.orderServiceSellerList = async function ({page, keyword, handle_status}) {
    const response = await cls.request({
      url: '/mall/service/seller',
      query: {
        page,
        keyword,
        handle_status
      }
    })

    return response.results
  }

  // 卖家售后详情
  cls.prototype.orderServiceSellerDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/service/seller/${id}',
      params: {id}
    })

    return response.results
  }

  // 卖家售后售后处理
  cls.prototype.orderServiceSellerHandle = async function ({id, handle_status, handle_reason, refund}) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/service/seller/handle',
      data: {
        id,
        handle_status,
        handle_reason,
        refund
      }
    })

    return response
  }
}
