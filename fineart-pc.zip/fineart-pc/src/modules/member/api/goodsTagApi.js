export default function (cls) {
  // 获取指定店铺的所有商品标签
  cls.prototype.goodsTagList = async function (store_id, is_all) {
    const response = await cls.request({
      url: '/mall/goods/tag/list',
      query: {
        store_id,
        is_all
      }
    })

    return response.results
  }

  // 商品标签添加
  cls.prototype.goodsTagAdd = async function (goods_id, tag) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/goods/tag/add',
      data: {
        goods_id,
        tag
      }
    })

    return response
  }

  // 商品标签删除
  cls.prototype.goodsTagDel = async function (id) {
    const response = await cls.request({
      url: '/mall/goods/tag/delete/${id}',
      params: {
        id
      }
    })

    return response
  }
}
