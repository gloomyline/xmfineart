export default function (cls) {
  // 创建文件上传参数
  cls.prototype.ossParamsCreate = async function (file, module, params) {
    // 定义参数获取的方法
    const getPolicy = async function (module) {
      const response = await cls.request({
        url: '/sys/oss/policy/${module}',
        params: {
          module
        }
      })

      if (response.code === 200) {
        return response.results
      }
    }

    const timestamp = Date.parse(new Date())
    // 判断是否过期，过期再次请求一次，未过期就不请求，继续使用之前的数据
    if (!params.expire || params.expire * 1000 < timestamp) {
      let option = await getPolicy(module)
      params = {
        host: option.host,
        format: option.filters.types.split(','),
        max_size: option.filters.max_size,
        dir: option.dir,
        expire: option.expire,
        accept: option.filters.types,
        data: {
          name: file.name,
          OSSAccessKeyId: option.accessid,
          Policy: option.policy,
          signature: option.signature,
          callback: option.callback,
          key: `${option.dir}${fnRename(file.name)}`
        }
      }
    } else {
      params.data.name = file.name
      params.data.key = `${params.dir}${fnRename(file.name)}`
    }

    return params
  }
}
/**
 * 重命名上传文件名
 *
 * @param sFilename {String} 文件名
 * @param iLen {Number} 重命名的长度
 * @returns {String}
 */
const fnRename = (sFilename, iLen) => {
  iLen = iLen || 17
  let chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
  let id = ''
  let rand
  for (let i = 0; i < iLen; i++) {
    rand = Math.floor(Math.random() * chars.length)
    id += chars.charAt(rand)
  }
  return sFilename.replace(/[^.]*/, id)
}
