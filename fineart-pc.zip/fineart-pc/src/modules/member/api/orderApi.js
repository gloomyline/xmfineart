export default function (cls) {
  // 我的订单列表
  cls.prototype.orderMyList = async function ({page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/order/buyer',
      query: {
        page,
        keyword,
        status
      }
    })

    return response.results
  }

  // 我的订单详情
  cls.prototype.orderMyDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/order/buyer/detail/${id}',
      params: { id }
    })

    return response.results
  }

  // 买家变更订单状态
  cls.prototype.orderBuyerUpdateStatus = async function (id, status) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/order/buyer/status',
      data: { id, status }
    })

    return response
  }

  // 卖家订单列表
  cls.prototype.orderSellerList = async function (store_id, {page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/order/seller',
      query: {
        store_id,
        page,
        keyword,
        status
      }
    })

    return response
  }

  // 卖家订单详情
  cls.prototype.orderSellerDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/order/seller/detail/${id}',
      params: {
        id
      }
    })

    return response.results
  }

  // 卖家发货
  cls.prototype.orderSellerSendOut = async function ({id, express_code, express_company}) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/order/seller/send-out',
      data: {
        id,
        express_code,
        express_company
      }
    })

    return response
  }

  // 卖家调整订单金额
  cls.prototype.orderSellerPriceAdjust = async function (order_id, price) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/order/seller/adjust',
      data: {
        id: order_id,
        price: price
      }
    })

    return response
  }

  // 卖家订单列表-代理商品
  cls.prototype.orderSellerAgentList = async function ({page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/order/seller/agent',
      query: {
        page,
        keyword,
        status
      }
    })

    return response.results
  }

  // 卖家订单列表-推广商品
  cls.prototype.orderSellerPromotionList = async function ({page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/promotion/order',
      query: {
        page,
        keyword,
        status
      }
    })

    return response.results
  }
}
