export default function (cls) {
  // 生成链接二维码
  cls.prototype.qrcodeCreate = async function (url) {
    const response = await cls.request({
      url: '/sys/qrcode/create',
      query: {
        url
      }
    })

    return response.results
  }
}
