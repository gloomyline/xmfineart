/**
 * @comment: member api instance
 * @author: alan_wang
 * @date: 11/10/2018
 * @time: 14:01:35
 */
import {BaseApi} from '@/common/js/BaseApi'
import initAuth from './initAuth.js'
import addressApi from './addressApi'
import collectApi from './collectApi'
import mapApi from './mapApi'
import orderApi from './orderApi'
import commentApi from './commentApi'
import goodsApi from './goodsApi'
import orderServiceApi from './orderServiceApi'
import storeApi from './storeApi'
import qrcodeApi from './qrcodeApi'
import resourceApi from './resourceApi'
import goodsTagApi from './goodsTagApi'
import settlementApi from './settlementApi'
import ossApi from './ossApi'
import expressApi from './expressApi'
import wechatApi from './wechatApi'

class MemberApi extends BaseApi {
  static token

  // 会员中心模块用户登录凭证
  constructor () {
    super()
    this._init()
  }

  _init () {
    MemberApi.updateToken(MemberApi.readTokenFromLocalStorage())
    initAuth(MemberApi)
    addressApi(MemberApi)
    collectApi(MemberApi)
    mapApi(MemberApi)
    orderApi(MemberApi)
    commentApi(MemberApi)
    goodsApi(MemberApi)
    orderServiceApi(MemberApi)
    storeApi(MemberApi)
    goodsApi(MemberApi)
    qrcodeApi(MemberApi)
    resourceApi(MemberApi)
    goodsTagApi(MemberApi)
    settlementApi(MemberApi)
    ossApi(MemberApi)
    expressApi(MemberApi)
    wechatApi(MemberApi)
  }
}

const memberApi = new MemberApi()

export default memberApi
