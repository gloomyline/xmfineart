<template>
  <div id="app">
    <fineart-head></fineart-head>
    <page>
      <section class="page-content member-wrap">
        <div class="sidebar">
          <i-menu width="178px" :active-name="parseInt(activeName)">
            <i-menu-group v-for="(item, index) in sidebars"
                          :title="item.name"
                          :key="index">
              <i-menu-item v-for="(sidebar, index) in item.children"
                           :name="sidebar.order"
                           :to="sidebar.route"
                           v-show="!sidebar.isShow"
                           :key="index"
                           @click.native="goToMyCart($event, sidebar)">{{ sidebar.name }}</i-menu-item>
            </i-menu-group>
          </i-menu>
        </div>
        <router-view class="wrapper"></router-view>
      </section>
    </page>
    <login-register-modal v-model="isShowed"></login-register-modal>
  </div>
</template>

<script>
import { FineartHead, Page, LoginRegisterModal } from 'components'
import { Menu, MenuItem, MenuGroup } from 'iview'
import api from 'modules/member/api/index.js'
import { mapState } from 'vuex'
export default {
  name: 'member',
  data () {
    return {
      isShowManage: false,
      activeName: this.$route.meta.order,
      sidebars: [
        {
          name: '账号管理',
          children: [
            {
              order: 1,
              name: '账号安全',
              route: '/account'
            },
            {
              order: 2,
              name: '我的关注',
              route: '/my-collection'
            },
            {
              order: 3,
              name: '我的预约',
              route: '/my-reservation'
            },
            {
              order: 4,
              name: '收货地址',
              route: '/my-address'
            }
          ]
        },
        {
          name: '我的订单',
          children: [
            {
              order: 5,
              name: '我的订单',
              route: '/my-order'
            },
            {
              order: 6,
              name: '我的购物车',
              route: ''
            }
          ]
        },
        {
          name: '经营中心',
          children: [
            {
              order: 7,
              name: '选择店铺',
              route: '/business/choose-store'
            },
            {
              order: 8,
              name: '店铺管理',
              route: '/store-manage/has-sold',
              isShow: true
            },
            {
              order: 9,
              name: '我的推广',
              route: '/promotion-goods',
              isShow: true
            }
          ]
        },
        {
          name: '主页管理',
          children: [
            {
              order: 10,
              name: '主页管理',
              route: '/home-manage'
            }
          ]
        },
        {
          name: '地图管理',
          children: [
            {
              order: 11,
              name: '地图管理',
              route: '/map-manage'
            }
          ]
        }
      ]
    }
  },
  computed: {
    ...mapState('member', ['storeInfo']),
    globalMessage () {
      return this.$store.state.message
    },
    isShowed: {
      set (value) {
        if (value) { // value 值为 true，提交显示模态窗
          this.$store.commit('SHOW_LOGIN_MODAL')
        } else { // value 值为 false，提交关闭模态窗
          this.$store.commit('CLOSE_LOGIN_MODAL')
        }
      },
      get () {
        return this.$store.state.showLogin
      }
    }
  },
  watch: {
    '$route' (newVal) {
      this.activeName = newVal.meta.order
    },
    globalMessage (newVal) {
      const message = newVal
      let method = message.type
      if (message.cb) { // 如果有 message 展示完成的回调
        this.$message[method]({ content: message.msg, onClose: message.cb })
      } else {
        this.$message[method]({ content: message.msg })
      }
    },
    storeInfo: {
      handler (newVal) {
        if (Object.keys(newVal).length !== 0 && this.isShowManage) {
          this.sidebars[2].children[1].isShow = false
        }
      },
      deep: true
    }
  },
  created () {
    this.initMemberSidebar()
    const store = this.$localStorage.get('MEMBER_CUR_STORE')
    if (store && store.id) {
      this.$store.commit('member/MEMBER_STORE_MANAGE_STORE_INFO', store)
    }
  },
  methods: {
    goToMyCart (e, sidebar) {
      e.preventDefault()
      if (sidebar.order === 6) {
        window.location = '/mall.html#/mall-cart'
      }
    },
    async initMemberSidebar () {
      const response = await api.storeAttributeList()
      for (let item in response.attr) {
        switch (response.attr[item]) {
        case '100':
          this.sidebars[2].children[2].isShow = false // 显示我的推广
          break
        case '200':
        case '300':
        case '400':
          this.isShowManage = true // 显示店铺管理
          break
        }
      }
      if (Object.keys(this.storeInfo).length !== 0 && this.isShowManage) {
        this.sidebars[2].children[1].isShow = false
      }
    }
  },
  components: {
    Page,
    FineartHead,
    LoginRegisterModal,
    'i-menu': Menu,
    'i-menu-item': MenuItem,
    'i-menu-group': MenuGroup
  }
}
</script>

<style lang="stylus">
#app
  height: 100%
  font-size: 12px
  color: $black
  .member-wrap
    display: flex
    padding-top: 40px
    .sidebar
      top: 120px
      height: 100%
      width: 180px
      position: sticky
      position: -webkit-sticky
      margin: 0 20px 58px 0
      .ivu-menu
        border: 1px solid $grey-high4
        .ivu-menu-item-group
          padding-bottom: 24px
      .ivu-menu-item-group-title
        height: 50px
        padding: 0
        color: $grey-high
        font-size: 14px
        line-height: 50px
        text-align: center
        background-color: $grey-high5
      .ivu-menu-vertical.ivu-menu-light:after
        background: transparent
      .ivu-menu-item
        text-align: center
        font-size: 14px
        color: $black
        padding: 0
        margin: 24px 0 0  0
        &:hover
          color: $orange
        &.ivu-menu-item-active:not(.ivu-menu-submenu)
          color: $orange
          background-color: transparent
          &:after
            left: 0
            width: 4px
            height: 18px
    .wrapper
      width: 1000px
</style>
