<template lang="html">
  <div class="choice-home-page">
    <p class="tip">根据您的需求，申请开通、管理主页。用户可以浏览您的主页，添加真实、完善的信息，可带来更多业务可能。</p>
    <ul class="home-list" v-show="showData">
      <li class="home-item"
          :key="index"
          v-for="(item, index ) in homePageList">
        <div class="img-wrap"><img :src="item.bgImg"/></div>
        <div class="home-info">
          <p class="title">{{ item.titleText }}</p>
          <p class="mode-desc">{{ item.modeDesc }}</p>
          <div class="name-wrap">
            <span class="name"  v-if="item.name">{{ item.name }}</span>
            <span class="name-null" v-else>未开通</span>
          </div>
          <p class="handle-box">
            <i-button v-if="item.status === null"
                      type="primary"
                      @click="openHome(index)">申请开通</i-button>
            <i-button v-if="item.status === '100'"
                      class="verifying"
                      @click="openHome(index, item.id)">审核中</i-button>
            <i-button v-if="item.status === '200'"
                      @click="openHome(index, item.id)">审核失败</i-button>
            <i-button v-if="item.status === '300'"
                      type="primary" ghost
                      @click="goDetail(index,item.id)">查看主页</i-button>
          </p>
        </div>
      </li>
    </ul>
    <i-modal class="store-tips-modal" v-model="isShowed"
              title="温馨提示"
              width="440">
      <p class="tip-text">需完成账号实名认证才能继续使用该功能，如需请点击 去认证，前往认证。</p>
      <div slot="footer">
        <div class="save-btn-group">
          <i-button type="text"
                    class="cancel"
                    @click="isShowed = false">取消</i-button>
          <i-button class="save-btn"
                    type="primary"
                    size="large"
                    to="/real-name">去认证</i-button>
        </div>
      </div>
     </i-modal>
  </div>
</template>

<script>
import { Button, Modal } from 'iview'
import { mapState } from 'vuex'
import api from 'modules/member/api/index.js'

export default {
  name: 'ChoiceHome',
  data () {
    return {
      homePageList: { // 优秀个人=100，优秀公司=200，优秀供应商=300，优秀品牌=400
        '100': {
          bgImg: require('../../../../assets/member/choice-home-person.png'),
          titleText: '个人主页',
          modeDesc: '',
          name: '',
          introduction: '',
          status: null // null=未申请，100=待审核，200=审核失败，300=审核通过，400=隐藏
        },
        '200': {
          bgImg: require('../../../../assets/member/choice-home-company.png'),
          titleText: '公司主页',
          modeDesc: '设计、建造、运营类',
          name: '',
          introduction: '',
          status: null
        },
        '300': {
          bgImg: require('../../../../assets/member/choice-home-supplier.png'),
          titleText: '公司主页',
          modeDesc: '供应商、代理商、经销商类',
          name: '',
          introduction: '',
          status: null
        },
        '400': {
          bgImg: require('../../../../assets/member/choice-home-brand.png'),
          titleText: '公司主页',
          modeDesc: '品牌方、生产方类',
          name: '',
          introduction: '',
          status: null
        },
        '500': {
          bgImg: require('../../../../assets/member/choice-home-decorator.png'),
          titleText: '装修师主页',
          modeDesc: '班组、工长类',
          name: '',
          introduction: '',
          status: null
        }
      },
      isShowed: false,
      showData: false
    }
  },
  created () {
    this.initPage()
  },
  computed: {
    ...mapState('member', ['memberInfo'])
  },
  methods: {
    // 获取用户所有资源列表
    async initPage () {
      let res = await api.resourceMyList()
      if (res.code === 200) {
        if (Object.keys(res.results).length > 0) {
          for (let key in res.results) {
            this.homePageList[key].id = res.results[key].id
            this.homePageList[key].status = res.results[key].status
            this.homePageList[key].name = res.results[key].name
            if (res.results[key].introduction) {
              this.homePageList[key].introduction = res.results[key].introduction.replace(/<\/?[^>]*>/g, '')
            }
          }
        }
        this.showData = true
      }
    },
    // 前往申请主页
    openHome (mode, id) {
      if (this.memberInfo.is_auth === '100') {
        this.isShowed = true
      } else {
        if (id === undefined) {
          this.$router.push(`open-home/${mode}`)
        } else {
          this.$router.push(`open-home/${mode}/${id}`)
        }
      }
    },
    // 前往资源详情页
    goDetail (mode, id) {
      switch (mode) {
      case '100':
        window.location = `/resource.html#/person-home/${id}`
        break
      case '200':
        window.location = `/resource.html#/company-home/${id}`
        break
      case '300':
        window.location = `/resource.html#/supplier-home/${id}`
        break
      case '400':
        window.location = `/resource.html#/brand-home/${id}`
        break
      case '500':
        window.location = `/resource.html#/decorator-home/${id}`
        break
      }
    }
  },
  components: {
    'i-button': Button,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.choice-home-page
  padding: 0 50px
  .tip
    color: $black1
    font-size: 14px
    margin-top: 20px
  .home-list
    padding: 34px 0
    font-size: 0
    display: flex
    flex-wrap: wrap
    margin-right: -60px
  .home-item
    font-size: 0
    margin-right: 60px
    margin-bottom: 50px
    border-radius: 4px
    background: $white
    width: 258px!important
    height: 318px!important
    .img-wrap
      width: 100%
      height: 100px
      overflow: hidden
      img
        width: 100%
    .home-info
      width: 100%
      height: 218px
      padding: 0 14px
      border-radius: 4px
      border: 1px solid $grey-high4
      border-top: none
      .title
        display: flex
        color: $black1
        font-size: 16px
        font-weight: 600
        line-height: 22px
        padding: 24px 0 10px 0
        align-items: center
        justify-content: center
        &:before, &:after
          content: ''
          height: 1px
          width: 22px
          margin: 0 5px
          border-top: 2px solid $grey
      .mode-desc
        color: $grey3
        font-size: 14px
        height: 20px
        line-height: 20px
        text-align: center
      .name-wrap
        width: 100%
        margin: 24px 0
        padding: 0 30px
        font-size: 14px
        line-height: 34px
        text-align: center
        border-radius: 4px
        background: $grey-high6
        {ellipse}
        .name
          color: $black1
        .name-null
          color: $grey-high1
    .handle-box
      width: 100%
      text-align: center
      .ivu-btn
        padding: 0
        margin: 0
        width: 128px
        font-size: 14px
        line-height: 36px
        border-radius: 50px
        &.ivu-btn-primary
          box-shadow: 0px 4px 14px 0px rgba(247,181,44,0.48)
          &.ivu-btn-ghost
            box-shadow: none
        &.verifying
          color: $white
          background: $grey-high1
          border: 1px solid $grey-high1
          box-shadow: 0px 4px 14px 0px rgba(187,187,187,0.51)
          &:hover
            border-color: $grey-high1
.save-btn
  line-height: 36px
  span
    display: inline
</style>
