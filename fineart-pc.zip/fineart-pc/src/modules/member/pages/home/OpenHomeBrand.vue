<template lang="html">
  <div class="open-home-page">
    <p class="title">申请开通品牌持有者/厂商类型-企业主页</p>
    <p class="describe">输入如下基本信息用于平台审核，审核通过后为您创建主页。</p>
    <p class="describe">在主页里，您还可以添加参与案例等丰富内容。</p>
    <p class="apply-false-reason" v-if="openHomeForm.status === '200'">
      <label>审核失败</label>
      <span>{{ openHomeForm.reason }}</span>
    </p>
    <i-form class="open-home-form"
            ref="openHomeForm"
            :model="openHomeForm"
            :rules="openHomeRule">
      <i-form-item class="home-add-item" label="公司logo" prop="logo">
          <div class="uploaded-img" v-if="openHomeForm.logo_cdn">
              <img :src="openHomeForm.logo_cdn">
              <div class="img-edit-cover">
                  <span class="fy-icon-delete-round" @click.stop="goDelLogo()"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
              </div>
          </div>
          <i-upload ref="upload"
                    v-if="openHomeForm.logo_cdn === ''"
                    :show-upload-list="false"
                    :max-size="ossLogo.max_size"
                    type="drag"
                    :data="ossLogo.data"
                    :action="ossLogo.host"
                    :format="ossLogo.format"
                    :accept="ossLogo.accept"
                    :before-upload="beforeUploadLogo"
                    :on-success="successLogo"
                    :on-exceeded-size="exceededSize"
                    :on-format-error="formatError">
              <div class="upload-box">
                  <span class="fy-icon-upload"></span>
                  <em>点击上传</em>
              </div>
          </i-upload>
          <p class="upload-tip">图片尺寸：最小300*300px，大小不超过5MB；<br/>上传正方形图片视觉效果更佳</p>
      </i-form-item>
      <i-form-item class="home-add-item" label="公司名称" prop="name">
        <i-input placeholder="请输入公司名称" v-model="openHomeForm.name"></i-input>
      </i-form-item>
      <i-form-item class="home-add-item" label="介绍公司" prop="subtitle">
        <i-input v-model.trim="openHomeForm.subtitle" :maxlength="128" placeholder="请输入一句话介绍公司的业务"></i-input>
      </i-form-item>
      <i-form-item class="home-add-item" label="品牌简介" prop="introduction">
        <i-input v-model="openHomeForm.introduction"
                 type="textarea"
                 :rows="5"
                 placeholder="请输入品牌简介"></i-input>
      </i-form-item>
      <i-form-item class="home-add-item resource-category" prop="resource_category_id">
        <fineart-cascader :width="'640'"
                          :data="categoryList"
                          :changeOnSelect="false"
                          v-model="category"
                          @change-category="changeCategory"></fineart-cascader>
      </i-form-item>
      <i-form-item class="home-add-item" label="营业执照">
        <div class="uploaded-img" v-if="openHomeForm.license_cdn">
          <img :src="openHomeForm.license_cdn">
          <div class="img-edit-cover">
            <span class="fy-icon-delete-round" @click.stop="goDelLicense()"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
          </div>
        </div>
        <i-upload ref="upload"
                  v-if="openHomeForm.license_cdn === ''"
                  :show-upload-list="false"
                  :max-size="ossLicense.max_size"
                  type="drag"
                  :data="ossLicense.data"
                  :action="ossLicense.host"
                  :format="ossLicense.format"
                  :accept="ossLicense.accept"
                  :before-upload="beforeUploadLicense"
                  :on-success="successLicense"
                  :on-exceeded-size="exceededSize"
                  :on-format-error="formatError">
          <div class="upload-box">
            <span class="fy-icon-upload"></span>
            <em>点击上传</em>
          </div>
        </i-upload>
        <p class="upload-tip">上传您营业执照的照片用于审核，<br/> 文件大小不超过5M；</p>
      </i-form-item>
      <i-form-item class="home-add-item" label="联系人" prop="contact_name">
        <i-input v-model.trim="openHomeForm.contact_name" placeholder="请输入联系人姓名"></i-input>
      </i-form-item>
      <i-form-item class="home-add-item" label="联系邮箱" prop="email">
        <i-input v-model.trim="openHomeForm.email" placeholder="请输入联系人邮箱"></i-input>
      </i-form-item>
      <i-form-item class="home-add-item" label="联系手机" prop="mobile">
        <i-input v-model.trim.number="openHomeForm.mobile" placeholder="请输入手机号"></i-input>
      </i-form-item>
      <i-form-item class="home-add-item" label="地区" >
          <i-input v-model.trim.number="openHomeForm.area" @on-focus="mapAddress=true" placeholder="请选择地区"></i-input>
      </i-form-item>
      <i-form-item class="home-add-item address-detail" label="详细地址" prop="address">
          <i-input v-model="openHomeForm.address" @on-focus="mapAddress=true" placeholder="请输入详细地址"></i-input>
          <p>系统会按距离优先推送资源给用户，准备的定位有助于您获得更多业务机会。</p>
      </i-form-item>
      <fa-map v-model="mapAddress"
              :lng="openHomeForm.lng"
              :lat="openHomeForm.lat"
              :address="openHomeForm.address"
              :sysAreaId="openHomeForm.sys_area_id"
              @save-edit="editArea"></fa-map>
      <i-form-item class="home-add-item">
        <i-button class="commit-btn" type="primary" @click="handleSubmit('openHomeForm')">提交</i-button>
      </i-form-item>
    </i-form>
  </div>
</template>

<script>
import { FaMap, FineartCascader } from 'components'
import { getResourceCategory, find } from '@/common/js/loadScript.js'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'
import {
  Form,
  Input,
  Select,
  Option,
  Upload,
  Button,
  FormItem,
  Dropdown,
  DropdownMenu
} from 'iview'

export default {
  name: 'OpenHomeBrand',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{9}\d$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      mapAddress: false,
      resourceId: this.$route.params.id,
      resourceMode: 400,
      categoryList: [],
      category: [],
      openHomeForm: {
        logo: '', // 企业LOGO，必须
        logo_cdn: '',
        name: '', // 企业名称，必须
        introduction: '', // 企业简介，必须
        license: '', // 营业执照，必须
        license_cdn: '',
        contact_name: '', // 联系人姓名，必须
        subtitle: '', // 一句话介绍，必须
        resource_category_id: '', // 分类ID，必须
        email: '', // 联系邮箱，必须
        mobile: '', // 联系手机，必须
        sys_area_id: '', // 地区ID，必须
        address: '', // 详细地址，必须
        lng: '', // 经度，必须
        lat: '', // 纬度，必须
        status: '100'
      },
      openHomeRule: {
        logo: [
          { required: true, message: '请上传公司logo', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入公司名称' }
        ],
        introduction: [
          { required: true, message: '请输入公司简介' }
        ],
        subtitle: [
          { required: true, message: '请输入一句话介绍公司的业务' }
        ],
        resource_category_id: [
          { required: true, message: '请选择分类' }
        ],
        license: [
          { required: true, message: '请上传营业执照', trigger: 'blur' }
        ],
        contact_name: [
          { required: true, message: '请输入联系人姓名' }
        ],
        email: [
          { required: true, message: '请输入邮箱' },
          { type: 'email', message: '邮箱格式不正确' }
        ],
        mobile: [
          { required: true, message: '请输入手机号' },
          mobileValidator
        ],
        address: [
          { required: true, message: '请输入详细地址' }
        ]
      },
      visible: false,
      ossLogo: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      ossLicense: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      }
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.initCategory()
      if (this.resourceId !== undefined) {
        this.openHomeForm = await api.resourceMyDetail(this.resourceId, this.resourceMode)
        let region = []
        for (let key in this.openHomeForm.area_line) {
          if (key !== '1') {
            region.push(this.openHomeForm.area_line[key])
          }
        }
        this.category = Object.keys(this.openHomeForm.category_line)
        this.openHomeForm.area = region.join(' / ')
      }
    },
    async initCategory () {
      const categoryList = await getResourceCategory()
      this.categoryList = find(categoryList, parseInt(this.resourceMode)).children
    },
    async editArea (mapAddress) {
      this.openHomeForm.lng = mapAddress.point.lng
      this.openHomeForm.lat = mapAddress.point.lat
      this.openHomeForm.sys_area_id = mapAddress.sysAreaId
      this.openHomeForm.area = mapAddress.addressData.province + ' / ' + mapAddress.addressData.city + ' / ' + mapAddress.addressData.district
      this.openHomeForm.address = mapAddress.addressData.address
    },
    changeCategory (param) {
      this.openHomeForm.resource_category_id = param
    },
    handleSubmit (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          let res = await api.resourceApplyCommon(400, this.openHomeForm)
          if (res.code === 200) {
            this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_HOME_APPLY_SUCCESS'], type: 'success'})
            this.$router.push({path: '/home-manage/choice-home'})
          }
        }
      })
    },
    async beforeUploadLogo (file) {
      this.ossLogo = await api.ossParamsCreate(file, 'resource_logo', this.ossLogo)
    },
    successLogo (res) {
      if (res.code === 200) {
        this.openHomeForm.logo_cdn = res.results.file_url_cdn
        this.openHomeForm.logo = res.results.file_url
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    goDelLogo () {
      this.openHomeForm.logo = ''
      this.openHomeForm.logo_cdn = ''
    },
    async beforeUploadLicense (file) {
      this.ossLicense = await api.ossParamsCreate(file, 'resource_license', this.ossLicense)
    },
    successLicense (res) {
      if (res.code === 200) {
        this.openHomeForm.license_cdn = res.results.file_url_cdn
        this.openHomeForm.license = res.results.file_url
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    goDelLicense () {
      this.openHomeForm.license = ''
      this.openHomeForm.license_cdn = ''
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    }
  },
  components: {
    FaMap,
    FineartCascader,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-upload': Upload,
    'i-button': Button,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-dropdown': Dropdown,
    'i-dropdown-menu': DropdownMenu
  }
}
</script>

<style lang="stylus">
  .open-home-page
    position: relative
    padding-left: 10px
    p
      &.title
        font-size: 18px
        margin-bottom: 20px
      &.describe
        font-size: 14px
        color: $black1
        margin-bottom: 10px
      &.apply-false-reason
        font-size: 16px
        color: $orange
        padding: 20px 0
        label
          margin-right: 20px
          display: inline-block
    .open-home-form
      padding: 20px 0 20px 0
      .home-add-item
        display:flex;
        align-items: center
        margin-bottom: 30px
        &.resource-category
          .fineart-cascade
            margin-bottom: 0
          .ivu-form-item-error-tip
            left: 84px
        .ivu-form-item-label
          width: 64px
          height: 40px
          padding: 0
          margin-right: 20px
          font-size: 16px
          color: $black
          overflow: hidden
          line-height: 40px
          text-align: justify
          /*实现文字两端对齐*/
          &:after
            content: ''
            display: inline-block
            padding-left: 100%
        .ivu-form-item-content
          display: flex
          font-size: 14px
          color: $grey-high
          align-items: center
          margin-left: 0!important
          p
            margin-top: 10px
            max-width: 640px
            color: $grey-high
            line-height: 32px
          .ivu-input, .ivu-select, .ivu-select-placeholder, .ivu-select-selected-value
            width: 640px
            font-size: 16px
          .commit-btn
            width: 120px
            height: 40px
            font-size: 16px
            margin-left: 84px
        &.map-position-add, &.address-detail
          align-items: baseline
          .ivu-form-item-content
            position: relative
            align-items: normal
            flex-direction: column
          .ivu-input-prefix i
            color: $grey-high1
      .map-plugin
        width: 888px
        height: 354px
        margin: 0 0 30px 84px
      .address-list
        width: 620px
        padding: 5px 20px
        cursor: pointer
      /*验证时文字位置*/
      .ivu-form-item-error-tip
        left: 0
</style>
