<template>
  <div class="my-order">
    <div class="filter-keyword">
      <i-input v-model="pageConfig.keyword"
               placeholder="输入商品名称/订单号">
        <i-button slot="append" class="search-btn" type="primary" @click="goSearch()"><span class="fy-icon-search"></span>搜一下</i-button>
      </i-input>
    </div>
    <div class="table-head">
      <div class="good-info">商品信息</div>
      <div class="pay-money">实付金额</div>
      <div class="filter">
        <i-select class="order-status" v-model="pageConfig.status" placeholder="全部订单" clearable @on-change="goSearch()">
          <i-option value="100">待付款</i-option>
          <i-option value="200">待发货</i-option>
          <i-option value="300">待收货</i-option>
        </i-select>
      </div>
      <div>操作</div>
    </div>
    <div class="my-order-page">
      <div v-if="orderList.total">
        <div class="order-item" v-for="(item, index) in orderList.data" :key="index">
          <p class="order-number">
            <span>{{ item.order_at }}</span>
            <span>订单号：{{ item.code }}</span>
          </p>
          <div class="order-detail">
            <div class="goods-img">
              <img :src="item.goods_thumbnail"/>
            </div>
            <div class="good-name">
              <a :href="`/mall.html#/goods-detail/${item.goods_id}/${item.mall_store_id_order}`">{{ item.goods_name }}</a>
            </div>
            <div class="after-sales">
              <router-link :to="`/apply-for-service/${item.id}`" v-if="! item.service_id && ['200', '300', '400'].indexOf(item.status) >= 0">申请售后</router-link>
              <router-link :to="`/sale-service/${item.id}`" class="red" v-else-if="item.service_handle_status === '100'">售后处理中</router-link>
              <router-link :to="`/sale-service/${item.id}`" class="yellow" v-else-if="item.service_handle_status === '200'">退款</router-link>
              <router-link :to="`/sale-service/${item.id}`" class="yellow" v-else-if="item.service_handle_status === '300'">换货</router-link>
              <router-link :to="`/sale-service/${item.id}`" class="yellow" v-else-if="item.service_handle_status === '400'">取消售后</router-link>
            </div>
            <div class="pay-total">&yen;{{ item.pay_total }}</div>
            <div class="order-status">
              <span :class="item.status === '100' ? 'red' : (item.status === '200' ? 'yellow' : '')">{{ item.status_desc }}</span>
              <router-link :to="`/order-detail/${item.id}`">订单详情</router-link>
            </div>
            <div class="handle-order">
              <i-button class="pay-order" @click="goPay(item.code)" v-if="item.status === '100'">去付款</i-button>
              <i-button class="cancel-order" type="text" @click="goCancel(item.id)" v-if="item.status === '100'">取消订单</i-button>
              <i-button @click="goReceive(item.id)" v-if="item.status === '300'">确认收货</i-button>
              <i-button class="cancel-order" type="text" v-if="item.comment_id">已评价</i-button>
              <router-link :to="`/order-comment/${item.id}`" v-else-if="item.status === '500'">评价</router-link>
            </div>
          </div>
        </div>
        <div class="pagination-cell">
          <pagination class="collection-store-pagination"
                      @page-confirm="changePage"
                      :page="parseInt(orderList.current_page)"
                      :total="orderList.total"
                      :page-size="orderList.per_page"></pagination>
        </div>
      </div>
      <div v-else class="nothing-container">
        <list-nothing class="list-nothing" ></list-nothing>
      </div>
    </div>
  </div>
</template>

<script>
import { Select, Option, Input, Modal } from 'iview'
import { Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'
import { scrollTop } from '@/common/js/utils'

export default {
  name: 'MyOrder',
  data () {
    return {
      orderList: {},
      pageConfig: {
        page: 1, // 页码
        keyword: '', // 搜索关键字，商品名称或者订单编号
        status: ''// 订单状态
      }
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.orderList = await api.orderMyList(this.pageConfig)
    },
    async changePage (data) {
      this.pageConfig.page = data.page
      this.orderList = await api.orderMyList(this.pageConfig)
      this.$nextTick(() => {
        const sTop = document.documentElement.scrollTop || document.body.scrollTop
        scrollTop(window, sTop, 0, 800)
      })
    },
    async goSearch () {
      if (this.pageConfig.status === undefined) {
        this.pageConfig.status = ''
      }
      this.pageConfig.page = 1
      this.orderList = await api.orderMyList(this.pageConfig)
    },
    goPay (orderCode) {
      window.location = `mall.html#/pay-home/payment/${orderCode}`
    },
    async goCancel (orderId) {
      let vm = this
      Modal.confirm({
        title: '温馨提示',
        content: '请确认您要取消该订单',
        onOk: async function () {
          let response = await api.orderBuyerUpdateStatus(orderId, 1000)
          if (response.code === 200) {
            vm.initPage()
          }
        }
      })
    },
    async goReceive (orderId) {
      let vm = this
      Modal.confirm({
        title: '温馨提示',
        content: '请确认您已经收到商品',
        onOk: async function () {
          let response = await api.orderBuyerUpdateStatus(orderId, 400)
          if (response.code === 200) {
            vm.initPage()
          }
        }
      })
    }
  },
  components: {
    Pagination,
    ListNothing,
    'i-select': Select,
    'i-option': Option,
    'i-input': Input
  }
}
</script>

<style lang="stylus">
.my-order
  .filter-keyword
    height: 50px
    position: relative
    .ivu-input-wrapper
      width: 366px
      absolute: right
      .ivu-input
        font-size: 14px
        border-color: $orange
      .search-btn
        width: 112px
        font-size: 14px
        color: $white
        padding: 0
        border: none
        border-radius: 0 4px 4px 0
        background-color: $orange
        &>span
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 40px
        .fy-icon-search
          margin-right: 5px
          font-size: 20px
  .table-head
    height: 48px
    line-height: 48px
    padding: 0 50px
    font-size: 16px
    color: $black1
    display: flex
    align-items: center
    flex-direction: row
    border-bottom: 3px solid $grey
    &>div
      display: inline-block
    .good-info
      width: 542px
    .pay-money
      width:140px
    .filter
      width: 150px
      .order-status
        width: 110px
        background-color: transparent
        .ivu-select-selection
          border: none
          height: 48px
          line-height: 48px
          background-color: transparent
          box-shadow: none
        .ivu-select-placeholder, .ivu-select-selected-value
          color: $black1
          font-size: 16px
          height: 48px
          line-height: 48px
  .my-order-page
    padding: 0 30px 30px 30px
    margin-top: 20px
    margin-bottom: 58px
    border: 1px solid $grey-high4
    .order-item
      height: 170px
      padding: 20px 0
      font-size: 14px
      border-bottom: 1px solid $grey-high4
      .order-number
        color: #bbb
        font-size: 14px
        margin-bottom: 10px
        span
          padding-right: 20px
      .order-detail
        display: flex
        align-items: center
        &>div
          margin-right: 40px
          &:last-child
            margin-right: 0
          &.goods-img
            width: 100px
            height: 100px
            overflow: hidden
            img
              width: 100px
              height: 100px
          &.good-name
            width: 260px
            display: block
            font-size: 16px
            a
              color: $black
          &.after-sales
            width: 80px
            text-align: center
            a
              color: $black1
              &.red
                color: $red
              &.yellow
                color: $orange
              &.grey-height
                color: $grey-high
          &.pay-total
            width: 120px
            color: $black1
            font-size: 18px
          &.order-status
            width: 60px
            text-align: center
            span
              display:block
              color: $grey-high
              margin-bottom: 12px
              &.red
                color: $red
              &.yellow
                color: $orange
            a
              color: $black1
          &.handle-order
            width: 110px
            text-align: center
            .ivu-btn, a
              display: inline-block
              width: 80px
              height: 26px
              margin: 5px auto
              padding: 0
              border: 1px solid $orange
              color: $orange
              font-size: 14px
              line-height: 26px
              cursor: pointer
              border-radius: 4px
              span
                display: inline-block
                height:26px
                line-height: 26px
            .cancel-order
              border: none
              color: $grey-high
            .evaluation
              color: $grey-high
              border: 1px solid $grey-high
    .pagination-cell
      height: 68px
      position: relative
      .collection-store-pagination
        width: auto
        absolute: right
        margin-bottom: 0
    .nothing-container
      min-height: 670px
      position: relative
      .list-nothing
        margin-top: -80px //补偿原本组件的padding-top： 80
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
</style>
