<template lang="html">
  <div class="order-detail">
    <div class="page-head">
      <span class="order-number">订单号：{{ orderDetail.code }}</span>
      <span class="order-data">下单时间：{{ orderDetail.order_at }}</span>
      <span class="order-status">
        <span class="red">{{ orderDetail.status_desc }}</span>
      </span>
    </div>
    <div class="order-info-card">
      <div class="info-card-title">
        <span class="receiver">收货人信息</span>
        <span class="money">金额信息</span>
      </div>
      <div class="info-card-content">
        <div class="receiver">
          <p>
            <label>收货人：</label>
            <span>{{ orderDetail.to_name }}</span>
          </p>
          <p>
            <label>联系方式：</label>
            <span>{{ orderDetail.to_mobile }}</span>
          </p>
          <p>
            <label>收货地址：</label>
            <span>{{ orderDetail.to_address_desc }}</span>
          </p>
        </div>
        <div class="money">
          <p>
            <label>订单金额：</label>
            <span>&yen;{{ orderDetail.total }}</span>
          </p>
          <p>
            <label>运费：</label>
            <span>&yen;{{ orderDetail.freight }}</span>
          </p>
          <p>
            <label>实付金额：</label>
            <span class="yellow">&yen;{{ orderDetail.pay_total }}</span>
          </p>
        </div>
      </div>
    </div>
    <div class="order-info-card goods-card">
      <div class="info-card-title">
        <span class="goods-info">商品信息</span>
        <span class="price">单价</span>
        <span class="number">数量</span>
        <span class="status">状态</span>
        <span class="handle">操作</span>
      </div>
      <div class="goods-detail">
        <div class="goods-img">
          <img :src="orderDetail.goods_thumbnail"/>
        </div>
        <div class="goods-name">{{ orderDetail.goods_name }}</div>
        <div class="after-sales">
          <router-link :to="`/apply-for-service/${orderDetail.id}`" v-if="! orderDetail.service_id && ['200', '300', '400'].indexOf(orderDetail.status) >= 0">申请售后</router-link>
          <router-link :to="`/sale-service/${orderDetail.id}`" class="red" v-else-if="orderDetail.service_handle_status === '100'">售后处理中</router-link>
          <router-link :to="`/sale-service/${orderDetail.id}`" class="yellow" v-else-if="orderDetail.service_handle_status === '200'">退款</router-link>
          <router-link :to="`/sale-service/${orderDetail.id}`" class="yellow" v-else-if="orderDetail.service_handle_status === '300'">换货</router-link>
          <router-link :to="`/sale-service/${orderDetail.id}`" class="yellow" v-else-if="orderDetail.service_handle_status === '400'">取消售后</router-link>
        </div>
        <div class="unit-price">&yen;{{ orderDetail.price_real }}</div>
        <div class="number">X{{ orderDetail.number }}</div>
        <div class="status"><span class="red">{{ orderDetail.status_desc }}</span></div>
        <div class="handle-order">
          <i-button class="pay-order" v-if="orderDetail.status === '100'" @click="goPay(orderDetail.code)">去付款</i-button>
          <i-button class="cancel-order" type="text" v-if="orderDetail.status === '100'" @click="goCancel(orderDetail.id)">取消订单</i-button>
          <i-button v-if="orderDetail.status === '300'" @click="goReceive(orderDetail.id)">确认收货</i-button>
          <i-button class="cancel-order" type="text" v-if="orderDetail.comment_id">已评价</i-button>
          <router-link :to="`/order-comment/${orderDetail.id}`" v-else-if="orderDetail.status === '500'">评价</router-link>
        </div>
      </div>
    </div>
    <div class="express">
      <div class="express-info-card">
        <div class="info-card-title">物流信息</div>
        <div class="info-card-content" v-if="express.code">
          <p>物流公司： {{ express.name }} </p>
          <p>运单号码： {{ express.code }} </p>
        </div>
        <div class="info-card-content" v-else>暂无物流信息，请稍后查询</div>
      </div>
      <div class="express-detail-card" v-if="express.code">
        <div class="info-card-title" >
          <span>物流状态</span>
          <i-button type="text" @click="showExpress = true">[获取最新动态]</i-button>
        </div>
        <div class="info-card-content" v-if="showExpress">
          <i-timeline>
            <i-timeline-item class="latest" v-for="(item, index) in express.list" :key="index">
              <span class="time">{{ item.time }}</span>
              <p class="content">{{ item.content }} </p>
            </i-timeline-item>
          </i-timeline>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Timeline, TimelineItem, Modal } from 'iview'
import api from 'modules/member/api/index.js'

export default {
  name: 'OrderDetail',
  data () {
    return {
      orderId: this.$route.params.id,
      orderDetail: {},
      express: {
        code: null,
        company: null,
        type: null,
        list: []
      },
      showExpress: false
    }
  },
  created () {
    this.initPage()
  },
  watch: {
    showExpress (newVal) {
      if (newVal) {
        this.fetchExpressDetail()
      }
    }
  },
  methods: {
    async initPage () {
      this.orderDetail = await api.orderMyDetail(this.orderId)
      if (this.orderDetail.express_code !== null) {
        this.express.code = this.orderDetail.express_code
        this.express.company = this.orderDetail.express_company
        this.express.name = this.$store.state.member.expressCompany[this.express.company]
      }
    },
    async fetchExpressDetail () {
      let res = await api.expressDetail(this.express.code, this.express.company)
      if (res.list.length) {
        this.express.list = res.list
      }
    },
    goPay (orderCode) {
      window.location = `mall.html#/pay-home/payment/${orderCode}`
    },
    async goCancel (orderId) {
      let vm = this
      Modal.confirm({
        title: '温馨提示',
        content: '请确认您要取消该订单',
        onOk: async function () {
          let response = await api.orderBuyerUpdateStatus(orderId, 1000)
          if (response.code === 200) {
            vm.initPage()
          }
        }
      })
    },
    async goReceive (orderId) {
      let vm = this
      Modal.confirm({
        title: '温馨提示',
        content: '请确认您已经收到商品',
        onOk: async function () {
          let response = await api.orderBuyerUpdateStatus(orderId, 400)
          if (response.code === 200) {
            vm.initPage()
          }
        }
      })
    }
  },
  components: {
    'i-timeline': Timeline,
    'i-timeline-item': TimelineItem
  }
}
</script>

<style lang="stylus">
.order-detail
  .page-head
    height: 48px
    line-height: 48px
    padding: 0 32px
    font-size: 14px
    color: $grey-high
    position: relative
    border-bottom: 3px solid $grey
    span
      display: inline-block
    .order-number
      width: 276px
      margin-right: 13px
    .order-data
      width: 242px
    .order-status
      width: 65px
      absolute: right
      .red
        color: $red
      .yellow
        color: $orange
  .order-info-card
    margin-top: 20px
    padding: 0 30px 30px 30px
    border: 1px solid $grey-high4
    .receiver
      width: 710px
      display: inline-block
    .money
      display: inline-block
    .info-card-title
      padding: 20px 0
      color: $black
      font-size: 16px
      font-weight: 500
      border-bottom: 1px dashed $grey-high4
    .info-card-content
      p
        font-size: 16px
        margin-top: 16px
        label
          width: 80px
          height: 22px
          line-height: 22px
          overflow: hidden
          margin-right: 5px
          color: $grey-high
          display: inline-block
          text-align: justify
          vertical-align: top
          &:after
            content: ''
            display: inline-block
            padding-left: 100%
        span
          color: $black
          height: 22px
          line-height: 22px
          display: inline-block
          vertical-align: top
          &.yellow
            color: $orange
    &.goods-card
      padding-bottom: 0
      .info-card-title
        span
          display: inline-block
        .goods-info
          width: 480px
        .price
          width: 120px
          text-align center
        .number
          width: 80px
          margin-left: 41px
        .status
          width: 80px
        .handle
          width: 100px
          text-align: center
      .goods-detail
        display: flex
        margin: 18px 0
        height: 100px
        font-size: 14px
        align-items: center
        flex-direction: row
        &>div
          margin-right: 40px
          &:last-child
            margin-right: 0
        .goods-img
          width: 100px
          height: 100px
          img
            width: 100px
            height: 100px
        .goods-name
          width: 210px
          font-size: 16px
        .after-sales
          width: 75px
          text-align: center
          a
            color: $black1
            &.red
              color: $red
            &.yellow
              color: $orange
            &.grey-height
              color: $grey-high
        .unit-price
          width: 100px
          font-size: 18px
          color: $black1
        .number
          width: 50px
          text-align: center
        .status
          width: 60px
          .red
            color: $red
          .yellow
            color: $orange
          .grey-height
            color: $grey-high
        .handle-order
          width: 100px
          text-align: center
          .ivu-btn, a
            width: 80px
            height: 26px
            line-height: 26px
            display: inline-block
            color: $orange
            font-size: 14px
            margin: 5px auto
            padding: 0 14px
            cursor: pointer
            border-radius: 4px
            border: 1px solid $orange
            span
              display: inline-block
              height:26px
              line-height: 26px
          .cancel-order
            border: none
            color: $grey-high
          .evaluation
            color: $grey-high
            border: 1px solid $grey-high
  .express
    color: $black1
    font-size: 14px
    line-height: 20px
    padding: 20px 0 20px 30px
    .info-card-title
      height: 22px
      line-height: 22px
      font-size: 16px
      color: $black
      margin-bottom: 14px
      font-weight: 500
    .express-info-card
      .info-card-content
        margin-bottom: 30px
        p
          margin-bottom: 10px
    .express-detail-card
      margin-bottom: 28px
      .info-card-content
        padding: 20px
        background-color: #fefbf4
        .ivu-timeline-item-head
          width: 7px
          height: 7px
          top: 4px
          border-color: transparent
          background-color: $grey-light2
        .ivu-timeline-item-tail
          height: 100%
          border-left: 1px solid $grey-light2
          absolute: left 3px top 4px
        .latest
          .ivu-timeline-item-head
            background-color: $orange
        .ivu-timeline-item-content
          display:flex
          .time
            width: 150px
            height: 20px
            font-size: 14px
            font-weight: 500
            margin-right: 20px
            color: $black
            line-height: 20px
            display:inline-block
          .content
            width:720px
            font-size: 14px
            font-weight: 400
            color: $black1
            line-height: 20px
</style>
