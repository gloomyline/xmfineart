<template lang="html">
  <div class="order-evaluate">
    <div class="page-head">
      <span class="goods">商品</span>
      <span class="evaluate">评价</span>
    </div>
    <div class="order-evaluate-page">
      <div class="page-content">
        <div class="goods">
          <div class="goods-img">
            <img v-if="orderDetail.goods_thumbnail" :src="orderDetail.goods_thumbnail"/>
          </div>
          <p class="goods-name">{{ orderDetail.goods_name }}</p>
        </div>
        <i-form ref="commentForm"
                :model="comment"
                :rules="ruleInput">
        <div class="evaluate">
          <div class="evaluate-score">
            <i-form-item prop="star">
              <label>评分</label>
              <i-rate v-model="comment.star" class="evaluate-star" custom-icon="fy-icon-star5"></i-rate>
            </i-form-item>
          </div>
          <div class="evaluate-words">
            <i-form-item prop="content">
              <i-input v-model="comment.content" type="textarea"  placeholder="分享体验评价，给他人一个参考~" :rows="5"></i-input>
            </i-form-item>
          </div>
          <div class="evaluate-pic">
            <p class="tip">晒图（最多可上传6张图片）</p>
            <div>
              <!--已上传的图片-->
              <div class="uploaded-img" @click="handleView(item)" v-for="(item, index) in comment.comment_images_cdn" :key="index">
                <img :src="item">
                <div class="img-edit-cover">
                  <span class="fy-icon-delete-round" @click.stop="deleteImg(index)"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
                </div>
              </div>
              <!--iview上传组件-->
              <i-upload
                class="goods-img-upload"
                ref="upload"
                v-if="comment.comment_images.length < 6"
                :show-upload-list="false"
                :max-size="ossImage.max_size"
                type="drag"
                :data="ossImage.data"
                :action="ossImage.host"
                :format="ossImage.format"
                :accept="ossImage.accept"
                :on-exceeded-size="exceededSize"
                :on-format-error="formatError"
                :before-upload="beforeUploadImage"
                :on-success="successImage">
                <div class="cover-upload-text">
                  <span class="fy-icon-add-thin-gray"></span>
                </div>
              </i-upload>
            </div>
          </div>
        </div>
        </i-form>
      </div>
      <div class="handle-evaluate">
        <i-button type="primary" @click="handlerSubmit('commentForm')">提交评价</i-button>
      </div>
    </div>
    <i-modal class="pic-modal" v-model="showPicModal" title="查看图片" footer-hide>
      <div class="img-cell">
        <img :src="bigImage"/>
      </div>
    </i-modal>
  </div>
</template>

<script>
import { Form, FormItem, Rate, Input, Upload, Modal } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'

export default {
  name: 'OrderComment',
  data () {
    return {
      orderId: this.$route.params.orderId,
      comment: {
        star: 0, // 商品评价星级
        content: '', // 商品评价内容
        score: 0, // 商品评价评分
        // 上传的图片，可以上传后放入该数组
        comment_images: [],
        comment_images_cdn: []
      },
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      ruleInput: {
        star: [
          {
            required: true,
            message: '评分为空!'
          }
        ],
        content: [
          {
            required: true,
            message: '评价内容为空！'
          }
        ]
      },
      orderDetail: {},
      evaluationScore: 5,
      showPicModal: false,
      bigImage: ''
    }
  },
  created () {
    this.initPage()
  },
  watch: {
    comment: {
      handler: function (newVal) {
        newVal.score = newVal.star * 20
      },
      deep: true
    }
  },
  methods: {
    async initPage () {
      this.orderDetail = await api.orderMyDetail(this.orderId)
      this.comment.code = this.orderDetail.code
    },
    deleteImg (index) {
      this.$delete(this.comment.comment_images_cdn, index)
      this.$delete(this.comment.comment_images, index)
    },
    handleView (src) {
      this.showPicModal = true
      this.bigImage = src
    },
    handlerSubmit (name) {
      if (!this.comment.star) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_GOODS_COMMENT_START_EMPTY'], type: 'error' })
      }
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.result = await api.insertMemberGoodsComment(this.comment)
          if (this.result.code === 200) {
            this.$store.commit('ADD_MESSAGE', {msg: MSG['MALL_GOODS_COMMENT_SUCCESS'], type: 'success'})
            this.$router.push({path: '/my-order'})
          }
        }
      })
    },
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'comment_image', this.ossImage)
    },
    successImage (res) {
      if (res.code === 200) {
        this.comment.comment_images.push(res.results.file_url)
        this.comment.comment_images_cdn.push(res.results.file_url_cdn)
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    }
  },
  components: {
    'i-form': Form,
    'i-form-item': FormItem,
    'i-modal': Modal,
    'i-rate': Rate,
    'i-input': Input,
    'i-upload': Upload
  }
}
</script>

<style lang="stylus">
.order-evaluate
  .page-head
    height: 48px
    line-height: 48px
    padding: 0 32px
    font-size: 14px
    color: $grey-high
    position: relative
    border-bottom: 3px solid $grey
    span
      font-size: 16px
      text-align: center
      color: $black1
      display: inline-block
    .goods
      width: 222px
    .evaluate
      width: 680px
  .order-evaluate-page
    padding: 30px
    height: 600px
    margin-top: 20px
    border: 1px solid $grey-high4
    .page-content
      display: flex
      height: 336px
      overflow: hidden
      .goods
        width: 250px
        text-align: center
        padding-right: 30px
        .goods-img
          width: 220px
          height: 220px
          img
            width: 220px
            height: 220px
        .goods-name
          width: 220px
          font-size: 16px
          color: $black1
          line-height: 22px
          text-align: left
          padding: 17px 20px 0 20px
      .evaluate
        width: 690px
        padding-left: 20px
        border-left: 1px dashed $grey-high4
        .evaluate-score
          height: 50px
          display: flex
          align-items: center
          label
            font-size: 16px
            color: $black
            padding-right: 20px
            display: inline-block
          .evaluate-star
            font-size: 32px
          .ivu-rate-star-chart.ivu-rate-star-full .ivu-rate-star-second
            color: $yellow
        .evaluate-pic
          margin-top: 20px
          .tip
            height: 22px
            font-size: 16px
            color: $black
            line-height: 22px
            margin-bottom: 14px
          &>div
            margin-right: -20px
            flex-wrap: wrap
            display: flex
            .uploaded-img
              width: 96px
              height: 96px
              margin: 0 17px 30px 0
              position: relative
            .goods-img-upload
              .ivu-upload-drag
                width: 96px
                height: 96px
                border: 1px solid $grey-high4
              .cover-upload-text
                width: 96px
                height: 96px
                display: flex
                align-items: center
                justify-content: space-around
                .fy-icon-add-thin-gray
                  font-size: 32px
    .handle-evaluate
      margin-top: 80px
      text-align: center
      .ivu-btn
        height: 40px
        width: 170px
        font-size: 16px
.pic-modal
  .img-cell
    width: 100%
    max-height: 460px
    overflow:hidden
    text-align: center
    img
      max-width: 460px
</style>
