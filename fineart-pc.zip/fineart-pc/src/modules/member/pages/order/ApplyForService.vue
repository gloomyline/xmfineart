<template lang="html">
  <div class="sale-service">
    <div class="page-head">
      <span>售后申请-详情</span>
    </div>
    <div class="sale-service-page">
      <div class="order-info-card">
        <p class="info-card-title">商品信息</p>
        <div class="info-card-content">
          <p>
            <label>订单号：</label>
            <span>{{ orderDetail.code }}</span>
          </p>
          <p>
            <label>商品名称：</label>
            <span>{{ orderDetail.goods_name }}</span>
          </p>
          <p>
            <label>实付金额：</label>
            <span class="yellow">&yen;{{ orderDetail.pay_total }}</span>
          </p>
        </div>
      </div>
      <div class="service-type">
        <p class="info-card-title"><span class="require">*</span>售后申请类型</p>
        <p class="tip">请确认您与商家已协商好，确定申请售后服务。请注意，在平台上只能申请一次。如后续需售后服务，请线下联系商家。</p>
        <div>
          <i-radio-group size="large" v-model="orderService.apply_operate">
            <i-radio label="100">退款</i-radio>
            <i-radio label="200">换货</i-radio>
          </i-radio-group>
        </div>
      </div>
      <div class="problem-description">
        <p class="info-card-title"><span class="require">*</span>问题描述</p>
        <div class="info-card-content">
          <i-input type="textarea" :rows="5" placeholder="请输入～～" v-model="orderService.apply_reason"></i-input>
        </div>
      </div>
      <div class="handle-application">
        <i-button type="primary" @click="doSubmit()">提交</i-button>
      </div>
    </div>
  </div>
</template>

<script>
import { RadioGroup, Radio, Input } from 'iview'
import api from 'modules/member/api/index.js'

export default {
  name: 'AfterSale',
  data () {
    return {
      orderId: this.$route.params.orderId,
      orderDetail: {},
      orderService: {
        code: '',
        apply_operate: '',
        apply_reason: ''
      }
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.orderDetail = await api.orderMyDetail(this.orderId)
      this.orderService.code = this.orderDetail.code
    },
    async doSubmit () {
      let response = await api.orderServiceApply(this.orderService)
      if (response.code === 200) {
        this.$router.push({path: '/my-order'})
      }
    }
  },
  components: {
    'i-radio': Radio,
    'i-input': Input,
    'i-radio-group': RadioGroup
  }
}
</script>

<style lang="stylus">
  .sale-service
    .page-head
      height: 48px
      line-height: 48px
      padding: 0 32px
      font-size: 16px
      color: $grey-high
      position: relative
      border-bottom: 3px solid $grey
    .sale-service-page
      height: 744px
      margin-top: 20px
      padding: 0 30px
      border: 1px solid $grey-high4
      &>div
        padding: 30px 0
        border-bottom: 1px dashed $grey-high4
        .info-card-title
          height: 22px
          font-size: 16px
          font-weight: 500
          color: $black
          line-height: 22px
          margin-bottom: 14px
          .require
            color: $red
            font-size: 16px
        &.order-info-card
          font-size: 16px
          p
            margin-bottom: 16px
            &:last-child
              margin-bottom: 0
            label
              width: 80px
              height: 22px
              line-height: 22px
              overflow: hidden
              margin-right: 5px
              color: $grey-high
              display: inline-block
              text-align: justify
              vertical-align: top
              &:after
                content: ''
                display: inline-block
                padding-left: 100%
            .yellow
              color: $orange
        &.service-type
          .tip
            height: 20px
            font-size: 14px
            color: $black1
            line-height: 20px
            margin-bottom: 16px
          .ivu-radio-large
            .ivu-radio-wrapper
              font-size: 16px
              margin-right: 40px
        &.problem-description
          border-bottom: none
        &.handle-application
          border-bottom: none
          text-align: center
          .ivu-btn
            font-size: 16px
            font-weight: 500px
            height: 40px
            width: 170px
</style>
