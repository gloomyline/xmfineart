<template>
  <div class="settlement-record">
    <p class="select-box">
      <i-select v-model="indexRoute" class="route-select">
        <i-option value="/promotion-goods">推广商品</i-option>
        <i-option value="/promote-sales-record">推广销售记录</i-option>
        <i-option value="/settlement-record">结算记录</i-option>
      </i-select>
    </p>
    <p class="description">
      每月20号更新上一个月的订单记录，[交易成功]的订单，才可结算。<br/>
      预估收入 = [订单实付金额] - [供货单价*数量]（状态为[交易成功]的商品订单才能结算，如差值＜0不会扣减。）<br/>
      本页展示的记录仅供参考，以运营与您实际结算时数据为准。
    </p>
    <div class="table-header">
      <span>结算编号</span>
      <span>收益年月</span>
      <span>收益金额</span>
    </div>
    <div class="settlement-record-content">
      <div class="settlement-record-item" v-for="(item, index) in settlementList" :key="index">
        <span class="number">{{ item.code }}</span>
        <span class="date">{{ item.month }}</span>
        <span class="money">&yen;{{ item.money }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import { Select, Option } from 'iview'
import { Pagination } from 'components'
import api from 'modules/member/api/index.js'

export default {
  name: 'SettlementRecord',
  data () {
    return {
      indexRoute: '/settlement-record',
      settlementList: {}
    }
  },
  created () {
    this.initPage()
  },
  watch: {
    indexRoute (newVal) {
      this.$router.push(newVal)
    }
  },
  methods: {
    async initPage () {
      this.settlementList = await api.settlementList('promotion')
    }
  },
  components: {
    Pagination,
    'i-select': Select,
    'i-option': Option
  }
}
</script>

<style lang="stylus">
.settlement-record
  p
    &.select-box
      height: 40px
      margin-bottom: 20px
      position: relative
      .route-select
        width: 228px
        .ivu-select-selected-value
          font-size: 16px
    &.description
      width: 1000px
      height: 60px
      font-size: 14px
      color: $grey-high
      line-height: 20px
  .table-header
    height: 48px
    line-height: 48px
    padding: 0 40px
    font-size: 16px
    color: $black1
    display: flex
    align-items: center
    margin-top: 16px
    justify-content: space-between
    flex-direction: row
    position: relative
    border-bottom: 3px solid $grey
  .settlement-record-content
    padding: 0 40px 28px 40px
    margin-top: 20px
    min-height: 568px
    border: 1px solid $grey-high4
    position: relative
    .settlement-record-item
      height: 66px
      padding: 20px 0
      font-size: 18px
      color: $black1
      display: flex
      justify-content: space-between
      border-bottom: 1px solid $grey-high4
      span
        width: 200px
        &.date
          text-align center
        &.money
          text-align: right
    .pagination-cell
      height: 68px
      .settlement-record-pagination
        width: auto
        absolute: right 30px bottom 30px
        margin-bottom: 0
</style>
