<template>
  <div class="agent-sales-record">
    <div class="filter-keyword">
      <i-select v-model="indexRoute" class="route-select">
        <i-option value="/store-manage/agent-goods">代理商品</i-option>
        <i-option value="/store-manage/agent-sales-record">代理销售记录</i-option>
        <i-option value="/store-manage/agent-settlement-record">结算记录</i-option>
      </i-select>
      <i-input v-model="pageConfig.keyword"
               placeholder="输入商品名称/订单号/店铺名称">
        <i-button slot="append" class="search-btn" type="primary" @click="goSearch()"><span class="fy-icon-search"></span>搜一下</i-button>
      </i-input>
    </div>
    <div class="table-head">
      <div class="good-info">商品信息</div>
      <div class="number">数量</div>
      <div class="pay-total">实付金额</div>
      <div class="unit-price">供货单价</div>
      <i-select class="status" placeholder="状态" clearable @on-change="goSearch()">
          <i-option value="100">待付款</i-option>
          <i-option value="200">待发货</i-option>
          <i-option value="300">待收货</i-option>
          <i-option value="400">已收货</i-option>
          <i-option value="500">交易成功</i-option>
          <i-option value="600">已退款</i-option>
          <i-option value="1000">交易取消</i-option>
      </i-select>
    </div>
    <div class="sales-record-page">
      <div v-if="orderList.total">
        <div class="record-item" v-for="(item, index) in orderList.data" :key="index">
          <div class="order-number">
            <span>{{ item.order_at }}</span>
            <span> 订单号：{{ item.code }}</span>
          </div>
          <div class="record-detail">
            <div class="goods-img">
              <img :src="item.goods_thumbnail"/>
            </div>
            <div class="goods-store-name">
              <a class="goods-name" :href="`/mall.html#/goods-detail/${item.goods_id}/${item.store_id}`">{{ item.goods_name }}</a>
              <a class="store-name" :href="`/mall.html#/store-detail/${item.store_id_source}`">{{ item.store_name_source }}>></a>
            </div>
            <div class="number">X{{ item.number }}</div>
            <div class="pay-total">&yen;{{ item.pay_total }}</div>
            <div class="unit-price">&yen;{{ item.price_agent }}</div>
            <div class="status">
              <span :class="item.status === '100' ? 'red' : (item.status === '200' ? 'yellow' : '')">{{ item.status_desc }}</span>
            </div>
          </div>
        </div>
        <div class="pagination-cell">
          <pagination class="sales-record-pagination"
                      @page-confirm="changePage"
                      :page="orderList.current_page"
                      :total="orderList.total"
                      :page-size="orderList.per_page"></pagination>
        </div>
      </div>
      <div v-else class="nothing-container">
        <list-nothing class="list-nothing" ></list-nothing>
      </div>
    </div>
  </div>
</template>

<script>
import { Select, Option, Input } from 'iview'
import { Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'

export default {
  name: 'PromoteSalesRecord',
  data () {
    return {
      indexRoute: '/store-manage/agent-sales-record',
      orderList: {},
      pageConfig: {
        page: 1, // 页码
        keyword: '', // 搜索关键字，商品名称或者订单编号
        status: ''// 订单状态
      }
    }
  },
  created () {
    this.initPage()
  },
  watch: {
    indexRoute (newVal) {
      this.$router.push(newVal)
    }
  },
  methods: {
    async initPage () {
      this.orderList = await api.orderSellerAgentList(this.pageConfig)
    },
    async changePage (data) {
      this.pageConfig.page = data.page
      this.initPage()
    },
    async goSearch () {
      if (this.pageConfig.status === undefined) {
        this.pageConfig.status = ''
      }
      this.pageConfig.page = 1
      this.initPage()
    }
  },
  components: {
    Pagination,
    ListNothing,
    'i-select': Select,
    'i-option': Option,
    'i-input': Input
  }
}
</script>

<style lang="stylus">
.agent-sales-record
  .filter-keyword
    height: 40px
    margin-bottom: 20px
    position: relative
    .route-select
      width: 228px
      .ivu-select-selected-value
        font-size: 16px
    .ivu-input-wrapper
      width: 366px
      absolute: right
      .ivu-input
        font-size: 14px
        border-color: $orange
      .search-btn
        width: 112px
        font-size: 14px
        color: $white
        padding: 0
        border: none
        border-radius: 0 4px 4px 0
        background-color: $orange
        &>span
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 40px
        .fy-icon-search
          margin-right: 5px
          font-size: 20px
  .table-head
    height: 48px
    line-height: 48px
    padding: 0 10px 0 40px
    font-size: 16px
    color: $black1
    display: flex
    align-items: center
    flex-direction: row
    position: relative
    border-bottom: 3px solid $grey
    &>div
      display: inline-block
    .good-info
      width: 400px
    .number
      width: 80px
      margin-right: 40px
    .unit-price
      width: 145px
      text-align: center
      margin-right: 40px
    .pay-total
      width: 106px
      text-align: center
      margin-right: 40px
    .status
      width: auto
      absolute: right 25px
      .ivu-select-selection
        height: 48px
        line-height: 48px
        border: none
        background-color: transparent
        box-shadow: none
        .ivu-select-placeholder, .ivu-select-selected-value
          height: 48px
          line-height: 48px
          color: $black1
          font-size: 16px
  .sales-record-page
    margin-top: 20px
    padding: 0 32px 32px 32px
    border: 1px solid $grey-high4
    .record-item
      height: 170px
      padding: 20px 0
      border-bottom: 1px solid $grey-high4
      .order-number
        position: relative
        height: 20px
        margin-bottom: 10px
        font-size: 14px
        line-height: 20px
      .record-detail
        display: flex
        align-items: center
        &>div
          margin-right: 40px
          &:last-child
            margin-right: 0
        .goods-img
          width: 100px
          height: 100px
          img
            width: 100px
            height: 100px
        .goods-store-name
          width: 233px
          font-size: 16px
          .goods-name
            color: $black
            width: 233px
            line-height: 22px
            max-height: 50px
            overflow: hidden
            -webkit-line-clamp: 2
            display: -webkit-box
            -webkit-box-orient: vertical
          .store-name
            height: 20px
            color: $black1
            font-size: 14px
        .number, .pay-total, .unit-price
          font-size: 18px
        .number
          width: 70px
        .pay-total
          width: 120px
          color: $orange
          text-align: center
        .unit-price
          width: 120px
          color: $black1
          text-align: center
        .status
          width: 80px
          text-align: right
          span
            color: $black1
            font-size: 14px
          .red
            color: $red
          .yellow
            color: $orange
    .pagination-cell
      height: 68px
      position: relative
      .sales-record-pagination
        width: auto
        absolute: right
        margin-bottom: 0
    .nothing-container
      min-height: 530px
      width: 100%
      position: relative
      .list-nothing
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
</style>
