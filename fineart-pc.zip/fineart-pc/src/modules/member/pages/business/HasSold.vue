<template>
  <div class="has-sold">
    <div class="filter-keyword">
      <i-input v-model="pageConfig.keyword"
               placeholder="输入商品名称/订单号">
        <i-button slot="append" class="search-btn" type="primary" @click="goSearch()"><span class="fy-icon-search"></span>搜一下</i-button>
      </i-input>
    </div>
    <div class="table-head">
      <div class="good-info">商品信息</div>
      <div class="pay-money">实付金额</div>
      <div class="filter">
        <i-select class="order-status" v-model="pageConfig.status" placeholder="状态" clearable @on-change="goSearch()">
          <i-option value="100">待付款</i-option>
          <i-option value="200">待发货</i-option>
          <i-option value="300">待收货</i-option>
          <i-option value="400">已收货</i-option>
          <i-option value="500">交易成功</i-option>
          <i-option value="600">已退款</i-option>
          <i-option value="1000">交易取消</i-option>
        </i-select>
      </div>
      <div>操作</div>
    </div>
    <div class="my-order-page">
      <div v-if="orderList.total">
        <div class="order-item" v-for="(item, index) in orderList.data" :key="index">
          <p class="order-number">
            <span>{{ item.order_at }}</span>
            <span>订单号：{{ item.code }}</span>
          </p>
          <div class="order-detail">
            <div class="goods-img">
              <img :src="item.goods_thumbnail"/>
            </div>
            <div class="good-name">
              <a :href="`/mall.html#/goods-detail/${item.goods_id}/${item.mall_store_id_order}`">{{ item.goods_name }}</a>
            </div>
            <div class="after-sales">
                <router-link :to="`/store-manage/unhandled-service/${item.service_id}`" class="red" v-if="item.service_handle_status === '100'">售后处理中</router-link>
                <router-link :to="`/store-manage/handled-service/${item.service_id}`" class="yellow" v-else-if="item.service_handle_status === '200'">退款</router-link>
                <router-link :to="`/store-manage/handled-service/${item.service_id}`" class="yellow" v-else-if="item.service_handle_status === '300'">换货</router-link>
                <router-link :to="`/store-manage/handled-service/${item.service_id}`" class="grey-height" v-else-if="item.service_handle_status === '400'">取消售后</router-link>
            </div>
            <div class="pay-total">&yen;{{ item.pay_total }}</div>
            <div class="order-status">
              <span :class="item.status === '100' ? 'red' : (item.status === '200' ? 'yellow' : '')">{{ item.status_desc }}</span>
              <router-link :to="`/store-manage/order-detail/${item.id}`">订单详情</router-link>
            </div>
            <div class="handle-order">
              <i-button class="pay-order" v-if="item.status === '200'" @click="goDelivery(item.id)">去发货</i-button>
            </div>
          </div>
        </div>
        <div class="pagination-cell">
          <pagination class="collection-store-pagination"
                      @page-confirm="changePage"
                      :page="orderList.current_page"
                      :total="orderList.total"
                      :page-size="orderList.per_page"></pagination>
        </div>
      </div>
      <div v-else class="nothing-container">
        <list-nothing class="list-nothing" ></list-nothing>
      </div>
    </div>
    <i-modal class="go-delivery"
             v-model="isShowed"
             width="595"
             :transfer="false"
             @on-ok="doSubmit"
             title="温馨提示">
      <p class="tips">请确认您已发货，如商品通过物流公司运送，请填写运单号。</p>
      <i-form>
        <i-form-item label="物流公司">
          <i-select v-model="express.express_company" :disabled="isNoExpress">
            <i-option v-for="(item, index) in expressCompanyList" :key="index" :value="index">{{ item }}</i-option>
          </i-select>
        </i-form-item>
        <i-form-item label="运号单">
          <i-input v-model="express.express_code" :disabled="isNoExpress"></i-input>
        </i-form-item>
        <i-form-item class="radio-box">
          <i-checkbox v-model="isNoExpress">无需物流</i-checkbox>
        </i-form-item>
      </i-form>
    </i-modal>
  </div>
</template>

<script>
import { Select, Option, Input, Modal, Form, FormItem, Checkbox } from 'iview'
import { Pagination, ListNothing } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'
import {scrollTop} from '@/common/js/utils'

export default {
  name: 'HasSold',
  data () {
    return {
      expressCompanyList: this.$store.state.member.expressCompany,
      storeId: this.$route.params.storeId === undefined ? '' : this.$route.params.storeId,
      isShowed: false,
      orderList: {},
      pageConfig: {
        page: 1, // 页码
        keyword: '', // 搜索关键字，商品名称或者订单编号
        status: ''// 订单状态
      },
      express: {
        id: '',
        express_company: '',
        express_code: ''
      },
      isNoExpress: false
    }
  },
  watch: {
    isNoExpress: function () {
      this.express.express_company = ''
      this.express.express_code = ''
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      let response = await api.orderSellerList(this.storeId, this.pageConfig)
      if (response.code === 200) {
        this.orderList = response.results
      } else if (response.code === 501) {
        this.$router.push({path: '/business/choose-store'})
      }
    },
    async changePage (data) {
      this.pageConfig.page = data.page
      let response = await api.orderSellerList(this.storeId, this.pageConfig)
      this.orderList = response.results
      this.$nextTick(() => {
        const sTop = document.documentElement.scrollTop || document.body.scrollTop
        scrollTop(window, sTop, 0, 800)
      })
    },
    async goSearch () {
      if (this.pageConfig.status === undefined) {
        this.pageConfig.status = ''
      }
      this.pageConfig.page = 1
      let response = await api.orderSellerList(this.storeId, this.pageConfig)
      this.orderList = response.results
    },
    goDelivery (orderId) {
      this.isShowed = true
      if (orderId !== this.express.id) {
        this.express.express_code = ''
        this.express.express_company = ''
        this.express.id = orderId
      }
    },
    async doSubmit () {
      if (this.express.express_company === undefined) {
        this.express.express_company = ''
      }
      let response = await api.orderSellerSendOut(this.express)
      if (response.code === 200) {
        this.initPage()
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_OPERATION_FAILED'], type: 'error' })
      }
    }
  },
  components: {
    Pagination,
    ListNothing,
    'i-form': Form,
    'i-modal': Modal,
    'i-checkbox': Checkbox,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-form-item': FormItem
  }
}
</script>

<style lang="stylus">
  .has-sold
    .filter-keyword
      height: 50px
      position: relative
      .ivu-input-wrapper
        width: 366px
        absolute: right
        .ivu-input
          font-size: 14px
          border-color: $orange
        .search-btn
          width: 112px
          font-size: 14px
          color: $white
          padding: 0
          border: none
          border-radius: 0 4px 4px 0
          background-color: $orange
          &>span
            display: flex
            justify-content: center
            align-items: center
            width: 100%
            height: 40px
          .fy-icon-search
            margin-right: 5px
            font-size: 20px
    .table-head
      height: 48px
      line-height: 48px
      padding: 0 50px
      font-size: 16px
      color: $black1
      display: flex
      align-items: center
      flex-direction: row
      border-bottom: 3px solid $grey
      &>div
        display: inline-block
      .good-info
        width: 542px
      .pay-money
        width:140px
      .filter
        width: 150px
        .order-status
          width: 110px
          background-color: transparent
          .ivu-select-selection
            border: none
            height: 48px
            line-height: 48px
            background-color: transparent
            box-shadow: none
          .ivu-select-placeholder, .ivu-select-selected-value
            color: $black1
            font-size: 16px
            height: 48px
            line-height: 48px
    .my-order-page
      padding: 0 30px 30px 30px
      margin-top: 20px
      margin-bottom: 58px
      border: 1px solid $grey-high4
      .order-item
        height: 170px
        padding: 20px 0
        font-size: 14px
        border-bottom: 1px solid $grey-high4
        .order-number
          color: $grey-high1
          font-size: 14px
          margin-bottom: 10px
          span
            padding-right: 20px
        .order-detail
          display: flex
          align-items: center
          &>div
            margin-right: 40px
            &:last-child
              margin-right: 0
            &.goods-img
              width: 100px
              height: 100px
              overflow: hidden
              img
                width: 100px
                height: 100px
            &.good-name
              width: 260px
              font-size: 16px
              a
                color: $black1
            &.after-sales
              width: 80px
              text-align: center
              .red
                color: $red
              .yellow
                color: $orange
              .grey-height
                color: $grey-high
            &.pay-total
              width: 120px
              color: $black1
              font-size: 18px
            &.order-status
              width: 60px
              text-align: center
              span
                display:block
                color: $grey-high
                margin-bottom: 12px
                &.red
                  color: $red
                &.yellow
                  color: $orange
              a
                color: $black1
            &.handle-order
              width: 110px
              text-align: center
              .ivu-btn
                height: 26px
                display: block
                color: $orange
                font-size: 14px
                margin: 5px auto
                padding: 0 14px
                border: 1px solid $orange
                span
                  display: inline-block
                  height:26px
                  line-height: 26px
              .cancel-order
                border: none
                color: $grey-high
              .evaluation
                color: $grey-high
                border: 1px solid $grey-high
      .pagination-cell
        height: 68px
        position: relative
        .collection-store-pagination
          width: auto
          absolute: right
          margin-bottom: 0
      .nothing-container
        min-height: 670px
        position: relative
        .list-nothing
          margin-top: -80px //补偿原本组件的padding-top： 80
          absolute: top 50% left 50%
          transform: translate(-50%,-50%)
  .go-delivery
    .ivu-select-dropdown
      max-height: 135px
    .tips
      color: $black1
      font-size: 14px
      margin-bottom: 30px
    .ivu-form-item
      display: flex
      .ivu-form-item-label
        float: none
        width: 68px
        height: 40px
        margin-right: 24px
        padding: 0
        line-height: 40px
        font-size: 16px
        color: $black1
        text-align: justify
        /*实现文字两端对齐*/
        &:after
          content: ''
          display: inline-block
          padding-left: 100%
      .ivu-form-item-content
        width: 443px
    .radio-box
      padding-left: 84px
      color: $black1
      font-size: 14px
</style>
