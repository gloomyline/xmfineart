<template>
  <div class="choice-store">
    <div class="choice-title">
      <span class="title-text">选择要管理的店铺</span>
      <i-button type="primary" size="large" ghost
                v-if="isCreate"
                custom-icon="fy-icon-add-orange"
                class="store-create"
                @click="goCreate()">创建店铺</i-button>
    </div>
    <div class="store-wrap">
      <ul class="store-list">
        <li class="store-item" v-for="(item, index) in storeList" :key="index">
          <img :src="item.thumbnail" alt="" class="store-img">
          <h3 class="store-name">{{ item.name }}</h3>
          <i-button type="primary" size="large" ghost @click="goManage(item)" v-if="item.status === '300'">管理店铺</i-button>
          <i-button type="primary" size="large" ghost :to="`/business/create-store/${item.id}`" v-if="item.status === '100' || item.status === '200'">{{ item.status === '100' ? '待审核' : '审核不通过' }}</i-button>
        </li>
      </ul>
    </div>
    <i-modal class="store-tips-modal" v-model="isShowed"
             title="温馨提示"
             width="440">
      <p class="tip-text">需完成账号实名认证才能继续使用该功能，如需请点击 去认证，前往认证。</p>
      <div slot="footer">
        <div class="save-btn-group">
          <i-button type="text"
                    class="cancel"
                    @click="isShowed = false">取消</i-button>
          <i-button class="save-btn"
                    type="primary"
                    size="large"
                    to="/real-name">去认证</i-button>
        </div>
      </div>
    </i-modal>
  </div>
</template>

<script>
import { Modal } from 'iview'
import api from 'modules/member/api/index.js'
import { mapState } from 'vuex'

export default {
  name: 'ChooseStore',
  data () {
    return {
      storeList: {},
      isShowed: false,
      isCreate: false
    }
  },
  created () {
    this.initPage()
  },
  computed: {
    ...mapState('member', ['memberInfo'])
  },
  methods: {
    async initPage () {
      this.storeList = await api.storeMyList()
      if (this.memberInfo.is_self === '200' || this.storeList.length < 1) {
        this.isCreate = true
      }
    },
    goCreate () {
      if (this.memberInfo.is_auth === '100') {
        this.isShowed = true
      } else {
        this.$router.push({path: '/business/create-store'})
      }
    },
    goManage (item) {
      this.$localStorage.set('MEMBER_CUR_STORE', item)
      this.$store.commit('member/MEMBER_STORE_MANAGE_STORE_INFO', item)
      this.$router.push({path: `/store-manage/has-sold/${item.id}`})
    }
  },
  components: {
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.choice-store
  padding: 30px 0 0 15px
  .choice-title
    display: flex
    justify-content: space-between
    margin-bottom: 30px
    .title-text
      color: $black1
      font-size: 16px
      line-height: 40px
  .store-create
    line-height: 26px
  .store-wrap
    width: 100%
    overflow: hidden
    .store-list
      display: flex
      flex-flow: wrap
      margin-right: -30px
      .store-item
        display: flex
        flex-direction: column
        align-items: center
        width: 308px
        height: 295px
        padding-top: 39px
        margin: 0 30px 30px 0
        border: 1px solid $grey-high4
        .store-img
          display: block
          width: 120px
          height: 120px
          margin-bottom: 20px
        .store-name
          margin-bottom: 20px
          color: $black
          font-size: 16px
.save-btn
  line-height: 36px
  span
    display: inline
</style>
