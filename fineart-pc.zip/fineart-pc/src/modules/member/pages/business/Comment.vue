<template lang="html">
<div class="store-manage-comment">
  <div class="table-head">
    <span class="goods-info">商品信息</span>
    <span class="comment">评价内容</span>
    <span class="guest">买家</span>
    <span class="handle">操作</span>
  </div>
  <div class="common-page">
    <div v-if="comments.total">
      <div class="comment-item" v-for="item in comments.data" :key="item.id">
        <div class="goods-info">
          <p class="order-number">订单号：{{ item.order_code }}</p>
          <p class="goods-name">{{ item.goods_name }}</p>
          <p class="money">¥{{ item.pay_total }}</p>
        </div>
        <div class="comment">
          <p class="star">
            <i-rate :value="item.star" disabled custom-icon="fy-icon-star5"></i-rate>
          </p>
          <div class="comment-text">{{ item.content }}</div>
          <div class="comment-img">
            <img v-for="image in item.images" :key="image" :src="image">
          </div>
        </div>
        <div class="guest">
          <div class="nick-name">{{ item.nickname }}</div>
        </div>
        <div class="handle">
          <div class="not-replying" v-if="!item.reply">
            <i-button type="text" @click="replyComment(item.id)">回复</i-button>
          </div>
          <p class="reply" v-else>已回复：{{ item.reply }}</p>
        </div>
      </div>
      <div class="pagination-cell">
        <pagination class="comment-pagination"
                    @page-confirm="goToCurrentPage"
                    v-if="!!comments.total"
                    :page="comments.current_page"
                    :total="comments.total"
                    :page-size="comments.per_page"></pagination>
      </div>
    </div>
    <div v-else class="nothing-container">
      <list-nothing class="list-nothing" ></list-nothing>
    </div>
  </div>
  <i-modal v-model="showReplyModal" title="回复" @on-ok="replyCommentSubmit">
    <i-input v-model="replyContent" type="textarea" :rows="8" placeholder="请输入"></i-input>
  </i-modal>
</div>
</template>

<script>
import { Rate, Modal, Input } from 'iview'
import { Pagination, ListNothing } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'
import { scrollTop } from '@/common/js/utils'

export default {
  name: 'Comment',
  data () {
    return {
      comments: {
        data: [],
        total: 2,
        current_page: 1,
        per_page: 10,
        last_page: 1,
        has_next: false
      },
      replyContent: '',
      showReplyModal: false,
      replyCommitId: '',
      pageConfig: {
        page: 1
      }
    }
  },
  created () {
    this.fetchStoreCommentList(this.pageConfig.page)
  },
  watch: {
    pageConfig: {
      handler: function (newVal) {
        this.fetchStoreCommentList(newVal.page)
      },
      deep: true
    }
  },
  methods: {
    goToCurrentPage (page) {
      this.pageConfig.page = page.page
      this.$nextTick(() => {
        const sTop = document.documentElement.scrollTop || document.body.scrollTop
        scrollTop(window, sTop, 0, 800)
      })
    },
    async fetchStoreCommentList (page) {
      this.comments = await api.fetchStoreCommentList(page)
      for (let key in this.comments.data) {
        this.comments.data[key].star = this.calculateStar(this.comments.data[key].score)
      }
    },
    // 评价分数转化成星数
    calculateStar (score) {
      return Number.parseInt(score / 20) + 1
    },
    replyComment (commentId) {
      this.replyCommitId = commentId
      this.showReplyModal = true
    },
    async replyCommentSubmit () {
      this.result = await api.commentReply({id: this.replyCommitId, content: this.replyContent})
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['MALL_GOODS_COMMENT_REPLY_SUCCESS'], type: 'success'})
        this.fetchStoreCommentList(this.pageConfig.page)
        this.replyContent = ''
      }
    }
  },
  components: {
    ListNothing,
    Pagination,
    'i-rate': Rate,
    'i-modal': Modal,
    'i-input': Input
  }
}
</script>

<style lang="stylus">
.store-manage-comment
  position: relative
  margin-bottom: 50px
  border: 1px solid $grey-high4
  padding: 0 30px 30px 30px
  .table-head
    font-size: 14px;
    color: $grey-high
    line-height: 20px
    padding: 14px 0
    display: flex
    justify-content: space-between
    border-bottom: 2px solid $grey-high4
    span
      display: inline-block
    .goods-info
      width: 238px
    .comment
      width: 336px
      text-align: center
    .guest
      width: 87px
      text-align: center
    .handle
      width: 170px
      text-align: center
  .common-page
    .comment-item
      height: 192px
      padding: 20px 0
      display: flex
      border-bottom: 1px solid $grey-high4
      justify-content: space-between
      .goods-info
        width: 238px
        font-size: 14px
        .order-number
          color: $grey-high1
          margin-bottom: 12px
        .goods-name
          color: $black
          line-height: 20px
          margin-bottom: 30px
        .money
          color: $orange
          font-size: 16px
      .comment
        width: 336px
        .star
          margin-top: -5px
          .ivu-rate-star-chart.ivu-rate-star-full .ivu-rate-star-second
            color: $yellow
        .comment-text
          color: $black1
          font-size: 14px
          max-height: 60px
          overflow: hidden
          -webkit-line-clamp: 3
          display: -webkit-box
          -webkit-box-orient: vertical
        .comment-img
          display: flex
          img
            height: 50px
            width: 50px
            margin: 7px 7px 0 0
            border: 1px solid $grey-high4
      .guest
        width: 87px
        padding-top: 30px
        text-align: center
        .user-number
          color: $black1
          font-size: 14px
        .nick-name
          height: 22px
          font-size: 16px
          color: $grey-high
          line-height: 22px
      .handle
        width: 170px
        .not-replying
          padding-top: 20px
          text-align: center
          .ivu-btn
            color: $orange
            font-size: 14px
        .reply
          font-size:14px;
          color: $grey-high
          line-height: 20px
          margin-top: 30px
          -webkit-line-clamp: 6
          max-height: 120px
          display: -webkit-box
          overflow: hidden
          -webkit-box-orient: vertical

  .pagination-cell
    height: 40px
    .comment-pagination
      width: auto
      absolute: right 20px bottom 20px
      margin-bottom: 0
  .nothing-container
    min-height: 533px
    position: relative
    .list-nothing
      absolute: top 50% left 50%
      transform: translate(-50%,-50%)
</style>
