<template lang="html">
  <div class="create-store">
    <p class="title">创建店铺</p>
    <p class="describe">提供您店铺相应的信息，平台审核通过后，即可发布商品。</p>
    <p class="tip-wrong" v-if="createForm.status === '200'">
      <label>审核失败</label>
      <span>{{ createForm.reason }}</span>
    </p>
    <i-form class="create-form"
            ref="createForm"
            :model="createForm"
            :rules="createRule">
      <i-form-item label="店铺名称" prop="name">
        <i-input v-model="createForm.name" placeholder="请输入店铺名称，审核通过后不能修改"></i-input>
      </i-form-item>
      <i-form-item label="主营商品" prop="subtitle">
        <i-input v-model="createForm.subtitle" placeholder="请输入主营商品，如“卫浴五金、管道”"></i-input>
      </i-form-item>
      <i-form-item label="店铺介绍" prop="introduction">
        <i-input v-model="createForm.introduction"
                 type="textarea"
                 :rows="5"
                 placeholder="介绍您的店铺"></i-input>
      </i-form-item>
      <i-form-item class="store-category" label="店铺分类" prop="mall_store_category_id">
        <i-select placeholder="请选择分类" v-model="createForm.mall_store_category_id">
          <i-option v-for="(item, index) in StoreCategoryList" :key="index" :value="item.value">{{ item.label }}</i-option>
        </i-select>
        <p class="input-tips">设置您的店铺分类，便于用户寻找</p>
      </i-form-item>
      <i-form-item class="store-picture-cover" label="店铺封面" prop="thumbnail">
        <div class="uploaded-img" v-if="createForm.thumbnail_cdn">
          <img :src="createForm.thumbnail_cdn">
          <div class="img-edit-cover">
            <span class="fy-icon-delete-round" @click="goDelThumb()"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
          </div>
        </div>
        <i-upload ref="upload"
                  v-else
                  :show-upload-list="false"
                  :max-size="ossThumbnail.max_size"
                  type="drag"
                  :data="ossThumbnail.data"
                  :action="ossThumbnail.host"
                  :format="ossThumbnail.format"
                  :accept="ossThumbnail.accept"
                  :on-exceeded-size="exceededSize"
                  :on-format-error="formatError"
                  :before-upload="beforeUploadThumb"
                  :on-success="successThumb">
          <div class="upload-box">
            <!--<img src="" alt="">-->
            <span class="fy-icon-upload"></span>
            <em>点击上传</em>
          </div>
        </i-upload>
        <p class="upload-tip">图片尺寸：最小300*300px<br/>格式为.jpg / .jpeg / .png ，大小不超过5MB；</p>
      </i-form-item>
      <i-form-item class="store-picture-main" label="店铺主图" prop="store_images">
        <div class="picture-wrap">
          <div class="uploaded-img" v-for="(item, index) in createForm.store_images_cdn" :key="index">
            <img :src="item">
            <div class="img-edit-cover">
              <span class="fy-icon-delete-round" @click="goDelImage(index)"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
            </div>
          </div>
          <i-upload ref="upload"
                    class="store-img-upload"
                    v-if="createForm.store_images.length < 6"
                    :show-upload-list="false"
                    :max-size="ossImage.max_size"
                    type="drag"
                    :data="ossImage.data"
                    :action="ossImage.host"
                    :format="ossImage.format"
                    :accept="ossImage.accept"
                    :on-exceeded-size="exceededSize"
                    :on-format-error="formatError"
                    :before-upload="beforeUploadImage"
                    :on-success="successImage">
            <div class="cover-upload-text">
              <span class="fy-icon-add-thin-gray"></span>
              <p>点击上传</p>
            </div>
          </i-upload>
        </div>
        <p class="main-picture-tip">图片尺寸：最小750*420px格式为.jpg / .jpeg / .png ，大小不超过5MB；</p>
      </i-form-item>
      <i-form-item label="店长姓名" prop="manager">
        <i-input placeholder="请输入店长姓名" v-model="createForm.manager"></i-input>
      </i-form-item>
      <i-form-item class="contact-number" label="联系电话" prop="mobile">
        <i-input v-model.trim.number="createForm.mobile" placeholder="请输入手机号码"></i-input>
        <p class="input-tips">提供真实的店长信息，方便与顾客沟通。</p>
      </i-form-item>
      <i-form-item class="home-add-item" label="地区" >
        <i-input v-model.trim.number="createForm.area" @on-focus="mapAddress=true" placeholder="请选择地区"></i-input>
      </i-form-item>
      <i-form-item class="address-detail" label="详细地址" prop="address">
        <i-input v-model="createForm.address" @on-focus="mapAddress=true" placeholder="请输入详细地址"></i-input>
        <p>准确定位您商店的位置，顾客可以更好的进店体验</p>
      </i-form-item>
      <!-- 编辑地区 -->
      <fa-map v-model="mapAddress"
              :lng="createForm.lng"
              :lat="createForm.lat"
              :address="createForm.address"
              :sysAreaId="createForm.sys_area_id"
              @save-edit="editArea"></fa-map>
      <i-form-item>
        <i-button class="commit-btn" type="primary" @click="handleSubmit('createForm')">提交</i-button>
      </i-form-item>
    </i-form>
  </div>
</template>

<script>
import { FaMap, FineartCascader } from 'components'
import { getStoreCategory } from '@/common/js/loadScript.js'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'
import {
  Form,
  Input,
  Select,
  Option,
  Upload,
  Button,
  FormItem,
  Dropdown,
  DropdownMenu
} from 'iview'

export default {
  name: 'CreateStore',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{9}\d$/.test(value))) {
        cb(new Error('手机号码格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      mapAddress: false, // 控制弹窗显示数组
      createForm: {
        name: '', // 姓名，必须
        introduction: '', // 个人简介，必须
        subtitle: '', // 一句话介绍，必须
        mall_store_category_id: '', // 分类ID，必须
        thumbnail: '', // 店铺封面图，必须
        thumbnail_cdn: '',
        store_images: [], // 店铺主图
        store_images_cdn: [],
        manager: '', // 店长姓名
        mobile: '', // 联系手机，必须
        sys_area_id: '', // 地区ID，必须
        address: '', // 详细地址，必须
        lng: '', // 经度，必须
        lat: ''// 纬度，必须,
      },
      createRule: {
        name: [
          { required: true, message: '请输入店铺名称' },
          { type: 'string', max: 20, message: '店铺名称超过20个字' }
        ],
        introduction: [
          { required: true, message: '请输入店铺介绍' }
        ],
        subtitle: [
          { required: true, message: '请输入主营商品' },
          { type: 'string', max: 20, message: '主营商品超过20个字' }
        ],
        mall_store_category_id: [
          { required: true, message: '请选择分类' }
        ],
        thumbnail: [
          { required: true, type: 'string', min: 1, message: '请上传店铺封面', trigger: 'blur' },
          { type: 'string', min: 2, message: '请上传店铺封面' }
        ],
        store_images: [
          { required: true, type: 'array', min: 1, message: '请上传店铺主图', trigger: 'blur' },
          { type: 'array', min: 1, max: 6, message: '请上传1~6张店铺主图' }
        ],
        manager: [
          { required: true, message: '请输入店长姓名' },
          { type: 'string', min: 2, max: 10, message: '店长姓名只能由2~10个汉字组成' }
        ],
        mobile: [
          { required: true, message: '请输入手机号' },
          mobileValidator
        ],
        address: [
          { required: true, message: '请输入详细地址' }
        ]
      },
      StoreCategoryList: [],
      areaInfo: [],
      keywords: '',
      visible: false,
      ossThumbnail: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      }
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      if (this.$route.params.id !== undefined) {
        this.createForm = await api.storeApplyInfo()
        if (this.createForm) {
          let area = []
          for (let index in this.createForm.area_line) {
            if (index !== '1') {
              area.push(this.createForm.area_line[index])
            }
          }
          this.createForm.area = area.join(' / ')
        }
      }
      this.initStoreCategory()
    },
    async editArea (mapAddress) {
      this.createForm.lng = mapAddress.point.lng
      this.createForm.lat = mapAddress.point.lat
      this.createForm.sys_area_id = mapAddress.sysAreaId
      this.createForm.area = mapAddress.addressData.province + ' / ' + mapAddress.addressData.city + ' / ' + mapAddress.addressData.district
      this.createForm.address = mapAddress.addressData.address
    },
    async initStoreCategory () {
      this.StoreCategoryList = await getStoreCategory()
    },
    changeCategory (param) {
      this.storeInfo.resource_category_id = param
    },
    handleSubmit (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.result = await api.insertStoreInfo(this.createForm)
          if (this.result.code === 200) {
            this.$store.commit('ADD_MESSAGE', {msg: MSG['STORE_MANAGE_STORE_ADD_SUCCESS'], type: 'success'})
            this.$router.push({path: '/business/choose-store'})
          }
        }
      })
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await api.ossParamsCreate(file, 'store_thumbnail', this.ossThumbnail)
    },
    successThumb (res) {
      if (res.code === 200) {
        this.createForm.thumbnail = res.results.file_url
        this.createForm.thumbnail_cdn = res.results.file_url_cdn
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    goDelThumb () {
      this.createForm.thumbnail = ''
      this.createForm.thumbnail_cdn = ''
    },
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'store_image', this.ossImage)
    },
    successImage (res) {
      if (res.code === 200) {
        this.createForm.store_images_cdn.push(res.results.file_url_cdn)
        this.createForm.store_images.push(res.results.file_url)
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    goDelImage (key) {
      this.$delete(this.createForm.store_images_cdn, key)
      this.$delete(this.createForm.store_images, key)
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    }
  },
  components: {
    FaMap,
    FineartCascader,
    'i-button': Button,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-upload': Upload,
    'i-dropdown': Dropdown,
    'i-dropdown-menu': DropdownMenu
  }
}
</script>

<style lang="stylus">
.create-store
  position: relative
  padding-left: 10px
  p
    &.title
      font-size: 18px
      margin-bottom: 20px
    &.describe
      font-size: 14px
      color: $black1
      margin-bottom: 10px
    &.tip-wrong
      margin: 30px 0 0 0
      label
        width: 64px
        margin-right: 20px
        color: $orange
        font-size: 16px
      span
        color: $orange
        font-size: 16px
  .create-form
    padding: 20px 0 20px 0
    .input-tips
      color: $grey-high
      font-size: 14px
    .ivu-form-item
      margin-bottom: 30px
      &.resource-category
        .fineart-cascade
          margin-bottom: 0
        .ivu-form-item-error-tip
          left: 84px
      .ivu-form-item-label
        width: 64px
        height: 40px
        padding: 0
        margin-right: 20px
        font-size: 16px
        color: $black
        overflow: hidden
        line-height: 40px
        text-align: justify
        /*实现文字两端对齐*/
        &:after
          content: ''
          display: inline-block
          padding-left: 100%
      .ivu-form-item-content
        display: flex
        &>p
          font-size: 14px
          margin-top: 10px
          max-width: 640px
          color: $grey-high
          line-height: 32px
        .ivu-input, .ivu-select, .ivu-select-placeholder, .ivu-select-selected-value
          width: 640px
        .commit-btn
          width: 120px
          height: 40px
          font-size: 16px
          margin-left: 84px
        .upload-tip
          margin: 0
          width: 341px
          height: 59px
          font-size: 14px
          color: $grey-high
          line-height: 32px
          padding-left: 20px
      &.map-position-add, &.address-detail
        align-items: baseline
        .ivu-form-item-content
          display: flex
          align-items: normal
          flex-direction: column
          .ivu-input-prefix i
            color: $grey-high1
      &.store-category, &.contact-number
        .ivu-form-item-content
          flex-direction: column
      &.store-picture-cover
        display: flex
        align-items: center
        .ivu-form-item-content
          display: flex
          align-items: center
          .uploaded-img
            margin: 0
      &.store-picture-main
        .ivu-form-item-content
          display: flex
          flex-direction: column
        .picture-wrap
          max-width: 680px
          display: flex
          flex-wrap: wrap
          .uploaded-img
            width: 200px
            height: 112px
            margin: 0 20px 20px 0
            position: relative
          .store-img-upload
            .ivu-upload-drag
              width: 200px
              height: 112px
              margin-bottom: 20px
              border: 1px solid $grey-high4
            .cover-upload-text
              width: 200px
              height: 112px
              p
                color: #bbb
                font-size: 14px
              .fy-icon-add-thin-gray
                display: inline-block
                font-size: 32px
                margin: 25px 0 0 0
        .main-picture-tip
          margin: 0
    .map-plugin
      width: 888px
      height: 354px
      margin: 0 0 30px 84px
    .address-list
      width: 620px
      padding: 5px 20px
      cursor: pointer
    /*验证时文字位置*/
    .ivu-form-item-error-tip
      left: 0
</style>
