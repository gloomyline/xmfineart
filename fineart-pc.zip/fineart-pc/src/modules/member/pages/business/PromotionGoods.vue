<template>
  <div class="promotion-goods">
    <div class="filter-keyword">
      <i-select v-model="indexRoute" class="route-select">
        <i-option value="/promotion-goods">推广商品</i-option>
        <i-option value="/promote-sales-record">推广销售记录</i-option>
        <i-option value="/settlement-record">结算记录</i-option>
      </i-select>
      <i-input v-model="pageConfig.keyword"
               placeholder="输入商品/店铺名称">
        <i-button slot="append" class="search-btn" type="primary"><span class="fy-icon-search"></span>搜一下</i-button>
      </i-input>
    </div>
    <div class="table-head">
      <div class="good-info">商品信息</div>
      <div class="unit-price">商品单价</div>
      <div class="supply-price">供货价</div>
      <div class="handle-goods">操作</div>
    </div>
    <div class="promotion-goods-page">
      <div v-if="goodsList.total">
        <div class="goods-item" v-for="(item, index) in goodsList.data" :key="index">
          <div class="goods-img">
            <img :src="item.thumbnail_cdn"/>
          </div>
          <div class="goods-store-name">
            <a class="goods-name" :href="`/mall.html#/goods-detail/${item.id}/${item.store_id}`">{{ item.name }}</a>
            <a class="store-name" :href="`/mall.html#/store-detail/${item.store_id_source}`">{{ item.store_name_source }}>></a>
          </div>
          <div class="unit-price">&yen;{{ item.price_norm }}</div>
          <div class="supply-price">&yen;{{ item.price_promotion }}</div>
          <div class="handle-goods">
            <i-button class="promote" @click="showQrCode(item.id, item.name, item.store_id)">二维码</i-button>
          </div>
        </div>
        <div class="pagination-cell">
          <pagination class="collection-store-pagination"
                      @page-confirm="changePage"
                      :page="parseInt(goodsList.current_page)"
                      :total="goodsList.total"
                      :page-size="goodsList.per_page"></pagination>
        </div>
      </div>
      <div v-else class="nothing-container">
        <list-nothing class="list-nothing" ></list-nothing>
      </div>
    </div>
    <i-modal title="商品二维码"
             class="goods-qr-modal"
             v-model="isShowedQr"
             width="440"
             footer-hide>
      <p class="goods-name">{{ qrcode.name }}</p>
      <img class="goods-qr" :src="qrcode.src" alt="">
      <i-button type="text" class="down-qr">下载二维码</i-button>
    </i-modal>
  </div>
</template>

<script>
import { Select, Option, Input, Modal } from 'iview'
import { Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'
import { MOB_ADDRESS } from '@/assets/data/constants'

export default {
  name: 'Promotion-goods',
  data () {
    return {
      isShowedQr: false,
      indexRoute: '/promotion-goods',
      goodsList: {},
      pageConfig: {
        page: 1, // 页码
        keyword: '' // 搜索关键字，商品名称或者订单编号
      },
      qrcode: {
        name: '',
        src: ''
      }
    }
  },
  created () {
    this.initPage()
  },
  watch: {
    indexRoute (newVal) {
      this.$router.push(newVal)
    }
  },
  methods: {
    async initPage () {
      this.goodsList = await api.goodsPromotionList(this.pageConfig)
    },
    async changePage (data) {
      this.pageConfig.page = data.page
      this.initPage()
    },
    async goShowQr () {
      this.isShowedQr = true
    },
    async showQrCode (id, name, store_id) {
      this.qrcode.name = name
      this.isShowedQr = true
      let url = `${MOB_ADDRESS}/mall.html#/goods-detail/${id}/${store_id}`
      let results = await api.qrcodeCreate(url)
      this.qrcode.src = results.qrcode
    }
  },
  components: {
    Pagination,
    ListNothing,
    'i-select': Select,
    'i-option': Option,
    'i-input': Input,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
  .promotion-goods
    .filter-keyword
      height: 40px
      margin-bottom: 20px
      position: relative
      .route-select
        width: 228px
        .ivu-select-selected-value
          font-size: 16px
      .ivu-input-wrapper
        width: 366px
        absolute: right
        .ivu-input
          font-size: 14px
          border-color: $orange
        .search-btn
          width: 112px
          font-size: 14px
          color: $white
          padding: 0
          border: none
          border-radius: 0 4px 4px 0
          background-color: $orange
          &>span
            display: flex
            justify-content: center
            align-items: center
            width: 100%
            height: 40px
          .fy-icon-search
            margin-right: 5px
            font-size: 20px
    .table-head
      height: 48px
      line-height: 48px
      padding: 0 50px
      font-size: 16px
      color: $black1
      display: flex
      align-items: center
      flex-direction: row
      border-bottom: 3px solid $grey
      &>div
        display: inline-block
      .good-info
        width: 440px
      .unit-price
        width: 90px
        text-align: center
        margin-right: 80px
      .supply-price
        width: 90px
        text-align: center
        margin-right: 80px
      .handle-goods
        width: 80px
        text-align: center
    .promotion-goods-page
      padding: 0 30px 30px 30px
      margin-top: 20px
      margin-bottom: 58px
      border: 1px solid $grey-high4
      .goods-item
        height: 170px
        padding: 20px 0
        font-size: 14px
        display: flex
        align-items: center
        border-bottom: 1px solid $grey-high4
        &>div
          margin-right: 80px
          &:last-child
            margin-right: 0
          &.goods-img
            width: 100px
            height: 100px
            margin-right: 40px
            overflow: hidden
            img
              width: 100px
              height: 100px
          &.goods-store-name
            width: 250px
            font-size: 16px
            .goods-name
              width: 250px
              color: $black
              max-height: 50px
              overflow: hidden
              -webkit-line-clamp: 2
              display: -webkit-box
              -webkit-box-orient: vertical
            .store-name
              height: 20px
              color: $black1
              font-size: 14px
          &.unit-price
            width: 90px
            font-size: 18px
            color: $orange
          &.supply-price
            width: 90px
            font-size: 18px
            color: $black1
          &.handle-goods
            width: 80px
            text-align: center
            .ivu-btn
              height: 24px
              line-height: 24px
              width: 72px
              display: block
              color: $orange
              font-size: 14px
              cursor: pointer
              border-radius: 4px
              padding: 0
              margin-bottom: 13px
              border: 1px solid $orange
              &.edit-tag
                color: $grey-high
                border: 1px solid $grey-high
      .pagination-cell
        height: 68px
        position: relative
        .collection-store-pagination
          width: auto
          absolute: right
          margin-bottom: 0
      .nothing-container
        min-height: 670px
        position: relative
        .list-nothing
          margin-top: -80px //补偿原本组件的padding-top： 80
          absolute: top 50% left 50%
          transform: translate(-50%,-50%)
.goods-qr-modal
    .goods-name
      width: 248px
      margin: 0 auto 12px auto
      color: $black1
      font-size: 18px
      text-align: center
    .goods-qr
      display: block
      width: 242px
      height: 242px
      margin: 0 auto 20px auto
    .down-qr
      display: block
      margin: 0 auto
      color: $orange
      font-size: 18px
</style>
