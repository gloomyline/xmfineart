<template>
  <div class="my-goods">
    <div class="filter-keyword">
      <i-select v-model="pageConfig.status" @on-change="goSearch()">
        <i-option value="100">审核中</i-option>
        <i-option value="200">审核失败</i-option>
        <i-option value="300">发布中</i-option>
        <i-option value="400">已下架</i-option>
      </i-select>
      <i-input placeholder="输入商品名称" v-model="pageConfig.keyword">
        <i-button slot="append" class="search-btn" type="primary" @click="goSearch()"><span class="fy-icon-search"></span>搜一下</i-button>
      </i-input>
      <div class="go-release">
        <i-button class="go-release" type="primary" ghost size="large"
                  custom-icon="fy-icon-add-thick-orange" to="/store-manage/release-goods">发布商品</i-button>
      </div>
    </div>
    <i-row class="table-title">
      <i-col span="10" class="goods-info">商品信息</i-col>
      <i-col span="5">标签</i-col>
      <i-col span="3">单价</i-col>
      <i-col span="3">库存</i-col>
      <i-col span="3">操作</i-col>
    </i-row>
    <div class="shopping-list">
      <i-row v-for="(item, index) in goodsList.data" :key="index">
        <i-col span="10" class="goods-intro">
          <div class="goods-img">
            <img :src="item.thumbnail_cdn" alt="">
          </div>
          <a class="goods-name" :href="item.status === '300' ? `/mall.html#/goods-detail/${item.id}/${item.store_id}` : 'javascript:;'">{{ item.name }}</a>
        </i-col>
        <i-col span="5">
          <div class="tag">
            <span v-for="(val, index) in item.tags" :key="index">{{ val }}</span>
          </div>
        </i-col>
        <i-col span="3" class="price-box">
          <span class="unit-price">&yen;{{ item.price_norm }}</span>
        </i-col>
        <i-col span="3">
          <span class="amount-price">{{ item.stock }}</span>
        </i-col>
        <i-col span="3" class="btn-group">
          <i-button type="primary" ghost class="opera"
                    @click="goShowQr(item.id, item.store_id, item.name)">二维码</i-button>
          <i-button class="opera-edit" :to="`/store-manage/edit-goods/${item.id}`">编辑</i-button>
          <i-button class="opera-edit" @click="tagEditOpen(item.id, item.tags)">编辑标签</i-button>
          <i-button class="opera-edit" @click="goOffShelves(item.id)" v-if="item.status === '300'">下架</i-button>
          <i-button class="opera-edit" @click="goOnSale(item.id)" v-if="item.status === '400'">上架</i-button>
        </i-col>
      </i-row>
    </div>
    <div class="pagination-cell">
      <pagination class="collection-store-pagination"
                  @page-confirm="changePage"
                  :page="goodsList.current_page"
                  :total="goodsList.total"
                  :page-size="goodsList.per_page"></pagination>
    </div>
    <list-nothing v-show="goodsList.data && goodsList.data.length === 0"></list-nothing>
    <i-modal title="商品二维码"
             class="goods-qr-modal"
             v-model="isShowed"
             width="440"
             footer-hide>
      <p class="goods-name">{{ qrcode.name }}</p>
      <img class="goods-qr" :src="qrcode.src" alt="">
      <i-button type="text" class="down-qr">下载二维码</i-button>
    </i-modal>
    <!-- 商品分组标签设置-->
    <goods-set-group v-model="isTagEdit"
                     :goodsId="tags.goods_id"
                     :goodsTagsAll="tags.goods_tags_all"></goods-set-group>
  </div>
</template>

<script>
import { Input, Select, Option, Row, Col, Checkbox, Modal } from 'iview'
import { ListNothing, Pagination, GoodsSetGroup } from 'components'
import api from 'modules/member/api/index.js'
import { MOB_ADDRESS } from '@/assets/data/constants'
import { scrollTop } from '@/common/js/utils'

export default {
  name: 'MyGoods',
  data () {
    return {
      isShowed: false,
      isTagEdit: false,
      goodsList: {},
      pageConfig: {
        page: 1,
        keyword: '',
        status: this.$route.params.status === undefined ? '300' : this.$route.params.status
      },
      qrcode: {
        name: '',
        src: ''
      },
      tags: {}
    }
  },
  watch: {
    isTagEdit (val) {
      if (!val) {
        this.initPage()
      }
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.goodsList = await api.goodsList(this.pageConfig)
    },
    async goSearch () {
      this.pageConfig.page = 1
      this.initPage()
    },
    changePage (data) {
      this.pageConfig.page = data.page
      this.initPage()
      this.$nextTick(() => {
        const sTop = document.documentElement.scrollTop || document.body.scrollTop
        scrollTop(window, sTop, 0, 800)
      })
    },
    async goShowQr (goods_id, store_id, name) {
      let url = `${MOB_ADDRESS}/mall.html#/goods-detail/${goods_id}/${store_id}`
      let results = await api.qrcodeCreate(url)
      this.qrcode.src = results.qrcode
      this.qrcode.name = name
      this.isShowed = true
    },
    async goOffShelves (goods_id) {
      let vm = this
      Modal.confirm({
        title: '温馨提示',
        content: '请确认您要下架该商品',
        onOk: async function () {
          let response = await api.goodsUpdateStatus([goods_id], 400)
          if (response.code === 200) {
            vm.initPage()
          } else {

          }
        }
      })
    },
    async goOnSale (goods_id) {
      let vm = this
      Modal.confirm({
        title: '温馨提示',
        content: '请确认您要上架该商品',
        onOk: async function () {
          let response = await api.goodsUpdateStatus([goods_id], 300)
          if (response.code === 200) {
            vm.initPage()
          }
        }
      })
    },
    async tagEditOpen (goods_id, tags) {
      this.tags.goods_id = goods_id
      this.tags.goods_tags_all = tags instanceof Array && tags.length === 0 ? {} : tags
      this.isTagEdit = true
    }
  },
  components: {
    Pagination,
    ListNothing,
    GoodsSetGroup,
    'i-row': Row,
    'i-col': Col,
    'i-modal': Modal,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-checkbox': Checkbox
  }
}
</script>

<style lang="stylus">
.my-goods
  .filter-keyword
    display: flex
    justify-content: space-between
    margin-bottom: 20px
    .ivu-select
      width: 228px
      .ivu-select-selected-value
        font-size: 16px
    .ivu-input-wrapper
      width: 366px
      .ivu-input
        font-size: 14px
        border-color: $orange
      .search-btn
        width: 112px
        font-size: 14px
        color: $white
        padding: 0
        border: none
        border-radius: 0 4px 4px 0
        background-color: $orange
        &>span
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 40px
        .fy-icon-search
          margin-right: 5px
          font-size: 20px
  .go-release
    display: flex
    justify-content: flex-end
    height: 40px
    line-height: 26px
    .ivu-icon
      line-height: 1.6
      &:before
        vertical-align: middle
  .table-title
    height: 52px
    margin: 30px 0 0 0
    border: 1px solid $grey-high4
    background-color: $grey-high5
    .ivu-col
      height: 52px
      color: $black
      line-height: 52px
      text-align: center
      font-size: 16px
      &.goods-info
        padding-left: 165px
        text-align: left
  .shopping-list
    margin-bottom: 30px
    border-top: 1px solid $grey-high5
    border-right: 1px solid $grey-high5
    border-left: 1px solid $grey-high5
    .ivu-row
      height: 140px
      //margin-bottom: 20px
      border-bottom: 1px solid $grey-high5
    .ivu-col
      display: flex
      justify-content: center
      align-items: center
      height: 140px
      &.price-box
        flex-direction: column
      &.goods-intro
        justify-content: flex-start
        padding-left: 20px
      &.btn-group
        height: 140px
        flex-direction: column
        justify-content: space-around
        .ivu-btn
          width: 74px
          height: 24px
          font-size: 14px
          padding: 0
          text-align: center
    .goods-img
      width: 100px
      height: 100px
      margin-right: 40px
      &>img
        width: 100px
        height: 100px
    .goods-name
      color: $black
      font-size: 18px
      line-height: 25px
      overflow: hidden
      -webkit-line-clamp: 2
      display: -webkit-box
      -webkit-box-orient: vertical
    .tag
      display: inline-block
      padding: 0 20px
      overflow: hidden
      text-align: auto
      {ellipse}
      span
        vertical-align: center
        font-size: 14px
        display: inline-block
        padding-right: 8px
    .amount-price
      font-size: 16px
    .unit-price
      display: block
      color: $black1
      font-size: 18px
      &.del-price
        text-decoration: line-through
        color: $grey-high1
        font-size: 16px
    .discount-price
      display: block
      color: $black1
      font-size: 18px
    .opera-edit
      color: $grey-high1
    .lose-tag
      padding: 1px 10px
      font-size: 14px
      color: $white
      background-color: $grey-light1
      border-radius: 4px
  .shopping-checked
    display: flex
    align-items: center
    .ivu-checkbox, .ivu-checkbox-inner
      width: 24px
      height: 24px
      border-radius: 4px
      &:after
        left: 7px
        width: 7px
        height: 14px
  .table-footer
    display: flex
    align-items: center
    padding-left: 30px
    .shopping-checked
      margin-right: 24px
      .ivu-checkbox
        margin-right: 16px
        font-size: 16px
  .pagination-cell
    height: 68px
    position: relative
    margin-bottom: 40px
    .collection-store-pagination
      width: auto
      absolute: right
      margin-bottom: 0
.goods-qr-modal
  .goods-name
    width: 248px
    margin: 0 auto 12px auto
    color: $black1
    font-size: 18px
    text-align: center
  .goods-qr
    display: block
    width: 242px
    height: 242px
    margin: 0 auto 20px auto
  .down-qr
    display: block
    margin: 0 auto
    color: $orange
    font-size: 18px
</style>
