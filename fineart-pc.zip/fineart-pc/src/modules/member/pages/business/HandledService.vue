<template lang="html">
  <div class="handled-service">
    <div class="handled-service-page">
      <div class="order-info-card">
        <p class="info-card-title">商品信息</p>
        <div class="info-card-content">
          <p>
            <label>订单号：</label>
            <span>{{ serviceDetail.mall_order_code }}</span>
          </p>
          <p>
            <label>商品名称：</label>
            <span>{{ serviceDetail.name }}</span>
          </p>
          <p>
            <label>实付金额：</label>
            <span class="yellow">&yen;{{ serviceDetail.pay_total }}</span>
          </p>
        </div>
      </div>
      <div class="application-detail">
        <p class="info-card-title">买家信息</p>
        <div class="info-card-content">
          <p>
            <label>手机号码：</label>
            <span>{{ serviceDetail.buyer_mobile }}</span>
          </p>
          <p>
            <label>昵称：</label>
            <span>{{ serviceDetail.buyer_nickname }}</span>
          </p>
        </div>
        <p class="info-card-title">售后申请类型</p>
        <p class="info-card-content" >
          <span class="red" v-if="serviceDetail.apply_operate === '100'">退款</span>
          <span class="red" v-if="serviceDetail.apply_operate === '200'">换货</span>
        </p>
        <p class="info-card-title">问题描述</p>
        <div class="info-card-content" v-html="serviceDetail.apply_reason"></div>
      </div>
      <div class="service-result">
        <p class="info-card-title">售后处理结果</p>
        <div class="info-card-content">
          <div class="type">
            <i-radio-group size="large" v-model="serviceDetail.handle_status">
              <i-radio label="200" disabled>退款</i-radio>
              <i-radio label="300" disabled>换货</i-radio>
              <i-radio label="400" disabled>取消售后</i-radio>
            </i-radio-group>
          </div>
          <div class="result" v-if="serviceDetail.handle_status === '200'">
            <label>退款金额：</label>
            <span class="money">&yen;{{ serviceDetail.refund }}</span>
          </div>
        </div>
        <p class="info-card-title">售后处理理由</p>
        <div class="info-card-content" v-html="serviceDetail.handle_reason"></div>
      </div>
    </div>
  </div>
</template>

<script>
import { RadioGroup, Radio, Input } from 'iview'
import api from 'modules/member/api/index.js'

export default {
  name: 'HandledService',
  data () {
    return {
      serviceId: this.$route.params.serviceId,
      serviceDetail: {}
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.serviceDetail = await api.orderServiceSellerDetail(this.serviceId)
    }
  },
  components: {
    'i-radio': Radio,
    'i-input': Input,
    'i-radio-group': RadioGroup
  }
}
</script>

<style lang="stylus">
.handled-service
  .handled-service-page
    margin: 20px 0 30px
    padding: 0 30px
    border: 1px solid $grey-high4
    &>div
      padding: 30px 0
      border-bottom: 1px dashed $grey-high4
      .info-card-title
        height: 22px
        font-size: 16px
        font-weight: 500
        color: $black
        line-height: 22px
        margin-bottom: 14px
      &.order-info-card
      &.application-detail
        font-size: 16px
        .info-card-content
          margin-bottom: 30px
          &:last-child
            margin-bottom: 0
        p
          margin-bottom: 16px
          &:last-child
            margin-bottom: 0
          label
            width: 80px
            height: 22px
            line-height: 22px
            overflow: hidden
            margin-right: 5px
            color: $grey-high
            display: inline-block
            text-align: justify
            vertical-align: top
            &:after
              content: ''
              display: inline-block
              padding-left: 100%
        .red
          color: $red
      &.service-result
        font-size: 16px
        color: $black1
        border-bottom: none
        .info-card-content
          width: 940px
          display: flex
          margin-bottom: 30px
          .type
            width: 300px
            font-size: 16px
            margin-top: -3px
            .ivu-radio-wrapper
              color: $black
              font-size: 16px
          .money
            color: $orange
</style>
