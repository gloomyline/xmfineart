<template lang="html">
  <div class="unhandled-service">
    <div class="unhandled-service-page">
      <div class="order-info-card">
        <p class="info-card-title">商品信息</p>
        <div class="info-card-content">
          <p>
            <label>订单号：</label>
            <span>{{ serviceDetail.mall_order_code }}</span>
          </p>
          <p>
            <label>商品名称：</label>
            <span>{{ serviceDetail.name }}</span>
          </p>
          <p>
            <label>实付金额：</label>
            <span class="yellow">&yen;{{ serviceDetail.pay_total }}</span>
          </p>
        </div>
      </div>
      <div class="application-detail">
        <p class="info-card-title">买家信息</p>
        <div class="info-card-content">
          <p>
            <label>手机号码：</label>
            <span>{{ serviceDetail.buyer_mobile }}</span>
          </p>
          <p>
            <label>昵称：</label>
            <span>{{ serviceDetail.buyer_nickname }}</span>
          </p>
        </div>
        <p class="info-card-title">售后申请类型</p>
        <p class="info-card-content" >
          <span class="red" v-if="handle.apply_operate === '100'">退款</span>
          <span class="red" v-if="handle.apply_operate === '200'">换货</span>
        </p>
        <p class="info-card-title">问题描述</p>
        <div class="info-card-content" v-html="serviceDetail.apply_reason"></div>
      </div>
      <div class="service-result">
        <p class="info-card-title">售后处理结果</p>
        <div class="info-card-content handle-type">
          <div class="type">
            <i-radio-group size="large" v-model="handle.handle_status">
              <i-radio label="200">退款</i-radio>
              <i-radio label="300">换货</i-radio>
              <i-radio label="400">取消售后</i-radio>
            </i-radio-group>
          </div>
          <div class="result" v-show="handle.handle_status === '200'">
            <label>退款金额：</label>
            <span class="money">&yen;
              <i-input style="width: 120px" v-model="handle.refund"></i-input>
            </span>
          </div>
        </div>
        <p class="info-card-title">售后处理理由</p>
        <div class="info-card-content">
          <i-input type="textarea" :rows="5" placeholder="请输入~" v-model="handle.handle_reason"></i-input>
        </div>
      </div>
      <div class="handle-box">
        <i-button class="handle-btn" type="primary" @click="doSubmit()">提交</i-button>
      </div>
    </div>
  </div>
</template>

<script>
import { RadioGroup, Radio, Input } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'

export default {
  name: 'UnHandleService',
  data () {
    return {
      serviceId: this.$route.params.serviceId,
      serviceDetail: {},
      handle: {
        id: this.$route.params.serviceId,
        handle_status: '',
        handle_reason: '',
        refund: ''
      }
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.serviceDetail = await api.orderServiceSellerDetail(this.serviceId)
    },
    async doSubmit () {
      let response = await api.orderServiceSellerHandle(this.handle)
      if (response.code === 200) {
        this.$router.push({path: `/store-manage/handled-service/${this.serviceId}`})
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_OPERATION_FAILED'], type: 'error' })
      }
    }
  },
  components: {
    'i-radio': Radio,
    'i-input': Input,
    'i-radio-group': RadioGroup
  }
}
</script>

<style lang="stylus">
.unhandled-service
  .unhandled-service-page
    margin: 20px 0 30px
    padding: 0 30px 30px 30px
    border: 1px solid $grey-high4
    &>div
      padding: 30px 0
      border-bottom: 1px dashed $grey-high4
      .info-card-title
        height: 22px
        font-size: 16px
        font-weight: 500
        color: $black
        line-height: 22px
        margin-bottom: 14px
      &.order-info-card
      &.application-detail
        font-size: 16px
        .info-card-content
          margin-bottom: 30px
          &:last-child
            margin-bottom: 0
        p
          margin-bottom: 16px
          &:last-child
            margin-bottom: 0
          label
            width: 80px
            height: 22px
            line-height: 22px
            overflow: hidden
            margin-right: 5px
            color: $grey-high
            display: inline-block
            text-align: justify
            vertical-align: top
            &:after
              content: ''
              display: inline-block
              padding-left: 100%
        .red
          color: $red
      &.service-result
        font-size: 16px
        color: $black1
        border-bottom: none
        .info-card-content
          width: 940px
          display: flex
          justify-content: space-between
          align-items: center
          margin-bottom: 30px
          &.handle-type
            height: 40px
          &:last-child
            margin-bottom: 0
          .type
            font-size: 16px
            margin-top: -3px
            .ivu-radio-wrapper
              color: $black
              font-size: 16px
              margin-right: 56px
          .money
            color: $orange
            .ivu-input
              font-size: 20px
              color: $orange
      &.handle-box
        text-align: center
        border-bottom: none
        .handle-btn
          width: 170px
          height: 40px
          font-size: 16px
</style>
