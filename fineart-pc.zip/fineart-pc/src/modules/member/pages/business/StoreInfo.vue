<template lang="html">
  <div class="store-info">
    <i-form class="store-form"
            ref="storeInfo"
            :model="storeInfo"
            :rules="editRule">
      <i-form-item label="店铺名称" prop="name">
        <div class="store-info-name">
          <span>{{ storeInfo.name }}</span>
          <i-button size="small" type="primary" ghost @click="goStoreDetail()" v-if="storeInfo.id">访问店铺</i-button>
        </div>
      </i-form-item>
      <i-form-item label="主营商品" prop="subtitle">
        <i-input placeholder="请输入主营商品，如“卫浴五金、管道”" v-model="storeInfo.subtitle"></i-input>
      </i-form-item>
      <i-form-item label="店铺介绍" prop="introduction">
        <i-input type="text" placeholder="介绍您的店铺" v-model="storeInfo.introduction"></i-input>
      </i-form-item>
      <i-form-item label="店铺分类" prop="mall_store_category_id">
        <i-select placeholder="请选择分类" v-model="storeInfo.mall_store_category_id">
          <i-option v-for="(item, index) in StoreCategoryList" :key="index" :value="item.value">{{ item.label }}</i-option>
        </i-select>
        <p class="input-tips">选择合适的分类，让顾客更便捷找到您</p>
      </i-form-item>
      <i-form-item class="store-picture-cover" label="店铺封面" prop="thumbnail">
        <div class="uploaded-img" v-if="storeInfo.thumbnail_cdn">
          <img :src="storeInfo.thumbnail_cdn">
          <div class="img-edit-cover">
            <span class="fy-icon-delete-round" @click="goDelThumb()"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
          </div>
        </div>
        <i-upload ref="upload"
                  v-if="storeInfo.thumbnail === ''"
                  :show-upload-list="false"
                  :max-size="ossThumbnail.max_size"
                  type="drag"
                  :data="ossThumbnail.data"
                  :action="ossThumbnail.host"
                  :format="ossThumbnail.format"
                  :accept="ossThumbnail.accept"
                  :before-upload="beforeUploadThumb"
                  :on-success="successThumb"
                  :on-exceeded-size="exceededSize"
                  :on-format-error="formatError">
          <div class="upload-box">
            <!--<img src="" alt="">-->
            <span class="fy-icon-upload"></span>
            <em>点击上传</em>
          </div>
        </i-upload>
        <p class="upload-tip">图片尺寸：最小300*300px<br/>格式为.jpg / .jpeg / .png ，大小不超过5MB；</p>
      </i-form-item>
      <i-form-item class="store-picture-main" label="店铺主图" prop="store_images">
        <div class="picture-wrap">
          <div class="uploaded-img" v-for="(item, index) in storeInfo.store_images_cdn" :key="index">
            <img :src="item">
            <div class="img-edit-cover">
              <span class="fy-icon-delete-round" @click="goDelImage(index)"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
            </div>
          </div>
          <i-upload ref="upload"
                    class="store-img-upload"
                    v-if="storeInfo.store_images.length < 6"
                    :show-upload-list="false"
                    :max-size="ossImage.max_size"
                    type="drag"
                    :data="ossImage.data"
                    :action="ossImage.host"
                    :format="ossImage.format"
                    :accept="ossImage.accept"
                    :on-exceeded-size="exceededSize"
                    :on-format-error="formatError"
                    :before-upload="beforeUploadImage"
                    :on-success="successImage">
            <div class="cover-upload-text">
              <span class="fy-icon-add-thin-gray"></span>
              <p>点击上传</p>
            </div>
          </i-upload>
        </div>
        <p class="tips-text">图片尺寸：最小750*420px，格式为.jpg / .jpeg / .png ，大小不超过5MB；</p>
      </i-form-item>
      <i-form-item label="店长姓名" prop="manager">
        <i-input placeholder="请输入店长姓名" v-model="storeInfo.manager"></i-input>
      </i-form-item>
      <i-form-item label="联系电话" prop="mobile">
        <i-input placeholder="请输入手机号码" v-model.trim.number="storeInfo.mobile"></i-input>
        <p class="input-tips">提供真实的店长信息，如有需要，顾客可直接与店长沟通。</p>
      </i-form-item>
      <i-form-item class="home-add-item" label="地区" >
        <i-input v-model.trim.number="storeInfo.area" @on-focus="mapAddress=true" readonly placeholder="请选择地区"></i-input>
      </i-form-item>
      <i-form-item class="address-detail" label="详细地址" prop="address">
        <i-input v-model="storeInfo.address" @on-focus="mapAddress=true" placeholder="请输入详细地址"></i-input>
        <p>准确定位您商店的位置，顾客可以更好的进店体验{{ storeInfo.address }}</p>
      </i-form-item>
      <!-- 编辑地区 -->
      <fa-map v-model="mapAddress"
              :lng="storeInfo.lng"
              :lat="storeInfo.lat"
              :address="storeInfo.address"
              :sysAreaId="storeInfo.sys_area_id"
              @save-edit="editArea"></fa-map>
      <i-form-item>
        <i-button class="commit-btn" type="primary" @click="handleSubmit('storeInfo')">提交</i-button>
      </i-form-item>
    </i-form>
  </div>
</template>

<script>
import { FaMap, FineartCascader } from 'components'
import { getStoreCategory } from '@/common/js/loadScript.js'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'
import {
  Form,
  Input,
  Select,
  Option,
  Upload,
  Button,
  FormItem,
  Dropdown,
  DropdownMenu
} from 'iview'

export default {
  name: 'CreateStore',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{9}\d$/.test(value))) {
        cb(new Error('手机号码格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      mapAddress: false, // 控制弹窗显示数组
      storeId: this.$store.state.member.storeInfo.id,
      storeInfo: {
        store_images: [],
        store_images_cdn: []
      },
      StoreCategoryList: [],
      StoreCategoryVal: [],
      areaInfo: [],
      keywords: '',
      visible: false,
      editRule: {
        introduction: [
          { required: true, message: '请输入店铺介绍' }
        ],
        subtitle: [
          { required: true, message: '请输入主营商品' },
          { type: 'string', max: 20, message: '主营商品超过20个字' }
        ],
        mall_store_category_id: [
          { required: true, message: '请选择分类' }
        ],
        thumbnail: [
          { required: true, message: '请上传店铺封面图', trigger: 'blur' },
          { type: 'string', message: '请上传店铺封面图' }
        ],
        store_images: [
          { required: true, type: 'array', min: 1, message: '请上传店铺主图', trigger: 'blur' },
          { type: 'array', min: 1, max: 6, message: '请上传1~6张店铺主图' }
        ],
        manager: [
          { required: true, message: '请输入店长姓名' },
          { type: 'string', min: 2, max: 10, message: '店长姓名只能由2~10个汉字组成' }
        ],
        mobile: [
          { required: true, message: '请输入手机号' },
          mobileValidator
        ],
        address: [
          { required: true, message: '请输入详细地址' }
        ]
      },
      ossThumbnail: {
        format: ['jpg', 'jpeg', 'png'],
        max_size: 0,
        host: '',
        data: {},
        accept: 'jpg,jpeg,png',
        length: 0
      },
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      }
    }
  },
  created () {
    this.initStoreDetail()
    this.initStoreCategory()
  },
  methods: {
    async initStoreDetail () {
      this.storeInfo = await api.fetchStoreDetail(this.storeId)
      this.storeInfo.area = ''
      if (this.storeInfo) {
        let area = []
        for (let index in this.storeInfo.area_line) {
          if (index !== '1') {
            area.push(this.storeInfo.area_line[index])
          }
        }
        this.storeInfo.area = area.join(' / ')
      }
    },
    async editArea (mapAddress) {
      this.storeInfo.lng = mapAddress.point.lng
      this.storeInfo.lat = mapAddress.point.lat
      this.storeInfo.sys_area_id = mapAddress.sysAreaId
      this.storeInfo.area = mapAddress.addressData.province + ' / ' + mapAddress.addressData.city + ' / ' + mapAddress.addressData.district
      this.storeInfo.address = mapAddress.addressData.address
    },
    async initStoreCategory () {
      this.StoreCategoryList = await getStoreCategory()
    },
    changeCategory (param) {
      this.storeInfo.resource_category_id = param
    },
    handleSubmit (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.result = await api.editStoreInfo(this.storeInfo)
          if (this.result.code === 200) {
            this.$store.commit('member/MEMBER_STORE_MANAGE_STORE_INFO', this.storeInfo)
            this.$store.commit('ADD_MESSAGE', {msg: MSG['STORE_MANAGE_STORE_EDIT_SUCCESS'], type: 'success'})

            let currentStore = this.$localStorage.get('MEMBER_CUR_STORE')
            currentStore.name = this.storeInfo.name
            currentStore.thumbnail = this.storeInfo.thumbnail_cdn
            this.$localStorage.set('MEMBER_CUR_STORE', currentStore)
          }
        }
      })
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await api.ossParamsCreate(file, 'store_thumbnail', this.ossThumbnail)
    },
    successThumb (res) {
      if (res.code === 200) {
        this.storeInfo.thumbnail = res.results.file_url
        this.storeInfo.thumbnail_cdn = res.results.file_url_cdn
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    goDelThumb () {
      this.storeInfo.thumbnail = ''
      this.storeInfo.thumbnail_cdn = ''
    },
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'store_image', this.ossImage)
    },
    successImage (res) {
      if (res.code === 200) {
        this.storeInfo.store_images_cdn.push(res.results.file_url_cdn)
        this.storeInfo.store_images.push(res.results.file_url)
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    goDelImage (key) {
      this.$delete(this.storeInfo.store_images_cdn, key)
      this.$delete(this.storeInfo.store_images, key)
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    },
    goStoreDetail () {
      window.location = `mall.html#/store-detail/${this.storeInfo.id}`
    }
  },
  components: {
    FaMap,
    FineartCascader,
    'i-button': Button,
    'i-form': Form,
    'i-form-item': FormItem,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-upload': Upload,
    'i-dropdown': Dropdown,
    'i-dropdown-menu': DropdownMenu
  }
}
</script>

<style lang="stylus">
.store-info
  position: relative
  padding-left: 10px
  p
    &.title
      font-size: 18px
      margin-bottom: 20px
    &.describe
      font-size: 14px
      color: $black1
      margin-bottom: 10px
    &.tip-wrong
      margin: 30px 0 0 0
      label
        width: 64px
        margin-right: 20px
        color: $orange
        font-size: 16px
      span
        color: $orange
        font-size: 16px
  .store-form
    padding: 20px 0 20px 0
    .store-info-name
      display: flex
      &>span
        margin-right: 30px
        color: $black1
        line-height: 40px
        font-size: 16px
      .ivu-btn
        width: 80px
        height: 36px
    .store-picture-cover
      display: flex
      align-items: center
      .ivu-form-item-content
        display: flex
        align-items: center
        .uploaded-img
          margin: 0
    .store-picture-main
      display: flex
      align-items: center
      .ivu-form-item-content
        display: flex
        flex-direction: column
        align-items: start
        .picture-wrap
          max-width: 680px
          display: flex
          flex-wrap: wrap
          .uploaded-img
            width: 200px
            height: 112px
            margin: 0 20px 20px 0
            position: relative
          .store-img-upload
            .ivu-upload-drag
              width: 200px
              height: 112px
              margin-bottom: 20px
              border: 1px solid $grey-high4
            .cover-upload-text
              width: 200px
              height: 112px
              p
                color: #bbb
                font-size: 14px
              .fy-icon-add-thin-gray
                display: inline-block
                font-size: 32px
                margin: 25px 0 0 0
        .main-picture-tip
          margin: 0
    .input-tips
      color: $grey-high
      font-size: 14px
    .ivu-form-item
      display: flex
      margin-bottom: 30px
      &.resource-category
        .fineart-cascade
          margin-bottom: 0
        .ivu-form-item-error-tip
          left: 84px
      .ivu-form-item-label
        width: 64px
        height: 40px
        padding: 0
        margin-right: 20px
        font-size: 16px
        color: $black
        overflow: hidden
        line-height: 40px
        text-align: justify
        /*实现文字两端对齐*/
        &:after
          content: ''
          display: inline-block
          padding-left: 100%
      .ivu-form-item-content
        font-size: 14px
        color: $grey-high
        margin-left: 0!important
        p
          margin-top: 10px
          max-width: 640px
          color: $grey-high
          line-height: 32px
        .ivu-input, .ivu-select, .ivu-select-placeholder, .ivu-select-selected-value
          width: 640px
        .commit-btn
          width: 120px
          height: 40px
          font-size: 16px
          margin-left: 84px
      &.map-position-add, &.address-detail
        align-items: baseline
        .ivu-form-item-content
          display: flex
          align-items: normal
          flex-direction: column
          .ivu-input-prefix i
            color: $grey-high1
    .map-plugin
      width: 888px
      height: 354px
      margin: 0 0 30px 84px
    .address-list
      width: 620px
      padding: 5px 20px
      cursor: pointer
    /*验证时文字位置*/
    .ivu-form-item-error-tip
      left: 0
</style>
