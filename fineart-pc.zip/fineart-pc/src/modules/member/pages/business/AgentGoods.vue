<template>
  <div class="agent-goods">
    <div class="filter-keyword">
      <i-select v-model="indexRoute" class="route-select">
        <i-option value="/store-manage/agent-goods">代理商品</i-option>
        <i-option value="/store-manage/agent-sales-record">代理销售记录</i-option>
        <i-option value="/store-manage/agent-settlement-record">结算记录</i-option>
      </i-select>
      <i-input v-model="pageConfig.keyword"
               placeholder="输入商品/店铺名称">
        <i-button slot="append" class="search-btn" type="primary"><span class="fy-icon-search" @click="goSearch()"></span>搜一下</i-button>
      </i-input>
    </div>
    <div class="table-head">
      <div class="good-info">商品信息</div>
      <div class="unit-price">单价</div>
      <div class="supply-price">供货价</div>
      <div class="tag">标签</div>
      <div class="handle-goods">操作</div>
    </div>
    <div class="agent-goods-page">
      <div v-if="goodsList.total">
        <div class="goods-item" v-for="(item, index) in goodsList.data" :key="index">
          <div class="goods-img">
            <img :src="item.thumbnail_cdn"/>
          </div>
          <div class="goods-store-name">
            <a class="goods-name" :href="`/mall.html#/goods-detail/${item.id}/${item.store_id}`">{{ item.name }}</a>
            <a class="store-name" :href="`/mall.html#/store-detail/${item.store_id_source}`">{{ item.store_name_source }}>></a>
          </div>
          <div class="unit-price">&yen;{{ item.price_norm }}</div>
          <div class="supply-price">&yen;{{ item.price_agent }}</div>
          <div class="tag">
              <span v-for="(val, index) in item.tags" :key="index">{{ val }}</span>
          </div>
          <div class="handle-goods">
            <i-button class="promote" @click="showQrCode(item.id, item.store_id, item.name)">二维码</i-button>
            <i-button class="edit-tag" @click="tagEditOpen(item.id, item.tags)">编辑标签</i-button>
          </div>
        </div>
        <div class="pagination-cell">
          <pagination class="agent-goods-pagination"
                      @page-confirm="changePage"
                      :page="goodsList.current_page"
                      :total="goodsList.total"
                      :page-size="goodsList.per_page"></pagination>
        </div>
      </div>
      <div v-else class="nothing-container">
        <list-nothing class="list-nothing" ></list-nothing>
      </div>
    </div>
    <!--二维码 弹窗-->
    <i-modal title="商品二维码"
             class="goods-qr-modal"
             v-model="isShowedQr"
             width="440"
             footer-hide>
      <p class="goods-name">{{ qrcode.name }}</p>
      <img class="goods-qr" :src="qrcode.src" alt="">
      <i-button type="text" class="down-qr">下载二维码</i-button>
    </i-modal>
    <!-- 商品分组标签设置-->
      <goods-set-group v-model="isTagEdit"
                       :goodsId="tags.goods_id"
                       :goodsTagsAll="tags.goods_tags_all"></goods-set-group>
  </div>
</template>

<script>
import { Select, Option, Input, Modal } from 'iview'
import { Pagination, ListNothing, GoodsSetGroup } from 'components'
import api from 'modules/member/api/index.js'
import { MOB_ADDRESS } from '@/assets/data/constants'

export default {
  name: 'AgentGoods',
  data () {
    return {
      isShowedQr: false,
      isTagEdit: false,
      indexRoute: '/store-manage/agent-goods',
      goodsList: {},
      pageConfig: {
        page: 1, // 页码
        keyword: '', // 搜索关键字，商品名称或者订单编号
        status: ''// 订单状态
      },
      qrcode: {
        name: '',
        src: ''
      },
      tags: {}
    }
  },
  created () {
    this.initPage()
  },
  watch: {
    indexRoute (newVal) {
      this.$router.push(newVal)
    },
    isTagEdit (val) {
      if (!val) {
        this.initPage()
      }
    }
  },
  methods: {
    async initPage () {
      this.goodsList = await api.goodsAgentList(this.pageConfig)
    },
    async changePage (data) {
      this.pageConfig.page = data.page
      this.goodsList = await api.goodsAgentList(this.pageConfig)
    },
    async goSearch () {
      this.pageConfig.page = 1
      this.goodsList = await api.goodsAgentList(this.pageConfig)
    },
    async showQrCode (goods_id, store_id, name) {
      this.qrcode.name = name
      let url = `${MOB_ADDRESS}/mall.html#/goods-detail/${goods_id}/${store_id}`
      let results = await api.qrcodeCreate(url)
      this.qrcode.src = results.qrcode
      this.isShowedQr = true
    },
    async tagEditOpen (goods_id, tags) {
      this.tags.goods_id = goods_id
      this.tags.goods_tags_all = tags instanceof Array && tags.length === 0 ? {} : tags
      this.isTagEdit = true
    }
  },
  components: {
    Pagination,
    ListNothing,
    GoodsSetGroup,
    'i-select': Select,
    'i-option': Option,
    'i-input': Input,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.agent-goods
  .filter-keyword
    height: 40px
    margin-bottom: 20px
    position: relative
    .route-select
      width: 228px
      .ivu-select-selected-value
        font-size: 16px
    .ivu-input-wrapper
      width: 366px
      absolute: right
      .ivu-input
        font-size: 14px
        border-color: $orange
      .search-btn
        width: 112px
        font-size: 14px
        color: $white
        padding: 0
        border: none
        border-radius: 0 4px 4px 0
        background-color: $orange
        &>span
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 40px
        .fy-icon-search
          margin-right: 5px
          font-size: 20px
  .table-head
    height: 48px
    line-height: 48px
    padding: 0 50px
    font-size: 16px
    color: $black1
    display: flex
    align-items: center
    flex-direction: row
    border-bottom: 3px solid $grey
    &>div
      display: inline-block
    .good-info
      width: 370px
    .unit-price
      width: 90px
      text-align: center
      margin-right: 40px
    .supply-price
      width: 90px
      text-align: center
      margin-right: 40px
    .tag
      width: 160px
      text-align: center
      margin-right: 40px
    .handle-goods
      width: 80px
      text-align: center
  .agent-goods-page
    padding: 0 30px 30px 30px
    margin-top: 20px
    margin-bottom: 58px
    border: 1px solid $grey-high4
    .goods-item
      height: 170px
      padding: 20px 0
      font-size: 14px
      display: flex
      align-items: center
      border-bottom: 1px solid $grey-high4
      &>div
        margin-right: 40px
        &:last-child
          margin-right: 0
        &.goods-img
          width: 100px
          height: 100px
          overflow: hidden
          img
            width: 100px
            height: 100px
        &.goods-store-name
          width: 210px
          font-size: 16px
          .goods-name
            width: 210px
            color: $black
            max-height: 50px
            overflow: hidden
            -webkit-line-clamp: 2
            display: -webkit-box
            -webkit-box-orient: vertical
          .store-name
            height: 20px
            color: $black1
            font-size: 14px
        &.unit-price
          width: 90px
          font-size: 18px
          color: $orange
          text-align: center
        &.supply-price
          width: 90px
          font-size: 18px
          color: $black1
          text-align center
        &.tag
          width: 168px
          font-size: 14px
          color: $black1
          text-align: center
          {ellipse}
          span
            margin-right: 5px
        &.handle-goods
          width: 80px
          text-align: center
          .ivu-btn
            height: 24px
            width: 72px
            display: block
            color: $orange
            font-size: 14px
            cursor: pointer
            border-radius: 4px
            padding: 0
            margin-bottom: 13px
            border: 1px solid $orange
            &.edit-tag
              color: $grey-high
              border: 1px solid $grey-high
    .pagination-cell
      height: 68px
      position: relative
      .agent-goods-pagination
        width: auto
        absolute: right
        margin-bottom: 0
    .nothing-container
      min-height: 670px
      position: relative
      .list-nothing
        margin-top: -80px //补偿原本组件的padding-top： 80
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
/* 二维码 弹窗 */
.goods-qr-modal
  .goods-name
    width: 248px
    margin: 0 auto 12px auto
    color: $black1
    font-size: 18px
    text-align: center
  .goods-qr
    display: block
    width: 242px
    height: 242px
    margin: 0 auto 20px auto
  .down-qr
    display: block
    margin: 0 auto
    color: $orange
    font-size: 18px
</style>
