<template>
  <div class="store-manage">
    <div class="store-name">
      <img :src="storeDetail.thumbnail" alt="">
      <span>{{ storeDetail.name }}</span>
    </div>
    <i-menu mode="horizontal" :active-name="parseInt(activeName)">
      <i-menu-item v-for="(item, index) in routeList"
                   v-show = "!item.isHide"
                   :key="index"
                   :to="item.route"
                   :name="item.listOrder">{{ item.name }}<span class="divider"></span></i-menu-item>
    </i-menu>
    <router-view class="member-content"></router-view>
  </div>
</template>

<script>
import { Menu, MenuItem } from 'iview'
import * as MSG from 'assets/data/message.js'
import { mapState } from 'vuex'

export default {
  name: 'BusinessManage',
  data () {
    return {
      activeName: this.$route.meta.listOrder,
      storeDetail: {},
      routeList: [
        {
          listOrder: 1,
          name: '已卖出的',
          route: '/store-manage/has-sold/'
        },
        {
          listOrder: 2,
          name: '我的商品',
          route: '/store-manage/my-goods'
        },
        {
          listOrder: 3,
          name: '店铺信息',
          route: '/store-manage/store-info'
        },
        {
          listOrder: 4,
          name: '评价管理',
          route: '/store-manage/comment'
        },
        {
          listOrder: 5,
          name: '售后管理',
          route: '/store-manage/after-sales'
        },
        {
          listOrder: 6,
          name: '代理管理',
          route: '/store-manage/agent-goods',
          isHide: true
        }
      ]
    }
  },
  created () {
    this.initStoreDetail()
  },
  computed: {
    ...mapState('member', ['storeInfo'])
  },
  watch: {
    '$route' (newVal) {
      this.activeName = newVal.meta.listOrder
    },
    storeInfo: {
      handler (newVal) {
        if (Object.keys(newVal).length !== 0 && newVal.is_open_agent === '200') {
          this.routeList[5].isHide = false
        }
      },
      deep: true
    }
  },
  methods: {
    async initStoreDetail () {
      const store = this.$localStorage.get('MEMBER_CUR_STORE')
      if (store && store.id) {
        this.storeDetail = store
        this.$store.commit('member/MEMBER_STORE_MANAGE_STORE_INFO', this.storeDetail)
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['STORE_MANAGE_STORE_ID_NULL'], type: 'error' })
        this.$router.push({path: '/business/choose-store'})
      }
    }
  },
  components: {
    'i-menu': Menu,
    'i-menu-item': MenuItem
  }
}
</script>

<style lang="stylus">
.store-manage
  .store-name
    display: flex
    margin-bottom: 14px
    padding-top: 10px
    img
      width: 26px
      height: 26px
      margin-right: 10px
    span
      font-size: 16px
  .ivu-menu-horizontal
    height: 50px
    line-height: 50px
    .ivu-menu-item-active
      border-bottom: 3px solid $orange
    &.ivu-menu-light:after
      height: 3px
      background: $grey
    .ivu-menu-item
      font-size: 16px
      .divider
        absolute: left
      &:hover
        border-bottom: 3px solid $orange
      &:first-child
        .divider
          display: none
    .divider
      position: absolute
      top: 50%
      right: 0
      width: 2px
      height: 20px
      background-color: $grey
      transform: translateY(-50%)
  .member-content
    margin-top: 20px
    width: 1000px
    min-height: 675px
</style>
