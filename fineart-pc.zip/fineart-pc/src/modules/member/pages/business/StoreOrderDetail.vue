<template lang="html">
  <div class="store-order-detail">
    <div class="page-head">
      <span class="order-number">订单号：{{ orderDetail.code }}</span>
      <span class="order-data">下单时间：{{ orderDetail.order_at }}</span>
      <span class="order-status">
        <span class="red">{{ orderDetail.status_desc }}</span>
      </span>
    </div>
    <div class="order-info-card">
      <div class="info-card-title">
        <span class="receiver">买家信息</span>
        <span class="money">金额信息</span>
      </div>
      <div class="info-card-content buy-box">
        <div class="receiver">
          <p>
            <label>昵称：</label>
            <span>{{ orderDetail.buyer_nickname }}</span>
          </p>
          <p>
            <label>手机号码：</label>
            <span>{{ orderDetail.buyer_mobile }}</span>
          </p>
        </div>
        <div class="money">
          <p>
            <label>订单金额：</label>
            <span>&yen;{{ orderDetail.total }}</span>
          </p>
          <p>
            <label>运费：</label>
            <span>&yen;{{ orderDetail.freight }}</span>
          </p>
          <p>
            <label>实付金额：</label>
            <span class="yellow">&yen;{{ orderDetail.pay_total }}</span>
            <i-button type="text" class="edit-btn"
                      custom-icon="fy-icon-edit"
                      v-if="orderDetail.status === '100' && orderDetail.adjust === '0.00'"
                      @click="changeMoney(orderDetail.id, orderDetail.pay_toatl)"></i-button>
          </p>
        </div>
      </div>
    </div>
    <div class="order-info-card goods-card">
      <div class="info-card-title">
        <span class="goods-info">商品信息</span>
        <span class="price">单价</span>
        <span class="number">数量</span>
        <span class="status">状态</span>
        <span class="handle">操作</span>
      </div>
      <div class="goods-detail">
        <div class="goods-img">
          <img :src="orderDetail.goods_thumbnail"/>
        </div>
        <div class="goods-name">{{ orderDetail.goods_name }}</div>
        <div class="after-sales">
          <router-link :to="`/store-manage/unhandled-service/${orderDetail.service_id}`" class="red" v-if="orderDetail.service_handle_status === '100'">售后处理中</router-link>
          <router-link :to="`/store-manage/handled-service/${orderDetail.service_id}`" class="yellow" v-else-if="orderDetail.service_handle_status === '200'">退款</router-link>
          <router-link :to="`/store-manage/handled-service/${orderDetail.service_id}`" class="yellow" v-else-if="orderDetail.service_handle_status === '300'">换货</router-link>
          <router-link :to="`/store-manage/handled-service/${orderDetail.service_id}`" class="grey-height" v-else-if="orderDetail.service_handle_status === '400'">取消售后</router-link>
        </div>
        <div class="unit-price">&yen;{{ orderDetail.price_real }}</div>
        <div class="number">X{{ orderDetail.number }}</div>
        <div class="status"><span class="red">{{ orderDetail.status_desc }}</span></div>
        <div class="handle-order">
          <i-button class="pay-order" v-if="orderDetail.status === '200'" @click="goDelivery()">去发货</i-button>
        </div>
      </div>
    </div>
    <div class="express">
      <div class="express-info-card">
        <div class="info-card-title">收货人信息</div>
        <div class="info-card-content">
          <p>&nbsp;&nbsp;&nbsp;收货人： {{ orderDetail.to_name }} </p>
          <p>收货地址： {{ orderDetail.to_address_desc }} </p>
          <p>手机号码： {{ orderDetail.to_mobile }} </p>
        </div>
      </div>
      <div class="express-info-card">
        <div class="info-card-title">物流信息</div>
        <div class="info-card-content" v-if="express.express_code">
          <p>物流公司： {{ express.name }}</p>
          <p>运单号码： {{ express.express_code }} </p>
        </div>
        <div class="info-card-content" v-else>暂无物流信息，请稍后查询</div>
      </div>
      <div class="express-detail-card" v-if="express.express_code">
        <div class="info-card-title">
          <span>物流状态</span>
          <i-button type="text" @click="showExpress = true">[获取最新动态]</i-button>
        </div>
        <div class="info-card-content" v-if="showExpress">
          <i-timeline>
            <i-timeline-item class="latest" v-for="(item, index) in express.list" :key="index">
              <span class="time">{{ item.time }}</span>
              <p class="content">{{ item.content }} </p>
            </i-timeline-item>
          </i-timeline>
        </div>
      </div>
    </div>
    <i-modal title="修改实付金额" v-model="isShowedAdjust" class="modify-money" @on-ok="doAdjust()">
      <div class="modify-input">
        <label class="label-text">实付金额:</label>
        <p>&yen;{{ orderDetail.pay_total }}</p>
      </div>
      <div class="modify-input">
        <label class="label-text">调整金额:</label>
        <i-input-number class="entry-money" :number="true" autofocus v-model="priceAdjust" ></i-input-number>
        <p>&yen;</p>
      </div>
      <p class="wrong-tip" v-if="tipsShow">
        <span class="fy-icon-notes"><span class="path1"></span><span class="path2"></span></span>
        <span>只能输入数字和减号</span>
      </p>
      <div class="finish-money"><span>调整后的金额:</span><em>&yen;{{ priceFinal }}</em></div>
      <p class="tips">注：输入的数值前带“-”号代表减去相应金额，订单实付金额以修改后为准，请确认。</p>
    </i-modal>

    <i-modal class="go-delivery" v-model="isShowedDelivery" width="595" @on-ok="doDelivery()" title="温馨提示">
      <p class="tips">请确认您已发货，如商品通过物流公司运送，请填写运单号。</p>
      <i-form>
        <i-form-item label="物流公司">
          <i-select v-model="express.express_company">
            <i-option v-for="(item, index) in expressCompanyList" :key="index" :value="index">{{ item }}</i-option>
          </i-select>
        </i-form-item>
        <i-form-item label="运号单">
          <i-input v-model="express.express_code"></i-input>
        </i-form-item>
        <i-form-item class="radio-box">
          <i-checkbox v-model="isNoExpress">无需物流</i-checkbox>
        </i-form-item>
      </i-form>
    </i-modal>
  </div>
</template>

<script>
import { Timeline, TimelineItem, Select, Option, Input, Modal, Form, FormItem, Checkbox, InputNumber } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'

export default {
  name: 'StoreOrderDetail',
  data () {
    return {
      orderId: this.$route.params.orderId,
      expressCompanyList: this.$store.state.member.expressCompany,
      orderDetail: {},
      isShowedAdjust: false,
      isShowedDelivery: false,
      tipsShow: false,
      priceAdjust: 0,
      express: {
        id: this.$route.params.orderId,
        express_company: '',
        express_code: '',
        name: '',
        list: ''
      },
      isNoExpress: false,
      showExpress: false
    }
  },
  created () {
    this.initPage()
  },
  computed: {
    priceFinal: function () {
      let result = parseFloat(this.orderDetail.pay_total) + parseInt(this.priceAdjust)
      return result.toFixed(2)
    }
  },
  watch: {
    showExpress (newVal) {
      if (newVal) {
        this.fetchExpressDetail()
      }
    }
  },
  methods: {
    async initPage () {
      this.orderDetail = await api.orderSellerDetail(this.orderId)
      if (this.orderDetail.express_code !== null) {
        this.express.express_code = this.orderDetail.express_code
        this.express.express_company = this.orderDetail.express_company
        this.express.name = this.$store.state.member.expressCompany[this.express.express_company]
      }
    },
    async fetchExpressDetail () {
      let res = await api.expressDetail(this.express.express_code, this.express.express_company)
      if (res.list.length) {
        this.express.list = res.list
      }
    },
    changeMoney () {
      this.isShowedAdjust = true
    },
    goDelivery () {
      this.isShowedDelivery = true
    },
    async doAdjust () {
      let response = await api.orderSellerPriceAdjust(this.orderId, this.priceAdjust)
      if (response.code === 200) {
        this.initPage()
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_OPERATION_FAILED'], type: 'error' })
      }
    },
    async doDelivery () {
      if (this.express.express_company === undefined) {
        this.express.express_company = ''
      }
      let response = await api.orderSellerSendOut(this.express)
      if (response.code === 200) {
        this.initPage()
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_OPERATION_FAILED'], type: 'error' })
      }
    }
  },
  components: {
    'i-input-number': InputNumber,
    'i-form': Form,
    'i-modal': Modal,
    'i-checkbox': Checkbox,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-form-item': FormItem,
    'i-timeline': Timeline,
    'i-timeline-item': TimelineItem
  }
}
</script>

<style lang="stylus">
.store-order-detail
  .page-head
    height: 48px
    line-height: 48px
    padding: 0 32px
    font-size: 14px
    color: $grey-high
    position: relative
    border-bottom: 1px solid $grey
    span
      display: inline-block
    .order-number
      width: 276px
      margin-right: 13px
    .order-data
      width: 242px
    .order-status
      width: 65px
      absolute: right
      .red
        color: $red
      .yellow
        color: $orange
  .order-info-card
    margin-top: 20px
    padding: 0 30px 30px 30px
    border: 1px solid $grey-high4
    .receiver
      width: 710px
      display: inline-block
      vertical-align: top
    .money
      display: inline-block
      line-height: 22px
      .edit-btn
        padding: 0 10px
        font-size: 14px
        vertical-align: middle
    .info-card-title
      padding: 20px 0
      color: $black
      font-size: 16px
      font-weight: 500
      border-bottom: 1px dashed $grey-high4
    .info-card-content
      p
        font-size: 16px
        margin-top: 16px
        label
          width: 80px
          height: 22px
          line-height: 22px
          overflow: hidden
          margin-right: 5px
          color: $grey-high
          display: inline-block
          text-align: justify
          vertical-align: top
          &:after
            content: ''
            display: inline-block
            padding-left: 100%
        span
          color: $black
          height: 22px
          line-height: 22px
          display: inline-block
          vertical-align: top
          &.yellow
            color: $orange
    &.goods-card
      padding-bottom: 0
      .info-card-title
        span
          display: inline-block
          width: 120px
          text-align: center
        .goods-info
          width: 430px
          text-align: left
      .goods-detail
        display: flex
        margin: 18px 0
        height: 100px
        font-size: 14px
        align-items: center
        flex-direction: row
        &>div
          width: 120px
          text-align: center
          &:last-child
            margin-right: 0
        .goods-img
          width: 100px
          height: 100px
          img
            width: 100px
            height: 100px
        .goods-name
          width: 230px
          margin-left: 20px
          font-size: 16px
          text-align: left
        .after-sales
          width: 90px
          text-align: center
          .red
            color: $red
          .yellow
            color: $orange
          .grey-height
            color: $grey-high
        .handle-order
          text-align: center
          .ivu-btn
            height: 26px
            display: block
            color: $orange
            font-size: 14px
            margin: 5px auto
            padding: 0 14px
            border: 1px solid $orange
            span
              display: inline-block
              height:26px
              line-height: 26px
          .cancel-order
            border: none
            color: $grey-high
          .evaluation
            color: $grey-high
            border: 1px solid $grey-high
  .express
    color: $black1
    font-size: 14px
    line-height: 20px
    padding: 20px 0 20px 30px
    .info-card-title
      height: 22px
      line-height: 22px
      font-size: 16px
      color: $black
      margin-bottom: 14px
      font-weight: 500
    .express-info-card
      .info-card-content
        margin-bottom: 30px
        p
          margin-bottom: 10px
    .express-detail-card
      margin-bottom: 28px
      .info-card-content
        padding: 20px
        background-color: #fefbf4
        .ivu-timeline-item-head
          width: 7px
          height: 7px
          top: 4px
          border-color: transparent
          background-color: $grey-light2
        .ivu-timeline-item-tail
          height: 100%
          border-left: 1px solid $grey-light2
          absolute: left 3px top 4px
        .latest
          .ivu-timeline-item-head
            background-color: $orange
        .ivu-timeline-item-content
          display:flex
          .time
            width: 150px
            height: 20px
            font-size: 14px
            font-weight: 500
            margin-right: 20px
            color: $black
            line-height: 20px
            display:inline-block
          .content
            width:720px
            font-size: 14px
            font-weight: 400
            color: $black1
            line-height: 20px
.modify-money
  .modify-input
    display: flex
    margin-bottom: 20px
    padding-left: 27px
    color: $black1
    font-size: 16px
    line-height: 40px
    .label-text
      width: 80px
      margin-left: 20px
    .entry-money
      width: 108px
      margin-right: 14px
  .wrong-tip
    padding-left: 170px
    color: $red
    font-size: 14px
    line-height: 22px
    .fy-icon-notes
      font-size: 18px
      vertical-align: middle
  .finish-money
    padding-left: 15px
    margin-bottom: 20px
    font-size: 16px
    span
      color: $black1
      margin-right: 14px
    em
      color: $red
  .tips
    padding-left: 15px
    color: $grey-high
    font-size: 14px
.go-delivery
  .tips
    color: $black1
    font-size: 14px
    margin-bottom: 30px
  .ivu-form-item
    display: flex
    .ivu-form-item-label
      float: none
      width: 68px
      height: 40px
      margin-right: 24px
      padding: 0
      line-height: 40px
      font-size: 16px
      color: $black1
      text-align: justify
      /*实现文字两端对齐*/
      &:after
        content: ''
        display: inline-block
        padding-left: 100%
    .ivu-form-item-content
      width: 443px
  .radio-box
    padding-left: 84px
    color: $black1
    font-size: 14px
</style>
