<template>
  <div class="release-goods">
    <i-form ref="goodsDetail" :model="goodsDetail" :rules="validateRules">
      <h3 class="title-text">{{ goodsId ? '编辑商品' : '发布商品' }}</h3>
      <span class="release-false-reason" v-if="goodsDetail.reason">审核失败：{{ goodsDetail.reason }}</span>
      <i-form-item prop="category_id" class="cascade-cate">
        <fineart-cascader :data="goodsCategory"
                          @change-category="changeCategory"
                          v-model="category"></fineart-cascader>
      </i-form-item>
      <i-form-item label="商品属性" prop="attribute">
        <i-radio-group v-model="goodsDetail.attribute">
          <i-radio label="100">产品型(有实物)</i-radio>
          <i-radio label="200">服务型(无实物)</i-radio>
        </i-radio-group>
      </i-form-item>
      <i-form-item label="商品标题" prop="name">
        <i-input class="input-box" type="text" placeholder="请输入商品标题" v-model="goodsDetail.name"></i-input>
      </i-form-item>
      <i-form-item label="副标题" prop="subtitle">
        <i-input class="input-box" type="text" placeholder="请输入副标题" v-model="goodsDetail.subtitle"></i-input>
      </i-form-item>
      <i-form-item label="单价" prop="price_norm">
        <i-input class="input-box-small" type="text" placeholder="请输入单价" v-model="goodsDetail.price_norm"></i-input>&yen;
      </i-form-item>
      <i-form-item class="orange-text" label="优惠单价" prop="price_discount" v-if="storeInfo.attribute === '400'">
        <i-input class="input-box-small" type="text" placeholder="请输入优惠单价" v-model="goodsDetail.price_discount"></i-input>&yen;
        <p class="tips-text">当顾客通过推广员的推广链接购买时，使用该价格作为单价来结算。</p>
      </i-form-item>
      <i-form-item label="库存" prop="stock">
        <i-input class="input-box-small" type="text" placeholder="请输入库存数量" v-model="goodsDetail.stock"></i-input>
        <p class="tips-text">买家下单后扣减库存数，库存为0时商品自动下架。</p>
      </i-form-item>
      <i-form-item class="goods-picture" label="封面图" prop="thumbnail">
        <div class="uploaded-img" v-if="goodsDetail.thumbnail_cdn">
          <img :src="goodsDetail.thumbnail_cdn">
          <div class="img-edit-cover">
            <span class="fy-icon-delete-round" @click="goDelThumb()"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
          </div>
        </div>
        <i-upload
          ref="upload"
          v-if="goodsDetail.thumbnail === ''"
          :show-upload-list="false"
          :max-size="ossThumbnail.max_size"
          type="drag"
          :data="ossThumbnail.data"
          :action="ossThumbnail.host"
          :format="ossThumbnail.format"
          :accept="ossThumbnail.accept"
          :before-upload="beforeUploadThumb"
          :on-success="successThumb"
          :on-exceeded-size="exceededSize"
          :on-format-error="formatError">
          <div class="upload-box">
            <span class="fy-icon-upload"></span>
            <em>点击上传</em>
          </div>
        </i-upload>
        <p class="upload-tip">图片尺寸：最小300*300px<br/>格式为.jpg / .jpeg / .png ，大小不超过10MB；</p>
      </i-form-item>
      <i-form-item class="upload-img-add" label="商品主图" prop="goods_images">
        <div class="uploaded-img" v-for="(src, key) in goodsDetail.goods_images_cdn" :key="key">
          <img :src="src">
          <div class="img-edit-cover">
            <span class="fy-icon-delete-round" @click="goDelImage(key)"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>
          </div>
        </div>
        <i-upload
          ref="upload"
          v-if="goodsDetail.goods_images.length < 3"
          :show-upload-list="false"
          :max-size="ossImage.max_size"
          type="drag"
          :data="ossImage.data"
          :action="ossImage.host"
          :format="ossImage.format"
          :accept="ossImage.accept"
          :before-upload="beforeUploadImage"
          :on-success="successImage"
          :on-exceeded-size="exceededSize"
          :on-format-error="formatError">
          <div class="cover-upload-text">
            <span class="fy-icon-add-thin-gray"></span>
            <p>点击上传</p>
          </div>
        </i-upload>
      </i-form-item>
      <p class="upload-img-tip">图片尺寸：最小750*420px，格式为.jpg / .jpeg / .png ，大小不超过5MB；</p>
      <i-form-item class="editor-item" label="商品详情" prop="introduction">
        <fineart-editor :catch-data="catchEditor"
                        :editor-content="goodsDetail.introduction"></fineart-editor>
        <p class="tips-text">商品详情图片如过长，请裁剪后分别上传；图片宽度=750像素，可视效果最佳；平台审核通过后，您的商品即自动上架。</p>
      </i-form-item>
      <i-form-item label="">
        <i-button size="large" class="submit-btn" type="primary" @click="goSubmit('goodsDetail')">提交</i-button>
      </i-form-item>
    </i-form>
  </div>
</template>

<script>
import { FineartCascader, FineartEditor } from 'components'
import { Form, FormItem, Radio, RadioGroup, Input, Upload, Modal } from 'iview'
import { getGoodsCategory, findValue } from '@/common/js/loadScript.js'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'
import { scrollTop } from '@/common/js/utils'

export default {
  name: 'ReleaseGoods',
  data () {
    const priceChecker = (rule, value, cb) => {
      if (isNaN(value) || parseFloat(value) <= 0) {
        cb(new Error('单价必须为大于0的数字'))
      } else {
        cb()
      }
    }
    const stockChecker = (rule, value, cb) => {
      let goodsId = this.$route.params.goodsId
      if (goodsId !== undefined) {
        if (isNaN(value) || parseFloat(value) < 0) {
          cb(new Error('库存必须为大于等于0的数字'))
        } else {
          cb()
        }
      } else if (isNaN(value) || parseFloat(value) <= 0) {
        cb(new Error('库存必须为大于0的数字'))
      } else {
        cb()
      }
    }
    return {
      isShowed: false,
      goodsCategory: [],
      category: [],
      content: '',
      goodsId: this.$route.params.goodsId,
      goodsDetail: {
        name: '',
        subtitle: '',
        category_id: '',
        price_norm: '',
        price_discount: '',
        stock: '',
        attribute: '',
        introduction: '',
        thumbnail: '',
        thumbnail_cdn: '',
        goods_images_cdn: [],
        goods_images: []
      },
      storeInfo: {},
      validateRules: {
        name: [
          { required: true, message: '请输入商品标题' },
          { type: 'string', max: 40, message: '商品标题超过40个字' }
        ],
        subtitle: [
          { required: true, message: '请输入副标题' },
          { type: 'string', max: 100, message: '副标题超过100个字' }
        ],
        category_id: [
          { required: true, message: '请选择分类' }
        ],
        price_norm: [
          { required: true, message: '请输入单价' },
          priceChecker
        ],
        price_discount: [
          { required: true, message: '请输入优惠单价' },
          priceChecker
        ],
        stock: [
          { required: true, message: '请输入库存' },
          stockChecker
        ],
        attribute: [
          { required: true, message: '请选择商品属性' }
        ],
        introduction: [
          { required: true, message: '请输入商品详情', trigger: 'blur' }
        ],
        thumbnail: [
          { required: true, message: '请上传封面图', trigger: 'blur' },
          { type: 'string', min: 2, message: '请上传店铺封面' }
        ],
        goods_images: [
          { required: true, type: 'array', min: 1, message: '请上传商品主图', trigger: 'blur' },
          { type: 'array', min: 1, max: 6, message: '请上传1~6张商品主图' }
        ]
      },
      ossThumbnail: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      apiProcessing: false // API请求处理中
    }
  },
  async created () {
    await this.initPage()
  },
  methods: {
    async initPage () {
      this.goodsCategory = await getGoodsCategory()
      this.storeInfo = this.$localStorage.get('MEMBER_CUR_STORE')
      if (this.goodsId !== undefined) {
        this.goodsDetail = await api.goodsDetailInfo(this.goodsId)
        this.category = findValue(this.goodsCategory, this.goodsDetail.category_id)
        this.$nextTick(() => {
          const sTop = document.documentElement.scrollTop || document.body.scrollTop
          scrollTop(window, sTop, 0, 0)
        })
      }
    },
    changeCategory (id) {
      this.goodsDetail.category_id = id
    },
    goDelThumb () {
      this.goodsDetail.thumbnail = ''
      this.goodsDetail.thumbnail_cdn = ''
    },
    goDelImage (key) {
      this.$delete(this.goodsDetail.goods_images_cdn, key)
      this.$delete(this.goodsDetail.goods_images, key)
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await api.ossParamsCreate(file, 'goods_thumbnail', this.ossThumbnail)
    },
    successThumb (res) {
      if (res.code === 200) {
        this.goodsDetail.thumbnail = res.results.file_url
        this.goodsDetail.thumbnail_cdn = res.results.file_url_cdn
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'goods_image', this.ossImage)
    },
    successImage (res) {
      if (res.code === 200) {
        this.goodsDetail.goods_images_cdn.push(res.results.file_url_cdn)
        this.goodsDetail.goods_images.push(res.results.file_url)
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    },
    // 获取富文本编辑的数据
    catchEditor (html) {
      this.goodsDetail.introduction = html
    },
    goSubmit (name) {
      if (this.apiProcessing) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.GLOBAL_PROCESSING, type: 'info' })
        return false
      }
      this.apiProcessing = true
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          let res
          if (this.goodsId === undefined) {
            res = await api.goodsAdd(this.goodsDetail)
          } else {
            this.goodsDetail.price_discount = this.goodsDetail.price_discount === null ? '' : this.goodsDetail.price_discount
            res = await api.goodsEdit(this.goodsId, this.goodsDetail)
          }

          if (res.code === 200) {
            this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_SAVE_SUCCESS'], type: 'success' })
            if (this.goodsDetail.status === '300') {
              this.$router.push({path: '/store-manage/my-goods'})
            } else if (this.goodsDetail.status === '400') {
              this.$router.push({path: '/store-manage/my-goods/400'})
            } else {
              this.$router.push({path: '/store-manage/my-goods/100'})
            }
          }
          this.apiProcessing = false
        }
      })
    }
  },
  components: {
    FineartEditor,
    FineartCascader,
    'i-form': Form,
    'i-input': Input,
    'i-radio': Radio,
    'i-modal': Modal,
    'i-upload': Upload,
    'i-form-item': FormItem,
    'i-radio-group': RadioGroup
  }
}
</script>

<style lang="stylus">
.release-goods
  padding: 0 0 30px 10px
  .release-false-reason
    font-size: 14px
    color: $pink
    padding: 0 14px
    margin-bottom: 22px
    line-height: 32px
    background: $pink2
    border-radius: 4px
    display: inline-block
    border: 1px solid $pink1
  .title-text
    margin-bottom: 40px
    font-size: 18px
  .ivu-form-item
    display: flex
    margin-bottom: 30px
    &.cascade-cate
      margin-bottom: 0
      .ivu-form-item-error-tip
        top: auto
        bottom: 10px
        left: 84px
    &.editor-item
      .ivu-form-item-content
        display: flex
        flex-direction: column
    &.orange-text
      .ivu-form-item-label
        color: $orange
    .ivu-form-item-label
      width: 64px
      height: 40px
      padding: 0
      margin-right: 20px
      font-size: 16px
      line-height: 40px
      text-align: justify
      &:after
        content: ''
        display: inline-block
        padding-left: 100%
    .ivu-radio-wrapper
      margin-right: 64px
      font-size: 16px
      color: $black1
    .input-box
      width: 640px
      .ivu-input
        font-size: 16px
    .input-box-small
      width: 205px
      margin-right: 10px
      .ivu-input
        font-size: 16px
    .tips-text
      width: 640px
      margin-top: 10px
      color: $grey-high
      font-size: 14px
    &.goods-picture
      display: flex
      align-items: center
      .ivu-form-item-content
        display: flex
        align-items: center
        .uploaded-img
          margin: 0
    &.upload-img-add
      display: flex
      align-items: center
      .uploaded-img
        width: 200px
        height: 112px
        margin: 0 20px 0 0
        position: relative
      .ivu-form-item-content
        display: flex
        margin: 0 !important
        .ivu-upload
          display: flex
          justify-content: center
          align-items: center
          width: 200px
          height: 112px
          .ivu-upload-drag
            display: flex
            border: 1px solid $grey-high4
            .cover-upload-text
              p
                font-size: 14px
                color: $grey-high
              &>em
                color: $grey-high4
              .fy-icon-add-thin-gray
                font-size: 32px
                margin: 25px 0 0 0
  .upload-img-tip
    padding-left: 84px
    margin-bottom: 30px
    color: $grey-high
    font-size: 14px
  .goods-group
    display: flex
    margin-bottom: 20px
    .label-span
      width: 64px
      margin-right: 20px
      font-size: 16px
      line-height: 40px
    .goods-list
      display: flex
      .goods-item
        display: flex
        justify-content: space-between
        align-items: center
        min-width: 96px
        height: 40px
        margin-right: 20px
        padding: 0 12px 0 20px
        border: 1px solid $grey-high4
        color: $black1
        font-size: 16px
        line-height: 40px
        border-radius: 4px
        &>.fy-icon-add-orange
          font-size: 16px
          cursor: pointer
          transform: rotate(45deg)
    .edit-group
      color: $orange
  .submit-btn
    width: 140px
    margin-left: 80px
</style>
