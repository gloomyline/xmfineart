<template>
  <div class="after-sales">
    <div class="filter-keyword">
      <i-input v-model="pageConfig.keyword" placeholder="输入商品名称/订单号">
        <i-button slot="append" class="search-btn" type="primary" @click="goSearch()"><span class="fy-icon-search"></span>搜一下</i-button>
      </i-input>
    </div>
    <div class="table-head">
      <div class="good-info">商品信息</div>
      <div class="pay-money">实付金额</div>
      <div class="type">申请类型</div>
      <div class="filter">
        <i-select class="order-status" v-model="pageConfig.handle_status" placeholder="处理状态" clearable @on-change="goSearch()">
          <i-option value="100">待处理</i-option>
          <i-option value="200">已退款</i-option>
          <i-option value="300">已换货</i-option>
          <i-option value="400">已取消</i-option>
        </i-select>
      </div>
      <div class="handle-order">操作</div>
    </div>
    <div class="after-sales-page">
      <div v-if="serviceList.total">
        <div class="order-item" v-for="(item, index) in serviceList.data" :key="index">
          <p class="order-number">
            <span>订单号：{{ item.mall_order_code }} </span>
          </p>
          <div class="order-detail">
            <div class="goods-img">
              <img :src="item.thumbnail"/>
            </div>
            <div class="good-name">{{ item.name }}</div>
            <div class="pay-total">&yen;{{ item.pay_total }}</div>
            <div class="type">
              <span class="red" v-if="item.apply_operate === '100'">退款</span>
              <span class="yellow" v-if="item.apply_operate === '200'">换货</span>
            </div>
            <div class="order-status">
              <span class="red" v-if="item.handle_status === '100'">待处理</span>
              <span class="yellow" v-if="item.handle_status === '200'">已退款</span>
              <span class="yellow" v-if="item.handle_status === '300'">已换货</span>
              <span v-if="item.handle_status === '400'">已取消</span>
            </div>
            <div class="handle-order">
              <!--前往已处理-->
              <router-link :to="`handled-service/${item.id}`" v-if="item.handle_status !== '100'">查看详情</router-link>
              <!--前往未处理-->
              <router-link :to="`unhandled-service/${item.id}`" v-if="item.handle_status === '100'">查看详情</router-link>
            </div>
          </div>
        </div>
        <div class="pagination-cell">
          <pagination class="collection-store-pagination"
                      @page-confirm="changePage"
                      :page="serviceList.current_page"
                      :total="serviceList.total"
                      :page-size="serviceList.per_page"></pagination>
        </div>
      </div>
      <div v-else class="nothing-container">
        <list-nothing class="list-nothing" ></list-nothing>
      </div>
    </div>
  </div>
</template>

<script>
import { Select, Option, Input } from 'iview'
import { Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'
import { scrollTop } from '@/common/js/utils'

export default {
  name: 'AfterSales',
  data () {
    return {
      serviceList: {},
      pageConfig: {
        page: 1, // 页码
        keyword: '', // 搜索关键字，商品名称或者订单编号
        handle_status: ''// 订单状态
      }
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.serviceList = await api.orderServiceSellerList(this.pageConfig)
    },
    async changePage (data) {
      this.pageConfig.page = data.page
      this.serviceList = await api.orderServiceSellerList(this.pageConfig)
      this.$nextTick(() => {
        const sTop = document.documentElement.scrollTop || document.body.scrollTop
        scrollTop(window, sTop, 0, 800)
      })
    },
    async goSearch () {
      if (this.pageConfig.handle_status === undefined) {
        this.pageConfig.handle_status = ''
      }
      this.pageConfig.page = 1
      this.serviceList = await api.orderServiceSellerList(this.pageConfig)
    }
  },
  components: {
    Pagination,
    ListNothing,
    'i-select': Select,
    'i-option': Option,
    'i-input': Input
  }
}
</script>

<style lang="stylus">
.after-sales
  .filter-keyword
    height: 40px
    margin-bottom: 18px
    position: relative
    .ivu-input-wrapper
      width: 366px
      absolute: right
      .ivu-input
        font-size: 14px
        border-color: $orange
      .search-btn
        width: 112px
        font-size: 14px
        color: $white
        padding: 0
        border: none
        border-radius: 0 4px 4px 0
        background-color: $orange
        &>span
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 40px
        .fy-icon-search
          margin-right: 5px
          font-size: 20px
  .table-head
    height: 48px
    line-height: 48px
    padding: 0 50px
    font-size: 16px
    color: $black1
    display: flex
    align-items: center
    flex-direction: row
    border-bottom: 3px solid $grey
    &>div
      display: inline-block
    .good-info
      width: 408px
    .pay-money
      width:140px
    .type
      width: 66px
      text-align: center
      margin-right: 40px
    .filter
      width: 125px
      text-align: center
      margin-right: 60px
      .order-status
        width: auto
        background-color: transparent
        .ivu-select-selection
          border: none
          height: 48px
          line-height: 48px
          background-color: transparent
          box-shadow: none
        .ivu-select-placeholder, .ivu-select-selected-value
          color: $black1
          font-size: 16px
          height: 48px
          line-height: 48px
    .handle-order
      width: 60px
      text-align: center
  .after-sales-page
    padding: 0 30px 30px 30px
    margin-top: 20px
    margin-bottom: 58px
    border: 1px solid $grey-high4
    .order-item
      height: 170px
      padding: 20px 0
      font-size: 14px
      border-bottom: 1px solid $grey-high4
      .order-number
        color: $grey-high1
        font-size: 14px
        margin-bottom: 10px
        span
          padding-right: 20px
      .order-detail
        display: flex
        align-items: center
        &>div
          margin-right: 40px
          &:last-child
            margin-right: 0
          &.goods-img
            width: 100px
            height: 100px
            overflow: hidden
            img
              width: 100px
              height: 100px
          &.good-name
            width: 245px
            font-size: 16px
            overflow: hidden
            -webkit-line-clamp: 2
            display: -webkit-box
            -webkit-box-orient: vertical
          &.type
            width: 80px
            font-size: 14px
            text-align: center
            span
              color: $black1
              &.red
                color: $red
              &.yellow
                color: $orange
              &.grey-height
                color: $grey-high
          &.pay-total
            width: 102px
            color: $black1
            font-size: 18px
          &.order-status
            width: 120px
            text-align: center
            span
              display:block
              color: $grey-high
              &.red
                color: $red
              &.yellow
                color: $orange
            a
              color: $black1
          &.handle-order
            width: 100px
            text-align: center
            .ivu-btn, a
              height: 26px
              line-height: 26px
              display: inline-block
              color: $orange
              font-size: 14px
              margin: 5px auto
              padding: 0 14px
              cursor: pointer
              border-radius: 4px
              border: 1px solid $orange
              span
                display: inline-block
                height:26px
                line-height: 26px
            .cancel-order
              border: none
              color: $grey-high
            .evaluation
              color: $grey-high
              border: 1px solid $grey-high
    .pagination-cell
      height: 68px
      position: relative
      .collection-store-pagination
        width: auto
        absolute: right
        margin-bottom: 0
    .nothing-container
      min-height: 533px
      position: relative
      .list-nothing
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
</style>
