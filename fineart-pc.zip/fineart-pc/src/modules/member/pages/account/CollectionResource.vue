<template>
  <div class="collection-resource-page">
    <div v-if="collectionResourceList.total">
      <div class="resource-card" :key="index" v-for="(item, index) in collectionResourceList.data">
        <a @click="goResourceHome(item.id, item.mode)">
          <div class="resource-img">
            <img :src="item.thumbnail">
          </div>
          <h3>
            <p class="resource-name">{{ item.name | labelFormatter(19) }}</p>
          </h3>
        </a>
      </div>
      <div class="pagination-cell">
        <pagination class="collection-resource-pagination"
                    @page-confirm="changePage"
                    :page="parseInt(collectionResourceList.current_page)"
                    :total="collectionResourceList.total"
                    :page-size="collectionResourceList.per_page"></pagination>
      </div>
    </div>
    <div v-else class="nothing-container">
      <list-nothing class="list-nothing" ></list-nothing>
    </div>
  </div>
</template>

<script>
import { Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'

export default {
  name: 'CollectionResource',
  data () {
    return {
      collectionResourceList: {}
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.collectionResourceList = await api.collectResourceList({ page: 1, object_type: 100 })
    },
    async changePage (data) {
      this.collectionResourceList = await api.collectResourceList({ page: data.page, object_type: 100 })
    },
    goResourceHome (id, mode) {
      let path = ''
      switch (mode) {
      case '100':
        path = 'person'
        break
      case '200':
        path = 'company'
        break
      case '300':
        path = 'supplier'
        break
      case '400':
        path = 'brand'
        break
      case '500':
        path = 'decorator'
        break
      }
      window.location = `/resource.html#/${path}-home/${id}`
    }
  },
  components: {
    Pagination,
    ListNothing
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  }
}
</script>

<style lang="stylus">
  .collection-resource-page
    font-size: 0
    margin-bottom: 58px
    padding: 30px
    padding-right: 8px
    position: relative
    .resource-card
      height: 278px
      width: 220px
      padding: 16px
      background: $grey-high2
      display: inline-block
      margin: 0 20px 20px 0
      .resource-img
        width: 187px
        height: 187px
        position: relative
        margin-bottom: 20px
        img
          absolute: left 50% top 50%
          max-width: 100%
          max-height: 100%
          transform: translate(-50%, -50%)
      .resource-name
        height: 44px
        color: $black
        font-size: 16px
        overflow: hidden
        text-align: center
    .pagination-cell
      height: 68px
      position: relative
      .collection-resource-pagination
        width: auto
        absolute: right
        margin-bottom: 0
        margin-right: 10px
    .nothing-container
      min-height: 670px
      .list-nothing
        margin-top: -80px //补偿原本组件的padding-top： 80
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
</style>
