<template>
  <div class="collection-store-page">
    <div v-if="collectionStoreList.total">
      <div class="store-card" :key="index" v-for="(item, index) in collectionStoreList.data">
        <a :href="`/mall.html#/store-detail/${item.id}`">
          <div class="store-img">
            <img :src="item.thumbnail">
          </div>
          <h3>
            <p class="store-name">{{ item.name }}</p>
          </h3>
        </a>
      </div>
      <div class="pagination-cell">
        <pagination class="collection-store-pagination"
                    @page-confirm="changePage"
                    :page="parseInt(collectionStoreList.current_page)"
                    :total="collectionStoreList.total"
                    :page-size="collectionStoreList.per_page"></pagination>
      </div>
    </div>
    <div v-else class="nothing-container">
      <list-nothing class="list-nothing" ></list-nothing>
    </div>
  </div>
</template>

<script>
import { Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'

export default {
  name: 'CollectionStore',
  data () {
    return {
      collectionStoreList: {}
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.collectionStoreList = await api.collectStoreList(1)
    },
    async changePage (data) {
      this.collectionStoreList = await api.collectStoreList(data.page)
    }
  },
  components: {
    Pagination,
    ListNothing
  }
}
</script>

<style lang="stylus">
  .collection-store-page
    font-size: 0
    padding: 30px
    padding-right: 8px
    margin-bottom: 58px
    position: relative
    .store-card
      height: 260px
      display: inline-block
      margin: 0 20px 20px 0
      a
        width: 220px
        display: block
      .store-img
        width: 220px
        height: 220px
        position: relative
        margin-bottom: 20px
        background: $grey-high2
        img
          absolute: left 50% top 50%
          max-width: 100%
          max-height: 100%
          transform: translate(-50%, -50%)
      .store-name
        width: 220px
        color: $black
        font-size: 16px
        text-align: center
        {ellipse}
    .pagination-cell
      height: 68px
      position: relative
      .collection-store-pagination
        width: auto
        absolute: right
        margin-bottom: 0
        margin-right: 10px
    .nothing-container
      min-height: 670px
      .list-nothing
        margin-top: -80px //补偿原本组件的padding-top： 80
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
</style>
