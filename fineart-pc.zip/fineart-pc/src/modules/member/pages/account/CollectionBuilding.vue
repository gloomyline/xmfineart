<template>
  <div class="collection-building-page">
    <div v-if="collectionBuildingList.total">
      <div class="building-card" :key="index" v-for="(item, index) in collectionBuildingList.data">
        <a :href="`/building.html#/building-detail/${item.id}`">
          <div class="building-img">
            <img :src="item.thumbnail">
          </div>
          <h3>
            <p class="building-name">{{ item.name }}</p>
          </h3>
        </a>
      </div>
      <div class="pagination-cell">
        <pagination class="collection-building-pagination"
                    @page-confirm="changePage"
                    :page="parseInt(collectionBuildingList.current_page)"
                    :total="collectionBuildingList.total"
                    :page-size="collectionBuildingList.per_page"></pagination>
      </div>
    </div>
    <div v-else class="nothing-container">
      <list-nothing class="list-nothing" ></list-nothing>
    </div>
  </div>
</template>

<script>
import { Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'

export default {
  name: 'CollectionBuilding',
  data () {
    return {
      collectionBuildingList: {}
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.collectionBuildingList = await api.collectBuildingList(1)
    },
    async changePage (data) {
      this.collectionBuildingList = await api.collectBuildingList(data.page)
    }
  },
  components: {
    Pagination,
    ListNothing
  }
}
</script>

<style lang="stylus">
  .collection-building-page
    font-size: 0
    padding: 30px
    padding-right: 8px
    margin-bottom: 58px
    position: relative
    .building-card
      height: 260px
      display: inline-block
      margin: 0 20px 20px 0
      a
        width: 220px
        display: block
      .building-img
        width: 220px
        height: 220px
        position: relative
        margin-bottom: 20px
        background: $grey-high2
        img
          absolute: left 50% top 50%
          max-width: 100%
          max-height: 100%
          transform: translate(-50%, -50%)
      .building-name
        width: 220px
        color: $black
        font-size: 16px
        text-align: center
        {ellipse}
    .pagination-cell
      height: 68px
      position: relative
      .collection-building-pagination
        width: auto
        absolute: right
        margin-bottom: 0
        margin-right: 10px
    .nothing-container
      min-height: 670px
      .list-nothing
        margin-top: -80px //补偿原本组件的padding-top： 80
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
</style>
