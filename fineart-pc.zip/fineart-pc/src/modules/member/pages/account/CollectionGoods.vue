<template>
  <div class="collection-goods-page">
    <div v-if="collectionGoodsList.total">
      <goods-card class="goods-item" v-for="(item, index) in collectionGoodsList.data"
                  size="219"
                  :key="index"
                  :href="`/mall.html#/goods-detail/${item.id}/${item.store_id}`"
                  :img-src="item.thumbnail">
        <h3>
          <p class="goods-name">{{ item.name }}</p>
        </h3>
      </goods-card>
      <div class="pagination-cell">
        <pagination class="collection-goods-pagination"
                    @page-confirm="changePage"
                    :page="parseInt(collectionGoodsList.current_page)"
                    :total="collectionGoodsList.total"
                    :page-size="collectionGoodsList.per_page"></pagination>
      </div>
    </div>
    <div v-else class="nothing-container">
      <list-nothing class="list-nothing" ></list-nothing>
    </div>
  </div>
</template>

<script>
import { GoodsCard, Pagination, ListNothing } from 'components'
import api from 'modules/member/api/index.js'

export default {
  name: 'CollectionGoods',
  data () {
    return {
      collectionGoodsList: {}
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.collectionGoodsList = await api.collectGoodsList(1)
    },
    async changePage (data) {
      this.collectionGoodsList = await api.collectStoreList(data.page)
    }
  },
  components: {
    GoodsCard,
    Pagination,
    ListNothing
  }
}
</script>

<style lang="stylus">
.collection-goods-page
  font-size: 0
  padding: 30px 10px 30px 30px
  margin-bottom: 58px
  position: relative
  .goods-item
    height: 260px
    display: inline-block
    margin: 0 20px 20px 0
    .goods-name
      text-align: center
      font-size: 16px
      color: $black
      {ellipse}
  .pagination-cell
    height: 68px
    position: relative
    .collection-goods-pagination
      width: auto
      absolute: right
      margin-bottom: 0
      margin-right: 10px
  .nothing-container
    min-height: 670px
    .list-nothing
      margin-top: -80px //补偿原本组件的padding-top： 80
      absolute: top 50% left 50%
      transform: translate(-50%,-50%)
</style>
