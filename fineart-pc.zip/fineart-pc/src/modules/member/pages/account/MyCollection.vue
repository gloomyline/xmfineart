<template>
  <div class="my-collection">
    <i-menu mode="horizontal" :active-name="parseInt(activeName)">
      <i-menu-item v-for="(item, index) in routeList"
                   :key="index"
                   :to="item.route"
                   :name="item.listOrder">{{ item.name }}<span class="divider"></span></i-menu-item>
    </i-menu>
    <router-view class="member-content"></router-view>
  </div>
</template>

<script>
import { Menu, MenuItem } from 'iview'
export default {
  name: 'MyCollection',
  data () {
    return {
      activeName: this.$route.meta.listOrder,
      routeList: [
        {
          listOrder: 1,
          name: '商品',
          route: '/my-collection/collection-goods'
        },
        {
          listOrder: 2,
          name: '店铺',
          route: '/my-collection/collection-store'
        },
        {
          listOrder: 3,
          name: '资源',
          route: '/my-collection/collection-resource'
        },
        {
          listOrder: 4,
          name: '建筑',
          route: '/my-collection/collection-building'
        }
      ]
    }
  },
  watch: {
    '$route' (newVal) {
      this.activeName = newVal.meta.listOrder
    }
  },
  components: {
    'i-menu': Menu,
    'i-menu-item': MenuItem
  }
}
</script>

<style lang="stylus">
  .my-collection
    .ivu-menu-horizontal
      height: 50px
      line-height: 50px
      .ivu-menu-item-active
        border-bottom: 3px solid $orange
      &.ivu-menu-light:after
        height: 3px
        background: $grey
      .ivu-menu-item
        font-size: 16px
        &:hover
          border-bottom: 3px solid $orange
        &:last-child
          .divider
            display: none
      .divider
        position: absolute
        top: 50%
        right: 0
        width: 2px
        height: 20px
        background-color: $grey
        transform: translateY(-50%)
    .member-content
      margin-top: 20px
      width: 1000px
      border: 1px solid $grey-high4
</style>
