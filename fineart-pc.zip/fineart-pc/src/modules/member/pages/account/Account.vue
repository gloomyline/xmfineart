<template>
  <div class="account-page">
    <i-form ref="accountModel" :model="accountModel" :rules="accountRule">
      <i-form-item class="portrait" label="头像">
        <!-- 编辑头像 -->
        <i-upload
          ref="upload"
          :show-upload-list="false"
          :max-size="ossThumbnail.max_size"
          type="select"
          :data="ossThumbnail.data"
          :action="ossThumbnail.host"
          :format="ossThumbnail.format"
          :accept="ossThumbnail.accept"
          :before-upload="beforeUploadThumb"
          :on-success="successThumb"
          :on-exceeded-size="exceededSize"
          :on-format-error="formatError">
          <div class="upload-wrap">
            <img :src="accountModel.avatar_cdn" :alt="accountModel.nickname">
            <div class="upload-box">
              <span class="fy-icon-upload"></span>
              <em>上传图片</em>
            </div>
          </div>
        </i-upload>
      </i-form-item>
      <div class="disable-entry">
        <span class="span-label">手机号码</span>
        <p class="content">{{ accountModel.mobile }}</p>
      </div>
      <i-form-item label="昵称" prop="nickname">
        <i-input style="width: 280px"
                 placeholder="请输入昵称"
                 v-model="accountModel.nickname"></i-input>
      </i-form-item>
      <i-form-item label="性别" prop="gender">
        <i-radio-group v-model="accountModel.gender">
          <i-radio label="200">男</i-radio>
          <i-radio label="300">女</i-radio>
        </i-radio-group>
      </i-form-item>
      <i-form-item label="邮箱" prop="email">
        <i-input style="width: 280px"
                 placeholder="请输入常用邮箱"
                 v-model="accountModel.email"></i-input>
      </i-form-item>
      <div class="disable-entry">
        <span class="span-label">实名认证</span>
        <p class="certified" v-if="accountModel.is_auth == 200"><span class="fy-icon-checkout"></span>已认证</p>
        <p class="certification" v-else>
          <span>未认证</span>
          <router-link class="go-real" to="/real-name">去认证 >></router-link>
        </p>
      </div>
      <div class="disable-entry wx-bind">
        <span class="span-label">微信绑定</span>
        <div class="not-bind" v-if="!memberInfo.unionid">
          <i-button class="binding-btn" @click="showQr">点击绑定</i-button>
        </div>
        <div class="binded" v-else>
          <i-button class="unbind-btn" type="cancel" @click="tipModal = true">解除绑定</i-button>
        </div>
      </div>
      <i-form-item>
        <i-button class="account-save" type="primary" @click="handleSubmit('accountModel')">保存</i-button>
      </i-form-item>
    </i-form>
    <div class="footer-tip">注：以上信息不会同步到个人主页。仅用于[商品评价]等非实名评论功能</div>
    <i-modal class="qr-modal" v-model="isQRCodeShow" width="370" footer-hide>
      <div class="scan-qr">
        <div class="qr" id="qr" v-show="!isQRTimeout"></div>
        <div class="invalid-tip" v-show="isQRTimeout">
          <p>二维码已失效</p>
          <i-button type="text" slot="append" @click="refreshQR"><i-icon type="ios-sync"/>点击刷新</i-button>
        </div>
      </div>
    </i-modal>
    <i-modal v-model="tipModal"
             title="温馨提示"
             @on-ok="unbindWeChat">
      <div>您将解除微信绑定，解除后将无法使用微信登录斐艺，请确定。</div>
    </i-modal>
  </div>
</template>

<script>
import { Input, Radio, Form, FormItem, RadioGroup, Button, Upload, Modal, Icon } from 'iview'
import { deepClone, getQuery } from '@/common/js/utils'
import api from 'modules/member/api'
import { mapState } from 'vuex'
import * as MSG from 'assets/data/message.js'
import { fetchScriptFile } from '@/common/js/loadScript.js'
import { WX_QR_URL, WX_APP_ID, WX_GETTING_CODE_INTERVAL, WX_GETTING_CODE_TIMEOUT } from '@/assets/data/constants.js'

export default {
  name: 'Account',
  data () {
    return {
      ossThumbnail: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      accountRule: {
        nickname: [
          { required: true, message: '请填写昵称', trigger: 'blur' }
        ],
        mobile: [
          { required: true, message: '请填写手机号', trigger: 'blur' }
        ],
        gender: [
          { required: true, message: '请选择性别', trigger: 'blur' }
        ],
        // avatar: [
        //   { required: true, message: '请上传图片' }
        // ],
        email: [
          { type: 'email', message: '邮箱无效', trigger: 'blur' }
        ]
      },
      accountModel: {},
      isQRCodeShow: false, // 是否显示微信绑定二维码
      isQRTimeout: false, // 微信绑定二维码是否过期
      tipModal: false // 是否显示解绑微信弹窗
    }
  },
  computed: {
    ...mapState('member', ['memberInfo'])
  },
  watch: {
    memberInfo: {
      handler (newVal) {
        this.accountModel = deepClone(newVal)
      },
      deep: true
    }
  },
  created () {
    this.accountModel = deepClone(this.memberInfo)
  },
  beforeDestroy () {
    if (this.timerId) {
      clearInterval(this.timerId)
      this.timerId = null
    }
  },
  methods: {
    // 解除微信绑定
    async unbindWeChat () {
      const res = await api.wechatUnbind()
      if (res.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.ACCOUNT_WECHAT_UNBIND_SUCCESS, type: 'success' })
        this.$store.dispatch('member/fetchAccountProfile')
      }
    },
    // 绑定微信
    async bindWeChat (code) {
      const res = await api.wechatBind({ code })
      if (res.code === 200) {
        this.isQRCodeShow = false
        this.$store.commit('ADD_MESSAGE', { msg: MSG.ACCOUNT_WECHAT_BIND_SUCCESS, type: 'success' })
        this.$store.dispatch('member/fetchAccountProfile')
      }
    },
    // 开启间隔获取url上的code计时器
    startGettingCode () {
      this.qrTimeout = WX_GETTING_CODE_TIMEOUT
      this.timerId = setInterval(() => {
        this.qrTimeout -= WX_GETTING_CODE_INTERVAL
        const code = getQuery('code')
        if (code) {
          this.bindWeChat(code)
          clearInterval(this.timerId)
        }
        if (this.qrTimeout <= 0) {
          this.isQRTimeout = true
        }
      }, WX_GETTING_CODE_INTERVAL)
    },
    // 刷新微信绑定二维码
    refreshQR () {
      if (!this.WxLogin) return
      this.isQRTimeout = false
      this.$nextTick(() => {
        this.createQr()
      })
    },
    // 创建微信二维码
    createQr () {
      /* eslint-disable no-unused-vars */
      const qrObj = new this.WxLogin({
        id: 'qr',
        appid: WX_APP_ID,
        scope: 'snsapi_login',
        href: 'https://static.xmfineart.com/static/wx-qr-style.css',
        redirect_uri: encodeURIComponent('https://www.xmfineart.com/member.html#/account')
      })
      this.startGettingCode()
    },
    // 显示微信绑定二维码
    async showQr () {
      this.WxLogin = await fetchScriptFile(WX_QR_URL, 'WxLogin')
      this.isQRCodeShow = true
      this.isQRTimeout = false
      this.$nextTick(() => {
        this.createQr()
      })
    },
    // 保存信息
    handleSubmit (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.accountModel.email = this.accountModel.email ? this.accountModel.email : ''
          this.result = await api.updateAccountProfile(this.accountModel)
          if (this.result.code === 200) {
            this.$store.dispatch('member/fetchAccountProfile')
            this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_INFO_SAVE_SUCCESS'], type: 'success' })
            this.memberInfo.avatar = this.accountModel.avatar
            this.memberInfo.avatar_cdn = this.accountModel.avatar_cdn
          } else {
            this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'error' })
          }
        }
      })
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await api.ossParamsCreate(file, 'member_avatar', this.ossThumbnail)
    },
    successThumb (res) {
      if (res.code === 200) {
        this.accountModel.avatar = res.results.file_url
        this.accountModel.avatar_cdn = res.results.file_url_cdn
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'error'})
      }
    },
    // 文件超出指定大小限制时的钩子
    exceededSize () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD_EXCEEDED_SIZE'], type: 'error'})
    },
    // 文件格式验证失败时的钩子
    formatError () {
      this.$store.commit('ADD_MESSAGE', {msg: MSG['UPLOAD__FORMAT_ERROR'], type: 'error'})
    }
  },
  components: {
    'i-form': Form,
    'i-icon': Icon,
    'i-input': Input,
    'i-modal': Modal,
    'i-radio': Radio,
    'i-button': Button,
    'i-upload': Upload,
    'i-form-item': FormItem,
    'i-radio-group': RadioGroup
  }
}
</script>

<style lang="stylus">
.account-page
  position: relative
  padding: 50px
  .upload-wrap
    position: relative
    width: 120px
    height: 120px
    &:hover .upload-box
      display: flex
    &>img
      width: 100%
      height: 100%
    .upload-box
      display: none
      absolute: top left
      flex-direction: column
      justify-content: center
      align-items: center
      width: 120px
      height: 120px
      border: 1px solid $grey-high5
      background-color: rgba(0, 0, 0, 0.6)
      cursor: pointer
      &>span
        font-size: 31px
      &>em
        color: $grey-high5
        font-size: 14px
  .ivu-form-item
    display: flex
  .ivu-form-item-label
    width: 64px
    height: 40px
    padding: 0
    margin-right: 50px
    font-size: 16px
    color: $black
    line-height: 40px
    text-align: justify
    /*实现文字两端对齐*/
    &:after
      content: ''
      display: inline-block
      padding-left: 100%
  .portrait
    .ivu-form-item-label
      height: 120px
      line-height: 120px
  .disable-entry
    display: flex
    height: 40px
    margin-bottom: 24px
    &.wx-bind
      .not-bind, .binded
        padding: 8px
      .ivu-btn
        width: 72px
        height: 24px
        padding: 0
        font-size: 14px
        border-radius: 4px
        &.binding-btn
          color: $orange
          border: 1px solid $orange
        &.unbind-btn
          color: $grey-light2
          border:1px solid $grey-light2
    .span-label
      width: 64px
      height: 40px
      margin-right: 50px
      font-size: 16px
      color: $black
      line-height: 40px
      text-align: justify
      &:after
        content: ''
        display: inline-block
        padding-left: 100%
    .content
      font-size: 16px
      line-height: 40px
  .ivu-input
    font-size: 16px
  .ivu-radio-wrapper
    margin-right: 40px
    font-size: 16px
    .ivu-radio-inner
      width: 20px
      height: 20px
      margin-right: 12px
      &:after
        left: 3px
        top: 3px
        width: 12px
        height: 12px
  .certification
    font-size: 16px
    line-height: 40px
    &>span
      margin-right: 30px
      color: $grey-high
    .go-real
      color: $orange
  .certified
    display: flex
    align-items: center
    color: $green
    font-size: 16px
    line-height: 40px
    .fy-icon-checkout
      font-size: 20px
      margin-right: 10px
  .account-save
    width: 280px
    height: 50px
    margin-left: 114px
    font-size: 18px
  .footer-tip
    position: absolute
    left: 0
    bottom: 0
    width: 100%
    height: 43px
    padding-left: 50px
    border-top: 1px solid $grey-high4
    color: $grey-high
    line-height: 43px
    font-size: 14px
.qr-modal
  .ivu-modal-close
    absolute: top right
    padding: 0 !important
    .ivu-icon
      font-size: 48px
  .ivu-modal-body
    .scan-qr
      .invalid-tip
        width: 300px
        height: 300px
        text-align: center
        padding-top: 100px
        padding-bottom: 100px
        font-size: 18px
        color: $black1
        .ivu-btn-text
          color: $black1
          font-size: 20px
          margin-top: 10px
          &:focus
            box-shadow: none
          &:hover
            background-color: transparent
</style>
