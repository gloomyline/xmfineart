<template lang="html">
  <div class="real-name-page">
    <i-form ref="realNameItem"
            v-if="memberInfo.is_auth && memberInfo.is_auth === '100'"
            :model="realNameItem"
            :rules="realNameRule">
      <div class="disable-entry">
        <span class="span-label">手机号码</span>
        <p class="content">{{ memberInfo.mobile }}</p>
      </div>
      <i-form-item label="短信验证" prop="code">
        <i-input style="width: 166px"
                 placeholder="输入短信验证码"
                 v-model="realNameItem.code"></i-input>
        <i-button class="send-code-btn" type="default" @click="sendCode(memberInfo.mobile)" ghost :disabled="isCodeBtnDisabled">{{ codeBtnLabel }}</i-button>
      </i-form-item>
      <i-form-item label="姓名" prop="realname">
        <i-input style="width: 280px"
                 placeholder="输入本人真实姓名"
                 v-model="realNameItem.realname"></i-input>
      </i-form-item>
      <i-form-item label="身份证号" prop="idcard">
        <i-input style="width: 280px"
                 placeholder="输入身份证号"
                 v-model="realNameItem.idcard"></i-input>
      </i-form-item>
      <i-form-item label="银行卡号" prop="bankcard">
        <i-input style="width: 280px"
                 placeholder=" 输入银行卡号"
                 v-model="realNameItem.bankcard"></i-input>
      </i-form-item>
      <i-form-item>
        <i-button class="real-name-save" type="primary" @click="handleSubmit('realNameItem')">提交认证</i-button>
      </i-form-item>
    </i-form>
    <div class="is-auth-info-card" v-if="memberInfo.is_auth && memberInfo.is_auth === '200'">
      <p class="info-item">
        <label>姓名</label>
        <span>{{ memberInfo.realname }}</span>
      </p>
      <p class="info-item">
        <label>手机号码</label>
        <span>{{ memberInfo.mobile }}</span>
      </p>
      <p class="info-item">
        <label>身份证号</label>
        <span>{{ memberInfo.identity }}</span>
      </p>
    </div>
    <div class="footer-tip">说明：以上信息仅作为实名认证用，使用银行接口进行认证，不会以任何形式保存您的信息。</div>
  </div>
</template>

<script>
import { Input, Form, FormItem, RadioGroup, Button, Spin } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'
import { mapState } from 'vuex'

export default {
  name: 'RealName',
  data () {
    return {
      realNameItem: {
        realname: '', // 姓名，必须
        idcard: '', // 身份证号码，必须
        bankcard: '', // 银行卡号，必须
        code: '' // 短信验证码，必须
      },
      realNameRule: {
        realname: [
          {
            required: true,
            message: '请填写真实姓名'
          }
        ],
        idcard: [
          {
            required: true,
            message: '请填写身份证号'
          }
        ],
        bankcard: [
          {
            required: true,
            message: '请填写银行卡号'
          }
        ],
        code: [
          {
            required: true,
            message: '请输入短信验证码'
          }
        ]
      },
      initCount: 60, // 获取短信验证码按钮初始冷却计数
      count: 60, // 获取短息验证码当前冷却计数
      counter: null // 计数器
    }
  },
  computed: {
    ...mapState('member', ['memberInfo']),
    isCodeBtnDisabled () {
      return this.count < 60
    },
    codeBtnLabel () {
      // 当计时器工作时，即获取验证码处于冷却中，显示当前计数
      return this.isCodeBtnDisabled ? `${this.count}s` : '获取验证码'
    }
  },
  methods: {
    startCount () {
      this.counter = setInterval(() => {
        --this.count
        if (this.count <= 0) {
          this.stopCount()
        }
      }, 1000)
    },
    stopCount () {
      this.count = this.initCount
      clearInterval(this.counter)
    },
    async sendCode (mobile) {
      // 实名认证短信类型
      const type = 205
      this.result = await api.fetchCode({ type, mobile })
      if (Number.parseInt(this.result.code) === 200) {
        this.startCount()
        this.$store.commit('ADD_MESSAGE', { msg: MSG['SEND_CODE_SUCCESS'], type: 'success' })
      }
    },
    spinShow () {
      // 显示加载遮罩层
      Spin.show({
        render: (h) => {
          return h('div', [
            h('div', {
              'class': 'demo-spin-icon-load'
            }),
            h('div', '认证中...')
          ])
        }
      })
      setTimeout(() => {
        Spin.hide()
      }, 3000)
    },
    handleSubmit (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.spinShow()
          this.result = await api.accountProfileAuthRealName(this.realNameItem)
          if (Number.parseInt(this.result.code) === 200) {
            this.$store.dispatch('member/fetchAccountProfile')
            this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_REAL_NAME_AUTH_SUCCESS'], type: 'success' })
            this.$router.push({path: `/account`})
          } else {
            this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'error' })
          }
          console.log('success')
        } else {
          console.log('Fail!')
        }
      })
    }
  },
  components: {
    'i-form': Form,
    'i-spin': Spin,
    'i-input': Input,
    'i-button': Button,
    'i-form-item': FormItem,
    'i-radio-group': RadioGroup
  }
}
</script>

<style lang="stylus">
.demo-spin-icon-load
  animation: ani-demo-spin 1s linear infinite
.real-name-page
  position: relative
  padding: 50px 50px 0 50px
  .is-auth-info-card
    .info-item
      display: flex
      text-align:center
      span
        font-size: 16px
        height: 40px
        line-height: 40px
        vertical-align: middle
        display: inline-block
  .ivu-form-item
    margin-bottom: 30px
  .ivu-form-item-label, .is-auth-info-card label
    width: 64px
    height: 40px
    padding: 0
    margin-right: 50px
    font-size: 16px
    color: $black
    line-height: 40px
    text-align: justify
    /*实现文字两端对齐*/
    &:after
      content: ''
      display: inline-block
      padding-left: 100%
  .disable-entry
    display: flex
    height: 40px
    margin-bottom: 24px
    .span-label
      width: 64px
      height: 40px
      margin-right: 50px
      font-size: 16px
      color: $black
      line-height: 40px
      text-align: justify
      &:after
        content: ''
        display: inline-block
        padding-left: 100%
    .content
      font-size: 16px
      line-height: 40px
  .ivu-input
    font-size: 16px
  .real-name-save
    width: 280px
    height: 50px
    margin-top: 40px
    margin-left: 114px
    font-size: 20px
  .send-code-btn
    width: 104px
    height: 38px
    color: $orange
    font-size: 16px
    padding: 0
    margin-left: 6px
    border: 1px solid $orange
   /*验证时文字位置*/
  .ivu-form-item-error-tip
    left: 114px
  .footer-tip
    position: absolute
    left: 0
    bottom: 0
    width: 100%
    height: 43px
    padding-left: 50px
    border-top: 1px solid $grey-high4
    color: $grey-high
    line-height: 43px
    font-size: 14px
</style>
