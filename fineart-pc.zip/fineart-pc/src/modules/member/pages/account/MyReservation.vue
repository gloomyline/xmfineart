<template lang="html">
  <div class="my-reservation">
    <div class="page-title">
      <span>我的预约</span>
      <span class="description-text">斐艺关注行业新科技，在此页面可查看您已预约的商品</span>
    </div>
    <div class="reservation-page">
      <div v-if="myReservationList.total">
        <goods-card class="goods-item" v-for="(item, index) in myReservationList.data"
                    size="219"
                    :key="index"
                    :href="`/mall.html#/fore-show-detail/${item.foreshow_id}`"
                    :img-src="item.thumbnail">
          <h3>
            <p class="goods-name">{{ item.name }}</p>
          </h3>
        </goods-card>
        <div class="pagination-cell">
          <pagination class="reservation-pagination"
                      @page-confirm="changePage"
                      :page="parseInt(myReservationList.current_page)"
                      :total="myReservationList.total"
                      :page-size="myReservationList.per_page"></pagination>
        </div>
      </div>
      <div v-else class="nothing-container">
        <list-nothing class="list-nothing" ></list-nothing>
      </div>
    </div>
  </div>
</template>

<script>
import { GoodsCard, Pagination, ListNothing } from 'components'
import api from 'modules/mall/api/index.js'

export default {
  name: 'MyReservation',
  data () {
    return {
      myReservationList: {}
    }
  },
  created () {
    this.initPage()
  },
  methods: {
    async initPage () {
      this.myReservationList = await api.foreShowMyReservation(1)
    },
    async changePage (data) {
      this.myReservationList = await api.foreShowMyReservation(data.page)
    }
  },
  components: {
    GoodsCard,
    Pagination,
    ListNothing
  }
}
</script>

<style lang="stylus">
.my-reservation
  .page-title
    font-size: 16px
    color: $black1
    position: relative
    padding: 12px 0 13px 40px
    border-bottom: 3px solid $grey
    .description-text
      font-size: 14px
      color: $grey-high
      padding-left: 20px
  .reservation-page
    font-size: 0
    width: 1000px
    margin-top: 20px
    margin-bottom: 58px
    position: relative
    border: 1px solid #e6e6e6
    padding: 30px 10px 30px 30px
    .goods-item
      height: 260px
      display: inline-block
      margin: 0 20px 20px 0
      .goods-name
        text-align: center
        font-size: 16px
        color: $black
        {ellipse}
    .pagination-cell
      height: 68px
      position: relative
      .reservation-pagination
        width: auto
        absolute: right
        margin-bottom: 0
        margin-right: 10px
    .nothing-container
      min-height: 670px
      .list-nothing
        margin-top: -80px //补偿原本组件的padding-top： 80
        absolute: top 50% left 50%
        transform: translate(-50%,-50%)
</style>
