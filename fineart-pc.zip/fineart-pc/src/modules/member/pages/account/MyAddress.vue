<template lang="html">
  <div class="my-address">
    <div class="page-title">
      <span class="name">收货人</span>
      <span class="address-description">地址</span>
      <span class="mobile">联系方式</span>
      <span class="handle-cell">操作</span>
    </div>
    <div class="address-page">
      <div class="address-item" v-for="(item, index) in addressList" :key="index">
        <div class="name">{{ item.name }}</div>
        <div class="address-description">{{ item.address_desc }}</div>
        <div class="mobile">{{ item.mobile }}</div>
        <div class="handle-cell">
          <i-button @click="editSubmit(item)">编辑</i-button>
          <i-button @click="deleteConfirm(item.id)">删除</i-button>
        </div>
        <div class="default-box">
          <div v-if="item.is_default" class="is-default">
            <i-icon type="md-checkmark"/>
            默认地址
          </div>
          <i-button v-else @click="setDefaultSubmit(item.id)">设为默认地址</i-button>
        </div>
      </div>
      <p class="add-address">
        <i-button slot="append" @click="showAddAddress"><span class="fy-icon-add-thick-orange"></span>添加收货地址</i-button>
      </p>
    </div>
    <i-modal v-model="delModal" title="删除确认" @on-ok="deleteSubmit">
      <p>确认删除收货地址吗？</p>
    </i-modal>
    <mall-address :type-show="modal.typeShow"
                  v-model="modal.isShowed" ref="bindAddressData"
                  @select-address="changeAddress" @change="initMyAddress"
                  :title-word="modal.title"></mall-address>
  </div>
</template>

<script>
import { Icon, Modal } from 'iview'
import { MallAddress } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'

export default {
  name: 'MyAddress',
  data () {
    return {
      delModal: false,
      delAddressId: '',
      addressList: [],
      modal: {
        isShowed: false,
        typeShow: 'add',
        title: '添加收货地址'
      }
    }
  },
  created () {
    this.initMyAddress()
  },
  methods: {
    showAddAddress () {
      this.modal.isShowed = true
      this.modal.title = '添加收货地址'
      this.$refs.bindAddressData.refsResetData()
    },
    async changeAddress (item) {
      console.log(item)
    },
    async initMyAddress () {
      this.addressList = await api.addressFetchList()
    },
    editSubmit (address) {
      this.modal.title = '编辑收货地址'
      this.modal.isShowed = true
      this.$refs.bindAddressData.refsDefaultData(address)
    },
    deleteConfirm (id) {
      this.delModal = true
      this.delAddressId = id
    },
    async deleteSubmit () {
      if (this.delAddressId) {
        this.result = await api.addressDel(this.delAddressId)
        if (this.result.code === 200) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_DELETE_SUCCESS'], type: 'success' })
          // 触发父组件的change事件，刷新父组件的数据
          this.initMyAddress()
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'error' })
        }
      }
    },
    async setDefaultSubmit (id) {
      this.result = await api.addressSetDefault(id)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_SET_DEFAULT_ADDRESS_SUCCESS'], type: 'success' })
        // 触发父组件的change事件，刷新父组件的数据
        this.initMyAddress()
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'error' })
      }
    }
  },
  components: {
    MallAddress,
    'i-icon': Icon,
    'i-modal': Modal
  }
}
</script>

<style lang="stylus">
.my-address
  .page-title
    height: 48px
    line-height: 48px
    padding: 0 50px
    font-size: 16px
    color: $black1
    border-bottom: 3px solid $grey
    display： flex
    &>span
      text-align: center
      margin-right: 50px
      display: inline-block
      &:last-child
        margin-right: 0
      &.name
        width: 50px
      &.address-description
        width: 300px
      &.mobile
        width: 110px
      &.handle-cell
        width: 77px
  .address-page
    padding: 0 50px
    min-height: 560px
    margin-top: 20px
    margin-bottom: 58px
    border: 1px solid $grey-high4
    .address-item
      display: flex
      align-items: center
      height: 115px
      color: $black
      font-size: 16px
      border-bottom: 1px solid $grey-high4
      &>div
        margin-right: 50px
        &:last-child
          margin-right: 0
        &.name
          width: 70px
        &.address-description
          width: 300px
        &.mobile
          width: 100px
        &.handle-cell
          width: 110px
        &.default-box
          width: 110px
          text-align center
          .is-default
            font-size: 14px
            color: $orange
        .ivu-btn
          font-size: 14px
          padding: 2px 8px
          color: $grey-high
          &:hover
            color: $orange
    .add-address
      height: 115px
      line-height: 115px
      text-align: center
      .ivu-btn
        width: 140px
        height: 40px
        font-size: 16px
        color: $orange
        border: 1px solid $orange
        vertical-align: middle
</style>
