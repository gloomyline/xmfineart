<template>
  <div class="change-mobile-page">
    <i-form ref="ChangeMobileItem1"
            :model="ChangeMobileItem1"
            :rules="ChangeMobileRule1"
            v-show="!showStep2">
      <div class="disable-entry">
        <span class="span-label">已绑定手机号</span>
        <p class="content">{{ memberInfo.mobile }}</p>
      </div>
      <i-form-item label="短信验证码" prop="code">
        <i-input style="width: 166px"
                 placeholder="输入短信验证码"
                 v-model.trim="ChangeMobileItem1.code"></i-input>
        <i-button class="send-code-btn" ghost
                  html-type="button"
                  :disabled="isCodeBtnDisabled"
                  @click="sendCode(memberInfo.mobile, ChangeMobileItem1.type)">{{ codeBtnLabel }}</i-button>
      </i-form-item>
      <i-form-item>
        <i-button class="next-step" type="primary" @click="nextStep('ChangeMobileItem1')">下一步</i-button>
      </i-form-item>
    </i-form>
    <i-form ref="ChangeMobileItem2"
            :model="ChangeMobileItem2"
            :rules="ChangeMobileRule2"
            v-show="showStep2">
      <i-form-item label="新手机号" prop="mobile">
        <i-input style="width: 280px"
                 placeholder="输入新手机号"
                 v-model.trim.number="ChangeMobileItem2.mobile"></i-input>
      </i-form-item>
      <i-form-item label="短信验证码" prop="code">
        <i-input style="width: 166px"
                 placeholder="输入短信验证码"
                 v-model.trim="ChangeMobileItem2.code"></i-input>
        <i-button class="send-code-btn" ghost
                  html-type="button"
                  :disabled="isCodeBtnDisabled"
                  @click="sendCode(ChangeMobileItem2.mobile, ChangeMobileItem2.type)">{{ codeBtnLabel }}</i-button>
      </i-form-item>
      <i-form-item>
        <i-button class="mobile-save" type="primary" @click="updateMobile('ChangeMobileItem2')">确定绑定</i-button>
      </i-form-item>
    </i-form>
  </div>
</template>

<script>
import { Input, Form, FormItem, Button } from 'iview'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'
import { mapState } from 'vuex'

export default {
  name: 'ChangeMobile',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{9}\d$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      ChangeMobileItem1: {
        type: 203,
        code: ''
      },
      ChangeMobileItem2: {
        type: 204,
        mobile: '',
        code: ''
      },
      ChangeMobileRule1: {
        code: [
          {
            required: true,
            message: '请输入短信验证码'
          }
        ]
      },
      ChangeMobileRule2: {
        mobile: [
          {
            required: true,
            message: '请输入新手机号'
          },
          {
            // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
            validator: mobileValidator
          }
        ],
        code: [
          {
            required: true,
            message: '请输入短信验证码'
          }
        ]
      },
      initCount: 60, // 获取短信验证码按钮初始冷却计数
      count: 60, // 获取短息验证码当前冷却计数
      counter: null, // 计数器
      showStep2: false
    }
  },
  computed: {
    ...mapState('member', ['memberInfo']),
    isCodeBtnDisabled () {
      return this.count < 60
    },
    codeBtnLabel () {
      // 当计时器工作时，即获取验证码处于冷却中，显示当前计数
      return this.isCodeBtnDisabled ? `${this.count}s` : '获取验证码'
    }
  },
  methods: {
    startCount () {
      this.counter = setInterval(() => {
        --this.count
        if (this.count <= 0) {
          this.stopCount()
        }
      }, 1000)
    },
    stopCount () {
      this.count = this.initCount
      clearInterval(this.counter)
    },
    // 获取手机验证码-步骤1和步骤2
    async sendCode (mobile, type) {
      this.result = await api.fetchCode({ type, mobile })
      if (Number.parseInt(this.result.code) === 200) {
        this.startCount()
        this.$store.commit('ADD_MESSAGE', { msg: MSG['SEND_CODE_SUCCESS'], type: 'success' })
      }
    },
    // 会员手机号码修改步骤1：请求接口校验验证码是否正确,正确将showStep2设为true，显示步骤2的炒作框
    nextStep (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.result = await api.accountProfileResetMobileStep1(this.ChangeMobileItem1.code)
          if (Number.parseInt(this.result.code) === 200) {
            this.stopCount()
            this.showStep2 = true
          } else {
            this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'error' })
          }
        }
      })
    },
    // 会员手机号码修改步骤2
    updateMobile (name) {
      this.$refs[name].validate(async (valid) => {
        if (valid) {
          this.result = await api.accountProfileResetMobileStep2(this.ChangeMobileItem2)
          if (Number.parseInt(this.result.code) === 200) {
            this.$store.dispatch('member/fetchAccountProfile')
            this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_CHANGE_MOBILE_SUCCESS'], type: 'success' })
            this.$router.push({path: `/change-mobile`})
          } else {
            this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'error' })
          }
        }
      })
    }

  },
  components: {
    'i-form': Form,
    'i-input': Input,
    'i-button': Button,
    'i-form-item': FormItem
  }
}
</script>

<style lang="stylus">
.change-mobile-page
  position: relative
  padding: 50px 50px 0 50px
  .ivu-form-item
    margin-bottom: 30px
  .ivu-form-item-label
    width: 96px
    height: 40px
    padding: 0
    margin-right: 20px
    font-size: 16px
    color: $black
    line-height: 40px
    text-align: right
  .ivu-input
    font-size: 16px
  .send-code-btn
    padding: 0
    width: 104px
    height: 40px
    color: $orange
    font-size: 16px
    margin-left: 6px
    border: 1px solid $orange
  .disable-entry
    display: flex
    height: 40px
    margin-bottom: 24px
    .span-label
      width: 96px
      height: 40px
      margin-right: 20px
      font-size: 16px
      color: $black
      line-height: 40px
      text-align: left
    .content
      font-size: 16px
      line-height: 40px
  .mobile-save, .next-step
    width: 280px
    height: 50px
    font-size: 20px
    margin: 60px 0 0 114px
  /*验证时文字位置*/
  .ivu-form-item-error-tip
    left: 114px
</style>
