<template lang="html">
  <div class="edit-marker-page">
    <p class="tips">在此页面，可以编辑您已经绑定在地图上提交的信息。</p>
    <div class="edit-marker-list">
      <div class="marker-card" v-for="(item, key) in myMarkerList" :key="key">
        <div class="marker-info">
          <div class="marker-name">{{ item.name }}</div>
          <div class="item-line">
            <label>类型：</label>
            <span>{{ item.category_name }}</span>
          </div>
          <div class="item-line">
            <label>手机号：</label>
            <span>{{ item.mobile }}</span>
          </div>
        </div>
        <div class="operation-box">
          <i-button type="text" slot="append" @click="prepareDelete(item.id)"><span class="fy-icon-delete"></span>删除</i-button>
          <i-button type="text" slot="append" @click="prepareMap(item)"><i-icon type="ios-sync"/>重新定位</i-button>
          <i-button type="text" slot="append" @click="prepareEdit(item)"><span class="fy-icon-edit"></span>编辑</i-button>
        </div>
      </div>
    </div>
    <list-nothing v-if="myMarkerList.length === 0"></list-nothing>
    <i-modal v-model="showDeleteTip"
             width="440"
             title="删除地图标记">
      <div>您在地图上添加的标记信息将被删除，请确认。</div>
      <div class="save-btn-group" slot="footer">
        <i-button type="primary" @click="deleteMarker">确认删除</i-button>
      </div>
    </i-modal>
    <i-modal v-model="showEditModal"
             title="编辑地图标记"
             width="440">
      <i-form>
        <i-form-item>
          <i-input placeholder="请输入姓名" v-model="curEditMarkerItem.name"></i-input>
        </i-form-item>
        <i-form-item>
          <i-input placeholder="请输入号码" v-model="curEditMarkerItem.mobile"></i-input>
        </i-form-item>
        <i-form-item>
          <i-select placeholder="请选择主页" @on-change="setResourceToMarker" v-model="curEditMarkerItem.resource_id">
            <i-option v-for="(res, k) in resourceList" :key="k" :value="res.resource_id">{{ res.resource_name }}</i-option>
          </i-select>
        </i-form-item>
        <i-form-item>
          <i-select placeholder="请选择店铺" @on-change="setStoreToMarker" v-model="curEditMarkerItem.store_id">
            <i-option v-for="(res, k) in storeList" :key="k" :value="res.store_id">{{ res.store_name }}</i-option>
          </i-select>
        </i-form-item>
      </i-form>
      <div class="save-btn-group" slot="footer">
        <i-button type="primary" @click="saveEditMarker">保存修改</i-button>
      </div>
    </i-modal>
    <fa-map v-model="showMapModal"
                  :lat="curEditMarkerItem.lat"
                  :lng="curEditMarkerItem.lng"
                  :address="curEditMarkerItem.address"
                  @save-edit="relocationMyMarker"></fa-map>
  </div>
</template>

<script>
import { Button, Icon, Modal, Input, Select, Option, Form, FormItem } from 'iview'
import { FaMap, ListNothing } from 'components'
import api from 'modules/member/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'EditMarker',
  data () {
    return {
      showDeleteTip: false,
      showMapModal: false,
      showEditModal: false,
      curDeleteMarkerId: '',
      curEditMarkerItem: {},
      myMarkerList: [],
      resourceList: [],
      storeList: []
    }
  },
  created () {
    this.fetchMyMarkerList()
    this.fetchResourceList()
    this.fetchStoreList()
  },
  methods: {
    // 获取可以被绑定的资源主页
    async fetchMyMarkerList () {
      let markerList = await api.fetchMyMarkerList()
      if (!markerList || !markerList.data || markerList.data.length === 0) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_MY_MARKER_EMPTY, type: 'info'})
        return false
      }
      this.myMarkerList = markerList.data
    },
    // 获取可以被绑定的资源主页
    async fetchResourceList () {
      this.resourceList = await api.fetchResourceListForMarker()
    },
    // 获取可以被绑定的店铺
    async fetchStoreList () {
      this.storeList = await api.fetchStoreListForMarker()
    },
    prepareDelete (markerId) {
      this.curDeleteMarkerId = markerId
      this.showDeleteTip = true
    },
    prepareEdit (markerItem) {
      this.curEditMarkerItem = markerItem
      this.setResourceToMarker(markerItem.resource_id)
      this.setStoreToMarker(markerItem.store_id)
      this.showEditModal = true
    },
    prepareMap (markerItem) {
      this.curEditMarkerItem = markerItem
      this.showMapModal = true
    },
    // 资源主页下拉框变更触发事件
    setResourceToMarker (resourceId) {
      this.curEditMarkerItem.bindResourceId = resourceId
      return true
    },
    // 店铺下拉框变更触发事件
    setStoreToMarker (storeId) {
      this.curEditMarkerItem.bindStoreId = storeId
      return true
    },
    // 确认删除
    async deleteMarker () {
      let response = await api.deleteMyMarker(this.curDeleteMarkerId)
      if (response.code === 200) {
        this.showDeleteTip = false
        // 刷新页面数据
        let newMarkerList = []
        for (let k in this.myMarkerList) {
          if (this.myMarkerList[k].id !== this.curDeleteMarkerId) {
            newMarkerList.push(this.myMarkerList[k])
          }
        }
        this.myMarkerList = newMarkerList
        this.curDeleteMarkerId = ''
      }
    },
    // 保存修改
    async saveEditMarker () {
      if (!this.curEditMarkerItem) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_EDIT_MARKER_EMPTY, type: 'error'})
        return false
      }
      if (this.curEditMarkerItem.bindResourceId || this.curEditMarkerItem.bindStoreId) {
        let params = {
          marker_id: this.curEditMarkerItem.id,
          name: this.curEditMarkerItem.name,
          mobile: this.curEditMarkerItem.mobile,
          resource_id: this.curEditMarkerItem.bindResourceId || '',
          // TODO: 添加店铺绑定的相关操作
          store_id: this.curEditMarkerItem.bindStoreId || ''
        }
        let response = await api.editMyMarker(params)
        if (response.code === 200) {
          this.showEditModal = false
          // 刷新页面数据
          let newMarkerList = this.myMarkerList
          for (let k in newMarkerList) {
            if (newMarkerList[k].id === this.curEditMarkerItem.id) {
              newMarkerList[k] = this.curEditMarkerItem
            }
          }
          this.myMarkerList = newMarkerList
          this.curEditMarkerItem = {}
          this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_MARKER_SAVE_OK, type: 'success'})
        }
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_RES_OR_STORE_EMPTY, type: 'error'})
        return false
      }
    },
    // 重新定位
    async relocationMyMarker (mapAddress) {
      let params = {
        marker_id: this.curEditMarkerItem.id,
        lng: mapAddress.point.lng,
        lat: mapAddress.point.lat,
        address: mapAddress.addressData.address
      }
      let response = await api.relocationMyMarker(params)
      if (response.code === 200) {
        this.showMapModal = false
        // 刷新页面数据
        let newMarkerList = this.myMarkerList
        for (let k in newMarkerList) {
          if (newMarkerList[k].id === this.curEditMarkerItem.id) {
            newMarkerList[k].lng = params.lng
            newMarkerList[k].lat = params.lat
            newMarkerList[k].address = params.address
          }
        }
        this.myMarkerList = newMarkerList
        this.curEditMarkerItem = {}
        this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_MARKER_RELOCATION_OK, type: 'success'})
      }
    }
  },
  components: {
    FaMap,
    ListNothing,
    'i-button': Button,
    'i-icon': Icon,
    'i-modal': Modal,
    'i-input': Input,
    'i-select': Select,
    'i-option': Option,
    'i-form': Form,
    'i-form-item': FormItem
  }
}
</script>

<style lang="stylus">
.edit-marker-page
  font-size: 16px
  .tips
    padding-bottom: 30px
  .edit-marker-list
    display: flex
    flex-wrap: wrap
    margin-right: -20px
    flex-direction: row
    .marker-card
      width: 315px
      height: 190px
      padding: 20px
      border-radius: 4px
      margin: 0 20px 20px 0
      border: 1px solid $grey-high4
      .marker-info
        padding-bottom: 10px
        border-bottom: 1px dashed $grey-high4
        .marker-name
          color: $black
          font-size: 18px
          margin-bottom: 15px
        .item-line
          font-size: 16px
          color: $grey-high
          vertical-align: middle
          label
            width: 65px
            height: 28px
            line-height: 28px
            overflow hidden
            display: inline-block
            text-align: justify
            /* 实现文字两端对齐 */
            &:after
              content: ''
              display: inline-block
              padding-left: 100%
          span
            height: 28px
            line-height: 28px
            vertical-align: top
            display: inline-block
      .operation-box
        .ivu-btn
          height: 23px
          padding:0 21px
          font-size: 14px
          line-height: 23px
          color: $orange
          border-radius: 0
          margin-top: 10px
          border-right: 1px solid $grey-high4
          &:last-child
            border: none
            padding-right: 0
          &:first-child
            padding-left: 0
        .ivu-btn-text:focus
          box-shadow: none
        .fy-icon-delete:before, .fy-icon-edit:before
          color: $orange
        [class*="-icon-"]
          font-size: 14px
          margin-right: 5px
          vertical-align: middle
          display: inline-block
</style>
