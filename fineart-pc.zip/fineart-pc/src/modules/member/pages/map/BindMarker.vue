<template lang="html">
  <div class="bind-marker">
    <i-form class="marker-search-form"
            ref="searchForm"
            :model="searchForm"
            :rules="searchRule">
      <p>您在斐艺地图提交的信息，可以在此页面进行关联，将其绑定到您已开通的合适主页。</p>
      <p class="tip">请先验证您的地图上提交的手机号码</p>
      <i-form-item label="手机号码" prop="mobile">
        <i-input style="width: 280px"
                 placeholder="手机号码"
                 v-model.trim.number="searchForm.mobile"></i-input>
      </i-form-item>
      <i-form-item label="短信验证码" prop="code">
        <i-input style="width: 166px"
                 placeholder="短信验证码"
                 v-model.trim.number="searchForm.code"></i-input>
        <i-button class="send-code-btn" @click="fetchSmsCode" type="primary" ghost :disabled="isCodeBtnDisabled">{{ codeBtnLabel }}</i-button>
      </i-form-item>
      <i-form-item>
        <i-button class="search-info" type="primary" @click="searchMapMarkerList">搜索地图标记</i-button>
      </i-form-item>
    </i-form>
    <div class="result-box">
      <p class="result-title">搜索结果<span>手机号码匹配且未绑定主页</span></p>
      <div class="result-item" v-for="(item, key) in mapMarkerList" :key="key">
        <div class="info">
          <p class="info-title">{{ item.name }}</p>
          <div class="info-item">
            <label>类型：</label>
            <span>{{ item.category_name }}</span>
          </div>
          <div class="info-item">
            <label>手机号：</label>
            <span>{{ item.mobile }}</span>
          </div>
        </div>
        <div class="select-box">
          <p>绑定到：</p>
          <i-select @on-change="setResourceToMarker" :disabled="item.disabled">
            <i-option v-for="(res, k) in resourceList" :key="k" :value="JSON.stringify({markerKey: key, resKey: k})">{{ res.resource_name }}</i-option>
          </i-select>
          <i-select @on-change="setStoreToMarker" :disabled="item.disabled" class="store-selelct">
            <i-option v-for="(res, k) in storeList" :key="k" :value="JSON.stringify({markerKey: key, storeKey: k})">{{ res.store_name }}</i-option>
          </i-select>
          <i-button class="binding-btn" long @click="bindResourceAndMarker(key)" :disabled="item.disabled">{{ item.bindBtnText }}</i-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Input, Form, FormItem, Button, Select, Option } from 'iview'
import api from 'modules/member/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'BindingInfo',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{10}$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      searchForm: {
        mobile: '',
        code: ''
      },
      searchRule: {
        mobile: [
          {
            required: true,
            message: '请输入手机号'
          },
          {
            // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
            validator: mobileValidator
          }
        ],
        code: [
          {
            required: true,
            message: '请输入验证码'
          }
        ]
      },
      verifiedMobile: '', // 已经经过验证的手机号
      mapMarkerList: [],
      initCount: 60, // 获取短信验证码按钮初始冷却计数
      count: 60, // 获取短息验证码当前冷却计数
      counter: null, // 计数器
      resourceList: [],
      storeList: []
    }
  },
  computed: {
    isCodeBtnDisabled () {
      return this.count < 60
    },
    codeBtnLabel () {
      // 当计时器工作时，即获取验证码处于冷却中，显示当前计数
      return this.isCodeBtnDisabled ? `${this.count}s` : '获取验证码'
    }
  },
  methods: {
    startCount () {
      this.counter = setInterval(() => {
        --this.count
        if (this.count <= 0) {
          this.stopCount()
        }
      }, 1000)
    },
    stopCount () {
      this.count = this.initCount
      clearInterval(this.counter)
    },
    // 获取短信验证码
    fetchSmsCode () {
      const cb = async (result) => {
        if (!result) {
          let mobile = this.searchForm.mobile
          const response = await api.fetchCode({ type: 206, mobile: mobile })
          if (response.code === 200) {
            this.startCount()
            this.$store.commit('ADD_MESSAGE', { msg: MSG['SEND_CODE_SUCCESS'], type: 'success' })
          }
        }
      }
      this.$refs.searchForm.validateField('mobile', cb)
    },
    // 搜索手机号对应的地图标记数据
    async searchMapMarkerList () {
      const result = await this.$refs.searchForm.validate()
      if (!result) {
        return false
      }
      let markerList = await api.fetchMapMarkerList(this.searchForm)
      if (!markerList || !markerList.data || markerList.data.length === 0) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_MARKER_EMPTY, type: 'info'})
        return false
      }
      for (let k in markerList.data) {
        markerList.data[k].bindRes = null
        markerList.data[k].disabled = false
        markerList.data[k].bindBtnText = '确认绑定'
      }
      this.mapMarkerList = markerList.data
      // 且存在Marker数据才认为手机号有效，可以作为下一步绑定的依据
      this.verifiedMobile = this.searchForm.mobile
      this.fetchResourceList()
      this.fetchStoreList()
    },
    // 获取可以被绑定的资源主页
    async fetchResourceList () {
      this.resourceList = await api.fetchResourceListForMarker()
    },
    // 获取可以被绑定的店铺
    async fetchStoreList () {
      this.storeList = await api.fetchStoreListForMarker()
    },
    // 资源主页下拉框变更触发事件
    setResourceToMarker (keyString) {
      let keyObj = JSON.parse(keyString)
      // 把将要绑定的资源绑定到地图标记上
      this.mapMarkerList[keyObj.markerKey].bindResourceId = this.resourceList[keyObj.resKey].resource_id
    },
    // 店铺下拉框变更触发事件
    setStoreToMarker (keyString) {
      let keyObj = JSON.parse(keyString)
      // 把将要绑定的店铺绑定到地图标记上
      this.mapMarkerList[keyObj.markerKey].bindStoreId = this.storeList[keyObj.storeKey].store_id
    },
    // 地图标签绑定资源主页
    async bindResourceAndMarker (markerKey) {
      let curMarker = this.mapMarkerList[markerKey]
      if (curMarker.bindResourceId || curMarker.bindStoreId) {
        let params = {
          mobile: this.verifiedMobile,
          marker_id: curMarker.id,
          resource_id: curMarker.bindResourceId || '',
          // TODO: 添加店铺绑定的相关操作
          store_id: curMarker.bindStoreId || ''
        }
        let response = await api.bindResourceAndMarker(params)
        if (response.code === 200) {
          // 禁用 资源选择下拉框 和 确定按钮
          this.mapMarkerList[markerKey].disabled = true
          this.mapMarkerList[markerKey].bindBtnText = '已绑定'
          this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_MARKER_BIND_OK, type: 'success'})
        }
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: MSG.ACCOUNT_MAP_RES_OR_STORE_EMPTY, type: 'error'})
        return false
      }
    }
  },
  components: {
    'i-form': Form,
    'i-input': Input,
    'i-button': Button,
    'i-select': Select,
    'i-option': Option,
    'i-form-item': FormItem
  }
}
</script>

<style lang="stylus">
.bind-marker
  position: relative
  font-size: 16px
  color: $black1
  .marker-search-form
    border-bottom: 1px dashed $grey-high4
    p
      margin-bottom: 30px
    .tip
      font-size: 14px
    .ivu-form-item
      margin-bottom: 30px
    .ivu-form-item-label
      width: 96px
      height: 40px
      padding: 0
      margin-right: 20px
      font-size: 16px
      color: $black1
      line-height: 40px
      text-align: left
    .ivu-input
      font-size: 16px
    .send-code-btn
      padding: 0
      width: 104px
      height: 40px
      color: $orange
      font-size: 16px
      margin-left: 6px
      border: 1px solid $orange
    .search-info
      width: 280px
      height: 40px
      padding: 0
      font-size: 16px
      margin-left: 114px
    /*验证时文字位置*/
    .ivu-form-item-error-tip
      left: 114px
  .result-box
    font-size: 0
    margin-right: -20px
    .result-title
      font-size: 18px
      color: $black
      padding: 30px 0
      span
        font-size: 14px
        color: $grey-high
        padding-left: 10px
    .store-selelct
      margin-top: 10px
    .result-item
      width: 315px
      height: 372px
      padding: 20px
      margin: 0 20px 20px 0
      display: inline-block
      border: 1px solid $grey-high4
      .info
        padding-bottom: 10px
        border-bottom: 1px dashed $grey-high4
        p
          color: $black
          font-size: 18px
          margin-bottom: 15px
        .info-item
          font-size: 16px
          color: $grey-high
          vertical-align: middle
          label
            width: 65px
            height: 28px
            line-height: 28px
            overflow hidden
            display: inline-block
            text-align: justify
            /* 实现文字两端对齐 */
            &:after
              content: ''
              display: inline-block
              padding-left: 100%
          span
            height: 28px
            line-height: 28px
            vertical-align: top
            display: inline-block
      .select-box
        p
          font-size: 14px
          color: $grey-high
          padding: 18px 0
        .binding-btn
          color: $orange
          height: 40px
          font-size: 16px
          margin-top: 20px
          border: 1px solid $orange
          &:disabled
            border: 1px solid $grey-high4
            color: $grey-high
        .ivu-select-placeholder, .ivu-select-selected-value
          font-size: 16px
</style>
