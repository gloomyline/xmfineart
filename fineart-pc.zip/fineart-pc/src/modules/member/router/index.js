import Vue from 'vue'
import VueRouter from 'vue-router'
import AccountSecurity from 'modules/member/pages/account/AccountSecurity.vue'
import Account from 'modules/member/pages/account/Account.vue'
import RealName from 'modules/member/pages/account/RealName.vue'
import ChangeMobile from 'modules/member/pages/account/ChangeMobile.vue'

import MyCollection from 'modules/member/pages/account/MyCollection.vue'
import CollectionGoods from 'modules/member/pages/account/CollectionGoods.vue'
import CollectionStore from 'modules/member/pages/account/CollectionStore.vue'
import CollectionResource from 'modules/member/pages/account/CollectionResource.vue'
import CollectionBuilding from 'modules/member/pages/account/CollectionBuilding.vue'

import MyReservation from 'modules/member/pages/account/MyReservation.vue'
import MyAddress from 'modules/member/pages/account/MyAddress.vue'

import MyOrder from 'modules/member/pages/order/MyOrder.vue'
import OrderDetail from 'modules/member/pages/order/OrderDetail.vue'
import OrderComment from 'modules/member/pages/order/OrderComment.vue'
import SaleService from 'modules/member/pages/order/SaleService.vue'
import ApplyForService from 'modules/member/pages/order/ApplyForService.vue'

import MapManage from 'modules/member/pages/map/MapManage.vue'
import BindMarker from 'modules/member/pages/map/BindMarker.vue'
import EditMarker from 'modules/member/pages/map/EditMarker.vue'

import HomeManage from 'modules/member/pages/home/HomeManage.vue'
import ChoiceHome from 'modules/member/pages/home/ChoiceHome.vue'
import OpenHomePerson from 'modules/member/pages/home/OpenHomePerson.vue'
import OpenHomeCompany from 'modules/member/pages/home/OpenHomeCompany.vue'
import OpenHomeSupplier from 'modules/member/pages/home/OpenHomeSupplier.vue'
import OpenHomeBrand from 'modules/member/pages/home/OpenHomeBrand.vue'
import OpenHomeDecorator from 'modules/member/pages/home/OpenHomeDecorator.vue'

import BusinessManage from 'modules/member/pages/business/BusinessManage.vue'
import ChooseStore from 'modules/member/pages/business/ChooseStore.vue'
import CreateStore from 'modules/member/pages/business/CreateStore.vue'

import StoreManage from 'modules/member/pages/business/StoreManage.vue'
import HasSold from 'modules/member/pages/business/HasSold.vue'
import StoreOrderDetail from 'modules/member/pages/business/StoreOrderDetail.vue'
import MyGoods from 'modules/member/pages/business/MyGoods.vue'
import ReleaseGoods from 'modules/member/pages/business/ReleaseGoods.vue'

import StoreInfo from 'modules/member/pages/business/StoreInfo.vue'
import Comment from 'modules/member/pages/business/Comment.vue'
import AfterSales from 'modules/member/pages/business/AfterSales.vue'
import HandledService from 'modules/member/pages/business/HandledService.vue'
import UnhandledService from 'modules/member/pages/business/UnhandledService.vue'
import AgentGoods from 'modules/member/pages/business/AgentGoods.vue'
import AgentSalesRecord from 'modules/member/pages/business/AgentSalesRecord.vue'
import AgentSettlementRecord from 'modules/member/pages/business/AgentSettlementRecord.vue'

import PromotionGoods from 'modules/member/pages/business/PromotionGoods.vue'
import PromoteSalesRecord from 'modules/member/pages/business/PromoteSalesRecord.vue'
import SettlementRecord from 'modules/member/pages/business/SettlementRecord.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'AccountSecurity',
    component: AccountSecurity,
    redirect: {
      name: 'Account'
    },
    meta: {
      order: 1,
      requiresAuth: true
    },
    children: [
      {
        path: 'account',
        name: 'Account',
        meta: {
          order: 1,
          listOrder: 1,
          requiresAuth: true
        },
        component: Account
      },
      {
        path: 'real-name',
        name: 'RealName',
        meta: {
          order: 1,
          listOrder: 2,
          requiresAuth: true
        },
        component: RealName
      },
      {
        path: 'change-mobile',
        name: 'ChangeMobile',
        meta: {
          order: 1,
          listOrder: 4,
          requiresAuth: true
        },
        component: ChangeMobile
      }
    ]
  },
  {
    path: '/my-collection',
    name: 'MyCollection',
    meta: {
      order: 2,
      requiresAuth: true
    },
    redirect: {
      name: 'CollectionGoods'
    },
    component: MyCollection,
    children: [
      {
        path: 'collection-goods',
        name: 'CollectionGoods',
        meta: {
          order: 2,
          listOrder: 1,
          requiresAuth: true
        },
        component: CollectionGoods
      },
      {
        path: 'collection-store',
        name: 'CollectionStore',
        meta: {
          order: 2,
          listOrder: 2,
          requiresAuth: true
        },
        component: CollectionStore
      },
      {
        path: 'collection-resource',
        name: 'CollectionResource',
        meta: {
          order: 2,
          listOrder: 3,
          requiresAuth: true
        },
        component: CollectionResource
      },
      {
        path: 'collection-building',
        name: 'CollectionBuilding',
        meta: {
          order: 2,
          listOrder: 4,
          requiresAuth: true
        },
        component: CollectionBuilding
      }
    ]
  },
  {
    path: '/my-reservation',
    name: 'MyReservation',
    component: MyReservation,
    meta: {
      order: 3,
      requiresAuth: true
    }
  },
  {
    path: '/my-address',
    name: 'MyAddress',
    component: MyAddress,
    meta: {
      order: 4,
      requiresAuth: true
    }
  },
  {
    path: '/my-order',
    name: 'MyOrder',
    component: MyOrder,
    meta: {
      order: 5,
      requiresAuth: true
    }
  },
  {
    path: '/order-detail/:id',
    name: 'OrderDetail',
    component: OrderDetail,
    meta: {
      order: 5,
      requiresAuth: true
    }
  },
  {
    path: '/order-comment/:orderId',
    name: 'OrderComment',
    component: OrderComment,
    props: true,
    meta: {
      order: 5,
      requiresAuth: true
    }
  },
  {
    path: '/sale-service/:orderId',
    name: 'SaleService',
    component: SaleService,
    meta: {
      order: 5,
      requiresAuth: true
    }
  },
  {
    path: '/apply-for-service/:orderId',
    name: 'ApplyForService',
    component: ApplyForService,
    meta: {
      order: 5,
      requiresAuth: true
    }
  },
  {
    path: '/map-manage',
    name: 'MapManage',
    component: MapManage,
    redirect: {
      name: 'BindMarker'
    },
    meta: {
      order: 11,
      requiresAuth: true
    },
    children: [
      {
        path: 'bind-marker',
        name: 'BindMarker',
        meta: {
          order: 11,
          listOrder: 1,
          requiresAuth: true
        },
        component: BindMarker
      },
      {
        path: 'edit-marker',
        name: 'EditMarker',
        meta: {
          order: 11,
          listOrder: 2,
          requiresAuth: true
        },
        component: EditMarker
      }
    ]
  },
  {
    path: '/home-manage',
    name: 'HomeManage',
    component: HomeManage,
    redirect: {
      name: 'ChoiceHome'
    },
    meta: {
      order: 10,
      requiresAuth: true
    },
    children: [
      {
        path: 'choice-home',
        name: 'ChoiceHome',
        component: ChoiceHome,
        meta: {
          order: 10,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'open-home/100/:id?',
        name: 'OpenHomePerson',
        component: OpenHomePerson,
        meta: {
          order: 10,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'open-home/200/:id?',
        name: 'OpenHomeCompany',
        component: OpenHomeCompany,
        meta: {
          order: 10,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'open-home/300/:id?',
        name: 'OpenHomeSupplier',
        component: OpenHomeSupplier,
        meta: {
          order: 10,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'open-home/400/:id?',
        name: 'OpenHomeBrand',
        component: OpenHomeBrand,
        meta: {
          order: 10,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'open-home/500/:id?',
        name: 'OpenHomeDecorator',
        component: OpenHomeDecorator,
        meta: {
          order: 10,
          listOrder: 1,
          requiresAuth: true
        }
      }
    ]
  },
  {
    path: '/business',
    name: 'BusinessManage',
    component: BusinessManage,
    meta: {
      order: 7,
      requiresAuth: true
    },
    redirect: {
      name: 'ChooseStore'
    },
    children: [
      {
        path: 'choose-store',
        name: 'ChooseStore',
        component: ChooseStore,
        meta: {
          order: 7,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'create-store/:id?',
        name: 'CreateStore',
        component: CreateStore,
        meta: {
          order: 7,
          listOrder: 1,
          requiresAuth: true
        }
      }
    ]
  },
  {
    path: '/store-manage',
    name: 'StoreManage',
    component: StoreManage,
    meta: {
      order: 8,
      requiresAuth: true
    },
    redirect: {
      name: 'HasSold'
    },
    children: [
      {
        path: 'has-sold/:storeId?',
        name: 'HasSold',
        component: HasSold,
        meta: {
          order: 8,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'order-detail/:orderId',
        name: 'StoreOrderDetail',
        component: StoreOrderDetail,
        meta: {
          order: 8,
          listOrder: 1,
          requiresAuth: true
        }
      },
      {
        path: 'my-goods/:status?',
        name: 'MyGoods',
        component: MyGoods,
        meta: {
          order: 8,
          listOrder: 2,
          requiresAuth: true
        }
      },
      {
        path: 'release-goods',
        name: 'ReleaseGoods',
        component: ReleaseGoods,
        meta: {
          order: 8,
          listOrder: 2,
          requiresAuth: true
        }
      },
      {
        path: 'edit-goods/:goodsId',
        name: 'EditGoods',
        component: ReleaseGoods,
        meta: {
          order: 8,
          listOrder: 2,
          requiresAuth: true
        }
      },
      {
        path: 'store-info',
        name: 'StoreInfo',
        component: StoreInfo,
        meta: {
          order: 8,
          listOrder: 3,
          requiresAuth: true
        }
      },
      {
        path: 'comment',
        name: 'Comment',
        component: Comment,
        meta: {
          order: 8,
          listOrder: 4,
          requiresAuth: true
        }
      },
      {
        path: 'after-sales',
        name: 'AfterSales',
        component: AfterSales,
        meta: {
          order: 8,
          listOrder: 5,
          requiresAuth: true
        }
      },
      {
        path: 'handled-service/:serviceId',
        name: 'HandledService',
        component: HandledService,
        meta: {
          order: 8,
          listOrder: 5,
          requiresAuth: true
        }
      },
      {
        path: 'unhandled-service/:serviceId',
        name: 'UnhandledService',
        component: UnhandledService,
        meta: {
          order: 8,
          listOrder: 6,
          requiresAuth: true
        }
      },
      {
        path: 'agent-goods',
        name: 'AgentGoods',
        component: AgentGoods,
        meta: {
          order: 8,
          listOrder: 6,
          requiresAuth: true
        }
      },
      {
        path: 'agent-sales-record',
        name: 'AgentSalesRecord',
        component: AgentSalesRecord,
        meta: {
          order: 8,
          listOrder: 6,
          requiresAuth: true
        }
      },
      {
        path: 'agent-settlement-record',
        name: AgentSettlementRecord,
        component: AgentSettlementRecord,
        meta: {
          order: 8,
          listOrder: 6,
          requiresAuth: true
        }
      }
    ]
  },
  {
    path: '/promotion-goods',
    name: 'PromotionGoods',
    component: PromotionGoods,
    meta: {
      order: 9,
      requiresAuth: true
    }
  },
  {
    path: '/promote-sales-record',
    name: 'PromoteSalesRecord',
    component: PromoteSalesRecord,
    meta: {
      order: 9,
      requiresAuth: true
    }
  },
  {
    path: '/settlement-record',
    name: 'SettlementRecord',
    component: SettlementRecord,
    meta: {
      order: 9,
      requiresAuth: true
    }
  }
]

export default new VueRouter({ routes })
