/**
 * @comment:
 * @author: alan_wang
 * @date: 08/10/2018
 * @time: 17:24:24
 */

export default function (cls) {
  cls.prototype.fetchAdsList = async function () {
    const response = await cls.request({
      url: '/sys/ads/${type}',
      params: { type: 10 }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchRecommendData = async function ({ position, limit }) {
    const response = await cls.request({
      url: '/sys/recommend/${position}/${limit}',
      params: { position, limit }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchCommonFaqList = async function () {
    const response = await cls.request({
      url: '/sys/faq',
      params: {}
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchNoticeList = async function (page = 1) {
    const response = await cls.request({
      url: '/sys/notice',
      query: { page }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchNoticeDetail = async function (id) {
    const response = await cls.request({
      url: '/sys/notice/${id}',
      params: { id }
    })
    if (response.code === 200) {
      return response.results
    }
  }
}
