/*
* @Author: Alan
* @Date:   2018-09-06 20:15:17
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-21 14:28:28
*/
import Vue from 'vue'
import Router from 'vue-router'
import Home from 'modules/index/pages/Home.vue'
import AboutUs from 'modules/index/pages/AboutUs.vue'
import ContactUS from 'modules/index/pages/ContactUs.vue'
import CommonFaq from 'modules/index/pages/CommonFaq.vue'
import NoticeList from 'modules/index/pages/NoticeList.vue'
import Page403 from 'components/403.vue'
import Page404 from 'components/404.vue'
import NoticeDetail from 'modules/index/pages/NoticeDetail.vue'
import Protocol from 'modules/index/pages/Protocol.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about-us',
      name: 'AboutUs',
      component: AboutUs
    },
    {
      path: '/contact-us',
      name: 'ContactUs',
      component: ContactUS
    },
    {
      path: '/common-faq',
      name: 'CommonFaq',
      component: CommonFaq
    },
    {
      path: '/notice-list',
      name: 'NoticeList',
      component: NoticeList
    },
    {
      path: '/403',
      name: '403',
      component: Page403
    },
    {
      path: '/404',
      name: '404',
      component: Page404
    },
    {
      path: '/notice-detail/:id',
      name: 'NoticeDetail',
      component: NoticeDetail,
      props: true
    },
    {
      path: '/protocol',
      name: 'Protocol',
      component: Protocol
    }
  ]
})
