<template lang="html">
  <Page class="home-pages">
    <i-carousel v-model="carouselIndex" loop arrow="always" autoplay :autoplay-speed="4000" class="swiper-wrap">
      <i-carousel-item v-for="(item, index) in adsList" :key="index">
        <a :href="item.link_url" class="carousel-banner" :style="{ backgroundImage: `url(${item.image_url})` }"></a>
      </i-carousel-item>
    </i-carousel>
    <section class="page-content">
      <div class="module-title">
        <h3 class="module-title-ch">斐艺地图</h3>
        <h3 class="module-title-en">FINE ART MAP</h3>
        <a href="map.html" title="斐艺地图" class="jump-icon">
          <span class="fy-icon-nextstep-black"></span>
        </a>
      </div>
      <!--地图-->
      <div class="map-exhibition">
        <div class="map-word">
          <p class="text-describe"><em>F</em>斐艺地图 — 连接你的服务，以地图的形式就地、就近化连接泛建筑全行业供需方，创造更多可能性。</p>
            <dl class="map-role">
              <dt class="map-role-img"><img src="../../../assets/fineart/map-find-icon.png" alt="发现"></dt>
              <dd class="map-role-word">
                <div class="map-role-word-wrap">
                  <p class="map-role-title">发现</p>
                  <p class="map-role-tip">找到最近的服务者</p>
                </div>
              </dd>
            </dl>
            <dl class="map-role">
              <dt class="map-role-img"><img src="../../../assets/fineart/map-join-icon.png" alt="发现"></dt>
              <dd class="map-role-word">
                <div class="map-role-word-wrap">
                  <p class="map-role-title">加入</p>
                  <p class="map-role-tip">提交信息，为您创造更多机会</p>
                </div>
              </dd>
            </dl>
        </div>
        <div class="map-pic">
          <img src="../../../assets/fineart/map-phone.png" alt="斐艺地图">
        </div>
      </div>
      <div class="module-title">
        <h3 class="module-title-ch">人气商品</h3>
        <h3 class="module-title-en">POPULAR GOODS</h3>
        <a href="mall.html" title="人气商品" class="jump-icon">
          <span class="fy-icon-nextstep-black"></span>
        </a>
      </div>
      <!--人气商品-->
      <div class="popular-goods">
        <div class="goods-card" v-for="item in goodsList" :key="item.object_id">
          <a :href="`mall.html#/goods-detail/${item.object_id}/${item.store_id}`">
            <div class="goods-img">
              <img :src="item.thumbnail" :alt="item.name" />
            </div>
            <h3>
              <p class="goods-name">{{ item.name }}</p>
              <p class="goods-price">&yen;{{ item.price_norm }}</p>
            </h3>
          </a>
        </div>
      </div>
      <div class="module-title">
        <h3 class="module-title-ch">优秀资源</h3>
        <h3 class="module-title-en">EXCELLENT RESOURCES</h3>
        <a href="resource.html" title="优秀资源" class="jump-icon">
          <span class="fy-icon-nextstep-black"></span>
        </a>
      </div>
      <!--优秀资源-->
      <ul class="excellent-resources">
        <li class="resource-item"
            v-for="item in resourceList"
            :key="item.object_id"
            @click="goToResource(item.object_id, item.mode)">
          <div class="resource">
            <img :src="item.thumbnail" class="resource-img" :alt="item.name" />
            <div class="resource-detail">
              <div>
                <h3 class="resource-title">{{ item.name }}</h3>
                <h4 class="resource-subtitle">{{ item.subtitle }}</h4>
                <p class="resource-info">{{ item.introduction | labelFormatter(85) }}</p>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <div class="module-title">
        <h3 class="module-title-ch">品质建筑</h3>
        <h3 class="module-title-en">QUALITY ARCHITECTURE</h3>
        <a href="building.html" title="品质建筑" class="jump-icon">
          <span class="fy-icon-nextstep-black"></span>
        </a>
      </div>
      <!--品质建筑-->
      <div class="quality-architecture">
        <div class="quality-wrap" v-for="item in buildingList" :key="item.object_id">
          <div class="quality quality-img">
            <a :href="`/building.html#/building-detail/${item.object_id}`">
              <img :src="item.thumbnail" :alt="item.name" />
            </a>
          </div>
          <div class="quality quality-word" @click="goBuildingDetail(item.object_id)">
            <div class="quality-word-wrap">
              <h3 class="quality-word-title">{{ item.name }}</h3>
              <h6 class="quality-word-subtitle">{{ item.subtitle }}</h6>
              <i-divider class="quality-short"></i-divider>
              <span class="quality-word-info">{{ item.introduction | labelFormatter(35) }}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
    <jump-top></jump-top>
  </Page>
</template>

<script>
import { Page, JumpTop } from 'components/index.js'
import { Carousel, CarouselItem, Divider } from 'iview'

import api from 'modules/index/api/index.js'

export default {
  data () {
    return {
      carouselIndex: 0,
      adsList: [],
      goodsList: [],
      resourceList: [],
      buildingList: []
    }
  },
  created () {
    this.initAdsList()
    this.initPopularGoods()
    this.initExcellentResources()
    this.initGoodQualityBuildings()
    this.isShowLogin()
  },
  methods: {
    isShowLogin () { // 从会员中心过来显示登录弹窗
      const user = this.$localStorage.getUser()
      if (user && user.memberIsLogin && !user.memberIsLogin) {
        this.$store.commit('SHOW_LOGIN_MODAL')
        // 显示完弹窗重置 memberIsLogin
        this.$localStorage.setUser({ token: null, isLogin: false, memberIsLogin: true })
      }
    },
    async initAdsList () {
      this.adsList = await api.fetchAdsList()
    },
    // 商品
    async initPopularGoods () {
      this.goodsList = await api.fetchRecommendData({ position: 100, limit: 4 })
    },
    // 资源
    async initExcellentResources () {
      this.resourceList = await api.fetchRecommendData({ position: 400, limit: 3 })
    },
    // 建筑
    async initGoodQualityBuildings () {
      this.buildingList = await api.fetchRecommendData({ position: 500, limit: 3 })
    },
    goBuildingDetail (id) {
      window.location = `/building.html#/building-detail/${id}`
    },
    goToResource (id, mode) {
      let path = ''
      switch (mode) {
      case '100':
        path = 'person'
        break
      case '200':
        path = 'company'
        break
      case '300':
        path = 'supplier'
        break
      case '400':
        path = 'brand'
        break
      }
      window.location = `/resource.html#/${path}-home/${id}`
    }
  },
  components: {
    Page,
    JumpTop,
    'i-carousel': Carousel,
    'i-divider': Divider,
    'i-carousel-item': CarouselItem
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  }
}
</script>

<style lang="stylus">
.home-pages
  .swiper-wrap
    width: 100%
    height: 400px
    margin-bottom: 100px
    text-align center
    background-color: rgba(0, 0, 0, 0.05)
    .ivu-carousel-arrow
      width: 56px
      height: 56px
      opacity: 0.7
      &.left
        left: 164px
      &.right
        right: 164px
      .ivu-icon
        font-size: 34px
    .ivu-carousel-dots li button
      width: 26px
      height: 4px
      background: rgba(255, 255, 255, 0.6)
    .ivu-carousel-dots .ivu-carousel-active button
        background-color: $orange
    .carousel-banner
      display: block
      width: 100%
      height: 400px
      background-position: center center
      background-repeat: no-repeat
      background-size: cover
  .module-title
    display: flex
    align-content: center
    flex-direction: column
    width: 100%
    h3
      text-align: center
      &.module-title-ch
        font-size: 24px
        color: $black
      &.module-title-en
        font-size: 14px
        color: $grey-high1
    .jump-icon
      display: block
      width: 64px
      height: 64px
      margin: 10px auto 0
      text-align: center
      color: $black
      border-radius: 100px
      span
        font-size: 34px
        line-height: 64px
      &:hover
        box-shadow: 0 3px 10px 0 rgba(0, 0, 0, 0.13);
  .map-exhibition
    display: flex
    margin-bottom: 110px
    .map-word
      width: 500px
      .text-describe
        position: relative
        margin-bottom: 90px
        padding: 70px 0 0 60px;
        font-size: 16px
        color: $black
        em
          absolute: left bottom -25px
          font-size: 150px
          font-family: Arial-Black
          font-weight: 900
          line-height: 150px
          color: rgba(102, 102, 102, 0.08)
    .map-picture
      width: 700px
    .map-role
      display: flex
      margin-bottom: 24px
      .map-role-img
        width: 94px
        height: 94px
        margin-right: 26px
        img
          display: block
          width: 94px
          height: 94px
      .map-role-word
        display: flex
        align-items: center
        height: 94px
        .map-role-title
          color: $black
          font-size: 18px
        .map-role-tip
          color: $black1
  .popular-goods
    display: flex
    justify-content: space-between
    margin: 40px 0 110px 0
    .goods-card
      width: 290px
      .goods-img
        position: relative
        height: 290px
        margin-bottom: 20px
        background-color: $grey-high2
        img
          absolute: left 50% top 50%
          max-width: 100%
          max-height: 100%
          transform: translate(-50%, -50%)
      .goods-name
        text-align: center
        font-weight: normal
        font-size: 18px
        color: $black
        {ellipse}
      .goods-price
        text-align center
        font-size: 16px
        color: $orange
  .excellent-resources
    margin: 55px 0 110px 0
    .resource-item
      position: relative
      left: 50%
      display: flex
      align-items: center
      width: 1200px
      height: 226px
      margin-bottom: 40px
      background-color: $grey-high2
      transform: translateX(-50%)
      transition: all .4s ease-in-out
      &:hover
        width: 1260px
        height: 234px
        background-color: $white
        box-shadow: 0 4px 16px 0 rgba(0, 0, 0, 0.1)
      .resource
        width: 100%
        height: 226px
        padding: 20px 24px
        cursor: pointer
        .resource-img
          width: 184px
          height: 184px
          margin-right: 50px
        .resource-detail
          float: left
          display: flex
          align-items: center
          width: 900px
          height: 184px
          .resource-title
            font-size: 24px
            color: $black
          .resource-subtitle
            margin: 16px 0
            font-size: 20px
            color: $black1
          .resource-info
            overflow: hidden
            font-size: 16px
            color: $grey-high
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2
      &:nth-child(odd) .resource-img
        float: left
      &:nth-child(even) .resource-img
        float: right
        margin-right: 0
  .quality-architecture
    display: flex
    flex-wrap: wrap
    margin: 3px 0 110px 0
    .quality-wrap
      width: 33.33%
      &:nth-child(even)
        display: flex
        flex-direction: column-reverse
      .quality
        width: 100%
        height: 400px
        &.quality-img
          overflow: hidden
          &:hover
            box-shadow: 0 4px 20px 0 rgba(0, 0, 0, 0.5)
          img
            display: block
            width: 100%
            height: 100%
        &.quality-word
          display: flex
          justify-content: center
          align-items: center
          .quality-word-wrap
            width: 300px
            text-align: center
            .quality-word-title
              color: $black
              font-size: 22px
              margin-bottom: 20px
              {ellipse}
            .quality-word-subtitle
              color: $black1
              font-size: 16px
            .quality-word-info
              overflow: hidden
              color: $black1
              font-size: 16px
              display: -webkit-box
              -webkit-box-orient: vertical
              -webkit-line-clamp: 2
            .quality-short
              width: 82px
              margin: 25px auto
              background-color: $black1
</style>
