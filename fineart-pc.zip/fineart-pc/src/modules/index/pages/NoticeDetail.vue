<template>
<Page>
  <section class="page-content notice-detail">
    <div class="notice-title">{{notice.title}}</div>
    <div class="notice-time">{{notice.created_at}}</div>
    <div class="notice-content" v-html="notice.content"></div>
  </section>
</Page>
</template>

<script>
import { Page } from 'components'
import api from 'modules/index/api/index.js'

export default {
  name: 'NoticeDetail',
  props: {
    id: {
      type: String,
      required: true
    }
  },
  data () {
    return {
      notice: {}
    }
  },
  created () {
    this.initNotice()
  },
  methods: {
    async initNotice () {
      this.notice = await api.fetchNoticeDetail(this.id)
    }
  },
  components: {
    Page
  }
}
</script>

<style lang="stylus">
.notice-detail
  .notice-title
    margin-top: 60px
    font-size: 26px
    color: $black
    font-weight:500
  .notice-time
    font-size: 18px
    color: $grey-high
    padding:20px 0
  .notice-content
    font-size: 16px
    color: $black1
    padding:20px 0
    line-height 32px
    img
      max-width: 1200px
</style>
