<template>
  <Page>
    <fineart-subtitle :titleCh="subtitle.titleCh" :titleEn="subtitle.titleEn" :titleBg="subtitle.titleBg"></fineart-subtitle>
    <section class="page-content contact-us">
      <div class="contact-qrcode">
        <div class="qrcode-obj" v-for="obj in contactInfo.qrcode" :key="obj.text">
          <div class="qrcode-text">{{obj.text}}</div>
          <img :src="obj.img">
        </div>
      </div>
      <div class="contact-content">
        <div>客服电话：{{contactInfo.tel}}</div>
        <div>客服手机号：{{contactInfo.mobile}}</div>
        <div>客服邮箱：{{contactInfo.email}}</div>
        <div>联系地址：{{contactInfo.address}}</div>
      </div>
    </section>
  </Page>
</template>

<script>
import { Page, FineartSubtitle } from 'components'

export default {
  name: 'ContactUs',
  data () {
    return {
      subtitle: {
        titleCh: '联系我们',
        titleEn: 'Contact us',
        titleBg: require('../../../assets/fineart/contact-us-title-bg.png')
      },
      contactInfo: {
        qrcode: [{
          img: require('../../../assets/fineart/fy-qrcode.png'),
          text: '斐艺平台'
        }, {
          img: require('../../../assets/fineart/mz-qrcode.png'),
          text: '美艺美宅'
        }],
        tel: '0592-5217662',
        mobile: '15259268926',
        email: 'kefu@xmfineart.cn',
        address: '厦门市湖里区泗水道597号海富中心A座1301'
      }
    }
  },
  components: {
    Page,
    FineartSubtitle
  }
}
</script>

<style lang="stylus">
.contact-us
  padding-top: 65px
  .contact-qrcode
    width: 566px
    margin: 0 auto
    font-size: 0
    .qrcode-obj
      display: inline-block
      text-align: center
      img
        box-shadow: 0 4px 16px 0 rgba(0, 0, 0, 0.13)
      .qrcode-text
        height: 22px;
        font-size: 16px
        color: $black
        line-height: 22px
        margin-bottom: 23px
      &:first-child
        margin-right: 110px
  .contact-content
    text-align: center
    margin:46px 0
    font-size 14px
    line-height: 25px
    color: $grey-high
</style>
