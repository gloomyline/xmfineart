<!--suppress ALL -->
<template>
<Page>
  <fineart-subtitle :titleCh="subtitle.titleCh" :titleEn="subtitle.titleEn" :titleBg="subtitle.titleBg"></fineart-subtitle>
  <section class="page-content common-faq">
    <div class="faq-menu">
      <div v-for="obj in question" :key="obj.name">
        <h2>{{obj.name}}</h2>
        <div  @click="indexQuestion=item" :class="{'activeClass': item.id == indexQuestion.id }" v-for="(item,index) in obj.data" :key="item.id">
          {{index+1}}.{{item.question}}
        </div>
      </div>
    </div>
    <div class="faq-content">
      <div class="faq-title">{{indexQuestion.question}}</div>
      <div class="faq-answer" v-html="indexQuestion.answer"></div>
    </div>
  </section>
</Page>
</template>

<script>

import { Page, FineartSubtitle } from 'components'
import api from 'modules/index/api/index.js'

export default {
  name: 'CommonFaq',
  data () {
    return {
      subtitle: {
        titleCh: '常见问题',
        titleEn: 'Common problem',
        titleBg: require('../../../assets/fineart/faq-title-bg.png')
      },
      question: [],
      indexQuestion: {}
    }
  },
  created () {
    this.initCommonFaq()
  },
  methods: {
    async initCommonFaq () {
      this.question = await api.fetchCommonFaqList()
      if (this.question.length > 0) {
        this.indexQuestion = this.question[0]['data'][0]
      }
    }
  },
  components: {
    Page,
    FineartSubtitle
  }
}
</script>

<style lang="stylus">
  .common-faq
    display: flex
    &>div
      margin: 100px 0
    .faq-menu
      border-right: 1px solid $grey
      width: 300px
      padding-right: 60px
      &>div
        margin-bottom: 30px
        h2
          color: $black
          font-size: 22px
          margin-bottom: 20px
          font-weight: 500
        div
          line-height: 50px
          font-size: 18px
          color: $black1
          &.activeClass
            color: $orange
            cursor: pointer
          &:hover
            color: $orange
    .faq-content
      width:900px
      padding-left: 60px
      .faq-title
        font-size: 18px
        color: $black
        margin-bottom: 30px
      .faq-answer
        font-size: 16px
        color: $black1
        img
          max-width: 900px
</style>
