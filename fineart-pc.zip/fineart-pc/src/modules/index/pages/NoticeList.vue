<template>
  <page>
    <fineart-subtitle :titleCh="subtitle.titleCh" :titleEn="subtitle.titleEn" :titleBg="subtitle.titleBg"></fineart-subtitle>
    <section class="page-content platform-board">
      <ul class="board-content">
        <li v-for="item in noticeInfo.data" :key="item.id">
            <div class="board-title"><router-link :to="`/notice-detail/${item.id}`">{{item.title}}</router-link></div>
            <div class="board-date">{{item.created_at}}</div>
        </li>
      </ul>
      <pagination class="board-pagination"
                  :total="noticeInfo.total"
                  :page="noticeInfo.current_page"
                  :page-size="noticeInfo.per_page"
                  @page-confirm="pageChangeHandler"></pagination>
    </section>
  </page>
</template>

<script>
import { Page, FineartSubtitle, Pagination } from 'components'
import api from 'modules/index/api/index.js'

export default {
  name: 'NoticeList',
  data () {
    return {
      subtitle: {
        titleCh: '平台公告',
        titleEn: 'Platform Bulletin',
        titleBg: require('../../../assets/fineart/notice-title-bg.png')
      },
      noticeInfo: {}
    }
  },
  created () {
    this.initNotice()
  },
  methods: {
    async initNotice () {
      this.noticeInfo = await api.fetchNoticeList()
    },
    async pageChangeHandler (data) {
      this.noticeInfo = await api.fetchNoticeList(data.page)
    }
  },
  components: {
    Page,
    FineartSubtitle,
    Pagination
  }
}
</script>

<style lang="stylus">
  ul.board-content
    margin:100px 0
    li
      font-size: 20px
      display: flex
      justify-content: space-between
      .board-title a
        color: $black
        height: 66px
        line-height:66px
        &:before
          margin:0 17px
          display: inline-block
          height: 6px
          width:6px
          background:$grey-high3
          content: ''
      .board-date
        color: $grey-high
        font-size: 16px
        line-height:66px
  .board-pagination
    margin:40px 0
</style>
