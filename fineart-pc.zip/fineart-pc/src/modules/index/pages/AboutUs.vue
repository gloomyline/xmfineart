<template>
  <page>
    <fineart-subtitle :title-bg="subtitle.titleBg" :title-ch="subtitle.titleCh" :title-en="subtitle.titleEn"></fineart-subtitle>
    <section class="page-content about-pages">
      <div class="us-introduce">
        <div class="us-introduce-img">
          <img src="../../../assets/fineart/about-us-intro.png">
        </div>
        <div class="us-introduce-detail">
          <p>斐艺平台(Fine Art)，建筑“滴滴”，专注于连接建筑行业优质资源，是一个以数据化驱动的平台型公司。</p>
          <p>连接建筑各方资源，进行系统整合，建立全面专业的资源数据库，输出设计/建造/开发的能力。</p>
          <p>容纳建筑行业多种应用场景，使众多应用场景发生在一个平台上，提高效率，从而优化整个建筑行业。</p>
          <em>愿景</em>
          <p>优化建筑行业供需方服务的数据化驱动科技公司</p>
          <em>使命</em>
          <p>让建筑更简单</p>
        </div>
      </div>
    </section>
  </page>
</template>

<script>
import { Page, FineartSubtitle } from 'components'
export default {
  data () {
    return {
      subtitle: {
        titleCh: '关于我们',
        titleEn: 'About us',
        titleBg: require('../../../assets/fineart/about-us-title-bg.png')
      }
    }
  },
  components: {
    Page,
    FineartSubtitle
  }
}
</script>

<style lang="stylus">
  .about-pages
    padding-top: 110px
    .us-introduce
      display: flex
      margin-bottom: 100px
      .us-introduce-img
        position: relative
        width: 500px
        margin-right: 50px
        img
          width: 500px
      .us-introduce-detail
        padding-top: 10px
        font-size: 16px
        color: $black1
        line-height: 29px
        &:last-child
          margin-bottom: 0
        p
          margin-bottom: 36px
          &:last-child
            margin-bottom: 0
        em
          color: $black
          font-weight: 500
</style>
