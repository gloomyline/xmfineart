/**
 * @comment: 操作文言
 * @author: alan_wang
 * @date: 11/10/2018
 * @time: 19:31:13
 */

// 全局提示消息：GLOBAL 开头
export const SEND_CODE_SUCCESS = '短信发送成功'
export const LOGIN_FIRST_PLZ = '请先登录'
export const GLOBAL_PROCESSING = '请求处理中...'
export const GLOBAL_PROCESSED_SUCCESS = '请求处理成功'
export const GLOBAL_AREA_NULL_ERROR = '请选择地区'
export const GLOBAL_DELETE_SUCCESS = '删除成功'
export const GLOBAL_SAVE_SUCCESS = '保存成功'
export const GLOBAL_SAVE_FAILED = '保存失败'
export const GLOBAL_OPERATION_SUCCESS = '操作成功'
export const GLOBAL_OPERATION_FAILED = '操作失败'
export const GLOBAL_COLLECTION_SUCCESS = '关注成功'
export const GLOBAL_CANCEL_COLLECTION_SUCCESS = '取消关注成功'

// 表单验证提示消息
export const REG_REQUIRE_ERROR = '请检查输入是否完整'
export const REG_MOBILE_ERROR = '手机号格式不正确'
export const REG_PASSWORD_ERROR = '密码格式不正确'

// 上传文件提示消息
export const UPLOAD_EXCEEDED_SIZE = '上传文件超出限定大小'
export const UPLOAD__FORMAT_ERROR = '上传文件格式错误'

// 会员相关提示消息：ACCOUNT 开头
export const ACCOUNT_INFO_SAVE_SUCCESS = '账户信息保存成功'
export const ACCOUNT_CHANGE_MOBILE_SUCCESS = '手机号更换成功'
export const ACCOUNT_REAL_NAME_AUTH_SUCCESS = '实名认证成功'
export const ACCOUNT_REGISTER_SUCCESS = '注册成功'
export const ACCOUNT_REGISTER_AGREE_TIP = '请先阅读并同意《斐艺平台用户协议》'
export const ACCOUNT_RESET_PW_SUCCESS = '密码已重置,请重新登录'
export const ACCOUNT_MAP_MARKER_EMPTY = '没有找到相关地图标记信息'
export const ACCOUNT_MAP_MARKER_BIND_OK = '绑定成功'
export const ACCOUNT_MAP_RES_EMPTY = '请选择要绑定的资源主页'
export const ACCOUNT_MAP_STORE_EMPTY = '请选择要绑定的店铺'
export const ACCOUNT_MAP_RES_OR_STORE_EMPTY = '请至少选择一个资源主页或者一个店铺'
export const ACCOUNT_MAP_MY_MARKER_EMPTY = '你目前还没有加入斐艺地图哦~'
export const ACCOUNT_MAP_EDIT_MARKER_EMPTY = '请选择要编辑的地图标记'
export const ACCOUNT_MAP_MARKER_SAVE_OK = '保存成功'
export const ACCOUNT_MAP_MARKER_RELOCATION_OK = '定位更新成功'
export const ACCOUNT_SAVE_ADDRESS_SUCCESS = '收货地址保存成功'
export const ACCOUNT_SET_DEFAULT_ADDRESS_SUCCESS = '默认地址设置成功'
export const ACCOUNT_WECHAT_BIND_ERROR = '微信绑定失败'
export const ACCOUNT_WECHAT_BIND_SUCCESS = '微信绑定成功'
export const ACCOUNT_WECHAT_UNBIND_SUCCESS = '微信解除绑定成功'

// 建筑相关提示信息：BUILDING 开头
export const BUILDING_ADD_CASE_SUCCESS = '参与记录保存成功'
export const BUILDING_ADD_EXIST_TIP = '该建筑已经存在，请勿重复添加'

// 店铺管理相关
export const STORE_MANAGE_STORE_ID_NULL = '请选择店铺'
export const STORE_MANAGE_STORE_ADD_SUCCESS = '提交成功，请等待管理员审核'
export const STORE_MANAGE_STORE_EDIT_SUCCESS = '店铺编辑成功'

// 资源相关
export const RESOURCE_HOME_APPLY_SUCCESS = '资源主页申请成功，请等待管理员审核'
export const RESOURCE_LOGO_UPLOAD_SUCCESS = 'logo上传成功'
export const RESOURCE_NAME_EDIT_SUCCESS = '资源名称编辑成功'
export const RESOURCE_TITLE_EDIT_SUCCESS = '资源标题编辑成功'
export const RESOURCE_CATEGORY_EDIT_SUCCESS = '资源分类编辑成功'
export const RESOURCE_INTRODUCTION_EDIT_SUCCESS = '资源简介编辑成功'
export const RESOURCE_AREA_EDIT_SUCCESS = '资源地址定位更新成功'
export const RESOURCE_EXPERIENCE_DELETE_SUCCESS = '工作经历删除成功'
export const RESOURCE_EXPERIENCE_ADD_SUCCESS = '工作经历添加成功'
export const RESOURCE_EXPERIENCE_EDIT_SUCCESS = '工作经历更新成功'
export const RESOURCE_CASE_EDIT_SUCCESS = '案例编辑成功'
export const RESOURCE_CASE_DELETE_SUCCESS = '案例删除成功'
export const RESOURCE_ACHIEVEMENT_ADD_SUCCESS = '作品添加成功'
export const RESOURCE_ACHIEVEMENT_EDIT_SUCCESS = '作品编辑成功'
export const RESOURCE_ACHIEVEMENT_DELETE_SUCCESS = '作品删除成功'
export const RESOURCE_AGENT_BRAND_ADD_SUCCESS = '代理品牌添加成功'
export const RESOURCE_AGENT_BRAND_EDIT_SUCCESS = '代理品牌编辑成功'
export const RESOURCE_AGENT_BRAND_DELETE_SUCCESS = '代理品牌删除成功'
export const RESOURCE_PRODUCT_ADD_SUCCESS = '产品添加成功'
export const RESOURCE_PRODUCT_EDIT_SUCCESS = '产品编辑成功'
export const RESOURCE_PRODUCT_DELETE_SUCCESS = '产品删除成功'
export const RESOURCE_TAG_SET_SUCCESS = '标签设置成功'
export const RESOURCE_TAG_ADD_SUCCESS = '标签添加成功'
export const RESOURCE_TAG_SET_NUMBER_ERROR = '最多仅能设置三个标签'
export const RESOURCE_PRICE_SET_SUCCESS = '收费标准设置成功'

// 斐艺购提示消息：MALL 开头
export const MALL_FORESHOW_RESERVATION_SUCCESS = '新品预约成功'
export const MALL_FORESHOW_CANCEL_RESERVATION_SUCCESS = '新品预约取消成功'
export const MALL_GOODS_COMMENT_START_EMPTY = '商品评价不能为空'
export const MALL_GOODS_COMMENT_SUCCESS = '商品评价成功'
export const MALL_GOODS_COMMENT_REPLY_SUCCESS = '回复成功'
export const MALL_CART_EMPTY = '您的购物车是空的~'
export const MALL_CART_ITEM_EDIT_FAILED = '更新数量失败，请重试'
export const MALL_CART_ITEM_DELETE_OK = '商品成功删除'
export const MALL_CART_CHECKOUT_EMPTY = '请先选择要下单的商品'
export const MALL_GOODS_ADD_CART_OK = '已加入购物车'
