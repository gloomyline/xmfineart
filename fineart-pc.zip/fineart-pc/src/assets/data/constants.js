import config from '@/../config/index.js'

// different url domain of corresponding environment server
const env = process.env.NODE_ENV === 'development'
  ? 'dev' : process.env.NODE_ENV === 'production'
    ? 'build' : 'test'

/**
 * @comment: 常量定义文件
 * @author: alan_wang
 * @date: 11/10/2018
 * @time: 20:21:45
 */

export const MESSAGE_TOP = 100
export const MESSAGE_DURATION = 3
export const COLLECT_MESSAGE_DURATION = 2000

export const A_MAP_Key = '768d15d6a7eefa4341fc9219e2818aee'

// 获取不同环境下不同的域名
export const API_ADDRESS = config[env].apiAddress
export const CACHE_ADDRESS = config[env].cacheAddress
export const MOB_ADDRESS = config[env].mobAddress

// wechat appid
export const WX_APP_ID = 'wx73d2d5862a2863b4'
export const WX_QR_URL = 'https://res.wx.qq.com/connect/zh_CN/htmledition/js/wxLogin.js'
export const WX_GETTING_CODE_INTERVAL = 1000 // ms
export const WX_GETTING_CODE_TIMEOUT = 5 * 60 * 1000 // ms
