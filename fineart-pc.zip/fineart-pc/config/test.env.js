/**
 * @comment: test env conf file
 * @author: alan_wang
 * @date: 10/10/2018
 * @time: 21:26:21
 */
'use strict'
module.exports = {
  NODE_ENV: '"test"'
}
