// https://eslint.org/docs/user-guide/configuring

module.exports = {
  root: true,
  parserOptions: {
    parser: 'babel-eslint'
  },
  env: {
    browser: true,
  },
  extends: [
    // https://github.com/vuejs/eslint-plugin-vue#priority-a-essential-error-prevention
    // consider switching to `plugin:vue/strongly-recommended` or `plugin:vue/recommended` for stricter rules.
    'plugin:vue/essential',
    // https://github.com/standard/standard/blob/master/docs/RULES-en.md
    'standard'
  ],
  // required to lint *.vue files
  plugins: [
    'vue'
  ],
  // add your custom rules here
  // ‘off' === 0
  // 'warn' === 1
  // 'error' === 2
  rules: {
    // forbid using alert, confirm and prompt
    'no-alert': 'error',
    // forbid using array constructor to create array
    'no-array-constructor': 'error',
    // forbid assigning value to a class
    'no-class-assign': 'error',
    'no-dupe-keys': 'warn',
    'no-dupe-args': 'warn',
    'no-eval': 'error',
    'no-floating-decimal': 'error',
    'no-func-assign': 'error',
    'no-implicit-coercion': 'error',
    // indent must be 2 white spaces
    'indent': ['error', 2],
    // allow async-await
    'generator-star-spacing': 'off',
    // allow template literal placeholder syntax in regular strings
    'no-template-curly-in-string': 'off',
    'camelcase': 'off',
    // allow debugger during development
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off'
  }
}
