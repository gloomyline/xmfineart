# fineart-mobile (FineArt v3.0 Mobile Site)

> Mobile frontend of fineart platform.

## Build Setup (If you have node >= 6.0.0 or see setup guidance)

``` bash
# install dependencies 安装依赖模块
npm install // or
yarn

# use eslint rules(.elsintrc.js) to check code styles 使用eslint规则检测代码风格
npm run lint // or
yarn lint

# try to fix invalid code styles 尝试修复不合规范代码
npm run fix-lint // or
yarn fix-lint

# serve with hot reload at localhost:8080
# 启动热更服务器，及时编译更新页码，便于开发
npm run dev // or
yarn dev // or
yarn start

# build for testing with minification
# 压缩打包项目静态文件，便于发布前在测试服务器上测试使用
npm run test // or
yarn test

# build for production with minification
# 压缩打包项目静态文件
npm run build // or
yarn build

# build for production and view the bundle analyzer report
# 报告模式打包，在需要了解打包分析报告时使用
npm run build --report // or
yarn build --report
```

## Setup Guidance

#### Mac 环境下

###### 安装 Homebrew

1. `Homebrew` 能干啥？

    - 使用 `Homebrew` 安装 `Apple` 没有预装但 你需要的东西
    - `Homebrew` 会将软件包安装到独立目录，并将其文件软链接至 `/usr/local`
    - `Homebrew` 不会将文件安装到它本身目录之外，所以您可将 `Homebrew` 安装到任意位置
    - 轻松创建你自己的 `Homebrew` 包
    - 完全基于 `git` 和 `ruby`，所以自由修改的同时你仍可以轻松撤销你的变更或与上游更新合并
    - `Homebrew` 的配方都是简单的 `Ruby` 脚本
    - `Homebrew` 使 macOS 更完整。使用 `gem` 来安装 `gems`，用 brew 来安装那些依赖包
  
2. `Homebrew` 安装
    
    ```bash
    /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
    ```

    > NOTE: 若在安装 `Homebrew` 后报错，**-bash:brew:command not found** 
  
    ```bash
    vim ~/.bash_profile // or
    vim ~/.zshrc  // if you use zsh instead of bash
    export PATH=/usr/local/bin:$PATH // add this into the file 
    source ~/${which file you have edited before} // restart
    ```
    
    若安装成功后再终端中键入以下
    
    ```bash
    brew --version
    ```
    
    则会得到当前安装的 `Homebrew` 的版本信息，否则未安装成功

3. 基本使用

    - 安装任意包
    
      ```bash
      brew install <package_name>
      ```
      
      tips: `Homebrew` 默认安装包的时候会自动检测更新，如若想跳过，可在 `zshrc file` 中键入
      
      ```bash
      # Disable homebrew auto update
      export HOMEBREW_NO_AUTO_UPDATE=true
      ```
      
      关闭 `Homebrew` 自动更新即可
      
    - 卸载任意包
    
      ```bash
      brew uninstall <package_name>
      ```
      
    - 更新 `Homebrew` 在服务器端上的包
    
      ```bash
      brew update
      ```
      
4. 参考链接

    [传送门](https://www.jianshu.com/p/066b5d45fde6)
    
###### 创建前端脚手架工作环境

1. 我们使用 `yarn` 作为 `nodejs` 的包管理工具替代其自带的 `npm`

    - 使用 `Homebrew` 安装 `yarn`
    
      ```bash
      brew install yarn
      ```
      
    - 配置 `yarn` 的镜像源为国内源，提高 `nodejs` 包的下载速度
    
      ```bash
      yarn config set registry https://registry.npm.taobao.org --global
      
      yarn config set disturl https://npm.taobao.org/dist --global
      ```
    
2. 我们选择 `n` 作为 `nodejs` 的版本管理工具

    - 安装 `n`, 作为一个 `npm` 包，和其他 `npm` 包一样全局安装即可
    
      ```bash
      // 如果已安装 yarn，则可以使用以下命令全局安装 n
      yarn global add n
      npm install -g n
      ```
      
    - 安装成功后键入以下
    
      ```bash
      n help // 若一切正常，此处可以得到使用 n 的帮助信息
      ```
      
    - 使用 `n` 安装指定版本的 `nodejs`，这里推荐 `8.11.4`
    
      ```bash
      n 8.11.4
      ```
      
    点我前往[github](https://github.com/tj/n)仓库详细了解 `n`
      
      
###### 构建开发环境

1. 在本地终端用户目录下，如 `~/Workspace/`，拉取本仓库

    ```bash
    git clone git@github.com:xmfineart/fineart-pc.git
    ```
    
2. 进入到项目目录下，安装依赖

    ```bash
    cd ~/Workspace/fineart-pc && yarn
    // 如若在使用 yarn 安装依赖的过程中出错，使用 npm 安装
    cd ~/Workspace/fineart-pc && npm install
    ```

## Preferences
For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
