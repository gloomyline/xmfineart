/*
* @Author: Alan
* @Date:   2018-09-17 11:16:32
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 15:03:08
*/
// 项目在不同环境下的配置
import { API_ADDRESS } from '@/assets/data/constants.js'
import Axios from 'axios'
import { sign } from './sign.js'
import { LocalStorage } from './LocalStorage.js'
import qs from 'qs'

const urlPrefix = API_ADDRESS

export class BaseApi {
  static $http // static property, axios instance within baseURL && headers
  static $localStorage = null // instance property, an Singleton localStorage
  static token = null // instance property, user token

  constructor ({token = null} = {}) {
    BaseApi.token = token
    this._init()
  }

  /**
   * Private method
   * @return
   */
  _init () {
    // the token has not passed by the constructor
    BaseApi.token = BaseApi.readTokenFromLocalStorage()
  }

  static readTokenFromLocalStorage () {
    const user = BaseApi.$localStorage.getUser()
    if (user) {
      return user.token
    } else {
      return null
    }
  }

  static saveTokenToLocalStorage (tokenData) {
    const user = {
      token: tokenData.value,
      isLogin: true,
      expired: tokenData.expired
    }
    BaseApi.$localStorage.setUser(user)
  }

  /**
   * 更新实例上 token 的值
   * @param value
   */
  static updateToken (value) {
    BaseApi.token = value
  }

  /**
   * static method
   * @param  {String}  opts.method                request method, 'post' or 'get'(default)
   * @param  {String}  opts.url                   api path, if method is get, reconstruct the url like 'account/sms/code/${type}/${mobile}'
   * @param  {Object}  opts.headers               reqeust headers, customer headers 'auth-sign' must be needed, or 'auth-token' may be needed
   * @param  {Object}  opts.params                get params, '${paramsKeyName}' regard as base url template which will be replaced by corresponding value of params
   * @param  {Object}  opts.data                  post data
   * @return {Promise}                            promise ofcurrent request instance
   */
  static async request ({
    method = 'get',
    url = '/',
    headers = {},
    params = {},
    query = {},
    data = {}
  } = {}) {
    BaseApi.token = BaseApi.readTokenFromLocalStorage()
    if (method === 'get') {
      // reconstructed url
      const reconstructedUrl = reconstructUrl(url, params)
      if (Object.keys(query).length !== 0) {
        try {
          const signature = sign(query)
          const response = await BaseApi.$http.get(reconstructedUrl, {
            headers: {
              ...headers,
              'auth-token': BaseApi.token ? BaseApi.token : '',
              'auth-sign': signature
            },
            params: query
          })
          return handleResponse(response)
        } catch (e) {
          console.error(e)
        }
      } else {
        try {
          // 通过构造静态URL的参数不进行签名
          const signature = sign({})
          const response = await BaseApi.$http.get(reconstructedUrl, {
            headers: {
              ...headers,
              'auth-token': BaseApi.token ? BaseApi.token : '',
              'auth-sign': signature
            }
          })
          return handleResponse(response)
        } catch (e) {
          console.error(e)
        }
      }
    } else if (method === 'post') {
      try {
        if (Object.keys(params).length !== 0) {
          url = reconstructUrl(url, params)
        }
        const postData = qs.stringify(data, { indices: false })
        const signature = sign(data)
        const response = await BaseApi.$http.post(url, postData, {
          headers: {
            ...headers,
            'auth-token': BaseApi.token ? BaseApi.token : '',
            'auth-sign': signature,
            // 设置 post 请求的参数格式，使用 form 表单提交方式
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        })
        return handleResponse(response)
      } catch (e) {
        console.error(e)
      }
    }
  }
}

// Axios default baseURL
Axios.defaults.baseURL = urlPrefix
// Axios default headers
Axios.defaults.headers = { 'auth-token': '', 'auth-sign': '' }

BaseApi.$http = Axios

BaseApi.$localStorage = new LocalStorage()

function reconstructUrl (baseUrl, params) {
  const reg = /\$\{(\w+)\}/g
  return String.prototype.replace.call(baseUrl, reg, (match, p1, ...rest) => { return params[p1] })
}

function handleResponse (response) {
  if (response.status === 200) {
    return response.data
  } else {
    return console.error('Server: ', response)
  }
}

export const VueAxios = {}
VueAxios.install = function (Vue, opts) {
  const http = BaseApi.$http
  Vue.http = http

  Vue.prototype.$http = http
}
