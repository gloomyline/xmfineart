import AsyncValidator from 'async-validator'
import store from '@/store'
import Vue from 'vue'
import { BACK_URL, WX_APP_ID, API_ADDRESS } from '@/assets/data/constants'
import qs from 'querystring'
import memberRouter from 'modules/member/router'

/**
 * 工具函数文件
 */

/**
 * 深复制对象
 * @param obj {Object} 被拷贝的对象
 * @returns {Object}
 */
export function deepClone (obj) {
  if (!isObject(obj)) {
    throw new Error('obj 不是一个对象！')
  }

  let isArray = Array.isArray(obj)
  let cloneObj = isArray ? [] : {}
  for (let key in obj) {
    cloneObj[key] = isObject(obj[key]) ? deepClone(obj[key]) : obj[key]
  }
  return cloneObj
}

// 判断是否为对象
export function isObject (o) {
  return (typeof o === 'object' || typeof o === 'function') && o !== null
}

// 返回一个空函数
export const emptyFunc = () => {}

// 判断一个原始值是否存在于一个数组中
export function oneOf (value, array = []) {
  if (!array.indexOf) {
    return console.error('TypeError: arg 2 must be an array.')
  }
  return array.indexOf(value) > -1
}

/**
 * 驼峰字符串转连字符，'FineArtPageHome' => 'fine-art-page-home', 'fineArt' => 'fine-art'
 * @params {String}    驼峰法字符串
 * @return {String}    连字符字符串
 */
const camelReg = /([A-Z])/g
export function hyphenCase (str) {
  let _str = str.replace(camelReg, ($1) => {
    return `-${$1.toLocaleLowerCase()}`
  })
  return _str.slice(0, 1) === '-' ? _str.substr(1) : _str
}

/**
 * 连字符转驼峰法 'fine-art-page-home' => 'fineArt'， 'fine-art-page-home' => 'FineArtPageHome'
 * @param str         连字符法字符串
 * @param isBigCamel  是否转大驼峰法
 * @returns {*}       驼峰法字符串
 */
const hyphenReg = /(\w*)-(\w*)/g
export function camelCase (str, isBigCamel = false) {
  let _str = str.replace(hyphenReg, ($1, $2, $3) => {
    return $2 + $3[0].toLocaleUpperCase() + $3.slice(1)
  })
  if (isBigCamel) {
    return _str[0].toLocaleUpperCase() + _str.slice(1)
  }
  return _str
}

const tagsReg = /(<(\/)?\w+(\/)?>)/g
export function removeTags (htmlStr) {
  return htmlStr.replace(tagsReg, ($1) => {
    return ''
  })
}

/**
 * 加载并运行具有 url 的 js 脚本
 * @param url {String}          js 脚本地址
 * @param cb  {Function}        加载完成回调
 * @return null
 */
export function loadScript (url, cb = emptyFunc) {
  const script = document.createElement('script')
  script.charset = 'utf-8'
  script.src = url
  script.id = 'map-script'
  document.head.appendChild(script)
  cb()
}

// scrollTop animation
/**
 * 滚动到窗口顶部动画
 * @param el          滚动元素
 * @param from        起始位置，距顶部距离，卷曲距离 scrollTop
 * @param to          终止位置，距顶部距离，卷曲距离 scrollTop
 * @param duration    动画持续时间
 * @param endCallback 动画执行完毕回调
 */
export function scrollTop (el, from = 0, to, duration = 500, endCallback) {
  // requestAnimationFrame 兼容
  if (!window.requestAnimationFrame) {
    window.requestAnimationFrame = (
      window.webkitRequestAnimationFrame ||
      window.mozRequestAnimationFrame ||
      window.msRequestAnimationFrame ||
      function (callback) {
        return window.setTimeout(callback, 1000 / 60)
      }
    )
  }
  const difference = Math.abs(from - to)
  const step = Math.ceil(difference / duration * 50)

  function scroll (start, end, step) {
    if (start === end) {
      endCallback && endCallback()
      return
    }

    let d = (start + step > end) ? end : start + step
    if (start > end) {
      d = (start - step < end) ? end : start - step
    }

    if (el === window) {
      window.scrollTo(d, d)
    } else {
      el.scrollTop = d
    }
    window.requestAnimationFrame(() => scroll(d, end, step))
  }
  scroll(from, to, step)
}

// 获取窗口的高度、宽度
export function getViewportSize () {
  return {
    width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
    height: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
  }
}

/**
 * 验证表单数据
 * @param inputData {Object} 要验证的表单数据
 * @param rules {Object} 验证的数据的规则
 * @returns {Boolean} true -- 验证通过， false 验证不通过
 */
export function validate (inputData, rules) {
  const validateRuler = new Promise(function (resolve, reject) {
    const validator = new AsyncValidator(rules)
    validator.validate(inputData, { firstFields: true }, (errors, fields) => {
      if (!errors) {
        resolve(true)
      } else {
        store.commit('ADD_MESSAGE', {msg: errors[0].message})
        resolve(false)
      }
    })
  })
  return validateRuler
}

export function isInWX () {
  const ua = navigator.userAgent.toLowerCase()
  const matched = ua.match(/MicroMessenger/i)
  return matched && matched[0] === 'micromessenger'
}

export function getQuery (name, url = window.location.href) {
  const queries = url.substr(url.indexOf('?') + 1)
  const params = qs.parse(queries)
  return name ? params[name] : params
}

/**
 * helper function 统一前往登录页工具函数
 * @param backUrl  前往登录页之前的页面 url
 */
export function goLogin (backUrl = window.location.href) {
  const ls = Vue.localStorage
  // STEP-1. 缓存 backUrl 到 localStorage
  if (backUrl) {
    ls.set(BACK_URL, backUrl, Date.now() + 24 * 60 * 60 * 1000)
  }
  if (store.state.member.isMember) {
    memberRouter.push({path: '/login'})
  } else {
    window.location = 'member.html#/login'
  }
}

/* 微信支付前获取 WX code */
export function fetchWXCodeForPay (orderCode) {
  const openid = Vue.localStorage.get('__FA_WX_PAY_OPENID__')
  if (!openid && isInWX() && process.env.NODE_ENV === 'production') {
    const redirectUri = encodeURIComponent(`https://m.xmfineart.com/mall.html#/payment/${orderCode}`)
    window.location = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${WX_APP_ID}&redirect_uri=${redirectUri}&response_type=code&scope=snsapi_base&#wechat_redirect`
  } else {
    window.location = `mall.html#/payment/${orderCode}`
  }
}

/**
 * 微信分享保持筛选条件时拼凑url函数
 * @param {*} keywords 搜索的关键字
 * @param {*} values 侧边栏选中的值
 * @param {*} path 当前的路由
 */
export function makeNewLink (keywords, values, path, type = 1) {
  const location = window.location
  const pageLink = location.href.replace(location.hash, '')
  let queryString = ''
  if (keywords) queryString += '&keywords=' + keywords
  if (type === 1) {
    for (let key in values) {
      if (values[key].length === 0) continue
      // 大于2表示选中了子菜单
      if (values[key].length > 2) {
        queryString += '&' + key + '-1=' + values[key][0] + '-' + values[key][2] + '-' + values[key][1]
      } else {
        queryString += '&' + key + '-0=' + values[key][0]
      }
    }
  } else {
    for (let key in values) {
      queryString += '&' + key + '=' + values[key]
    }
  }
  let _link = ''
  if (queryString.length > 0) {
    // 去掉第一个&‘’
    queryString = queryString.substr(1, queryString.length - 1)
    _link = `${pageLink}#${path}?${queryString}`
  } else {
    _link = `${pageLink}#${path}`
  }
  const link = API_ADDRESS + `/sys/wechat/share?url=${encodeURIComponent(_link)}`
  return link
}
/**
 * 格式化用于初始化侧边栏的对象
 *  @param {*} values 侧边栏选中的值
 */
export function formatSidebarValue (values) {
  let sidebarValue = {}
  if (values === {}) return sidebarValue
  for (let key in values) {
    if (values[key].length === 0) continue
    // 大于2表示选中了子菜单
    if (values[key].length > 2) {
      sidebarValue[key + '-1'] = values[key][0] + '-' + values[key][2] + '-' + values[key][1]
    } else {
      sidebarValue[key + '-0'] = values[key][0]
    }
  }
  return sidebarValue
}
/**
 * 解析url里的参数
 * @param {*} queries 要解析的路由里的query对象
 * @param {*} type: 1 默认：侧边如有选择了子菜单，只返回子菜单的id， 2：侧边如有选择了子菜单，返回父菜单id和子菜单id
 */
export function resolveUrlQuery (queries, type = 1) {
  let returnObj = {}
  for (let key in queries) {
    const keys = key.split('-')
    const values = queries[key].split('-')
    // 选择了子菜单
    if (keys[1] === '1') {
      if (type === 1) {
        returnObj[keys[0]] = values[1]
      } else {
        returnObj[keys[0]] = values[0] + '-' + values[1]
      }
    } else {
      returnObj[keys[0]] = values[0]
    }
  }
  return returnObj
}
/**
 * 判断两个对象相同属性的属性值是否相等
 */
export function isObjectValueEqual (obj1, obj2) {
  var o1 = obj1 instanceof Object
  var o2 = obj2 instanceof Object
  if (!o1 || !o2) {
    return obj1 === obj2
  }
  if (Object.keys(obj1).length !== Object.keys(obj2).length) {
    return false
  }
  for (var attr in obj1) {
    var t1 = obj1[attr] instanceof Object
    var t2 = obj2[attr] instanceof Object
    if (t1 && t2) {
      return isObjectValueEqual(obj1[attr], obj2[attr])
    } else if (obj1[attr] !== obj2[attr]) {
      return false
    }
  }
  return true
}
