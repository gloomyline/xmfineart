/**
 * @comment: AMap Class
 * @author: alan_wang
 * @date: 02/11/2018
 * @time: 10:38:47
 */
import {A_MAP_Key, A_MAP_DEFAULT_ZOOM_INDEX} from 'assets/data/constants'
import {loadScript} from './utils'

let instance = null
const initAMap = Symbol('initAMap')
export class FMap {
  // private 地图插件 key
  _key = ''
  selector = ''
  AMap = null
  _map = null
  isEnableHighAccuracy = true

  geocoderOpts = {
    radius: 1000,
    batch: false,
    extensions: 'all'
  }

  geocoder = null
  positionMarker = null

  constructor ({
    key = A_MAP_Key,
    selector = '',
    defaultZoomIndex = A_MAP_DEFAULT_ZOOM_INDEX
  } = {}) {
    // singleton pattern
    if (instance) return instance
    instance = this

    // init class property
    this._key = key
    this.selector = selector.replace(/#/g, '')
    this.defaultZoomIndex = defaultZoomIndex

    // init Map api
    // this[initAMap]()
  }

  [initAMap] () {
    this.initMap()
  }

  initMap () {
    return new Promise((resolve, reject) => {
      try {
        const AMapUrl = `https://webapi.amap.com/maps?v=1.4.10&key=${this._key}&callback=onApiLoaded`
        const cb = () => {
          window.onApiLoaded = async () => {
            // guarantee AMap api is mounted to instance once
            if (this.AMap) return
            // init AMap
            const AMap = this.AMap = window.AMap
            // init geocoder
            AMap.plugin('AMap.Geocoder', () => {
              this.geocoder = new AMap.Geocoder(this.geocoderOpts)
            })
            // create map instance
            if (this.selector) {
              this._map = this.createMap(this.selector)
            }
            resolve(this)
          }
        }
        loadScript(AMapUrl, cb)
      } catch (e) {
        reject(e)
      }
    })
  }

  get Map () {
    return this.AMap
  }

  get map () {
    return this._map
  }

  /**
   * 获取当前的地理位置
   * @returns {Promise<position>} Object<lng, lat>
   */
  geoLocation () {
    return new Promise(resolve => {
      this._map.plugin('AMap.Geolocation', () => {
        const geolocation = new this.AMap.Geolocation({
          // 是否使用高精度定位，默认：true
          enableHighAccuracy: this.isEnableHighAccuracy,
          // 设置定位超时时间，默认：无穷大
          timeout: 10000
        })
        geolocation.getCurrentPosition((status, result) => {
          if (status === 'complete') {
            // 具体的定位信息
            resolve(result.position)
          } else {
            // 地图中心点作为用户当前地理位置点
            const mapCP = this._map.getCenter()
            resolve(mapCP)
          }
        })
      })
    })
  }

  /**
   * 在指定地图实例上创建标记
   * @param iconUrl         {String}        标记的图标 url
   * @param mapInstance     {Object<w,h>}   标记图标的宽度、长度
   * @returns               {Marker}        标记的实例
   */
  createMarker (iconUrl, { w = 32, h = 32 } = {}) {
    const Icon = this.AMap.Icon
    const Size = this.AMap.Size
    const Pixel = this.AMap.Pixel
    const Marker = this.AMap.Marker
    // 创建 AMap.Icon 实例
    const icon = new Icon({
      size: new Size(w, h),
      image: iconUrl,
      imageSize: new Size(w, h)
    })
    const marker = new Marker({
      offset: new Pixel(-(w / 2), -h),
      icon: icon
    })
    return marker
  }

  /**
   * 在地图上设置定位点
   * @returns {Promise<void>}
   */
  async mapGeoLocal (position = []) {
    if (!position[0] || !position[1]) {
      const _position = await this.geoLocation()
      position = [_position.lng, _position.lat]
    }
    // 设置当前定位作为地图的中心点视野
    this._map.setCenter(position)
    // 设置当前地理位置的定位点在地图上的位置
    const pm = this.positionMarker
      ? this.positionMarker : this._map.positionMarker
        ? this._map.positionMarker : null
    pm && pm.setPosition(position)
  }

  /**
   * 创建地图实例
   * @param selector {String}                           html 元素 id 选择器名称
   * @param opts     {Object<zoom, resizeEnable...>}    创建地图实例是的参数配置
   * @returns {*}    {AMap.Map}                         创建的地图实例
   */
  async createMap (selector, opts = { zoom: this.defaultZoomIndex, resizeEnable: true }) {
    if (!this.AMap) {
      instance = await this.initMap()
    }
    const AMap = this.AMap
    // 创建地图实例
    this._map = new AMap.Map(selector.replace(/[#]/g, ''), opts)
    // 添加比例尺控件
    AMap.plugin(['AMap.ToolBar', 'AMap.Scale'], () => {
      // 在图面添加比例尺控件，展示地图在当前层级和纬度下的比例尺
      this._map.addControl(new AMap.Scale())
    })
    return this._map
  }

  /**
   * 格式化简单地址（去掉省市区）
   * @param addressData {Object}
   */
  static formatSimpleAddress (addressData) {
    if (!addressData.address || !addressData.province || !addressData.city || !addressData.district) {
      console.error('formatSimpleAddress NG')
      return addressData
    }
    addressData.address = addressData.address.replace(addressData.province, '')
    addressData.address = addressData.address.replace(addressData.city, '')
    addressData.address = addressData.address.replace(addressData.district, '')
    return addressData
  }

  /**
   * 获取给定地理位置的详细地址
   * @param position  {Array<Number>} [lng, lat]
   * @returns {Promise<addressData>} addressData Obeject<province, city, address, fullAddress>
   */
  getAddress (position = []) {
    const geocoder = this.geocoder ? this.geocoder : new this.AMap.Geocoder(this.geocoderOpts)
    return new Promise(resolve => {
      this._map.plugin('AMap.Geocoder', () => {
        geocoder.getAddress(position, (status, res) => {
          if (status !== 'complete' && res.info !== 'OK') return
          const addressData = {
            province: res.regeocode.addressComponent.province,
            // 如果没有城市则说明是直辖市
            city: res.regeocode.addressComponent.city || res.regeocode.addressComponent.province,
            district: res.regeocode.addressComponent.district,
            address: res.regeocode.formattedAddress,
            fullAddress: res.regeocode.formattedAddress
          }
          resolve(FMap.formatSimpleAddress(addressData))
        })
      })
    })
  }
  /**
   * 获取给定地址获取地理定位
   * @param address  {String} 地址
   * @returns {Promise<Array>} Array [lng, lat]
   */
  getLocation (address) {
    const geocoder = this.geocoder ? this.geocoder : new this.AMap.Geocoder(this.geocoderOpts)
    return new Promise(resolve => {
      this._map.plugin('AMap.Geocoder', () => {
        geocoder.getLocation(address, function (status, result) {
          if (status === 'complete' && result.geocodes.length) {
            resolve([result.geocodes[0].location.lng, result.geocodes[0].location.lat])
          }
        })
      })
    })
  }
  /**
   * 根据关键字搜索
   * @param keywords {String}
   */
  search (keywords) {
    return new Promise(resolve => {
      this.AMap.plugin('AMap.Autocomplete', () => {
        const autoComplete = new instance.AMap.Autocomplete()
        autoComplete.search(keywords, (status, result) => {
          if (status === 'complete') {
            resolve(result.tips)
          }
        })
      })
    })
  }
  /**
   * 周边搜索，不需要dom元素
   * @param pageSize {Number} 一页展示多少条数据
   * @param pageIndex {Number} - 页码
   */
  async aMapSearchNearBy ({pageSize = 20, pageIndex = 1}) {
    if (!this.AMap) {
      instance = await this.initMap()
    }
    const info = await this.geoPosition()
    return new Promise(resolve => {
      this.AMap.service(['AMap.PlaceSearch'], function () {
        const placeSearch = new instance.AMap.PlaceSearch({
          pageSize,
          pageIndex,
          city: info.city
        })
        placeSearch.searchNearBy('', info.centerPoint, 1000, function (status, result) {
          if (result.info === 'OK') {
            let locationList = result.poiList
            locationList.city = info.city
            resolve(locationList)
          } else {
            resolve(false)
          }
        })
      })
    })
  }
  /**
   * 根据经纬度获取城市
   * @param lngLat {Array} [lng, lat]
   */
  getCity (lngLat) {
    return new Promise(resolve => {
      this.AMap.service('AMap.Geocoder', function () {
        const geocoder = new instance.AMap.Geocoder({
          city: ''
        })
        geocoder.getAddress(lngLat, function (status, result) {
          if (status === 'complete' && result.info === 'OK') {
            const city = result.regeocode.addressComponent.city
            resolve(city)
          }
        })
      })
    })
  }
  /**
   * 定位当前位置，不需要dom元素
   */
  geoPosition () {
    return new Promise((resolve) => {
      this.AMap.plugin('AMap.Geolocation', function () {
        const geolocation = new instance.AMap.Geolocation({
          // 是否使用高精度定位，默认：true
          enableHighAccuracy: false,
          // 设置定位超时时间，默认：无穷大
          timeout: 10000
        })
        geolocation.getCurrentPosition(async (status, result) => {
          if (status === 'complete') {
            // 具体的定位信息
            const info = {}
            info.centerPoint = [result.position.lng, result.position.lat]
            info.city = await instance.getCity(info.centerPoint)
            resolve(info)
          }
        })
      })
    })
  }
  /**
   * 设置中心点和缩放
   * @param keywords {String}
   */
  async setZoom (zoom = 11) {
    this._map.setZoom(zoom) // 同时设置地图层级
  }
  destory () {
    this._map.destroy()
    this._map = null
    this.AMap = null
    const jsMap = document.getElementById('map-script')
    jsMap.parentNode.removeChild(jsMap)
  }
}

export const VueMap = {}
VueMap.install = function (Vue, options = {}) {
  const fMap = new FMap()
  Vue.fMap = fMap
  Vue.prototype.$fMap = fMap
}
