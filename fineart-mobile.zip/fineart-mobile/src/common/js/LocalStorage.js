/**
 * @author: alan_wang
 * @date: 30/09/2018
 * @time: 17:27:36
 * @comment: LocalStorage Class && localStorage Vue plugin
 */
import engine from 'store/src/store-engine.js'
import localStorage from 'store/storages/localStorage.js'
import expirePlugin from 'store/plugins/expire.js'
import { BACK_URL, WX_PAY_OPENID, USER_CURRENT_POSITION, WX_CODE } from '@/assets/data/constants'

const defaultKey = '__FA_USER__'
const defaultExpire = 60 * 60 * 1000 // 60 minutes
let instance = null
let instanceId = 0
export class LocalStorage {
  constructor (keys = [defaultKey], expire = defaultExpire) {
    if (instance) return instance
    instance = this
    this.instanceId = ++instanceId
    this.keys = keys
    this.expire = expire
    const storages = [localStorage]
    const plugins = [expirePlugin]
    this.store = engine.createStore(storages, plugins)

    // init canvas for saving image base64string
    this.canvas = document.createElement('canvas')
    this.ctx2d = this.canvas.getContext('2d')

    return this
  }

  _checkIsInKeys (key) {
    if (this.keys.indexOf(key) === -1) {
      console.error('The key is not in the keys array, if you want to use it, just adding it when constructing')
      return false
    }
    return true
  }

  addKeys (keys = []) {
    if (!Array.isArray(keys)) {
      return new Error('Keys needed to be an array.')
    }
    // this.keys = Array.prototype.concat.call(this.keys, keys)
    this.keys = [...this.keys, ...keys]
  }

  get (key) {
    if (!this._checkIsInKeys(key)) return null
    if (!this.isExpired(key)) {
      return this.store.get(key)
    }
    return null
  }

  set (key, value, expire = defaultExpire + Date.now()) {
    if (!this._checkIsInKeys(key)) return
    this.store.set(key, value, expire)
  }

  isExpired (key) {
    if (!this._checkIsInKeys(key)) return
    return this.store.getExpiration(key) <= Date.now()
  }

  remove (key) {
    if (!this._checkIsInKeys(key)) return
    this.store.remove(key)
  }

  clearAllExpired () {
    this.store.removeExpiredKeys()
  }

  getUser () {
    if (!this.isUserExpired()) {
      return this.get(defaultKey)
    } else {
      this.remove(defaultKey)
      return null
    }
  }

  setUser (value) {
    let expiredAt = null
    if (value && value.token && value.expired) {
      expiredAt = value.expired * 1000
    } else if (value.expired) {
      expiredAt = value.expired * 1000
    } else {
      expiredAt = Date.now() + this.expire
    }
    this.set(defaultKey, value, expiredAt)
  }

  isUserExpired () {
    if (this.store.getExpiration(defaultKey) === 'undefined') return true
    return this.store.getExpiration(defaultKey) <= Date.now()
  }

  getImage (name) {
    if (this.isExpired(name)) {
      this.clearExpired(name)
      return null
    }
    return this.get(name)
  }

  saveImage (name, imageSrc, expire = defaultExpire) {
    // clear before drawing new image into canvas
    this.ctx2d.save()
    this.ctx2d.setTransform(1, 0, 0, 1, 0, 0)
    this.ctx2d.clearRect(0, 0, this.canvas.width, this.canvas.height)
    this.ctx2d.restore()

    const image = new Image()
    image.addEventListener('load', (e) => {
      this.canvas.width = image.width
      this.canvas.height = image.height
      this.ctx2d.drawImage(image, 0, 0)
      const imageSrcArray = imageSrc.split('.')
      const imageExt = imageSrcArray[imageSrcArray.length - 1]
      const base64string = this.canvas.toDataURL(`image/${imageExt}`)
      this.set(name, base64string, Date.now() + expire)
    })
    image.src = imageSrc
  }
}

export const VueLocalStorage = {}
VueLocalStorage.install = function (Vue, options) {
  let ls = null
  if (!options) {
    ls = new LocalStorage()
  } else {
    const keys = options.keys
    const expire = options.expire
    ls = new LocalStorage(keys, expire)
  }

  // common ls keys
  // 前往登录页当前页面 backUrl
  // 微信支付使用 openId
  // 用户当前地理位置 currentPosition
  ls.addKeys([BACK_URL, WX_PAY_OPENID, USER_CURRENT_POSITION, WX_CODE])

  // Global
  Vue.localStorage = ls

  // VM instance
  Vue.prototype.$localStorage = ls
}
