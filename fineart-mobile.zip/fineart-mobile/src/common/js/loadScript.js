import Vue from 'vue'
import LoadScript from 'vue-plugin-load-script'
import { CACHE_ADDRESS } from '@/assets/data/constants.js'

const urlPrefix = CACHE_ADDRESS

Vue.use(LoadScript)
const treeGoodsCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-goods-category.js`
const treeAreaUrl = `${urlPrefix}/admin/scripts/lib/tree-area.js`
const treeBuildingCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-building-category.js`
const treeMapMarkerCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-map-marker-category.js`
const treeResourceCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-resource-category.js`
const treeStoreCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-store-category.js`
const treeGrouponCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-groupon-category.js`
const treeResourcePortfolioCategoryUrl = `${urlPrefix}/admin/scripts/lib/tree-resource-portfolio-category.js`
/**
 * 获取js格式文件数据
 * @param  {String}  opts.url               js文件的路径
 * @param  {String}  opts.name              属性名
 * @return {Promise}
 */
const fetchScriptFile = (url, name) => {
  return new Promise((resolve, reject) => {
    Vue.loadScript(url)
      .then(() => {
        resolve(window[name])
      }).catch((error) => {
        reject(error)
        console.log('ERROR')
      })
  })
}

/**
 * 在数组成员中找出给定属性的值等于给定的值的成员对象
 * @param arr         待寻找数组
 * @param key         给定的属性名
 * @param value       给定的属性值
 * @returns {*}       返回的成员对象
 */
const find = (arr, value, key = 'label') => {
  const arrVal = arr.find(item => item[key] === value || item.value === value)
  return arrVal
}

/**
 * 将对象数据结构转换换成数组
 * @param obj         带转化对象数据
 * @returns {*}       转化完成的数组
 */
const getArray = (obj) => {
  if (Object.keys(obj).length === 0) return
  let arr = []
  for (let key in obj) {
    if (Object.keys(obj[key].son).length === 0) {
      arr.push({
        value: obj[key].id,
        label: obj[key].name,
        parent_id: obj[key].parent_id,
        depth: obj[key].depth
      })
    } else {
      arr.push({
        value: obj[key].id,
        label: obj[key].name,
        parent_id: obj[key].parent_id,
        depth: obj[key].depth,
        children: getArray(obj[key].son)
      })
    }
  }
  return arr
}
/**
 * 获取指定分类的指定字段值和父辈分类的指定字段值组成的数组
 * @param arr {Array}       指定的分类列表
 * @param value {String}     指定的值，取值范围 id 或 name
 * @return {Array}         指定分类的指定字段值和父辈分类的指定字段值组成的数组
 */
const findValue = (arr, value) => {
  let category = []
  let cate = []
  const forCate = (cateArr, cateVal) => {
    for (let i = 0, max = cateArr.length; i < max; i++) {
      if (cateArr[i].value === cateVal || cateArr[i].label === cateVal) {
        cate.push(cateArr[i])
        category.push(cateArr[i].value)
        // 再一次在原数组中查找父级id
        forCate(arr, cate[cate.length - 1].parent_id)
      } else if (cateArr[i].children) {
        // 第一层查找没有相对应的id 则继续查找下一层的id
        forCate(cateArr[i].children, cateVal)
      }
    }
  }
  forCate(arr, value)
  return category.reverse()
}

// 获取商品分类js文件数据
const getGoodsCategory = async () => {
  const response = await fetchScriptFile(treeGoodsCategoryUrl, 'jTreeGoodsCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}

// 获取省市区js文件数据
const getArea = async () => {
  let response = await fetchScriptFile(treeAreaUrl, 'jTreeArea')
  let aTreeArea = getArray(response.son['1'].son)
  return aTreeArea
}

// 获取建筑分类js文件数据
const getBuildingCategory = async () => {
  const response = await fetchScriptFile(treeBuildingCategoryUrl, 'jTreeBuildingCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}

// 获取地图分类js文件数据
const getMapMarkerCategory = async () => {
  const response = await fetchScriptFile(treeMapMarkerCategoryUrl, 'jTreeMapMarkerCategoryArray')
  const aTreeCategory = response.son
  return aTreeCategory
}

// 获取资源分类js文件数据
const getResourceCategory = async () => {
  let response = await fetchScriptFile(treeResourceCategoryUrl, 'jTreeResourceCategory')
  let jTreeResourceCategory = response.son
  let aTreeResourceCategory = {
    company: {id: 200, name: '优秀公司', son: {}},
    person: {id: 100, name: '优秀个人', son: {}},
    brand: {id: 400, name: '优秀品牌', son: {}},
    supplier: {id: 300, name: '优秀供应商', son: {}},
    decorator: {id: 500, name: '装修师', son: {}}
  }
  for (let key in jTreeResourceCategory) {
    let mode = jTreeResourceCategory[key].mode
    let name = ''
    switch (mode) {
    case '100':
      name = 'person'
      break
    case '200':
      name = 'company'
      break
    case '400':
      name = 'brand'
      break
    case '300':
      name = 'supplier'
      break
    case '500':
      name = 'decorator'
      break
    }
    aTreeResourceCategory[name].son[jTreeResourceCategory[key].id] = jTreeResourceCategory[key]
  }
  const aTreeCategory = getArray(aTreeResourceCategory)
  return aTreeCategory
}

// 获取店铺分类js文件
const getStoreCategory = async () => {
  const response = await fetchScriptFile(treeStoreCategoryUrl, 'jTreeStoreCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}
// 获取团购商品分类js文件
const getGrouponCategory = async () => {
  const response = await fetchScriptFile(treeGrouponCategoryUrl, 'jTreeGrouponCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}
// 获取资源作品标签
const getPortfolioCategory = async () => {
  const response = await fetchScriptFile(treeResourcePortfolioCategoryUrl, 'jTreeResourcePortfolioCategory')
  const aTreeCategory = getArray(response.son)
  return aTreeCategory
}
export {
  getArray,
  getArea,
  find,
  findValue,
  getGoodsCategory,
  getBuildingCategory,
  getMapMarkerCategory,
  getResourceCategory,
  getStoreCategory,
  getGrouponCategory,
  getPortfolioCategory
}
