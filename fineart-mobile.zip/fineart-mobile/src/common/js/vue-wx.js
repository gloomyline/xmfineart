import Vue from 'vue'
import LoadScript from 'vue-plugin-load-script'
import { BaseApi } from '@/common/js/BaseApi'
import { SHARE_DATA } from '@/assets/data/constants.js'
import { isInWX } from '@/common/js/utils'

Vue.use(LoadScript)

const WX_API_LIST = [
  'previewImage',
  'onMenuShareWeibo',
  'updateTimelineShareData',
  'updateAppMessageShareData',
  'onMenuShareTimeline',
  'onMenuShareQZone',
  'onMenuShareAppMessage',
  'onMenuShareQQ'
]

class WXSDK {
  wx = null // wx sdk
  wxApiStatus = null
  shareData = null
  module = null

  constructor ({ shareData = {} } = {}) {
    this.shareData = shareData
    this._init()
  }

  _loadSdk () {
    return new Promise((resolve, reject) => {
      Vue.loadScript('//res.wx.qq.com/open/js/jweixin-1.4.0.js')
        .then(() => {
          const wx = this.wx = window['wx']
          resolve(wx)
        }).catch((error) => {
          reject(error)
          console.log('ERROR')
        })
    })
  }

  async _init () {
    if (!isInWX()) {
      console.log('当前处于非微信环境下！')
      return
    }
    this.wx = await this._loadSdk()
    await this.configureWxApi()
    this._wxUpdateShare()
  }

  async configureWxApi () {
    const ticketData = await WXSDK.fetchTickets()
    const wxSdkCfg = {
      debug: false, // 开启调试模式
      appId: ticketData.appId, // 必填，公众号的唯一标识
      timestamp: ticketData.timestamp, // 必填，生成签名的时间戳
      nonceStr: ticketData.nonceStr, // 必填，生成签名的随机串
      signature: ticketData.signature, // 必填，签名，见附录1
      jsApiList: WX_API_LIST // 必填，需要使用的JS接口列表
    }
    this.wx.config(wxSdkCfg)
  }

  checkApiList () {
    return new Promise(resolve => {
      this.wx.checkJsApi({
        jsApiList: WX_API_LIST,
        success: (res) => {
          resolve(res.checkResult)
        }
      })
    })
  }

  _wxUpdateShare () {
    if (!isInWX() || !this.wx) {
      return
    }
    // 微信初始化完成后调用
    this.wx.ready(async () => {
      // 获取签名票据出错
      this.wx.error((res) => {
        console.log('微信API配置信息错误')
        console.log(res)
      })
      // 检测JS接口
      this.wxApiStatus = await this.checkApiList()
      if (this.wxApiStatus.updateAppMessageShareData) {
        this.wx.updateAppMessageShareData(this.shareData) // 分享到朋友或者QQ
      } else {
        this.wx.onMenuShareAppMessage(this.shareData) // 分享到朋友
        this.wx.onMenuShareQQ(this.shareData) // 分享到QQ
      }
      if (this.wxApiStatus.updateTimelineShareData) {
        this.wx.updateTimelineShareData(this.shareData) // 分享到朋友圈或者QQ空间
      } else {
        this.wx.onMenuShareTimeline(this.shareData) // 分享到朋友圈
        this.wx.onMenuShareQZone(this.shareData) // 分享到QQ空间
      }
      this.wx.onMenuShareWeibo(this.shareData) // 分享到腾讯微博
    })
  }

  static async fetchTickets () {
    const url = window.location.href.split('#')[0]
    try {
      const ticketRes = await BaseApi.request({
        url: '/sys/wechat/js-params',
        method: 'post',
        data: { url }
      })
      if (ticketRes.code === 200) {
        return ticketRes.results
      }
    } catch (e) {
      console.error(e)
    }
  }

  updateShareData (moduleName, {
    isInitPage = true,
    title,
    desc,
    link,
    imgUrl
  } = {}) {
    const shareData = SHARE_DATA[moduleName]
    this.shareData.title = title || shareData.title
    this.shareData.desc = desc || shareData.desc
    this.shareData.link = link || this.shareData.link
    this.shareData.imgUrl = imgUrl || shareData.imgUrl
    this._wxUpdateShare()
  }

  previewImage ({
    current = '', // 当前显示图片的http链接
    urls = [] // 需要预览的图片http链接列表
  } = {}) {
    if (!isInWX() || !this.wx) {
      return
    }
    // 微信初始化完成后调用
    this.wx.ready(async () => {
      // 获取签名票据出错
      this.wx.error((res) => {
        console.log('微信API配置信息错误')
        console.log(res)
      })
      // 检测JS接口
      this.wxApiStatus = await this.checkApiList()
      this.wx.previewImage({ current: current, urls: urls }) // 预览图片
    })
  }
}

export const WXPlugin = {}
WXPlugin.install = (vue, { shareData = SHARE_DATA } = {}) => {
  const wxSdk = new WXSDK({ shareData })
  Vue.wx = wxSdk
  Vue.prototype.$wx = wxSdk
}
