<template>
  <div :class="classes">
    <cube-scroll
      ref="scroll"
      :data="items"
      :options="options"
      @pulling-down="onPullingDown"
      @pulling-up="onPullingUp">
      <slot v-if="hasData"><ul class="list-wrap"><li class="item" v-for="i in items" :key="`key-${i}`">{{ i }}</li></ul></slot>
      <fine-art-empty v-else></fine-art-empty>
    </cube-scroll>
  </div>
</template>

<script>
import {COMPONENT_PREFIX} from '@/assets/data/constants'
import {hyphenCase} from '@/common/js/utils'

import FineArtEmpty from './FineArtEmpty.vue'
import { Scroll } from 'cube-ui'

export default {
  name: `${COMPONENT_PREFIX}Scroller`,
  components: {
    FineArtEmpty,
    'cube-scroll': Scroll
  },
  data () {
    return {
    }
  },
  created () {
  },
  mounted () {
    this._resizeScroll()
  },
  watch: {
    items: {
      deep: true,
      handler (newVal) {
        if (!this.$refs.scroll || this.disabled) return
        if (newVal.length < 3) {
          this.$refs.scroll.disable()
        } else {
          this.$refs.scroll.enable()
        }
      }
    },
    disabled (newVal) {
      if (newVal) {
        this.$refs.scroll.disable()
      } else {
        this.$refs.scroll.enable()
      }
    },
    height (newVal) {
      if (newVal) {
        this.$el.style.position = 'none'
        this.$el.style.height = newVal + 'rem'
      }
    }
  },
  props: {
    list: {
      type: [Array, Number],
      default () {
        return 10
      }
    },
    pullDownRefreshObj: {
      type: [Object, Boolean],
      default () {
        return {
          threshold: 60,
          txt: '加载成功'
        }
      }
    },
    pullUpLoadObj: {
      type: [Object, Boolean],
      default () {
        return {
          threshold: 30,
          txt: {
            more: '加载完成',
            noMore: '-- END --'
          }
        }
      }
    },
    disabled: {
      type: Boolean,
      default: false
    },
    hasData: {
      type: Boolean,
      default: true
    },
    height: {
      type: Number,
      default: 0
    },
    scrollbar: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-scroller`
    },
    options () {
      return {
        pullDownRefresh: this.pullDownRefreshObj,
        pullUpLoad: this.pullUpLoadObj,
        scrollbar: this.scrollbar
      }
    },
    items () {
      if (Array.isArray(this.list)) {
        return this.list
      } else {
        const ret = []
        for (let i = 0; i < this.list.length; ++i) {
          ret.push(i)
        }
        return ret
      }
    },
    scroll () {
      return this.$refs.scroll || null
    }
  },
  methods: {
    _resizeScroll () {
      if (this.height === 0) return
      if (this.height > 0) {
        this.$el.style.position = 'none'
        this.$el.style.height = this.height + 'rem'
      } else {
        this.$el.style.top = Math.abs(this.height) + 'rem'
      }
    },
    onPullingDown () {
      this.$emit('refresh', () => {})
    },
    onPullingUp () {
      const vm = this
      this.$emit('load-more', () => {
        vm.$refs.scroll.forceUpdate()
      })
    },
    _forceUpdate () {
      this.$nextTick(() => {
        this.$refs.scroll.forceUpdate()
      })
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-scroller
  fixed: left top 184px
  bottom: 0
  width: 100%
  color: $black
  .cube-pullup-wrapper
    .before-trigger
      font-size: 26px
      color: $grey
  .cube-pulldown-wrapper
    .after-trigger
      .cube-pulldown-loaded
        font-size: 26px
        color: $grey
  .cube-loading-spinners
    width: 48px
    height: 48px
  .cube-scroll-list-wrapper
    background-color: $white
</style>
