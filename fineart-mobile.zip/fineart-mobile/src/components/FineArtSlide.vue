<template>
  <div :class="classes" ref="slide">
    <div class="slide-group" ref="slideGroup">
      <slot></slot>
    </div>
    <div v-if="showDot" class="dots">
      <span class="dot"
            :key="index"
            :class="{active: currentPageIndex === index }"
            v-for="(item, index) in dots">{{ item }}</span>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import BScroll from 'better-scroll'

export default {
  name: `${COMPONENT_PREFIX}Slide`,
  props: {
    showDot: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      dots: [],
      slideWidth: '',
      slideGroup: '',
      children: '',
      stepX: '',
      currentPageIndex: 0
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-slide`
    }
  },
  mounted () {
    this.update()
  },
  activated () {
    if (!this.slide) {
      return
    }
    this.slide.enable()
    let pageIndex = this.slide.getCurrentPage().pageX
    this.slide.goToPage(pageIndex, 0, 0)
    this.currentPageIndex = pageIndex
  },
  deactivated () {
    this.slide.disable()
  },
  beforeDestroy () {
    this.slide.disable()
  },
  methods: {
    update () {
      if (this.slide) {
        this.slide.destroy()
      }
      this.$nextTick(() => {
        this.init()
      })
    },
    refresh () {
      this._setSlideWidth(true)
      this.slide.refresh()
    },
    init () {
      this.currentPageIndex = 0
      this._setSlideWidth()
      if (this.showDot) {
        this._initDots()
      }
      this._initSlide()
    },
    _setSlideWidth (isResize) {
      this.slideWidth = this.$refs.slide.clientWidth
      this.slideGroup = this.$refs.slideGroup.children[0].clientWidth
      this.$refs.slideGroup.style.width = this.$refs.slideGroup.children[0].clientWidth + 'px'
      this.children = this.$refs.slideGroup.children[0].children.length
      this.stepX = (this.slideGroup - this.slideWidth) / (this.children - 1)
    },
    _initSlide () {
      this.slide = new BScroll(this.$refs.slide, {
        scrollX: true,
        scrollY: false,
        momentum: false,
        bounce: false,
        snap: {
          loop: false,
          threshold: 0.1,
          stepX: this.stepX
        },
        stopPropagation: true,
        click: this.click
      })
      this.slide.on('scrollEnd', this._onScrollEnd)
    },
    _onScrollEnd () {
      let pageIndex = this.slide.getCurrentPage().pageX
      this.currentPageIndex = pageIndex
    },
    _initDots () {
      this.dots = new Array(this.children)
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-slide
  position: relative
  .dots
    position: absolute
    right: 0
    left: 0
    bottom: -12px
    transform: translateZ(1px)
    text-align: center
    font-size: 0
    .dot
      display: inline-block
      margin: 0 6px
      width: 12px
      height: 12px
      border-radius: 50%
      background: $grey1
      &.active
        background: $orange
</style>
