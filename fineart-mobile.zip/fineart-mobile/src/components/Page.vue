<template>
  <div :class="classes">
    <slot>这里是页面默认内容。</slot>
  </div>
</template>

<script>
const COMPONENT_NAME = 'FineArtPage'
const cls_prefix = 'fine-art'
export default {
  name: COMPONENT_NAME,
  data () {
    return {}
  },
  computed: {
    classes () {
      return `${cls_prefix}-page`
    },
    pageHeadShow () {
      return this.$store.state.pageHeadStatus
    }
  }
}
</script>

<style lang="stylus">
.fine-art-page
  padding-top: 94px
</style>
