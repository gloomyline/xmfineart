<template>
  <div class="fine-art-foot-nav fy-1px-t">
    <div class="nav-list">
      <a href="/index.html" class="nav-item" :class="{'choice': isChoose === 0}">
        <div class="wrap">
          <span class="icon icon-home"></span>
          <span class="name">首页</span>
        </div>
      </a>
      <a href="/discovery.html" class="nav-item" :class="{'choice': isChoose === 1}">
        <div class="wrap">
          <span class="icon icon-find"></span>
          <span class="name">发现</span>
        </div>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'FineArtFootNav',
  data () {
    return {
    }
  },
  props: {
    isChoose: {
      type: Number
    }
  }
}
</script>

<style lang="stylus" scoped>
.fine-art-foot-nav
  fixed: bottom left
  width: 100%
  height: 88px
  background-color: $white
  .nav-list
    display: flex
    .nav-item
      display: flex
      justify-content: center
      align-items: center
      width: 50%
      height: 88px
      &.choice
        .wrap .icon.icon-home
          background: url('../assets/imgs/home/icon-nav-home.png') center center no-repeat
          background-size: 42px auto
        .wrap .icon.icon-find
          background: url('../assets/imgs/home/icon-nav-find.png') center center no-repeat
          background-size: 42px auto
        .wrap .name
           color: $orange
      .wrap
        display: flex
        flex-wrap: wrap
        justify-content: center
        .icon
          display: block
          width: 42px
          height: 42px
          margin-right: 0
          margin-bottom: 12px
          background-color: $orange
          &.icon-home
            background: url('../assets/imgs/home/icon-nav-home-grey.png') center center no-repeat
            background-size: 42px auto
          &.icon-find
            background: url('../assets/imgs/home/icon-nav-find-grey.png') center center no-repeat
            background-size: 42px auto
        .name
          width: 100%
          text-align: center
          font-size: 18px
          color: $grey3
</style>
