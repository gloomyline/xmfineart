<template>
  <div class="myAdress">
    <!--装饰线-->
    <div class="decorate-line-wrap">
    </div>
    <!--地址-->
    <div class="address">
      <div class="address-item fy-1px-b" v-for="(item, index) in addressList" :key="index" @click="pageType === 2 ? toEditAddress(item) : selectAddress(item)">
        <div class="buyer-name">
          <div>{{item.name | labelFormatter(3)}}</div>
          <div class="default" v-if="item.is_default"><span>默认</span></div>
        </div>
        <div class="phone-address">
          <p class="phone">{{item.mobile}}</p>
          <p class="address-name">{{item.address_desc}}</p>
        </div>
        <div class="delete-address" @click.stop="deleteAddress(item)" v-show="pageType === 2">
          <i class="fy-icon-trash-grey"></i>
        </div>
      </div>
    </div>
    <!--按钮-->
    <div class="add-address" @click="goAddAddress()"><i class="fy-icon-add-orange"></i>&nbsp;添加收货地址</div>
  </div>
</template>
<script>
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'
export default {
  name: `FineArtMyAddress`,
  data () {
    return {
      addressList: []
    }
  },
  props: {
    pageType: {
      type: Number // 1: 可选择地址 ， 2：可编辑地址
    }
  },
  computed: {
  },
  created () {
    this.initMyAddress()
  },
  methods: {
    toEditAddress (addressItem = {}) {
      addressItem.flag = 1 // 1表示编辑地址
      this.$router.push(
        {
          name: 'AddressAdd', // 使用prarams传参需要使用name属性
          params: addressItem
        }
      )
    },
    selectAddress (item) {
      this.$emit('selected-address', item)
    },
    goAddAddress () {
      this.$emit('handle-add')
    },
    async initMyAddress () {
      this.addressList = await api.addressFetchList()
      // 手动添加地区名称，用于收货地址编辑页面使用
      for (let value of this.addressList) {
        const index = value.address_desc.search(value.address)
        value.area = value.address_desc.substring(0, index)
      }
    },
    async deleteAddress (addressItem = {}) {
      const responResult = await api.addressDel(addressItem.id)
      if (responResult.code === 200) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['ACCOUNT_ADDRESS_DELETE_OK'], type: 'success'})
        this.initMyAddress()
      }
    }
  },
  filters: {
    labelFormatter (str, length) {
      if (typeof str !== 'string') return
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
  }
}
</script>
<style lang="stylus" scoped>
  .myAdress
    position: relative
    .decorate-line-wrap
      height: 12px
      background-image: url("../assets/imgs/mall/icon-check-bill-decorate-line@2x.png")
      background-repeat: no-repeat
      background-size: cover
    .address
      padding: 0 20px 0 20px
      .address-item
        padding: 30px 30px 30px 10px
        display: flex
        flex-direction: row
        .buyer-name
          width: 120px
          font-size: 28px
          line-height: 40px
          margin-right: 20px
          color: $black1
          .default
            width: 62px
            height: 32px
            color: $orange
            line-height: 32px
            border-radius: 4px
            font-size: 18px
            text-align: center
            margin-top: 14px
            border: 1.4px solid $orange
        .phone-address
          width: 496px
          .phone
            font-size: 28px
            line-height: 40px
            color: $black1
          .address-name
            font-size: 24px
            line-height: 33px
            color: $grey3
            margin-top: 14px
        .delete-address
          font-size: 30px
          display: flex
          align-items: center
          justify-content: left
          margin-left: 40px
          .fy-icon-trash-grey
            color: $grey2
    .add-address
      margin: 30px 30px 0 30px
      text-align: center
      font-size: 30px
      line-height: 88px
      color: $orange
      height: 88px
      border-radius: 4px
      border: 1.4px solid $orange
    .fy-1px,.fy-1px-b
      font-family: PingFangSC, Microsoft Yahei!important
</style>
