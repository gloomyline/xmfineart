<template>
  <div class="fine-art-map">
    <!-- map 容器 -->
    <div class="map-container" id="map"></div>
    <div class="btn-location" @click="location"><span class="icon"></span></div>
    <group class="marker-relocation">
      <fine-art-category title="地区" v-model="area" :data-list="areaList" @choice-name="changeArea"></fine-art-category>
      <x-input title="详细地址" :show-clear="false" v-model="userInputAddress" class="detail-address" text-align="right" placeholder="请填写详细地址"></x-input>
    </group>
  </div>
</template>

<script>
import {
  MAP_TOUCH_MOVE_DISTANCE,
  MAP_POSITION_MARKER_WIDTH,
  MAP_POSITION_MARKER_HEIGHT
} from '@/assets/data/constants'
import { deepClone } from '@/common/js/utils'
import FineArtCategory from './FineArtCategory.vue'
import { getArea, findValue } from '@/common/js/loadScript'
import { FMap } from '@/common/js/Map'

export default {
  name: 'FineArtMap',
  data () {
    return {
      mapInstance: null,
      // 地图初始化时用户定位
      userInitPosition: {},
      // 当前用户定位
      userCurrentPosition: {},
      areaList: [],
      area: '',
      // 当前用户地址
      address: {
        address: '',
        city: '',
        district: '', // 行政区
        fullAddress: '',
        province: '',
        area_id: [],
        point: [] // [lng, lat]
      },
      FMap: null
    }
  },
  props: {
    // 经纬度数组[lng, lat]
    point: {
      type: Array
    }
  },
  computed: {
    // 当前用户地址
    userCurrentAddress () {
      const address = this.address
      return `${address.province}${address.city}${address.district}`
    },
    // 用户填写详细地址
    userInputAddress: {
      set (val) {
        this.address.address = val
      },
      get () {
        return this.address.address
      }
    }
  },
  watch: {
    address: {
      handler (newVal) {
        this.area = `${newVal.province} / ${newVal.city} / ${newVal.district}`
        const areaArr = findValue(this.areaList, newVal.district)
        newVal.area_id = areaArr
        newVal.point = [this.userCurrentPosition.lng, this.userCurrentPosition.lat]
        this.$emit('change-address', newVal)
      },
      deep: true
    },
    point (newVal, oldVal) {
      if (oldVal !== newVal) {
        this._initMap()
      }
    }
  },
  created () {
    this.FMap = new FMap()
    this._initMap()
    this.initArea()
  },
  beforeDestroy () {
    this.FMap.destory()
  },
  methods: {
    // 选择省市区定位地图
    async changeArea (val) {
      const areaVal = val.replace(' / ', '')
      const position = await this.FMap.getLocation(areaVal)
      this.FMap.mapGeoLocal(position)
      this.address = await this.FMap.getAddress(position)
      this.userCurrentPosition = {
        lng: position[0],
        lat: position[1]
      }
    },
    async initArea () {
      this.areaList = await getArea()
    },
    // 绑定地图事件
    _bindEvents (mapInstance) {
      // 绑定地图点击事件
      mapInstance.on('click', async (data) => {
        mapInstance.positionMarker.setTop(true)
        this.userCurrentPosition = data.lnglat
        const position = [data.lnglat.lng, data.lnglat.lat]
        this.FMap.mapGeoLocal(position)
        // 更新当前用户地址
        this.address = await this.FMap.getAddress(this.userCurrentPosition)
      })
      // 绑定地图缩放事件, 监听缩放比例的变化,(双指)缩放
      mapInstance.on('zoomchange', async () => {
        const position = mapInstance.getCenter()
        this.userCurrentPosition = position
        this.FMap.mapGeoLocal([position.lng, position.lat])
        this.address = await this.FMap.getAddress(position)
      })
      // 绑定(单指)触摸移动事件
      mapInstance.on('touchstart', ev => {
        this.sp = ev.pixel
      })
      mapInstance.on('touchend', async ev => {
        this.ep = ev.pixel
        const distance = Math.pow(Math.pow(this.ep.x - this.sp.x, 2) + Math.pow(this.ep.y - this.sp.y, 2), 1 / 2)
        if (distance >= MAP_TOUCH_MOVE_DISTANCE) {
          const position = mapInstance.getCenter()
          this.userCurrentPosition = position
          this.FMap.mapGeoLocal([position.lng, position.lat])
          this.address = await this.FMap.getAddress(position)
        }
      })
    },
    // 添加定位点标记
    _initPositionMarker (mapInstance) {
      const dpr = window.devicePixelRatio >= 3 ? 3 : 2
      const icon = require(`assets/imgs/icon-map-select@${dpr}x.png`)
      const positionMarker = this.positionMarker = this.FMap.createMarker(icon, {
        w: MAP_POSITION_MARKER_WIDTH,
        h: MAP_POSITION_MARKER_HEIGHT
      })
      mapInstance.add(positionMarker)
      mapInstance.positionMarker = positionMarker
      // 初始化定位点位置
      this.FMap.mapGeoLocal()
    },
    async _initMap () {
      try {
        // 创建地图实例
        const mapInstance = await this.FMap.createMap('map', this)
        this._initPositionMarker(mapInstance)
        this._bindEvents(mapInstance)
        // 获取当前用户地理位置
        let position = []
        if (!this.point[0] || !this.point[1]) {
          position = this.userCurrentPosition = await this.FMap.geoLocation()
        } else {
          position = this.point
          this.FMap.mapGeoLocal(position)
        }
        this.userInitPosition = deepClone(position)
        // 获取当前用户地址信息
        this.address = await this.FMap.getAddress(position)
        this.address.point = position
        this.mapInstance = mapInstance
      } catch (e) {
        console.log('error info:', e)
        // 创建地图实例出错的话刷新当前页，重新创建
        window.location.reload()
      }
    },
    // 重新定位当前用户位置
    async location () {
      const position = [this.userInitPosition.lng, this.userInitPosition.lat]
      this.FMap.mapGeoLocal(position)
      this.userCurrentPosition = deepClone(position)
      this.address = await this.FMap.getAddress(position)
    }
  },
  components: {
    FineArtCategory
  }
}
</script>

<style lang="stylus">
.fine-art-map
  position: relative
  color: $black1
  .map-container
    width: 100%
    height: 459px
    margin-bottom: 30px
    z-index: 1
  .btn-location
    absolute: right 20px top 380px
    display: block
    width: 80px
    height: 80px
    z-index: 502
    .icon
      inline-icon(80px, 80px)
      bg-img('../assets/imgs/map/icon-location')
  .marker-relocation
    color: $black1
    z-index: 10
    .weui-cells
      margin-top: 0
      &:before
        display: none
    .weui-cell
      height: 94px
      padding: 0
    .address .weui-cell__ft
      width: 80%
      font-size: 28px
      color: $black1
      {ellipse}
    .detail-address
      input
        {ellipse}
</style>
