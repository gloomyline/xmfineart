<template>
  <div class="error-page">
    <div class="page-content">
      <img class="tip-img" src="../assets/imgs/member/error.png">
      <p class="tip-text">{{ message }}</p>
      <x-button class="jump-btn" plain type="primary" @click.native="goToIndex()">返回首页</x-button>
    </div>
  </div>
</template>

<script>
import { XButton } from 'vux'

export default {
  name: 'Error',
  data () {
    return {
      message: '',
      messageList: {
        403: '被拒绝访问了',
        404: '页面找不到了',
        500: '服务器出错了'
      }
    }
  },
  methods: {
    goToIndex () {
      window.location = 'index.html'
    }
  },
  created () {
    this.message = this.messageList[this.$route.query.code] || '服务器出错了～'
  },
  components: {
    XButton
  }
}
</script>

<style lang="stylus">
.error-page
  .page-content
    position: absolute
    top: 50px
    width: 100%
    .tip-img
      width: 610px
      height: 610px
      display: block
      margin: 0 auto
    .tip-text
      width: 100%
      height: 40px
      font-size: 28px
      color: $grey2
      line-height: 40px
      text-align: center
      margin-top: 36px
  .jump-btn
    padding: 0
    width: 469px
    height: 76px
    line-height: 76px
    margin-top: 30px
</style>
