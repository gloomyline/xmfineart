<template>
  <div class="fine-art-category">
    <x-input
      class="category-input"
      disabled
      text-align="right"
      :title="title"
      :value="value"
      @click.native="showPopup()">
      <span slot="right" class="input-placeholder" v-if="!value">{{ placeholder }}</span>
    </x-input>
    <div v-transfer-dom>
      <popup v-model="isShowed" position="bottom" :show-mask="true" :popup-style="{zIndex: 502}">
        <div class="fy-popup-header fy-1px-b">
          <ul class="fy-choice">
            <li class="fy-choice-item"
                :class="{'is-select': index === category.length - 1}"
                v-for="(item, index) in category"
                :key="index"
                @click="changeList(item, index)">{{ item.label }}</li>
            <li class="fy-choice-item is-select"
                v-show="!category.length">请选择</li>
          </ul>
          <x-button class="fy-popup-btn" plain @click.native="confirmHandler()">确定</x-button>
        </div>
        <scroller lock-x class="fy-popup-content" height="6.17rem" ref="scroller">
          <div class="cate-wrap">
            <ul class="cate-list"
                v-if="list.length && showPanel === cateIndex"
                v-for="(cate, cateIndex) in list"
                :key="cateIndex">
              <li class="cate-item"
                  v-for="(item, index) in cate"
                  :class="{'is-cate': item.value === isCate}"
                  :key="index"
                  @click="chooseCate(item, cateIndex)">{{item.label}}</li>
            </ul>
          </div>
        </scroller>
      </popup>
    </div>
  </div>
</template>

<script>
import { Popup, Group, CellBox, Scroller } from 'vux'
export default {
  name: 'FineArtCategory',
  data () {
    return {
      // 是否显示Popup
      isShowed: false,
      // 显示的数据数组
      list: [],
      // 选中分类的样式
      isCate: 0,
      // 显示面板的数组下标 list[showPanel]
      showPanel: 0,
      // 选中的数组
      category: []
    }
  },
  props: {
    title: {
      type: String,
      default: '分类'
    },
    placeholder: {
      type: String,
      default: '请选择'
    },
    dataList: {
      type: Array,
      default () {
        return []
      }
    },
    value: {
      type: String,
      default: ''
    }
  },
  model: {
    prop: 'value',
    event: 'choice-name'
  },
  watch: {
    dataList (newVal) {
      this.list.push([...newVal])
    },
    // 监听tab视图变化
    showPanel () {
      this.$nextTick(() => {
        this.$refs.scroller.reset({top: 0})
      })
    }
  },
  methods: {
    showPopup () {
      // 显示Popup
      this.isShowed = true
    },
    confirmHandler () {
      // 关闭Popup
      this.isShowed = false
      if (this.category.length === 0) return

      const cate = this.category.map((x) => {
        return x.label
      })
      const cateId = this.category.map((x) => {
        return x.value
      })
      this.$emit('choice-name', cate.join(' / '))
      this.$emit('choice-cate', cateId)
    },
    // 选择分类
    chooseCate (item, caseIndex) {
      this.isCate = item.value
      this.category[caseIndex] = item
      // 是否还有下一层选项
      if (item.children) {
        this.list.push([...item.children])
        this.showPanel++ // 展示第几层数据
      }
    },
    // 选择Tab
    changeList (item, index) {
      this.showPanel = index
      // 重置当前选中之后的数据
      if (this.category.length - 1 >= index) {
        this.category.length = index + 1
        this.list.length = index + 1
      }
      this.isCate = this.category[index].value
    }
  },
  components: {
    Popup,
    Group,
    CellBox,
    Scroller
  }
}
</script>

<style lang="stylus">
.fine-art-category
  color: $black1
  .category-input
    .weui-cell__bd
      position: relative
      padding-right: 17PX
      &:after
        absolute: top 50% right 4px
        content: ''
        width: 18px
        height: 18px
        border-width: 2px 2px 0 0
        border-color: $grey2
        border-style: solid
        transform: translateY(-50%) rotate(45deg)
  .vux-x-input.disabled .weui-input
    text-fill-color: unset !important
    -webkit-text-fill-color: unset !important
  .input-placeholder
    absolute: right 24px top 50%
    font-weight: 300
    font-size: 27px
    color: $grey2
    transform: translateY(-50%)
.fy-popup-header
  display: flex
  justify-content: space-between
  width: 100%
  height: 100px
  padding: 0 30px
  background-color: $grey-menu
  .fy-choice
    display: flex
    &-item
      height: 100px
      line-height: 100px
      margin-right: 30px
      font-size: 28px
      &.is-select
        position: relative
        &:before
          content: ''
          position: absolute
          bottom: 0
          left: 50%
          width: 100%
          height: 4px
          background-color: $orange
          transform: translateX(-50%)
  .fy-popup-btn
    width: 60px
    height: 100px
    padding: 0
    margin: 0
    font-size: 28px
    color: $orange
    border: none
.fy-popup-content
  width: 100%
  background-color: $white
  .cate-list
    width: 100%
    padding: 30px
    .cate-item
      padding: 20px 0
      font-size: 26px
      &.is-cate
        color: $orange
</style>
