<template>
  <x-dialog
    class="login-tip-modal"
    v-model="isShowed">
    <span class="close-btn fy-icon-off" @click="closeModal()"></span>
    <div class="modal-body">
      <div class="modal-bg"></div>
        <div class="tip-text">
          <slot name="tip-text">您还未登录，请先前往登录</slot>
        </div>
      <x-button
        class="go-login-btn"
        type="primary"
        @click.native="goToLogin">去登录</x-button>
    </div>
  </x-dialog>
</template>

<script>
import { XDialog, XButton } from 'vux'
import { goLogin } from '@/common/js/utils'
export default {
  name: 'FineArtLoginTip',
  data () {
    return {
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    goToLogin () {
      goLogin()
    },
    closeModal () {
      this.$emit('change-show', false)
    }
  },
  components: {
    XDialog,
    XButton
  }
}
</script>

<style lang="stylus">
.login-tip-modal .weui-dialog
  width: 566px
  max-width: unset
  border-radius: 10px
  .close-btn
    color: $grey6
    font-size: 25px
    padding: 25px
    absolute: top right
  .modal-body
    padding: 60px 82px 52px 82px
    border-radius: 4px
    .modal-bg
      height: 300px
      width: 360px
      margin: 0 auto
      background-size: cover
      background-repeat: no-repeat
      bg-img('../assets/imgs/login-tip-bg')
    .tip-text
      width: 328px
      margin: 0 auto
      color: $black2
      font-size: 26px
      line-height: 40px
      text-align: center
      padding-top: 30px
    .go-login-btn
      width: 416px
      line-height: 80px
      font-size: 30px
      margin-top: 30px
      padding: 0
      border-radius: 40px
      box-shadow:0px 4px 14px 0px rgba(247,181,44,0.48)
</style>
