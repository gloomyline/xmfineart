<template>
  <div :class="classes">
    <group>
      <!-- 省市区 -->
      <fine-art-category title="省市区" v-model="areaVal" :data-list="areaList" @choice-cate="chooseCate"></fine-art-category>
      <x-input
        title="详细地区"
        placeholder='输入详细地址'
        placeholder-align="right"
        text-align="right"
        :show-clear="false"
        v-model="addressObj.address"></x-input>
      <x-input
        title="邮政编码"
        placeholder='输入邮政编码'
        placeholder-align="right"
        text-align="right"
        :show-clear="false"
        v-model="addressObj.zip_code" type="number"></x-input>
      <x-input
        title="收货人"
        placeholder='输入收货人姓名'
        placeholder-align="right"
        text-align="right"
        :show-clear="false"
        v-model="addressObj.name"></x-input>
      <x-input
        title="手机号码"
        placeholder='输入手机号码'
        placeholder-align="right"
        text-align="right"
        :show-clear="false"
        v-model="addressObj.mobile" type="number"></x-input>
      <div class="checker-wrap">
        <check-icon :value.sync="isDefault">默认地址</check-icon>
      </div>
      <x-button class="save-btn" type="primary" @click.native="saveAddress()" v-if="flag === 2">保存</x-button>
      <x-button class="save-btn" type="primary" @click.native="saveAddress()" v-else>保存编辑</x-button>
      <x-button class="cancel-btn" type="default" plain @click.native="goCancel()">取消</x-button>
    </group>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import FineArtCategory from './FineArtCategory.vue'
import { getArea } from '@/common/js/loadScript'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'

export default {
  name: 'FineArtAddressAdd',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{10}$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      addressObj: {
        address: '',
        area: '',
        zip_code: '',
        name: '',
        mobile: '',
        is_default: false,
        sys_area_id: ''
      },
      areaVal: '',
      isDefault: false,
      addressObjRule: {
        area: [
          { required: true, message: '请选择地区' }
        ],
        address: [
          { required: true, message: '请输入详细收货地址' }
        ],
        name: [
          { required: true, message: '请输入收货人名字' }
        ],
        mobile: [
          { required: true, message: '请输入手机号' },
          mobileValidator
        ]
      },
      flag: 2,
      areaList: []
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-address-add`
    }
  },
  created  () {
    this.init()
  },
  methods: {
    async init () {
      this.areaList = await getArea()
      // 根据收货地址页面传过来的路由参数初始化页面 1：编辑地址 ，2：添加地址
      this.flag = this.$route.params.flag ? this.$route.params.flag : 2
      if (this.flag === 1) {
        this.addressObj = this.$route.params
        this.isDefault = this.addressObj.is_default
        this.areaVal = this.addressObj.area
      }
    },
    chooseCate (value) {
      this.addressObj.area = this.areaVal
      const arrayLength = value.length
      this.addressObj.sys_area_id = value[arrayLength - 1]
    },
    async saveAddress () {
      const rules = await validate(this.addressObj, this.addressObjRule)
      if (!rules) return
      // 新增收货地址
      // 处理是否为默认地址
      this.addressObj.is_default = this.isDefault ? 100 : 200
      let responseResult = {}
      if (this.flag === 2) {
        responseResult = await api.addressAdd(this.addressObj)
        if (responseResult.code === 200) {
          this.$store.commit('ADD_MESSAGE', {msg: MSG['ACCOUNT_ADDRESS_ADD_OK'], type: 'success'})
          this.$emit('before-close')
        }
      } else {
        responseResult = await api.addressEdit(this.addressObj)
        if (responseResult.code === 200) {
          this.$store.commit('ADD_MESSAGE', {msg: MSG['ACCOUNT_ADDRESS_EDIT_OK'], type: 'success'})
          this.$emit('before-close')
        }
      }
    },
    goCancel () {
      this.$emit('before-close')
    }
  },
  components: {
    FineArtCategory
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-address-add
  color: $black1
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      padding-left: 0
      padding-right: 0
  .cancel-btn
    color: $grey3
    font-weight: 300
    margin-top: 30px
    border-color: $grey
  .save-btn
    margin-top: 30px
  .checker-wrap
    font-size: 30px
    padding: 20px 0 20px 0
    .vux-check-icon
      .weui-icon-success
        font-size: 39px
      .weui-icon-circle
        font-size: 39px
      .weui-icon-success-circle
        font-size: 39px
</style>
