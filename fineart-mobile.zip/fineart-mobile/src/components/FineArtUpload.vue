<template>
  <div :class="[prefixCls]" :style="styles">
    <div
      :class="classes">
      <input
        ref="input"
        type="file"
        accept="image/*"
        :class="[prefixCls + '-input']"
        @change="handleChange">
      <slot></slot>
    </div>
    <slot name="tip"></slot>
  </div>
</template>
<script>
import { BaseApi } from '@/common/js/BaseApi'
const prefixCls = 'fy-upload'
export default {
  name: 'FineArtUpload',
  props: {
    width: {
      type: [Number, String],
      default: 120
    },
    height: {
      type: [Number, String],
      default: 120
    },
    action: {
      type: String,
      required: true
    },
    headers: {
      type: Object,
      default () {
        return {}
      }
    },
    data: {
      type: Object
    },
    name: {
      type: String,
      default: 'file'
    },
    type: {
      type: String,
      default: 'select'
    },
    format: {
      type: Array,
      default () {
        return []
      }
    },
    maxSize: {
      type: Number
    },
    beforeUpload: Function,
    onProgress: {
      type: Function,
      default () {
        return {}
      }
    },
    onSuccess: {
      type: Function,
      default () {
        return {}
      }
    },
    onError: {
      type: Function,
      default () {
        return {}
      }
    },
    onRemove: {
      type: Function,
      default () {
        return {}
      }
    },
    onPreview: {
      type: Function,
      default () {
        return {}
      }
    },
    onExceededSize: {
      type: Function,
      default () {
        return {}
      }
    },
    onFormatError: {
      type: Function,
      default () {
        return {}
      }
    }
  },
  data () {
    return {
      prefixCls: prefixCls,
      dragOver: false,
      fileList: [],
      tempIndex: 1
    }
  },
  computed: {
    classes () {
      return [
        `${prefixCls}`,
        `${prefixCls}-select`
      ]
    },
    styles () {
      return {
        width: `${this.width / 75}rem`,
        height: `${this.height / 75}rem`
      }
    }
  },
  methods: {
    handleChange (e) {
      const files = e.target.files

      if (!files) {
        return
      }
      this.uploadFiles(files)
      this.$refs.input.value = null
    },
    uploadFiles (files) {
      let postFiles = Array.prototype.slice.call(files)
      if (!this.multiple) postFiles = postFiles.slice(0, 1)

      if (postFiles.length === 0) return

      postFiles.forEach(file => {
        this.upload(file)
      })
    },
    upload (file) {
      if (!this.beforeUpload) {
        return this.post(file)
      }

      const before = this.beforeUpload(file)
      if (before && before.then) {
        before.then(processedFile => {
          if (Object.prototype.toString.call(processedFile) === '[object File]') {
            this.post(processedFile)
          } else {
            this.post(file)
          }
        }, () => {
          // this.$emit('cancel', file);
        })
      } else if (before !== false) {
        this.post(file)
      } else {
        // this.$emit('cancel', file);
      }
    },
    async post (file) {
      // check format
      if (this.format.length) {
        const _file_format = file.name.split('.').pop().toLocaleLowerCase()
        const checked = this.format.some(item => item.toLocaleLowerCase() === _file_format)
        if (!checked) {
          this.onFormatError(file, this.fileList)
          return false
        }
      }

      // check maxSize
      if (this.maxSize) {
        if (file.size > this.maxSize * 1024) {
          this.onExceededSize(file, this.fileList)
          return false
        }
      }

      this.handleStart(file)
      let formData = new FormData() // 创建form对象
      // 添加form表单中其他数据
      Object.keys(this.data).map(key => {
        formData.append(key, this.data[key])
      })
      // 通过append向form对象添加数据
      formData.append(this.name, file)
      // 添加请求头
      let config = {
        headers: {'Content-Type': 'multipart/form-data'}
      }
      BaseApi.$http.post(this.action, formData, config)
        .then(res => {
          // handle success
          if (res.data.code === 200) {
            this.handleSuccess(res.data, file)
          } else {
            this.$store.commit('ADD_MESSAGE', { msg: res.data.msg })
          }
        })
        .catch((error) => {
          // handle error
          this.handleError(error, file)
        })
    },
    handleStart (file) {
      file.uid = Date.now() + this.tempIndex++
      const _file = {
        status: 'uploading',
        name: file.name,
        size: file.size,
        percentage: 0,
        uid: file.uid,
        showProgress: true
      }

      this.fileList.push(_file)
    },
    getFile (file) {
      const fileList = this.fileList
      let target
      fileList.every(item => {
        target = file.uid === item.uid ? item : null
        return !target
      })
      return target
    },
    handleProgress (e, file) {
      const _file = this.getFile(file)
      this.onProgress(e, _file, this.fileList)
      _file.percentage = e.percent || 0
    },
    handleSuccess (res, file) {
      const _file = this.getFile(file)

      if (_file) {
        _file.status = 'finished'
        _file.response = res

        this.onSuccess(res, _file, this.fileList)

        setTimeout(() => {
          _file.showProgress = false
        }, 1000)
      }
    },
    handleError (err, file) {
      const _file = this.getFile(file)
      const fileList = this.fileList

      _file.status = 'fail'

      fileList.splice(fileList.indexOf(_file), 1)

      this.onError(err, file)
    }
  }
}
</script>
<style lang="stylus" scoped>
.fy-upload
  position: relative
  &-select
    display: inline-block
    width: 100%
    height: 100%
  input[type="file"]
    display: block
    absolute: top left
    opacity: 0
    width: 100%
    height: 100%
    z-index: 5
</style>
