<template lang="html">
  <div class="fineart-head-wrap">
    <div class="fineart-head fy-1px-b">
      <div class="left" @click.stop="memberClickHandler">
        <slot name="icon-avatar">
          <div class="avatar-wrap"><i class="icon" :class="avatarName"></i></div>
        </slot>
      </div>
      <div class="center">
        <slot name="title"><h2 class="title-text">{{ title }}</h2></slot>
      </div>
      <div class="right" @click.stop="funcClickHandler" id="rightFunc">
        <transition name="fade-in">
          <div class="func-wrap" v-if="!isFuncExpanded" key="unexpanded"><i class="icon" :class="funcName"></i></div>
          <div class="close-wrap" v-else key="expanded"><i class="icon fy-icon-off"></i></div>
        </transition>
      </div>
    </div>
    <transition name="fade">
      <div class="member-mask"
           v-show="isMemberExpanded"
           @touchmove="preventScroll($event)"
           @click="closeMember"></div>
    </transition>
    <transition name="slide">
      <div class="member-menu-wrap" v-show="isMemberExpanded" @touchmove="preventScroll($event)">
        <side-bar @slide-left="isMemberExpanded = false"  @click-handler="changeHandler" :status="isMemberExpanded"></side-bar>
      </div>
    </transition>
    <transition name="fade">
      <div class="func-mask"
           v-show="isFuncExpanded"
           @touchmove="preventScroll($event)"
           @click="closeFunc"></div>
    </transition>
    <div class="func-menu-wrap" @touchmove="preventScroll($event)">
      <div class="func-menu" :class="{'expanded': isFuncExpanded}">
        <div class="menu-wrap">
          <div class="menu-list">
            <a class="menu-item" :href="tab.link" v-for="(tab, index) in tabs" :key="index" @click="closeFunc">{{ tab.label }}</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SideBar from 'components/SideBar.vue'

export default {
  data () {
    return {
      tabs: [
        {
          label: '首页',
          link: 'index.html'
        },
        {
          label: '斐艺地图',
          link: 'map.html'
        },
        {
          label: '斐艺购',
          link: 'mall.html'
        },
        {
          label: '斐艺建筑',
          link: 'building.html'
        },
        {
          label: '斐艺资源',
          link: 'resource.html'
        },
        {
          label: '官方微信',
          link: 'index.html#/focus-us'
        }
      ],
      isMemberExpanded: false, // 会员中心是否处于展开状态
      isFuncExpanded: false // 功能菜单是否处于展开状态
    }
  },
  props: {
    title: {
      type: String,
      default: '首页'
    },
    avatarName: { // 使用svg字符集的类名，可以使用对应的 svg icon 字体图标
      type: String,
      default: 'fy-icon-home'
    },
    funcName: {
      type: String,
      default: 'fy-icon-more'
    }
  },
  watch: {
    isMemberExpanded (newVal) {
      const vm = this
      if (newVal) {
        document.addEventListener('mousewheel', vm.preventScroll, false)
      } else {
        document.removeEventListener('mousewheel', vm.preventScroll, false)
      }
    },
    isFuncExpanded (newVal) {
      const vm = this
      if (newVal) { // 阻止滚动事件
        document.addEventListener('mousewheel', vm.preventScroll, false)
      } else { // 取消阻止滚动事件
        document.removeEventListener('mousewheel', vm.preventScroll, false)
      }
    }
  },
  methods: {
    changeHandler (value) {
      this.isMemberExpanded = value
    },
    // 左边栏以及导航栏弹窗弹出时，阻止弹窗触发滚动事件
    preventScroll (e) {
      e.preventDefault()
      return false
    },
    // toggle 会员中心左边栏菜单展开、关闭
    memberClickHandler () {
      if (this.isFuncExpanded) return // 如果功能导航下拉菜单栏已展开，则维持当前会员中心菜单栏折叠状况
      this.isMemberExpanded = !this.isMemberExpanded
    },
    // toggle 模块导航栏展开、关闭
    funcClickHandler () {
      if (this.isMemberExpanded) return // 如果会员中心左侧菜单栏已展开，则维持当前功能菜单折叠状况
      this.isFuncExpanded = !this.isFuncExpanded
      if (!this.isFuncExpanded) {
        this.$emit('close-func')
      }
    },
    // 关闭会员中心左边栏菜单
    closeMember () {
      this.isMemberExpanded = false
    },
    // 关闭功能菜单
    closeFunc () {
      this.isFuncExpanded = false
      this.$emit('close-func')
    }
  },
  components: {
    SideBar
  }
}
</script>

<style lang="stylus" scoped>
.fineart-head-wrap
  fixed: left top
  width: 100%
  background-color: $white
  z-index: 11 /* keep it top on the first layout (page-display-layout) */
  .fineart-head
    position: relative
    display: flex
    justify-content: space-between
    align-items: center
    width: 100%
    height: 94px
    padding: 0 24px
    color: $black
    .right
      position: relative
      width: 52px
      height: 52px
      .func-wrap
        absolute: left top
    .close-wrap
        absolute: left 8px top 8px
        font-size: 0
        .fy-icon-off
          font-size: 34px
          color: $black2
        &.fade-in-enter-active
          transition: all .6s ease-in-out
        &.fade-in-enter
          opacity: 0
          transform: rotate(90deg)
    .avatar-wrap
      padding: 6px
      font-size: 0
      .icon
        font-size: 40px
    .func-wrap
      padding: 6px
      font-size: 0
      .icon
        font-size: 34px
    .title-text
      font-size: 32px
  .member-mask
    fixed: left top
    width: 100%
    height: 100%
    background-color: rgba(33, 33, 33, 0.6)
    z-index: 1
    &.fade-enter-active, &.fade-leave-active
      transition: opacity .8s ease
    &.fade-enter, &.fade-leave-to
      opacity: 0
  .member-menu-wrap
    fixed: left top
    bottom: 0
    width: 460px
    z-index: 2
    &.slide-enter-active
      transition: all 0.8s ease
    &.slide-leave-active
      transition all .6s cubic-bezier(1, .4, .71, 1.52)
    &.slide-enter, &.slide-leave-to
      transform: translate3d(-460px, 0, 0)
    .member-menu
      width: 100%
      height: 100%
      background-color: $white
  .func-mask
    fixed: left top 94px
    height: 100%
    width: 100%
    background-color: rgba(33, 33, 33, 0.6)
    z-index: 9
    &.fade-enter-active, &.fade-leave-active
      transition: all .8s ease
    &.fade-enter, &.fade-leave-to
      opacity: 0
  .func-menu-wrap
    fixed: left top 94px
    width: 100%
    z-index: 10
    .func-menu
      width: 100%
      max-height: 0
      padding: 0 30px
      background-color: $white
      transition: all 0.6s cubic-bezier(0, 1, 0, 1) -.1s
      overflow: hidden
      &.expanded
        max-height: 999px
        transition-timing-function: cubic-bezier(.5, 0, 1, 0)
        transition-delay: 0
      .menu-wrap
        width: 100%
        overflow: hidden
        .menu-list
          display: flex
          flex-flow: wrap
          padding: 60px 0 30px 0
          margin-right: -30px
          .menu-item
            width: 210px
            height: 110px
            line-height: 110px
            text-align: center
            margin: 0 30px 30px 0
            border: 1px solid $grey1
            font-size: 26px
            color: $black
            text-decoration: none
</style>
