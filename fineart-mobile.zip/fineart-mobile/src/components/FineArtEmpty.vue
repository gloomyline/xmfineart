<template>
  <div :class="classes">
    <img class="empty-img" src="../assets/imgs/resource/empty-list.png"/>
    <p class="nothing-word">
      <slot>空空如也~</slot>
    </p>
  </div>
</template>

<script>
import {COMPONENT_PREFIX} from '@/assets/data/constants'
import {hyphenCase} from '@/common/js/utils'

export default {
  name: `${COMPONENT_PREFIX}Empty`,
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-empty`
    }
  }
}
</script>

<style lang="stylus" scoped>
.{$cls_prefix}-empty
  padding-top: 80px
  padding-bottom: 40px
  text-align: center
  .empty-img
    width: 420px
    margin: 0 auto 75px
  .nothing-word
    font-size: 28px
    color: $grey2
    line-height: 42px
</style>
