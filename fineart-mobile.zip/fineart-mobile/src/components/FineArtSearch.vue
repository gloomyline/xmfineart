<template>
  <div :class="[classes, 'fy-1px-b']">
    <form action="javascript: void(0)" class="box-input" @click="focus">
      <div class="icon icon-search" @click.stop="search"></div>
      <input ref="searchInput" @keyup.enter="search" v-model="searchValue" type="search" class="search-input" placeholder="输入关键词">
    </form>
    <div class="btn-filter" @click="filter">
      <span class="label">筛选</span>
      <span class="icon icon-screen"></span>
    </div>
  </div>
</template>

<script>
import {COMPONENT_PREFIX} from '@/assets/data/constants'
import {hyphenCase} from '@/common/js/utils'

export default {
  name: `${COMPONENT_PREFIX}Search`,
  data () {
    return {
      searchValue: null
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-search`
    }
  },
  methods: {
    focus () {
      this.$refs.searchInput.focus()
    },
    search () {
      this.$refs.searchInput.blur()
      this.$emit('search', this.searchValue)
    },
    filter () {
      this.$emit('filter')
    },
    setSearchValue (searchValue) {
      this.searchValue = searchValue
    }
  }
}
</script>

<style lang="stylus" scoped>
.{$cls_prefix}-search
  display: flex
  align-items: center
  justify-content: space-between
  padding: 14px 35px 14px 30px
  background: $white
  font-size: 0
  .box-input
    position: relative
    display: inline-block
    vertical-align: top
    width: 541px
    height: 60px
    border-radius: 31px
    background-color: $grey5
    .icon.icon-search
      absolute: top 17px left 29px
      padding: 8px
      font-size: 0
      inline-icon(24px, 24px)
      bg-img('../assets/imgs/icon-search')
    .search-input
      width: 446px
      height: 60px
      padding: 12px 0
      border: none
      outline: none
      margin-left: 77px
      font-size: 26px
      color: $black1
      background-color: rgba(0, 0, 0, 0)
      caret-color: $orange
      &::placeholder
        color: $grey2
  .btn-filter
    display: flex
    line-height: 62px
    justify-content: row
    align-items: center
    .label
      font-size: 26px
      color: $black2
      margin-right: 8px
    .icon-screen
      width: 34px
      height: 40px
      background: url('../assets/imgs/mall/icon-tgscreen.png') center center no-repeat
      background-size: 34px auto
      margin-top: 6px
</style>
