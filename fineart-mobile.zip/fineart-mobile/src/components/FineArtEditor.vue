<template>
  <div ref="editorEle" class="fineart-edit"></div>
</template>

<script>
import Editor from 'wangeditor'

export default {
  name: `FineArtEditor`,
  data () {
    return {
      editorBox: null
    }
  },
  props: ['catchData', 'editorContent', 'getHtml'],
  watch: {
    editorContent (newVal) {
      // 有内容时赋值给富文本编辑器
      if (this.editorBox && !this.editorBox.txt.text()) {
        // 有内容时赋值给富文本编辑器
        this.editorBox.txt.html(newVal)
      }
    },
    getHtml (newVal) {
      if (newVal) {
        const html = this.editorBox.txt.html()
        this.catchData(html)
      }
    }
  },
  mounted () {
    this.editorBox = new Editor(this.$refs.editorEle)
    // 编辑器改变即保存数据
    this.editorBox.customConfig.onchange = (html) => {
      // 触发浏览器的重绘，使的错误的渲染回复正常
      document.body && (document.body.scrollTop = document.body.scrollTop)
      // html => 即编辑器中的内容
      this.catchData(html)
    }
    this.editorBox.customConfig.onfocus = function () {
      // 触发浏览器的重绘，使的错误的渲染回复正常
      document.body && (document.body.scrollTop = document.body.scrollTop)
      this.editorBox.change && this.editorBox.change()
    }
    this.editorBox.customConfig.onblur = () => {
      // 触发浏览器的重绘，使的错误的渲染回复正常
      document.body && (document.body.scrollTop = document.body.scrollTop)
      // 如果未配置 editor.customConfig.onchange，则 editor.change 为 undefined
      this.editorBox.change && this.editorBox.change()
    }
    // 菜单配置
    this.editorBox.customConfig.menus = []
    this.editorBox.create()
    // 赋值给富文本编辑器
    this.editorBox.txt.html(this.editorContent)
  },
  methods: {
    blur () {
      this.formFocus = false
    },
    focus () {
      this.formFocus = true
    }
  }
}
</script>

<style lang="stylus">
.fineart-edit
  height: 263px
  &>div
    border: 1px solid $grey !important
    &:first-child
      display: none
  .w-e-text-container
    padding: 20px 24px
    z-index: 2 !important
    font-size: 28px !important
    height: 100% !important
    .w-e-text
      padding: 0
      &>p
        margin: 0 !important
  img
    max-width: 100%
</style>
