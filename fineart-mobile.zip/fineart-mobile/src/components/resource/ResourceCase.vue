<template>
  <popup :value="isShowed" position="right" width="100%" :class="classes" @on-show="initHandler">
    <fine-art-head title="编辑案例"></fine-art-head>
    <group class="form-box" label-align="left">
      <cell title="主页" :value="modeName"></cell>
      <x-input
        v-model="caseModel.service_type"
        title="服务类型"
        placeholder='如"建筑设计"'
        placeholder-align="right"
        text-align="right"
        :show-clear="false" ></x-input>
      <!-- 服务起始时间-->
      <datetime
        v-model="caseModel.start_at"
        format="YYYY-MM"
        placeholder="请选择"
        title="服务起始时间"></datetime>
      <!-- 服务结束时间 -->
      <datetime
        v-model="caseModel.end_at"
        format="YYYY-MM"
        placeholder="请选择"
        title="服务结束时间"></datetime>
      <!-- 服务详情 -->
      <h3 class="label-span">服务详情</h3>
      <fine-art-editor v-if="isShowed" :catch-data="catchEditor" :editor-content="caseModel.content" :get-html="getHtml"></fine-art-editor>
      <x-button class="save-btn" type="primary" @click.native="saveAndGoToHome()">保存并返回</x-button>
      <x-button class="cancel-btn" type="default" plain @click.native="closePopup()">返回</x-button>
    </group>
  </popup>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import { Datetime, Popup } from 'vux'
import FineArtHead from '../FineArtHead.vue'
import FineArtEditor from '../FineArtEditor.vue'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resources/api'

export default {
  name: `${COMPONENT_PREFIX}ResourceCase`,
  data () {
    return {
      caseModel: {
        id: '', // 参与案例ID
        service_type: '', // <string>必须，服务类型
        content: '', // <string>必须，服务内容
        start_at: '', // <string>开始时间
        end_at: ''// <string>结束时间
      },
      recordModelRule: {
        service_type: [{ required: true, message: '请输入服务类型' }],
        start_at: [{ required: true, message: '请选择起始时间' }],
        end_at: [{ required: true, message: '请选择结束时间' }],
        content: [{ required: true, message: '请输入服务详情' }]
      },
      getHtml: false
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    },
    // 参与案例信息
    case: {
      type: [Number, String, Boolean],
      require: true
    },
    modeName: {
      type: String,
      default: ''
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  created () {
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-resource-case`
    }
  },
  methods: {
    async initHandler () {
      this.caseModel = await api.fetchCaseDetail(this.case)
      this.caseModel.start_at = this.handleTime(this.caseModel.start_at)
      this.caseModel.end_at = this.handleTime(this.caseModel.end_at)
    },
    // 保存并返回主页
    async saveAndGoToHome () {
      this.getHtml = true
      // 校验表单信息
      const rules = await validate(this.caseModel, this.recordModelRule)
      if (!rules) return

      this.result = await api.editResourceCase(this.caseModel)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_CASE_EDIT_SUCCESS'], type: 'success' })
        // 关闭弹窗
        this.$emit('change-show', false)
        // 刷新列表
        this.$emit('save-refresh')
      }
    },
    handleTime (date) {
      let time = ''
      if (date) {
        let dt = new Date(date)
        let month = dt.getMonth() + 1
        time = dt.getFullYear() + '-' + (month >= 10 ? month : `0${month}`)
      } else {
        time = ''
      }
      return time
    },
    // 关闭
    closePopup () {
      this.$emit('change-show', false)
    },
    // 获取富文本编辑框的数据
    catchEditor (html) {
      this.caseModel.content = html
    }
  },
  components: {
    Popup,
    Datetime,
    FineArtEditor,
    FineArtHead
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-resource-case
  color: $black1
  &.vux-popup-dialog
    background: $white
  .form-box
    padding-top: 96px
    padding-bottom: 30px
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      padding-left: 0
      padding-right: 0
      .weui-cell__ft
        font-size: 28px
        color: $black2
    .label-span
      color: $black1
      font-size: 28px
      height: 98px
      line-height: 98px
    .cancel-btn
      color: $grey3
      font-weight: 300
      margin-top: 30px
      border-color: $grey
    .save-btn
      margin-top: 30px
</style>
