<template>
  <popup :popup-style="style" position="bottom" height="11.15rem" class="resource-choose-tag"
         @on-show="init"
         @on-hide="closePopup"
         :show-mask="true" :value="isShowed">
    <h3 class="resource-choose-tag-title">添加标签</h3>
    <div class="resource-choose-tag-close-btn fy-icon-off" @click="closePopup"></div>
    <div class="resource-choose-tag-wrap" v-for="(item, index) in tagList" :key="index">
      <h4 class="resource-choose-tag-subtitle">
        <span class="name">{{item.label}}</span>
        <span class="tip">（必选，最多一个）</span>
      </h4>
      <ul class="resource-choose-tag-list">
        <li class="tags"
            :class="{'choice-tag': (chooseId[0] && chooseId[0].value === tag.value) || (chooseId[1] && chooseId[1].value === tag.value)}"
            v-for="(tag, tagIndex) in item.children"
            :key="tagIndex"
            @click="chooseTag(tag, index)">
          <span class="name">{{tag.label | labelFormatter(4)}}</span>
          <span class="icon fy-icon-select"><span class="path1"></span><span class="path2"></span></span>
        </li>
      </ul>
    </div>
    <x-button type="primary" class="save-btn" @click.native="saveTag">完成</x-button>
  </popup>
</template>

<script>
import { Popup } from 'vux'
import { getPortfolioCategory } from '@/common/js/loadScript'
export default {
  name: 'ResourceChooseTag',
  components: {
    Popup
  },
  data () {
    return {
      style: {
        zIndex: 502
      },
      tagList: [],
      chooseId: []
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    closePopup () {
      this.$emit('change-show', false)
    },
    async init () {
      this.tagList = await getPortfolioCategory()
    },
    chooseTag (item, index) {
      this.$set(this.chooseId, index, item)
    },
    saveTag () {
      if (!this.chooseId[0]) {
        this.$store.commit('ADD_MESSAGE', {msg: '请选择风格'})
        return
      }
      if (!this.chooseId[1]) {
        this.$store.commit('ADD_MESSAGE', {msg: '请选择空间'})
        return
      }
      this.$emit('choose', this.chooseId)
      this.closePopup()
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  }
}
</script>

<style lang="stylus">
.resource-choose-tag
  &.vux-popup-dialog
    background-color: $white
    border-radius: 20px 20px 0 0
  &-title
    padding: 30px 0 47px 0
    color: $black2
    font-size: 28px
    text-align: center
    line-height: 40px
  &-close-btn
    absolute: right 30px top 35px
    font-size: 26px
    color: $grey2
  &-subtitle
    display: flex
    align-items: center
    margin-bottom: 30px
    .name
      margin-right: 20px
      color: $black1
      font-size: 30px
      line-height: 42px
    .tip
      font-size: 24px
      line-height: 33px
      color: $grey3
  &-wrap
    overflow: hidden
    padding: 0 30px
    margin-bottom: 60px
  &-list
    display: flex
    flex-flow: wrap
    margin-right: -18px
    .tags
      position: relative
      display: flex
      justify-content: center
      align-items: center
      width: 159px
      height: 64px
      margin-right: 18px
      margin-bottom: 20px
      background-color: $grey-menu
      border-radius: 4px
      .name
        font-size: 26px
        color: $black2
      .icon
        display: none
      &.choice-tag
        background-color: rgba(247, 181, 44, 0.2)
        .name
          color: $orange
        .icon
          display: block
          absolute: right -2px bottom -12px
          font-size: 50px
  .save-btn
    margin-top: 40px
    width: 690px
</style>
