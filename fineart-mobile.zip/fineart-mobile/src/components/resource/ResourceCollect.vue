<template>
  <popup :value="isShowed" position="right" width="100%" :class="classes" @on-show="initHandler">
    <fine-art-head :title="title"></fine-art-head>
    <group class="form-box">
      <div class="thumbnail fy-1px-b">
        <span class="thumbnail-label">{{ coverTitleText }}</span>
        <div class="upload-wrap fy-1px">
          <div class="thumbnail-img" v-if="worksVal.thumbnail_cdn">
            <img :src="worksVal.thumbnail_cdn" alt="worksVal.title">
            <span class="del-img" @click="goDelThumb()">—</span>
          </div>
          <fine-art-upload v-else width="153"
                           height="153"
                           :max-size="ossThumbnail.max_size"
                           :data="ossThumbnail.data"
                           :action="ossThumbnail.host"
                           :format="ossThumbnail.format"
                           :accept="ossThumbnail.accept"
                           :before-upload="beforeUploadThumb"
                           :on-success="successThumb">
            <div class="upload-box">
              <span class="fy-icon-camera"></span>
              <em>上传图片</em>
            </div>
          </fine-art-upload>
        </div>
      </div>
      <!--作品名称-->
      <x-input :title="`${subTitleText}名称`" :placeholder="`请填写${subTitleText}名称`" v-model="worksVal.title" text-align="right" :show-clear="false"></x-input>
      <h3 class="label-span">{{ subTitleText }}介绍</h3>
      <!-- 多文本框 -->
      <x-textarea class="detail-textarea" v-model="worksVal.introduction" @on-blur="scrollBody" :placeholder="`请填写${subTitleText}介绍`"></x-textarea>
      <!--<fine-art-editor v-if="isShowed" :catch-data="catchEditor" :editor-content="worksVal.introduction"></fine-art-editor>-->
      <h3 class="label-span">{{ subTitleText }}图片 <em>(最多9张)</em></h3>
      <div class="works-picture">
        <ul class="works-picture-list">
          <li class="works-picture-list-item" v-for="(item, index) in worksVal.image_urls_cdn" :key="index">
            <img :src="item" alt="">
            <span class="del-img" @click="goDelImage(index)">—</span>
          </li>
          <li class="works-picture-list-item" v-show="worksVal.image_urls_cdn && worksVal.image_urls_cdn.length < 9">
            <fine-art-upload width="210"
                             height="210"
                             :max-size="ossImage.max_size"
                             :data="ossImage.data"
                             :action="ossImage.host"
                             :format="ossImage.format"
                             :accept="ossImage.accept"
                             :before-upload="beforeUploadImage"
                             :on-success="successImage">
              <div class="upload-box fy-1px">
                <span class="fy-icon-add-grey"></span>
                <em>上传图片</em>
              </div>
            </fine-art-upload>
          </li>
        </ul>
      </div>
      <!-- 保存并返回 -->
      <x-button class="save-btn" type="primary" @click.native="saveAndGoToHome()">保存并返回</x-button>
      <x-button class="del-btn" plain @click.native="goToHome()">返回</x-button>
    </group>
  </popup>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import FineArtHead from '../FineArtHead.vue'
import FineArtUpload from '../FineArtUpload.vue'
import FineArtEditor from '../FineArtEditor.vue'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resources/api'

export default {
  name: `${COMPONENT_PREFIX}ResourceCollect`,
  data () {
    return {
      title: '产品添加',
      ossThumbnail: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {},
        length: 0
      },
      worksVal: {
        resource_id: '',
        id: '',
        title: '',
        thumbnail: '',
        thumbnail_cdn: '',
        image_url: [],
        image_urls_cdn: [],
        introduction: ''
      },
      supplierRule: {
        thumbnail: [
          { required: true, message: '请上传封面图' }
        ],
        title: [
          { required: true, message: '请填写品牌名称' }
        ],
        introduction: [
          { required: true, message: '请填写品牌介绍' }
        ],
        image_url: [
          { required: true, message: '请上传品牌图片' }
        ]
      },
      brandRule: {
        thumbnail: [
          { required: true, message: '请上传LOGO' }
        ],
        title: [
          { required: true, message: '请填写产品名称' }
        ],
        introduction: [
          { required: true, message: '请填写产品介绍' }
        ],
        image_url: [
          { required: true, message: '请上传产品图片' }
        ]
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-resource-collect`
    },
    subTitleText () {
      switch (this.resourceMode) {
      case '400':
        return '产品'
      case '300':
        return '品牌'
      }
    },
    coverTitleText () {
      switch (this.resourceMode) {
      case '400':
        return 'logo'
      default:
        return '封面图'
      }
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    },
    resourceMode: {
      type: String,
      default: '100'
    },
    itemId: {
      type: [Number, String, Boolean],
      default: false
    },
    resourceId: {
      type: [Number, String]
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    initHandler () {
      this.worksVal = {
        resource_id: '',
        id: '',
        title: '',
        thumbnail: '',
        thumbnail_cdn: '',
        image_url: [],
        image_urls_cdn: [],
        introduction: ''
      }
      switch (this.resourceMode) {
      case '400':
        this.title = this.itemId ? '产品编辑' : '产品添加'
        this.getProductDetail()
        break
      case '300':
        this.title = this.itemId ? '代理品牌编辑' : '代理品牌添加'
        this.getAgentBrandDetail()
        break
      }
    },
    // 获取代理品牌详情
    async getAgentBrandDetail () {
      if (!this.itemId) return
      const res = await api.fetchAgentBrandDetail(this.itemId)
      this.worksVal = res
      this.worksVal.image_url = res.image_urls
      this.worksVal.introduction = this.worksVal.introduction.replace(/<br \/>|<br>/g, '\r\n')
    },
    // 获取产品系列详情
    async getProductDetail () {
      if (!this.itemId) return
      const res = await api.fetchProductDetail(this.itemId)
      this.worksVal = res
      this.worksVal.image_url = res.image_urls
      this.worksVal.introduction = this.worksVal.introduction.replace(/<br \/>|<br>/g, '\r\n')
    },
    // 保存并返回主页
    async saveAndGoToHome () {
      switch (this.resourceMode) {
      case '400':
        if (this.worksVal.id) {
          // 编辑产品
          this.editResourceProduct()
        } else {
          // 添加产品
          this.addResourceProduct()
        }
        break
      case '300':
        if (this.worksVal.id) {
          // 编辑代理商品
          this.editResourceAgentBrand()
        } else {
          // 添加代理商品
          this.addResourceAgentBrand()
        }
        break
      }
    },
    // 返回主页
    goToHome () {
      // 关闭弹窗
      this.$emit('change-show', false)
    },
    // 获取富文本编辑框的数据
    catchEditor (html) {
      this.worksVal.introduction = html
    },
    // 添加资源代理品牌
    async addResourceAgentBrand () {
      let params = {
        resource_id: this.resourceId,
        title: this.worksVal.title,
        introduction: this.worksVal.introduction,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      const rules = await validate(params, this.supplierRule)
      if (!rules) return
      this.result = await api.addResourceAgentBrand(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_AGENT_BRAND_ADD_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 编辑资源代理品牌
    async editResourceAgentBrand () {
      let params = {
        agent_brand_id: this.worksVal.id,
        title: this.worksVal.title,
        introduction: this.worksVal.introduction,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      const rules = await validate(params, this.supplierRule)
      if (!rules) return
      const result = await api.editResourceAgentBrand(params)
      if (result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_AGENT_BRAND_EDIT_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 添加资源产品
    async addResourceProduct () {
      let params = {
        resource_id: this.resourceId,
        title: this.worksVal.title,
        introduction: this.worksVal.introduction,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      const rules = await validate(params, this.brandRule)
      if (!rules) return
      this.result = await api.addResourceProduct(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_PRODUCT_ADD_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    // 编辑资源产品
    async editResourceProduct () {
      let params = {
        product_series_id: this.worksVal.id,
        title: this.worksVal.title,
        introduction: this.worksVal.introduction,
        thumbnail: this.worksVal.thumbnail,
        image_url: this.worksVal.image_url
      }
      const rules = await validate(params, this.brandRule)
      if (!rules) return
      this.result = await api.editResourceProduct(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_PRODUCT_EDIT_SUCCESS'], type: 'success' })
        this.$emit('save-refresh') // 刷新列表
        this.$emit('change-show', false) // 关闭弹窗
      }
    },
    async beforeUploadThumb (file) {
      this.ossThumbnail = await api.ossParamsCreate(file, 'achievement_thumbnail', this.ossThumbnail)
    },
    successThumb (res) {
      this.worksVal.thumbnail = res.results.file_url
      this.worksVal.thumbnail_cdn = res.results.file_url_cdn
    },
    goDelThumb () {
      this.worksVal.thumbnail = ''
      this.worksVal.thumbnail_cdn = ''
    },
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'achievement_image', this.ossImage)
    },
    successImage (res) {
      this.worksVal.image_urls_cdn.push(res.results.file_url_cdn)
      this.worksVal.image_url.push(res.results.file_url)
    },
    goDelImage (key) {
      this.worksVal.image_urls_cdn.splice(key, 1)
      this.worksVal.image_url.splice(key, 1)
    },
    scrollBody () {
      // 触发浏览器的重绘，使的错误的渲染回复正常
      document.body && (document.body.scrollTop = document.body.scrollTop)
    }
  },
  components: {
    FineArtHead,
    FineArtUpload,
    FineArtEditor
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-resource-collect
  padding-bottom: 30px
  color: $black1
  &.vux-popup-dialog
    background: $white
  .form-box
    padding-top: 96px
    padding-bottom: 30px
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      line-height: 98px
      padding-left: 0
    .del-btn
      border-color: $grey
      color: $grey3
      font-weight: 300
    .save-btn
      margin-top: 30px
  .label-span
    width: 100%
    height: 96px
    font-size: 30px
    line-height: 96px
    &>em
      color: $grey3
      font-size: 24px
  .thumbnail
    display: flex
    justify-content: space-between
    align-items: center
    height: 186px
    .thumbnail-label
      font-size: 30px
    .upload-wrap
      width: 153px
      height: 153px
      .upload-box
        display: flex
        flex-direction: column
        justify-content: center
        align-items: center
        width: 153px
        height: 153px
        .fy-icon-camera
          font-size: 40px
          color: $grey2
        &>em
          color: $grey2
          font-size: 24px
      .thumbnail-img
        position: relative
        width: 153px
        height: 153px
        &>img
          width: 100%
          height: 100%
  .works-picture
    width: 100%
    &-list
      display: flex
      flex-flow: wrap
      align-content: space-between
      margin-right: -24px
      &-item
        position: relative
        width: 210px
        height: 210px
        margin: 0 24px 24px 0
        &>img
          width: 100%
          height: 100%
        .upload-box
          display: flex
          flex-direction: column
          justify-content: center
          align-items: center
          width: 210px
          height: 210px
          .fy-icon-camera
            font-size: 60px
            color: $grey2
          &>em
            color: $grey2
            font-size: 24px
  .del-img
    absolute: right -10px top -10px
    display: block
    width: 40px
    height: 40px
    font-size: 24px
    font-weight: 600px
    line-height: 40px
    text-align: center
    color: $white
    background-color: rgba(0, 0, 0, 0.5)
    border-radius: 50%
  .weui-cell.detail-textarea
    height: 275px
    padding: 0
    .weui-cell__bd
      width: 100%
      height: 275px
      padding: 30px
      border: 1.4px solid $grey
      .weui-textarea
        width: 100%
        height: 100%
        outline: none
        padding: 0
        border: none
        line-height: 40px
        background-color: rgba(0, 0, 0, 0)
        border-radius: 4px
</style>
