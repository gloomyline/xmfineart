<template>
  <popup :value="isOperate" position="bottom" class="resource-operate" @on-hide="closePopup">
    <x-button type="default" plain class="operate-btn operate-edit" @click.native="editItem">编辑</x-button>
    <x-button type="default" plain class="operate-btn operate-delete" @click.native="deleteItem">删除</x-button>
    <!--分割线-->
    <div class="fy-divider"></div>
    <x-button type="default" plain class="operate-btn operate-cancel" @click.native="closePopup">取消</x-button>
  </popup>
</template>

<script>
import { Popup } from 'vux'

export default {
  name: 'ResourceOperate',
  data () {
    return {
    }
  },
  props: {
    isOperate: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isOperate',
    event: 'change-show'
  },
  components: {
    Popup
  },
  methods: {
    closePopup () {
      this.$emit('change-show', false)
    },
    deleteItem () {
      this.$emit('delete', () => {
        this.$emit('change-show', false)
      })
    },
    editItem () {
      this.$emit('edit', () => {
        this.$emit('change-show', false)
      })
    }
  }
}
</script>

<style lang="stylus">
.resource-operate
  .fy-divider
    width: 100%
    height: 20px
    background-color: $grey5
  &.vux-popup-dialog
    background-color: $white
    border-radius: 12px 12px 0 0
  .operate-btn
    height: 100px
    border: none
    margin-bottom: 0
    margin-left: 0
    margin-right: 0
    margin-top: 0 !important
    color: $black1
    font-size: 28px
    border-radius: 0
    &.operate-edit
      border-bottom: 1.4px solid $grey
    &.operate-delete
      color: $red2
    &.operate-cancel
      color: $grey3
</style>
