<template>
  <popup :value="isShowed" position="right" width="100%" :class="classes" @on-show="initHandler">
    <fine-art-head :title="experienceModel.id?'编辑工作经历':'添加工作经历'"></fine-art-head>
    <group class="form-box">
      <!-- 公司名称 -->
      <x-input title="公司名称" placeholder="请填写公司名称" text-align="right" :show-clear="false" v-model="experienceModel.company"></x-input>
      <!-- 职务  -->
      <x-input title="职务" placeholder="请填写职务" text-align="right" :show-clear="false" v-model="experienceModel.job"></x-input>
      <!--入职时间-->
      <datetime
        v-model="experienceModel.start_date"
        placeholder="选择入职时间"
        format="YYYY-MM"
        title="入职时间"></datetime>
      <!--离职时间-->
      <datetime
        v-model="experienceModel.end_date"
        placeholder="选择离职时间"
        format="YYYY-MM"
        title="离职时间"></datetime>
      <!-- 保存并返回 -->
      <x-button class="save-btn" type="primary" @click.native="saveAndGoToHome()">保存并返回</x-button>
      <x-button class="del-btn" plain @click.native="deleteModal = true" v-if="experienceModel.id">删除本条</x-button>
      <x-button v-else class="del-btn" plain @click.native="goToHome()">返回</x-button>
    </group>
    <div v-transfer-dom>
      <confirm v-model="deleteModal"
               title="工作经历删除确认"
               confirm-text="确定删除"
               cancel-text="下次再说"
               @on-confirm="delWork(experienceModel.id)">
        <p>您确定删除工作经历吗。</p>
      </confirm>
    </div>
  </popup>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, deepClone } from '@/common/js/utils'
import FineArtHead from '../FineArtHead.vue'
import { Datetime } from 'vux'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resources/api'

export default {
  name: `${COMPONENT_PREFIX}ResourceWorks`,
  data () {
    return {
      deleteModal: false,
      experienceModel: {
        id: '',
        job: '',
        type: '',
        company: '',
        end_date: '',
        start_date: '',
        resource_id: ''
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-works-info`
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    },
    // 工作经历信息
    experience: {
      type: Object,
      require: true
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    initHandler () {
      if (this.experience.id) {
        this.experienceModel = deepClone(this.experience)
        this.experienceModel.start_date = this.changeMonth(this.experience.start_date)
        if (this.experience.end_date && this.experience.end_date !== '至今') {
          this.experienceModel.end_date = this.changeMonth(this.experience.end_date)
        } else {
          this.experienceModel.end_date = ''
        }
      } else {
        this.experienceModel = {
          id: '',
          job: '',
          type: 200,
          company: '',
          end_date: '',
          start_date: '',
          resource_id: this.experience.resource_id
        }
      }
    },
    changeMonth (date) {
      let dt = date.split('.')
      let dateString = `${dt[0]}-${dt[1]}`
      return dateString
    },
    // 保存并返回主页
    async saveAndGoToHome () {
      // 校验表单信息
      if (!this.experienceModel.company) {
        this.$store.commit('ADD_MESSAGE', { msg: '请选择公司名称' })
        return false
      }
      if (!this.experienceModel.job) {
        this.$store.commit('ADD_MESSAGE', { msg: '请输入职务名称' })
        return false
      }
      if (!this.experienceModel.start_date) {
        this.$store.commit('ADD_MESSAGE', { msg: '请输入开始时间' })
        return false
      }

      if (this.experienceModel.id) {
        this.result = await api.resourceEditExperience(this.experienceModel)
      } else {
        this.result = await api.resourceAddExperience(this.experienceModel)
      }
      if (this.result.code === 200) {
        if (this.experienceModel.id) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_EXPERIENCE_EDIT_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_EXPERIENCE_ADD_SUCCESS'], type: 'success' })
        }
        // 关闭弹窗
        this.$emit('change-show', false)
        // 返回数据
        this.$emit('save-refresh')
      }
    },
    // 返回主页
    goToHome () {
      // 关闭弹窗
      this.$emit('change-show', false)
    },
    // 删除本条
    delWork (id) {
      // 关闭弹窗
      this.$emit('change-show', false)
      this.$emit('delete-work', id)
    }
  },
  components: {
    Datetime,
    FineArtHead
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-works-info
  color: $black1
  &.vux-popup-dialog
    background: $white
  .form-box
    padding-top: 96px
    padding-bottom: 30px
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      padding-left: 0
      padding-right: 0
    .del-btn
      border-color: $grey
      color: $grey3
      font-weight: 300
    .save-btn
      margin-top: 30px
</style>
