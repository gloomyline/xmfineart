<template>
  <popup :popup-style="style" position="bottom" height="11.15rem" class="resource-position"
         @on-show="init"
         @on-hide="closePopup"
         :show-mask="true" :value="isShowed">
    <h3 class="resource-position-title">所在位置</h3>
    <div class="resource-choose-tag-close-btn fy-icon-off" @click="closePopup"></div>
    <fine-art-scroller class="address-scroller"
                       ref="scroller"
                       :list="info.pois"
                       @load-more="loadMore"
                       :has-data="hasData"
                       :pullDownRefreshObj="false">
      <ul class="address-list">
        <li class="address fy-1px-b default" :class="{'is-selected': isDefault}" @click="useDefault">
          <span class="name">不显示所在的位置</span>
          <i class="icon icon-selected"></i>
        </li>
        <li class="address fy-1px-b" v-for="(item, index) in info.pois"
            :key="index"
            :class="{'is-selected': item.id === address.id}"
            @click="chooseAddress(item)">
          <span class="name">{{item.name}}</span>
          <i class="icon icon-selected"></i>
        </li>
      </ul>
    </fine-art-scroller>
    <x-button type="primary" class="save-btn" @click.native="saveAddress">完成</x-button>
  </popup>
</template>

<script>
import { Popup } from 'vux'
import { FMap } from '@/common/js/Map'
import FineArtScroller from '../FineArtScroller.vue'
export default {
  name: 'ResourcePosition',
  components: {
    Popup,
    FineArtScroller
  },
  data () {
    return {
      style: {
        zIndex: 502
      },
      chooseId: [],
      FMap: null,
      info: {
        pois: [],
        pageIndex: 1,
        count: 0
      },
      address: {},
      isDefault: false
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  computed: {
    hasData () {
      return this.info.pois.length > 0
    }
  },
  created () {
    this.FMap = new FMap()
  },
  methods: {
    closePopup () {
      this.$emit('change-show', false)
    },
    async init () {
      this.info = await this.FMap.aMapSearchNearBy({ pageIndex: 1 })
    },
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (this.info.pois.length === this.info.count) return cb()
      const response = await this.FMap.aMapSearchNearBy({ pageIndex: this.info.pageIndex + 1 })
      if (!response) return cb()
      this.info.pois = [...this.info.pois, ...response.pois]
      this.info.pageIndex = response.pageIndex
    },
    chooseAddress (item) {
      this.isDefault = false
      this.address = item
      this.address.city = this.info.city
    },
    useDefault () {
      this.isDefault = true
      this.address = {}
    },
    saveAddress () {
      this.$emit('choose', this.address)
      this.closePopup()
    }
  }
}
</script>

<style lang="stylus">
.resource-position
  .address-scroller
    absolute: top 110px bottom 150px
    height: 580px
  &.vux-popup-dialog
    background-color: $white
    border-radius: 20px 20px 0 0
  &-title
    padding: 30px 0 47px 0
    color: $black2
    font-size: 28px
    text-align: center
    line-height: 40px
  &-close-btn
    absolute: right 30px top 35px
    font-size: 26px
    color: $grey2
  .address-list
    padding: 0 30px
    .address
      display: flex
      justify-content: space-between
      align-items: center
      height: 98px
      .name
        color: $black2
        font-size: 28px
        line-height: 40px
      .icon-selected
        display: none
      &.default
        .name
          color: $grey2
      &.is-selected
        .name
          color: $orange
        .icon-selected
          display: block
          width: 24px
          height: 24px
          margin-right: 7px
          background: url('../../assets/imgs/resource/icon-selected@2x.png') center center no-repeat
          background-size: auto 24px
  .save-btn
    absolute: bottom 30px left 50%
    width: 690px
    transform: translateX(-50%)
</style>
