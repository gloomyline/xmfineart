<template>
  <popup :value="isShowed" :popup-style="style" position="bottom" height="11.15rem" class="resource-dynamic-tag" @on-hide="closePopup" @on-first-show="init">
    <h3 class="resource-dynamic-tag-title">添加标签</h3>
    <div class="resource-dynamic-tag-close-btn fy-icon-off" @click="closePopup"></div>
    <!-- 添加标签 -->
    <div class="search-bar">
      <div class="search-box">
        <span class="icon-search icon-search"></span>
        <input class="search-input" ref="inputEle" v-model="tagName" type="search" placeholder="输入标签名" @blur="blur"/>
        <span class="icon" v-if="tagName" @click="clear">
          <i class="icon-clear"></i>
        </span>
      </div>
      <x-button type="primary" plain class="btn-add" @click.native="addTag">添加</x-button>
    </div>
    <scroller lock-x class="fy-popup-content" height="6.17rem" ref="scroller">
      <div class="dynamic-tag-wrap">
        <ul class="dynamic-tag-list" v-if="tagList.length !== 0">
          <li class="tags"
              v-for="(item, index) in tagList" :key="index"
              @click="chooseTag(item)"
              :class="{'choice-tag': (choiceTag[0] && choiceTag[0].id === item.id) || (choiceTag[1] && choiceTag[1].id === item.id) || (choiceTag[2] && choiceTag[2].id === item.id)}">
            <span class="name">{{item.tag | labelFormatter(4)}}</span>
            <span class="icon fy-icon-select"><span class="path1"></span><span class="path2"></span></span>
          </li>
        </ul>
      </div>
    </scroller>
    <x-button type="primary" class="save-btn" @click.native="saveTag">完成</x-button>
  </popup>
</template>

<script>
import { Popup, Scroller } from 'vux'
import api from 'modules/resources/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'DynamicTag',
  data () {
    return {
      style: {
        zIndex: 502
      },
      tagName: '',
      tagList: [],
      // 防止重复提交
      flag: true,
      choiceTag: []
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    },
    type: {
      type: [String, Number],
      default: 300
    },
    tags: {
      type: Array,
      default () {
        return []
      }
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  components: {
    Popup,
    Scroller
  },
  methods: {
    async init () {
      this.tagList = await api.handleDynamicTagList({object_type: this.type})
      this.choiceTag = this.tags
    },
    closePopup () {
      this.$emit('change-show', false)
    },
    clear () {
      this.tagName = ''
    },
    chooseTag (item) {
      for (let i = 0, max = this.choiceTag.length; i < max; i++) {
        if (this.choiceTag[i].id === item.id) {
          this.choiceTag.splice(i, 1)
          return
        }
      }
      if (this.choiceTag.length === 3) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DYNAMIC_TAG_THREE']})
        return
      }
      this.choiceTag.push(item)
    },
    async addTag () {
      if (!this.tagName) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DYNAMIC_TAG_REQUIRED']})
        return
      }
      if (!this.flag) return
      this.flag = false
      const response = await api.handleAddDynamicTag({object_type: this.type, tag: this.tagName})
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DYNAMIC_TAG_ADD_SUCCESS'], type: 'success'})
        this.init()
        this.flag = true
      } else {
        this.flag = true
        this.$store.commit('ADD_MESSAGE', {msg: response.msg})
      }
    },
    saveTag () {
      this.$emit('choose', this.choiceTag)
      this.closePopup()
    },
    blur () {
      document.body && (document.body.scrollTop = document.body.scrollTop)
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  }
}
</script>

<style lang="stylus">
.resource-dynamic-tag
  .fy-popup-content
    width: 100%
    background-color: $white
  &-title
    padding: 30px 0 47px 0
    color: $black2
    font-size: 28px
    text-align: center
    line-height: 40px
  &-close-btn
    absolute: right 30px top 35px
    font-size: 26px
    color: $grey2
  &.vux-popup-dialog
    background-color: $white
    border-radius: 20px 20px 0 0
  .search-bar
    display: flex
    padding-left: 30px
    margin-bottom: 40px
    .search-box
      display: flex
      width: 604px
      height: 66px
      border-radius: 34px
      background-color: $grey4
      .icon-search
        display: flex
        justify-content: center
        align-items: center
        width: 70px
        height: 66px
        background: url('../../assets/imgs/mall/icon-tgsearch.png') center center no-repeat
        background-size: 28px auto
      .icon
        display: flex
        justify-content: center
        align-items: center
        width: 76px
        height: 66px
        .icon-clear
          width: 28px
          height: 28px
          background-repeat: no-repeat
          background-size: cover
          bg-img('../../assets/imgs/mall/icon-clear')
      .search-input
        width: 478px
        height: 66px
        padding: 16px 0
        color: $black1
        font-size: 28px
        border: none
        outline: none
        background-color: rgba(0, 0, 0, 0)
        &::-webkit-input-placeholder
          font-size: 28px
          color: $grey2
    .btn-add.weui-btn
      width: 116px
      padding-right: 30px
      padding-left: 0
      text-align: right
      font-size: 28px
      line-height: 66px
      border: none
  .dynamic-tag-wrap
    overflow: hidden
    padding: 0 30px
    margin-bottom: 60px
    .dynamic-tag-list
      display: flex
      flex-flow: wrap
      margin-right: -18px
      .tags
        position: relative
        display: flex
        justify-content: center
        align-items: center
        width: 159px
        height: 64px
        margin-right: 18px
        margin-bottom: 20px
        background-color: $grey-menu
        border-radius: 4px
        .name
          font-size: 26px
          color: $black2
        .icon
          display: none
        &.choice-tag
          background-color: rgba(247, 181, 44, 0.2)
          .name
            color: $orange
          .icon
            display: block
            absolute: right -2px bottom -12px
            font-size: 50px
  .save-btn
    margin-top: 30px
    width: 690px
</style>
