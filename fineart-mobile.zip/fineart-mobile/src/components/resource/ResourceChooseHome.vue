<template>
  <popup :value="isShowed" :popup-style="style" position="bottom" height="11.15rem" class="resource-choose-home" @on-hide="closePopup">
    <h3 class="resource-choose-home-title">发布动态位置</h3>
    <div class="resource-choose-home-close-btn fy-icon-off" @click="closePopup"></div>
    <scroller lock-x class="fy-popup-content" height="7.7rem" ref="scroller">
      <div class="home-wrap">
        <ul class="home-list">
          <li class="item"
              :class="{'is-active': home.id === chooseHome.id}"
              v-for="(home, index) in homeList"
              :key="index"
              @click="choiceHome(home)">
            <img :src="home.logo" alt="" class="logo">
            <span class="name"> {{home.name}}</span>
          </li>
        </ul>
      </div>
    </scroller>
    <x-button type="primary" class="save-btn" @click.native="saveHome">完成</x-button>
  </popup>
</template>

<script>
import { Popup, Scroller } from 'vux'
import api from 'modules/resources/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: 'ResourceChooseHome',
  data () {
    return {
      style: {
        zIndex: 502
      },
      homeList: [],
      chooseHome: {}
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  watch: {
    chooseHome (newVal) {
      this.$emit('choose', newVal)
    }
  },
  components: {
    Popup,
    Scroller
  },
  created () {
    this.init()
  },
  methods: {
    async init () {
      const res = await api.fetchHomeModeList()
      if (res.length === 0) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_HOME_EMPTY'], cb () { window.location.href = 'member.html#/choice-home' }})
        return
      }
      for (let key in res) {
        if (res[key].status === '300') {
          this.homeList.push(res[key])
        }
      }
      if (this.homeList.length === 0) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_HOME_EMPTY'], cb () { window.location.href = 'member.html#/choice-home' }})
      }
      this.chooseHome = this.homeList[0]
      for (let i = 0, max = this.homeList.length; i < max; i++) {
        if (this.chooseHome.id > this.homeList[i].id) {
          this.chooseHome = this.homeList[i]
        }
      }
    },
    choiceHome (item) {
      this.chooseHome = item
    },
    closePopup () {
      this.$emit('change-show', false)
    },
    saveHome () {
      this.$emit('change-show', false)
    }
  }
}
</script>

<style lang="stylus">
.resource-choose-home
  .fy-popup-content
    width: 100%
    background-color: $white
  &-title
    padding: 30px 0 47px 0
    color: $black2
    font-size: 28px
    text-align: center
    line-height: 40px
  &-close-btn
    absolute: right 30px top 35px
    font-size: 26px
    color: $grey2
  &.vux-popup-dialog
    background-color: $white
    border-radius: 20px 20px 0 0
  .save-btn
    margin-top: 30px
    width: 690px
  .home-wrap
    padding: 0 30px
    .home-list
      .item
        display: flex
        align-items: center
        width: 100%
        height: 90px
        padding: 0 30px
        margin-bottom: 30px
        background-color: $grey5
        border-radius: 4px
        .logo
          width: 48px
          height: 48px
          margin-right: 20px
          border-radius: 50%
        .name
          color: $black2
          font-size: 28px
          {ellipse}
        &.is-active
          border: 1.4px solid $orange
          background-color: rgba(247, 181, 44, 0.1)
</style>
