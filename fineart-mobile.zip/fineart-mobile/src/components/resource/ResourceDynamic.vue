<template>
  <popup :value="isShowed" position="right" width="100%" class="resource-add-production">
    <fine-art-head title="发布动态"></fine-art-head>
    <group class="form-box">
      <x-textarea class="detail-textarea" placeholder="这一刻的心情…"></x-textarea>
      <div class="upload-picture-wrap">
        <ul class="show-pic">
          <li class="pic" v-for="(img, index) in ossImageThumb" :key="index">
            <img :src="img" alt="">
            <i class="icon fy-icon-off" @click="deleteImage(index)"></i>
          </li>
          <li class="pic upload" v-show="ossImageThumb.length < 6">
            <fine-art-upload :width="214" :height="214"
                             :max-size="ossImage.max_size"
                             :data="ossImage.data"
                             :action="ossImage.host"
                             :format="ossImage.format"
                             :accept="ossImage.accept"
                             :beforeUpload="beforeUploadImage"
                             :on-success="successImage">
              <div class="upload-box"></div>
            </fine-art-upload>
          </li>
        </ul>
      </div>
      <ul class="add-tags">
        <li class="tag icon-tag-origin" v-for="(item, index) in tagList" :key="index">{{item.tag}}</li>
        <li class="tag icon-tag" @click="chooseTag">添加标签</li>
      </ul>
      <ul class="add-address">
        <li class="address" :class="[Object.values(address).length === 0 ? 'icon-address' : 'icon-address-orange']" @click="chooseAddress">{{addressText}}</li>
      </ul>
      <x-button type="primary" class="save-btn" @click.native="releaseDynamic">发布</x-button>
    </group>
    <div v-transfer-dom>
      <dynamic-tag v-model="isShowTag" @choose="getTag"></dynamic-tag>
    </div>
    <div v-transfer-dom>
      <resource-position v-model="isShowPosition" @choose="getAddress"></resource-position>
    </div>
    <div class="mask-tag" v-if="isShowTag || isShowPosition" @touchend="closePopup"></div>
  </popup>
</template>

<script>
import FineArtHead from '../FineArtHead.vue'
import FineArtUpload from '../FineArtUpload.vue'
import DynamicTag from './DynamicTag.vue'
import ResourcePosition from './ResourcePosition.vue'
import { Popup } from 'vux'
import api from 'modules/resources/api'
// import { validate } from '@/common/js/utils.js'
// import * as MSG from '@/assets/data/message.js'
// import { findValue, getArea } from '@/common/js/loadScript.js'

export default {
  name: 'ResourceAddProduction',
  components: {
    Popup,
    FineArtHead,
    FineArtUpload,
    DynamicTag,
    ResourcePosition
  },
  data () {
    return {
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      ossImageThumb: [],
      isShowTag: false,
      isShowPosition: false,
      tagList: [],
      address: {}
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  computed: {
    addressText () {
      return this.address && this.address.name ? this.address.name : '添加位置'
    }
  },
  methods: {
    deleteImage (index) {
      this.ossImageThumb.splice(index, 1)
      this.portfolio.image_url.splice(index, 1)
    },
    // 图片上传之前
    async beforeUploadImage (file) {
      // TODO achievement_image名称更换
      this.ossImage = await api.ossParamsCreate(file, 'achievement_image', this.ossImage)
    },
    // 图片上传成功
    successImage (res) {
      this.ossImageThumb.push(res.results.file_url_cdn)
    },
    chooseTag () {
      this.isShowTag = !this.isShowTag
    },
    closePopup () {
      if (this.isShowTag) {
        this.isShowTag = false
        return
      }
      if (this.isShowPosition) {
        this.isShowPosition = false
      }
    },
    chooseAddress () {
      this.isShowPosition = !this.isShowPosition
    },
    getTag (tag) {
      this.tagList = tag
    },
    async getAddress (value) {
      this.address = value
    },
    async releaseDynamic () {
    }
  }
}
</script>

<style lang="stylus">
  .resource-add-production
    color: $black1
    &.vux-popup-dialog
      background: $white
    .form-box
      padding: 96px 30px 30px 30px
      .weui-cells
        margin-top: 0
        &.vux-no-group-title
          margin-top: 0
        .weui-cell
          padding: 0
          height: 100px
          .weui-label
            color: $black2
          &.detail-textarea:after
            display: none !important
          &.vux-x-textarea
            height: 255px
            padding: 30px 0
            .weui-cell__bd
              height: 100%
              .weui-textarea-counter
                display: none
              .weui-textarea
                height: 100%
      .upload-picture-wrap
        overflow: hidden
        margin-bottom: 16px
        .show-pic
          display: flex
          flex-flow: wrap
          margin-right: -24px
          .pic
            position: relative
            width: 214px
            height: 214px
            margin-right: 24px
            margin-bottom: 26px
            border-radius: 6px
            &>img
              display: block
              width: 214px
              height: 214px
              border-radius: 6px
            .icon
              absolute: right top
              width: 40px
              height: 40px
              text-align: center
              color: $white
              font-size: 18px
              line-height: 40px
              background-color: rgba(67, 67, 67, 0.7)
              border-radius: 0 6px 0 6px
        .upload-box
          width: 214px
          height: 214px
          background: $greyF9 url('../../assets/imgs/mall/icon-tgupload.png') center center no-repeat
          background-size: 122px auto
          border-radius: 6px
      .add-tags
        display: flex
        flex-wrap: wrap
        margin-bottom: 30px
        .tag
          padding: 0 16px 0 46px
          margin: 0 10px 10px 0
          height: 46px
          line-height: 46px
          color: $grey3
          font-size: 22px
          background-color: $grey5
          border-radius: 25px
          &.icon-tag
            background-image: url('../../assets/imgs/resource/icon-tag@2x.png')
            background-position: 14px center
            background-repeat: no-repeat
            background-size: auto 20px
          &.icon-tag-origin
            color: $black2
            background-image: url('../../assets/imgs/resource/icon-tag-orange@2x.png')
            background-position: 14px center
            background-repeat: no-repeat
            background-size: auto 20px
      .add-address
        display: flex
        .address
          padding: 0 16px 0 46px
          height: 46px
          line-height: 46px
          color: $grey3
          font-size: 22px
          background-color: $grey5
          border-radius: 25px
          &.icon-address
            background-image: url('../../assets/imgs/resource/icon-address-grey@2x.png')
            background-position: 14px center
            background-repeat: no-repeat
            background-size: auto 20px
          &.icon-address-orange
            color: $black2
            background-image: url('../../assets/imgs/resource/icon-address-orange@2x.png')
            background-position: 14px center
            background-repeat: no-repeat
            background-size: auto 20px
    .save-btn
      margin-top: 40px
    .mask-tag
      fixed: top right
      bottom: 0
      left: 0
      background-color: rgba(51, 51, 51, 0.5)
      z-index: 501
</style>
