<template>
  <div :class="classes">
    <div class="home-intro">
      <div class="bg-box">
        <img :src="resourceDetail.logo_cdn" alt="" class="blur">
      </div>
      <div class="detail-wrap">
        <div class="logo" @click="previewImage(resourceDetail.logo_original_cdn)">
          <img :src="resourceDetail.logo_cdn">
        </div>
        <div class="attention-wrap">
          <div class="like-fans">
            <div class="give-like">
              <span class="title">获赞</span>
              <span class="number">{{ resourceDetail.like_num }}</span>
            </div>
            <div class="fans">
              <span class="title">粉丝</span>
              <span class="number">{{ resourceDetail.fans_num }}</span>
            </div>
          </div>
          <div class="btn-group">
            <!-- 已关注/关注TA -->
            <x-button class="fy-btn collection" plain
                      v-if="!isSelf"
                      @click.native="changeIsCollect(resourceDetail.id)"
                      :class="{'is-collection': resourceDetail.collection_status}"
                      type="default"><span class="icon-collection" v-if="!resourceDetail.collection_status"></span>{{ resourceDetail.collection_status ? '取消关注' : '关注' }}</x-button>
            <!-- 编辑资料 -->
            <x-button class="fy-btn fy-btn-edit" type="default" mini plain
                      v-if="isSelf"
                      action-type="button"
                      :link="`/home-edit/${resourceDetail.mode}/${resourceDetail.id}`">编辑资料</x-button>
            <!-- 发布动态 -->
            <x-button class="fy-btn fy-btn-release" type="default" mini plain
                      v-if="isSelf"
                      :link="`/dynamic-add/${resourceDetail.id}/${resourceDetail.mode}`"
                      @click.native="isShowDynamic = true">发布动态</x-button>
          </div>
        </div>
      </div>
      <h3 class="name">{{ resourceDetail.name }}</h3>
      <h4 class="subtitle">{{ resourceDetail.subtitle }}</h4>
      <ul class="tab-wrap" v-if="mode === 100">
        <router-link tag="li" :to="`/person-home/${this.id}/production`" class="tab">作品</router-link>
        <router-link tag="li" :to="`/person-home/${this.id}/dynamic`" class="tab">动态</router-link>
        <router-link tag="li" :to="`/person-home/${this.id}/about`" class="tab">{{tabText}}</router-link>
      </ul>
      <ul class="tab-wrap" v-if="mode === 200">
        <router-link tag="li" :to="`/company-home/${this.id}/production`" class="tab">作品</router-link>
        <router-link tag="li" :to="`/company-home/${this.id}/dynamic`" class="tab">动态</router-link>
        <router-link tag="li" :to="`/company-home/${this.id}/about`" class="tab">{{tabText}}</router-link>
      </ul>
      <ul class="tab-wrap" v-if="mode === 300">
        <router-link tag="li" :to="`/supplier-home/${this.id}/dynamic`" class="tab">动态</router-link>
        <router-link tag="li" :to="`/supplier-home/${this.id}/about`" class="tab">{{tabText}}</router-link>
      </ul>
      <ul class="tab-wrap" v-if="mode === 400">
        <router-link tag="li" :to="`/brand-home/${this.id}/dynamic`" class="tab">动态</router-link>
        <router-link tag="li" :to="`/brand-home/${this.id}/about`" class="tab">{{tabText}}</router-link>
      </ul>
      <ul class="tab-wrap" v-if="mode === 500">
        <router-link tag="li" :to="`/decorator-home/${this.id}/dynamic`" class="tab">动态</router-link>
        <router-link tag="li" :to="`/decorator-home/${this.id}/about`" class="tab">{{tabText}}</router-link>
      </ul>
    </div>
    <router-view class="pages-content"></router-view>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, COLLECT_MESSAGE_DURATION } from '@/assets/data/constants'
import FineArtLoginTip from '../FineArtLoginTip.vue'
import { hyphenCase } from '@/common/js/utils'
import { mapMutations, mapState } from 'vuex'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resources/api'

export default {
  name: `${COMPONENT_PREFIX}ResourceHead`,
  props: {
    id: {
      type: String,
      required: true
    }
  },
  data () {
    return {
      loginTipModal: false,
      // API请求处理中
      apiProcessing: false,
      // 发布动态
      isShowDynamic: false,
      // 是否处于编辑状态 true => 正在编辑
      isEdit: false,
      // isSelf: false,
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      mode: 0
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-resource-head`
    },
    resourceDetail () {
      return this.$store.state.resource.resourceDetail
    },
    // 是否本人 true =>本人，false =>非本人, 默认非本人
    isSelf () {
      return this.resourceDetail.is_master
    },
    tabText () {
      return this.isSelf ? '关于我' : '关于TA'
    },
    ...mapState(['isLogin'])
  },
  created () {
    this.getMode()
    this.getResourceDetail()
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    getMode () {
      const name = this.$route.matched[0].name
      switch (name) {
      case 'PersonHome':
        this.mode = 100
        this.modifyPageName('个人主页')
        break
      case 'CompanyHome':
        this.mode = 200
        this.modifyPageName('优秀公司')
        break
      case 'SupplierHome':
        this.mode = 300
        this.modifyPageName('优秀供应商')
        break
      case 'BrandHome':
        this.mode = 400
        this.modifyPageName('优秀品牌')
        break
      case 'DecoratorHome':
        this.mode = 500
        this.modifyPageName('装修师')
        break
      }
    },
    async getResourceDetail () {
      const vm = this
      this.$wx.updateShareData('resource', {
        title: vm.resourceDetail.name,
        desc: vm.resourceDetail.introduction_raw
      })
      if (Object.keys(this.resourceDetail).length !== 0) return
      this.$store.dispatch('resource/fetchDetail', {
        resource_id: this.id,
        resource_mode: this.mode
      })
    },
    async changeIsCollect (id) {
      // 判断是否登录
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      if (this.apiProcessing) {
        return false
      }
      this.apiProcessing = true
      this.result = await api.handleResourceCollect({object_type: 100, object_id: id})
      if (this.result.code === 200) {
        this.resourceDetail.collection_status = !this.resourceDetail.collection_status
        // 提示关注成功或取消关注成功
        if (this.resourceDetail.collection_status) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    },
    // 切换tab
    handlerTab (index) {
      this.tabSelected = index
    },
    previewImage (img_url) {
      this.$wx.previewImage(
        {
          current: img_url, // 当前显示图片的http链接
          urls: [img_url] // 需要预览的图片http链接列表
        }
      )
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtLoginTip
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-resource-head
  width: 100%
  font-family: PingFangSC-Regular
  .home-intro
    position: relative
    width: 100%
    padding: 46px 30px 38px 30px
    background-color: rgba(46, 46, 46, 0.5)
    .bg-box
      absolute: top left
      width: 100%
      height: 100%
      overflow: hidden
      z-index: -1
      .blur
        absolute: top 50% left 50%
        display: block
        width: 100%
        filter: blur(20px)
        transform: translate(-50%, -50%)
    .detail-wrap
      display: flex
      justify-content: space-between
      align-items: center
      width: 100%
      margin-bottom: 33px
      .logo
        position: relative
        width: 139px
        height: 139px
        border-radius: 50%
        &>img
          display: block
          width: 139px
          height: 139px
          border-radius: 50%
      .attention-wrap
        width: 354px
        .like-fans
          display: flex
          justify-content: space-between
          .give-like, .fans
            width: 170px
            text-align: left
            .title
              display: block
              margin-bottom: 6px
              color: $white
              font-size: 22px
              line-height: 30px
            .number
              display: block
              font-size: 34px
              color: $white
              font-weight: bold
              line-height: 40px
        .btn-group
          display: flex
          justify-content: space-between
          margin-top: 15px
          .fy-btn
            margin: 0
            padding: 0
            font-size: 26px
            line-height: 1.3
            border-radius: 6px
            &.fy-btn-edit
              width: 170px
              height: 58px
              color: $white
              border: 1.4px solid $white
            &.fy-btn-release
              width: 170px
              height: 58px
              color: $orange
              border: none
              background-color: $white
            &.collection
              display: flex
              justify-content: center
              align-items: center
              width: 354px
              height: 58px
              color: $white
              border: 1.5px solid $white
              .icon-collection
                width: 22px
                height: 23px
                margin-right: 12px
                background: url('../../assets/imgs/resource/icon-collection.png') center center no-repeat
                background-size: cover
              &.is-collection
                color: $white
    .name
      margin-bottom: 9px
      font-size: 30px
      line-height: 42px
      font-weight: 600
      color: $white
    .subtitle
      font-size: 24px
      color: $white
    .tab-wrap
      absolute: bottom -90px left
      display: flex
      justify-content: center
      align-items: center
      width: 100%
      height: 100px
      background-color: $white
      border-radius: 20px 20px 0 0
      z-index: 11
      .tab
        margin-right: 74px
        color: $grey3
        font-size: 28px
        line-height: 40px
        font-weight: 600
        &.router-link-active
          position: relative
          color: $black1
          &:before
            absolute: bottom -13px left 50%
            content: ''
            width: 8px
            height: 8px
            background-color: $black1
            border-radius: 50%
            transform: translateX(-50%)
        &:last-child
          margin-right: 0
</style>
