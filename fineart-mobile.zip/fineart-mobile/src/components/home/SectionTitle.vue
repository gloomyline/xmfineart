<template>
  <div :class="classes" class="text-center">
    <h3 class="chinese-text">{{ chineseTxt }}</h3>
    <h4 class="english-text">{{ englishTxt }}</h4>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import {hyphenCase, oneOf} from '@/common/js/utils'

const Texts = {
  fineArtMap: '斐艺地图',
  popularGoods: '人气商品',
  excellentResources: '优秀资源',
  qualityArchitecture: '品质建筑'
}

export default {
  name: `${COMPONENT_PREFIX}SectionTitle`,
  data () {
    return {}
  },
  props: {
    txt: {
      type: String,
      default: 'fineArtMap',
      validator (value) {
        return oneOf(value, Object.keys(Texts))
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-section-title`
    },
    chineseTxt () {
      return Texts[this.txt]
    },
    englishTxt () {
      return this.txt.replace(/([A-Z])/g, ($1) => {
        return ` ${$1}`
      }).toLocaleUpperCase()
    }
  }
}
</script>

<style lang="stylus">
.fine-art-section-title
  .chinese-text
    line-height: 45px
    font-weight: 500
    font-size: 32px
    color: $black1
  .english-text
    line-height: 32px
    font-weight: 400
    font-size: 24px
    color: $grey2
</style>
