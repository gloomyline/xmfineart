<template>
  <div :class="classes">
    <ul class="nav">
      <li class="nav-item" v-for="(item, index) in navList" :key="index">
        <router-link class="nav-route text-center" :to="item.route">{{ item.label }}</router-link>
      </li>
    </ul>
    <p class="copyright text-center">@ 2018 Fine Art. All Rights Reserved. 闽ICP备15003414号</p>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'

export default {
  name: `${COMPONENT_PREFIX}Foot`,
  data () {
    const navList = [
      {
        route: '/about-us',
        label: '关于我们'
      },
      {
        route: '/common-faq',
        label: '常见问题'
      },
      {
        route: '/notice-list',
        label: '平台公告'
      },
      {
        route: '/contact-us',
        label: '联系我们'
      }
    ]
    return {
      navList
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-foot`
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-foot
  width: 100%
  height: 147px
  background-color: $grey4
  .nav
    display: flex
    padding: 40px 0 36px 0
    .nav-item
      flex: 1
      .nav-route
        display: block
        width: 100%
        height: 100%
        line-height: 32px
        font-size: 24px
        color: $black2
  .copyright
    font-size: 20px
    color: $grey2
</style>
