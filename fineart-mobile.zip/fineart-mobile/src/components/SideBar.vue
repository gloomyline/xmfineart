<template>
  <fine-art-scroll
    ref="scroller"
    class="fineart-side-bar"
    :has-data="true"
    :scrollbar="false"
    :has-more="false"
    :pullDownRefreshObj="sideBarCfg.pullDownRefreshObj"
    :pullUpLoadObj="sideBarCfg.pullUpLoadObj">
    <div class="side-bar-head">
      <slot name="head">
        <div class="avatar-wrap text-center">
          <img :src="memberProfile.avatar_cdn" width="65" height="65" v-if="!!memberProfile.avatar_cdn" @click="goLoginPage">
          <span @click="goLoginPage" v-else class="avatar fy-icon-default-avatar"><span class="path1"></span><span class="path2"></span><span
            class="path3"></span><span class="path4"></span><span class="path5"></span></span>
        </div>
        <a href="/member.html#/account-security" class="title text-center" v-if="isLogin">{{ memberProfile.nickname }}</a>
        <p @click="goLoginPage" class="title text-center" v-else>未登录</p>
      </slot>
    </div>
    <div class="side-bar-menu-wrap">
      <ul class="side-bar-menu">
        <li class="side-bar-menu-item" v-for="(item, index) in menu" :key="index" @click="handler">
          <a class="menu-item-link" :href="item.link">
            <span class="icon" :class="item.icon"></span>
            <span class="label">{{ item.label }}</span>
          </a>
        </li>
      </ul>
      <ul v-if="isLogin" class="logout" @click="logout">
        <li class="menu-item-link">
          <span class="icon fy-icon-exit"></span>
          <span class="label">退出登录</span>
        </li>
      </ul>
    </div>
  </fine-art-scroll>
</template>

<script>
import FineArtScroll from './FineArtScroller.vue'
import { goLogin } from '@/common/js/utils'
import { GLOBAL_LOGOUT_SUCCESS } from 'assets/data/message'
const DEFAULT_MENU = [
  {
    icon: 'fy-icon-my-order',
    label: '我的订单',
    link: 'member.html#/my-order'
  },
  {
    icon: 'fy-icon-my-groupon',
    label: '我的团购',
    link: 'member.html#/groupon/my'
  },
  {
    icon: 'fy-icon-my-cart',
    label: '购物车',
    link: '/mall.html#/mall-cart'
  },
  {
    icon: 'fy-icon-my-follow',
    label: '我的关注',
    link: 'member.html#/my-collection'
  },
  {
    icon: 'fy-icon-my-address',
    label: '收货地址',
    link: 'member.html#/my-address'
  },
  {
    icon: 'fy-icon-my-reservation',
    label: '我的预约',
    link: 'member.html#/my-reservation'
  },
  {
    icon: 'fy-icon-my-home',
    label: '我的主页',
    link: 'member.html#/choice-home'
  },
  {
    icon: 'fy-icon-feed',
    label: '发布动态',
    link: 'resource.html#/dynamic-add'
  },
  {
    icon: 'fy-icon-my-map',
    label: '地图管理',
    link: 'member.html#/map-manage/bind-marker'
  }
]
export default {
  name: 'SideBar',
  data () {
    return {
      sideBarCfg: {
        pullDownRefreshObj: false,
        pullUpLoadObj: false
      }
    }
  },
  props: {
    avatar: {
      type: String
    },
    // 侧边栏状态（显示/隐藏）
    status: {
      type: Boolean
    },
    menu: {
      type: Array,
      default () {
        return DEFAULT_MENU
      }
    }
  },
  computed: {
    isLogin () {
      return this.$store.state.isLogin
    },
    memberProfile () {
      return this.$store.state.memberProfile
    }
  },
  watch: {
    status (newVal) {
      if (newVal) {
        this.$refs.scroller.scroll.initScroll()
      }
    }
  },
  methods: {
    handler () {
      this.$emit('click-handler', false)
    },
    goLoginPage () {
      if (!this.isLogin) {
        goLogin()
      } else {
        window.location = '/member.html#/account-security'
      }
      this.$emit('click-handler', false)
    },
    logout () {
      const vm = this
      this.$emit('slide-left')
      // 处理请求响应结果
      this.$localStorage.setUser({ token: null, isLogin: false, expired: parseInt(Date.now() / 1000) })
      // 退出成功弹窗
      this.$store.commit('ADD_MESSAGE', {
        msg: GLOBAL_LOGOUT_SUCCESS,
        cb () {
          vm.$store.dispatch('logout')
          // 返回到首页模块
          window.location = 'index.html'
        }
      })
    }
  },
  components: {
    FineArtScroll
  }
}
</script>

<style lang="stylus" scoped>
.fineart-side-bar
  top: 0
  width: 460px
  height: 100%
  background-color: $white
  .side-bar-head
    padding: 45px 0 35px 0
    .avatar-wrap
      margin-bottom: 27px
      font-size: 130px
      &>img, .avatar
        display: block
        width: 124px
        height: 124px
        margin: 0 auto
        border-radius: 50%
    .title
      display: block
      line-height: 48px
      font-size: 34px
      color: $black1
      font-weight: 500
  .side-bar-menu-wrap
    .side-bar-menu, .logout
      .menu-item-link /* a link */
        display: flex
        align-items: center
        padding: 25px 0 25px 70px
        text-decoration: none
        .icon, .label
          display: inline-block
          vertical-align: top
          height: 42px
          line-height: 42px
        .icon
          color: $grey2
          font-size: 36px
          margin-right: 15px
          &.fy-icon-my-groupon, &.fy-icon-feed, &.fy-icon-my-cart
            inline-icon(38px, 38px)
            margin-right: 15px
          &.fy-icon-my-groupon
            background-image: url("../assets/imgs/icon-my-groupon.png")
          &.fy-icon-feed
            background-image: url("../assets/imgs/icon-feed.png")
          &.fy-icon-my-cart
            background-image: url("../assets/imgs/icon-my-cart.png")
        .label
          font-size: 26px
          color: $black2
          width: 120px
          text-align: left
    .side-bar-menu
      padding-bottom: 12px
    .logout .menu-item-link
      padding: 30px 0
      margin: 0 70px
      border-top: 1px solid $grey
</style>
