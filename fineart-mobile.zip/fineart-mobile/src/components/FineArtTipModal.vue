<template>
  <x-dialog
    class="tip-modal"
    v-model="isShowed">
    <span class="close-btn fy-icon-off" @click="closeModal()"></span>
    <!-- 内容 -->
    <div class="modal-body">
      <div class="img-wrap">
        <slot name="img"></slot>
      </div>
      <div class="text">
        <slot name="text"></slot>
      </div>
    </div>
    <!-- 底部 -->
    <div class="modal-foot" v-if="!footHide">
      <slot name="foot"></slot>
    </div>
  </x-dialog>
</template>

<script>
import { XDialog, XButton } from 'vux'
export default {
  name: 'FineArtTipModal',
  data () {
    return {
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    },
    footHide: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  methods: {
    closeModal () {
      this.$emit('change-show', false)
    }
  },
  components: {
    XDialog,
    XButton
  }
}
</script>

<style lang="stylus">
.tip-modal .weui-dialog
  width: 566px
  max-width: unset
  border-radius: 10px
  padding: 60px 82px 52px 82px
  .close-btn
    color: $grey6
    font-size: 25px
    padding: 25px
    absolute: top right
  .modal-body
    border-radius: 4px
    .img-wrap img
      width: 360px
      height: 300px
      margin: 0 auto
    .text
      width: 100%
      margin: 0 auto
      color: $black2
      font-size: 26px
      line-height: 40px
      text-align: center
      padding-top: 20px
  .modal-foot button
    width: 416px
    line-height: 80px
    font-size: 30px
    margin-top: 30px
    padding: 0
    border-radius: 40px
    box-shadow:0px 4px 14px 0px rgba(247,181,44,0.48)
</style>
