<template>
  <popup :value="isShowed" position="right" width="100%" class="groupon-search" @on-show="initHandler">
    <!-- header -->
    <div class="fineart-head-wrap">
      <div class="fineart-head fy-1px-b">
        <div class="left" @click="goBack">
          <span class="fy-icon-arrow-right"></span>
        </div>
        <div class="center">
          <h2 class="title-text">搜索</h2>
        </div>
      </div>
    </div>
    <!-- 搜索框 -->
    <div class="search-bar">
      <form class="search-box" action="javascript: void(0)">
        <span class="icon-search"></span>
        <input class="search-input" ref="inputEle" @keyup.13="search(keywords)" v-model="keywords" type="search" placeholder="请输入关键字"/>
        <span class="icon" v-if="keywords" @click="clearKey">
          <i class="icon-clear"></i>
        </span>
      </form>
      <x-button type="primary" plain class="btn-cancel" @click.native="goBack">取消</x-button>
    </div>
    <!-- 暂时隐藏 -->
    <!--<div class="tag-wrap">-->
      <!--<h3 class="tag-title">热门搜索</h3>-->
      <!--<ul class="tag-list">-->
        <!--<li class="tag-item">橱柜</li>-->
      <!--</ul>-->
    <!--</div>-->
  </popup>
</template>

<script>
import { Popup } from 'vux'
export default {
  name: 'GrouponSearch',
  data () {
    return {
      keywords: ''
    }
  },
  props: {
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  components: {
    Popup
  },
  methods: {
    initHandler () {
      console.log('搜索')
    },
    search (values) {
      if (!values) return
      this.$emit('search-key', values)
      this.$refs.inputEle.blur()
      this.goBack()
    },
    clearKey () {
      this.keywords = ''
      this.$emit('search-key', this.keywords)
      this.$emit('change-show', false)
    },
    goBack () {
      this.$emit('change-show', false)
    },
    setKeywords (keywords) {
      this.keywords = keywords
    }
  }
}
</script>

<style lang="stylus" scoped>
.groupon-search
  background-color: $white
  .fineart-head-wrap
    width: 100%
    margin-bottom: 20px
    background-color: $white
    .fineart-head
      position: relative
      display: flex
      align-items: center
      width: 100%
      height: 94px
      color: $black
      .left
        display: flex
        width: 94px
        height: 94px
        justify-content: center
        align-items: center
        .fy-icon-arrow-right
          display: inline-block
          color: $grey3
          font-size: 34px
          transform: rotate(180deg)
      .center
        display: flex
        justify-content: center
        width: 100%
        padding-right: 94px
        .title-text
          text-align: center
          font-size: 32px
  .search-bar
    display: flex
    padding-left: 30px
    margin-bottom: 40px
    .search-box
      display: flex
      width: 604px
      height: 66px
      border-radius: 34px
      background-color: $grey4
      .icon-search
        display: flex
        justify-content: center
        align-items: center
        width: 70px
        height: 66px
        background: url('../../assets/imgs/icon-search@3x.png') center center no-repeat
        background-size: 28px auto
      .icon
        display: flex
        justify-content: center
        align-items: center
        width: 76px
        height: 66px
        .icon-clear
          width: 28px
          height: 28px
          background-repeat: no-repeat
          background-size: cover
          bg-img('../../assets/imgs/mall/icon-clear')
      .search-input
        width: 478px
        height: 66px
        padding: 16px 0
        color: $black1
        font-size: 28px
        border: none
        outline: none
        background-color: rgba(0, 0, 0, 0)
        caret-color: $orange
        &::-webkit-input-placeholder
          font-size: 28px
          color: $grey2
    .btn-cancel.weui-btn
      width: 116px
      padding-right: 30px
      padding-left: 0
      text-align: right
      font-size: 28px
      line-height: 66px
      border: none
      color: $grey2
  .tag-wrap
    overflow: hidden
    padding: 0 30px
    .tag-title
      margin-bottom: 30px
      color: $grey3
      font-size: 26px
    .tag-list
      display: flex
      flex-flow: wrap
      margin-right: -24px
      .tag-item
        margin-right: 24px
        margin-bottom: 20px
        padding: 0 24px
        line-height: 54px
        font-size: 26px
        color: $black2
        background-color: $greyF5
        border-radius: 10px
</style>
