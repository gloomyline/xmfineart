<template lang="html">
  <div class="fineart-head-wrap">
    <div class="fineart-head fy-1px-b">
      <div class="left" @click="goBack">
        <span class="fy-icon-arrow-right"></span>
      </div>
      <div class="center">
        <slot name="title"><h2 class="title-text">{{ title }}</h2></slot>
      </div>
      <div class="right">
        <slot name="right"></slot>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  data () {
    return {
    }
  },
  props: {
    title: {
      type: String,
      default: '团购'
    }
  },
  methods: {
    goBack () {
      document.referrer === '' ? this.$router.push({ path: '/' }) : window.history.back()
    }
  }
}
</script>

<style lang="stylus" scoped>
.fineart-head-wrap
  fixed: left top
  width: 100%
  background-color: $white
  z-index: 11 /* keep it top on the first layout (page-display-layout) */
  .fineart-head
    position: relative
    display: flex
    justify-content: space-between
    align-items: center
    width: 100%
    height: 94px
    padding: 0 24px
    color: $black
    .left, .right
      display: flex
      height: 94px
      align-items: center
      [class^="fy-icon"]
        color: $grey3
        font-size: 34px
        display: inline-block
        &.fy-icon-arrow-right
          transform: rotate(180deg)
    .title-text
      font-size: 32px
    .center
      position: absolute
      left: 50%
      transform: translateX(-50%)
</style>
