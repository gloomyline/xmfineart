<template>
  <div class="groupon-nav">
    <i class="icon-triangle" v-show="isOpen"></i>
    <ul class="release-nav" :class="{'expanded': isOpen}">
      <router-link tag="li" to="/groupon/release/100" class="nav-item icon-product">发布产品</router-link>
      <router-link tag="li" to="/groupon/release/200" class="nav-item icon-service">发布服务</router-link>
    </ul>
    <div class="mask" v-show="isMaskShow" @touchend="closeShow"></div>
  </div>
</template>

<script>
export default {
  name: 'GrouponNav',
  data () {
    return {
    }
  },
  props: {
    isOpen: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isOpen',
    event: 'change-show'
  },
  computed: {
    isMaskShow () {
      return this.isOpen
    }
  },
  methods: {
    closeShow () {
      this.$emit('change-show', false)
    }
  }
}
</script>

<style lang="stylus" scoped>
.groupon-nav
  color: $white
  .mask
    position: fixed
    top: 94px
    right: 0
    bottom: 0
    left: 0
    background-color: transparent
    z-index: 5
  .icon-triangle
    fixed: right 40px top 78px
    display: block
    width: 0
    height: 0
    border-width: 0 20px 16px
    border-style: solid
    border-color: transparent transparent #48484a
    z-index: 12
  .release-nav
    fixed: top 93px right 11px
    overflow: hidden
    width: 259px
    max-height: 0
    padding: 0 26px
    background-color: #48484a
    border-radius: 8px
    transition: all 0.6s cubic-bezier(0, 1, 0, 1) -.1s
    z-index: 12
    &.expanded
      max-height: 999px
      transition-timing-function: cubic-bezier(.5, 0, 1, 0)
      transition-delay: 0
    .nav-item
      height: 86px
      padding-left: 70px
      border-bottom: 1.4px solid #575658
      font-size: 30px
      line-height: 86px
      &:last-child
        border-bottom: none
      &.icon-product
        background: url("../../assets/imgs/mall/icon-tgproduct.png") 18px center no-repeat
        background-size: 34px auto
      &.icon-service
        background: url("../../assets/imgs/mall/icon-tyservice.png") 18px center no-repeat
        background-size: 34px auto
</style>
