<template>
  <div class="groupon-apply-wrap">
    <div class="mask"></div>
    <div class="groupon-apply">
      <div class="head-wrap">
        <p class="title">团购意向</p>
        <button class="close-btn" @click="closeModal">
          <span class="fy-icon-off"></span>
        </button>
      </div>
      <div class="body-wrap">
        <input placeholder="填写您的称呼"
               v-model="grouponApplyModal.name"
               maxlength="24"
               @blur="blur"
               @focus="focus">
        <input placeholder="填写您的手机号码"
               v-model="grouponApplyModal.mobile"
               type="tel"
               @blur="blur"
               @focus="focus">
        <input placeholder="填写预估需求量（数字）"
               v-model.trim="grouponApplyModal.num"
               maxlength="8"
               type="tel"
               @blur="blur"
               @focus="focus">
        <textarea placeholder="请备注您的需求"
                  v-model="grouponApplyModal.remark"
                  maxlength="256"
                  @blur="blur"
                  @focus="focus"></textarea>
      </div>
      <div class="bottom">
        <button class="submit-btn" @click="submitApply">提交</button>
      </div>
    </div>
  </div>
</template>

<script>
import { validate } from '@/common/js/utils'

export default {
  name: 'GrouponApply',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{10}$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    const numberValidator = (rule, value, cb) => {
      if (value > 0) {
        cb()
      } else {
        cb(new Error('请输入正确的需求数值'))
      }
    }
    return {
      grouponApplyModal: {
        name: '',
        mobile: '',
        num: '',
        remark: ''
      },
      grouponApplyModalReset: {
        name: '',
        mobile: '',
        num: '',
        remark: ''
      },
      grouponApplyRule: {
        name: [{ required: true, message: '请输入您的姓名' }],
        mobile: [{ required: true, message: '请输入手机号码' }, mobileValidator],
        num: [{ required: true, message: '请输入预估需求量' }, numberValidator]

      },
      formFocus: true
    }
  },
  watch: {
    formFocus (newVal) {
      if (!newVal) {
        document.body && (document.body.scrollTop = document.body.scrollTop)
      }
    }
  },
  methods: {
    closeModal () {
      this.$emit('close-modal')
      this.grouponApplyModal = this.grouponApplyModalReset
    },
    async submitApply () {
      document.body && (document.body.scrollTop = document.body.scrollTop)
      const rules = await validate(this.grouponApplyModal, this.grouponApplyRule)
      if (!rules) return
      this.$emit('submit-apply', this.grouponApplyModal)
    },
    blur () {
      this.formFocus = false
    },
    focus () {
      this.formFocus = true
    }
  }
}
</script>

<style lang="stylus">
.groupon-apply-wrap
  z-index: 33
  width: 100%
  height: 100%
  overflow: hidden
  fixed: top bottom left right
  .mask
    absolute: top  bottom
    width: 100%
    height: 100%
    background: #000
    opacity: 0.65
    z-index: 33
  .groupon-apply
    height: 742px
    width: 586px
    background: $white
    border-radius: 10px
    absolute: left 50% top 50%
    transform: translate(-50%, -50%)
    z-index: 34
    .head-wrap
      height: 128px
      background: linear-gradient(90deg,rgba(248,182,43,1) 0%,rgba(249,204,108,1) 87%,rgba(249,204,109,1) 100%)
      border-radius: 10px 10px 100px 100px
      .title
        color: $white
        font-size: 32px
        line-height: 128px
        font-weight: 500
        text-align: center
        background: url("../../../src/assets/imgs/mall/icon-tgtitle.png") no-repeat center
        background-size: 290px 60px
      .close-btn
        padding: 0
        margin: 0
        border: none
        absolute: top 22px right 22px
        background: transparent
        .fy-icon-off
          color: $white
          font-size: 25px
          padding: 7px
    .body-wrap
      font-size: 0
      padding: 30px
      input, textarea
        height: 70px
        width: 100%
        font-size: 28px
        padding: 20px
        margin: 0 0 20px 0
        border: 2px solid #ddd
        border-radius: 10px
        box-sizing: border-box
        background: none
        outline: none
        -webkit-appearance:none /*去除input默认样式*/
        -webkit-tap-highlight-color:rgba(0, 0, 0, 0) /*去除点击高亮的颜色*/
        &:focus
          border: 2px solid $orange
        &::-webkit-input-placeholder /* WebKit, Blink, Edge */
          color: $grey2
        &:-moz-placeholder /* Mozilla Firefox 4 to 18 */
          color: $grey2
        &::-moz-placeholder /* Mozilla Firefox 19+ */
          color: $grey2
        &:-ms-input-placeholder /* Internet Explorer 10-11 */
          color: $grey2
      textarea
        height: 164px
        margin: 0
    .bottom
      padding: 0 30px
      text-align: center
      .submit-btn
        width: 416px
        color: $white
        font-size: 30px
        padding: 0
        height: 80px
        line-height: 80px
        background: #FFC54C
        border-radius: 40px
        border: none
        border-bottom: 6px solid #F8B62B
        box-sizing: border-box
</style>
