<template>
  <popup :value="isShowed" position="right" width="100%" :class="classes" @on-show="initHandler">
    <fine-art-head title="编辑其他信息"></fine-art-head>
    <div class="form-box">
      <fine-art-map :point="point" @change-address="changeHandler"></fine-art-map>
      <div v-if="showDefaultTip" class="tip"><span class="label">温馨提示：</span><span class="text">如详细地址有误，可手动修改； 提供准确的位置，有助于获取更多业务机会。</span></div>
      <slot name="tip"></slot>
      <x-button class="save-btn" type="primary" @click.native="saveAndGoToHome()">保存并返回</x-button>
    </div>
  </popup>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { Popup } from 'vux'
import FineArtHead from './FineArtHead.vue'
import FineArtMap from './FineArtMap.vue'

export default {
  name: `${COMPONENT_PREFIX}FineArtAddress`,
  data () {
    return {
      point: [],
      info: {
        address: '',
        point: [],
        area_id: ''
      }
    }
  },
  props: {
    lat: '',
    lng: '',
    isShowed: {
      type: Boolean,
      default: false
    }
  },
  model: {
    prop: 'isShowed',
    event: 'change-show'
  },
  created () {
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-fine-art-address`
    },
    // 显示默认显示
    showDefaultTip () {
      if (this.$slots && this.$slots.tip) {
        return false
      } else {
        return true
      }
    }
  },
  methods: {
    initHandler () {
      this.point = [this.lng, this.lat]
    },
    changeHandler (val) {
      this.info = val
      this.info.area_id = val.area_id[val.area_id.length - 1]
    },
    // 返回主页
    saveAndGoToHome () {
      // 关闭弹窗
      this.$emit('change-show', false)
      // 返回数据
      this.$emit('save-edit', this.info)
    },
    // 获取富文本编辑框的数据
    catchEditor (html) {
      this.content = html
    }
  },
  components: {
    Popup,
    FineArtMap,
    FineArtHead
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-fine-art-address
  color: $black1
  &.vux-popup-dialog
    background: $white
  .form-box
    padding: 126px 30px 30px 30px
    .save-btn
      margin-top: 30px
  .tip
    margin-top: 20px
    margin-bottom: 30px
    line-height: 48px
    font-size: 0
    .label
      margin-right: 8px
      font-size: 24px
      font-weight: 500
      color: #747474
    .text
      font-size: 24px
      color: $grey2
</style>
