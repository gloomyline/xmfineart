/**
 * @comment:
 * @author: alan_wang
 * @date: 18/10/2018
 * @time: 17:59:43
 */

import FineArtCateSideBar from './FineArtCateSideBar.vue'
import FineArtEmpty from './FineArtEmpty.vue'
import FineArtFoot from './home/FineArtFoot.vue'
import FineArtHead from './FineArtHead.vue'
import FineArtSearch from './FineArtSearch.vue'
import FineArtScroller from './FineArtScroller.vue'
import FineArtSlide from './FineArtSlide.vue'
import FineArtEditor from './FineArtEditor.vue'
import FineArtUpload from './FineArtUpload.vue'
import FineArtMap from './FineArtMap.vue'
import FineArtCategory from './FineArtCategory.vue'
import FineArtAddress from './FineArtAddress.vue'
import HomeSectionTitle from './home/SectionTitle.vue'
import FineArtLoginTip from './FineArtLoginTip.vue'
import FineArtTipModal from './FineArtTipModal.vue'
import JumpTop from './JumpTop.vue'
import Page from './Page.vue'
import SideBar from './SideBar.vue'

import ResourceWorks from './resource/ResourceWorks.vue'
import ResourceCollect from './resource/ResourceCollect.vue'
import ResourceCase from './resource/ResourceCase.vue'
import FineArtMyAddress from './FineArtMyAddress.vue'
import FineArtAddressAdd from './FineArtAddressAdd.vue'

import GrouponHead from './Groupon/GrouponHead.vue'
import GrouponSearch from './Groupon/GrouponSearch.vue'
import GrouponNav from './Groupon/GrouponNav.vue'
import GrouponApply from './Groupon/GrouponApply'

import FineArtFootNav from './FineArtFootNav.vue'

import ResourcePosition from './resource/ResourcePosition.vue'
import ResourceChooseTag from './resource/ResourceChooseTag.vue'
import ResourceOperate from './resource/ResourceOperate.vue'
import DynamicTag from './resource/DynamicTag.vue'
import ResourceChooseHome from './resource/ResourceChooseHome.vue'
import ResourceHead from './resource/ResourceHead.vue'

export {
  FineArtCateSideBar,
  FineArtEmpty,
  FineArtFoot,
  FineArtHead,
  FineArtSearch,
  FineArtScroller,
  FineArtSlide,
  FineArtEditor,
  FineArtUpload,
  FineArtCategory,
  FineArtAddress,
  HomeSectionTitle,
  FineArtLoginTip,
  FineArtTipModal,
  JumpTop,
  Page,
  SideBar,
  ResourceWorks,
  ResourceCollect,
  ResourceCase,
  FineArtMap,
  FineArtMyAddress,
  FineArtAddressAdd,
  GrouponHead,
  GrouponSearch,
  GrouponNav,
  GrouponApply,
  FineArtFootNav,
  ResourcePosition,
  ResourceChooseTag,
  ResourceOperate,
  DynamicTag,
  ResourceChooseHome,
  ResourceHead
}
