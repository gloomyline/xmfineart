<template>
  <div :class="classes">
    <transition name="slide-left">
      <div class="side-bar" v-show="isExpanded" @touchmove="preventDefault($event)">
        <scroller height="-136" lock-x scrollbar-y ref="scroller">
          <div class="cate-menu">
            <section class="menu-item" v-for="(menu, index) in menus" :key="index">
              <h3 class="menu-title">{{ menu.title }}</h3>
              <div class="menu-content">
                <div class="menu" v-for="(item, index) in menu.content"
                     :key="index"
                     :class="[menu.id, {'menu-new-height': menu.cssType}]"
                     @click="chooseMenu(item, menu, index)">
                     <span class="menu-con" :class="[{'selected': item.value == checkerValues[menu.id][0]}, {'menu-con-some-new-style': menu.cssType}]">
                       <span v-if="menu.cssType">{{ item.label}}</span>
                       <span v-else>{{ item.label | labelFormatter(5) }}</span>
                       <span class="icon fy-icon-select"><span class="path1"></span><span class="path2"></span></span>
                      </span>
                  </div>
                <div class="menu-children"
                     :id="`children-${menu.id}`"
                     v-if="menu.type === 1"
                     v-show="menuChildren[menu.id].children.length !== 0">
                  <span class="menu-child"
                        v-for="(item, indexItem) in menuChildren[menu.id].children"
                        :class="{'selected': item.value === checkerValues[menu.id][2]}"
                        :key="indexItem"
                        @click="chooseChildMenu(item, menu.id)">{{ item.label | labelFormatter(5) }}
                        <span class="icon fy-icon-select"><span class="path1"></span><span class="path2"></span></span>
                  </span>
                </div>
              </div>
            </section>
          </div>
        </scroller>
        <div class="cate-buttons">
          <span class="btn-reset" @click="reset">重置</span>
          <span class="btn-confirm" @click="confirm">选好了</span>
        </div>
      </div>
    </transition>
    <transition name="fade">
      <div class="mask" @click.prevent="unExpand" v-show="isExpanded"></div>
    </transition>
  </div>
</template>

<script>
import {COMPONENT_PREFIX} from '@/assets/data/constants'
import {hyphenCase} from '@/common/js/utils'

export default {
  name: `${COMPONENT_PREFIX}CateSideBar`,
  data () {
    return {
      checkerValues: {},
      menus: [],
      menuChildren: {}
    }
  },
  created () {
  },
  mounted () {
  },
  props: {
    menuData: {
      type: [Array, Object],
      default () {
        return [{
          // 菜单标识
          id: '0',
          // 菜单标题
          title: '商品分类',
          // checker 类型，0 => 单选框，1 => 复选框
          type: 1,
          // 若是复选框，最多可以选几个
          max: 2,
          // 菜单内容
          content: [{
            // 表单值
            value: '0',
            // 标签名
            label: '全部'
          }, {
            value: '1',
            label: '室内装饰'
          }]
        }]
      }
    },
    sidebarValues: {
      type: [Object],
      return: {}
    },
    // 是否处于展开状态
    value: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-cate-side-bar`
    },
    // 父子组件间单向数据流 prop -> computed
    isExpanded () {
      return this.value
    }
  },
  watch: {
    isExpanded (newVal) {
      const vm = this
      if (newVal) {
        window.addEventListener('mousewheel', vm.preventDefault, false)
      } else {
        window.removeEventListener('mousewheel', vm.preventDefault, false)
      }
    }
  },
  methods: {
    _initData () {
      if (!Array.isArray(this.menuData)) {
        this.menus.push(this.menuData)
      } else {
        this.menus = this.menuData
      }
      this.menus.forEach(menu => {
        if (this.checkerValues[menu.id]) return
        this.$set(this.checkerValues, [menu.id], [])
        if (menu.type === 1) {
          this.menuChildren[menu.id] = {
            id: menu.id,
            children: []
          }
        }
      })
      // 初始化侧边栏的选中情况
      if (Object.keys(this.sidebarValues).length === 0) return
      this.$nextTick(() => {
        for (let key in this.sidebarValues) {
          // key指 形如 attr-0 ,attr-1: attr表示menu.id,后面的数字代表是否选中子菜单
          // this.sidebarValues[key]指 形如 0-0-0 前面数字表示选中的父菜单id，中间数字表示选中的子菜单id，后面数字表示选中的父菜单index
          if (!this.sidebarValues[key]) continue
          const keys = key.split('-')
          const values = this.sidebarValues[key].split('-')
          // 选择了子菜单
          if (keys[1] === '1') {
            this.$set(this.checkerValues[keys[0]], 0, values[0])
            let children = []
            for (let item of this.menus) {
              if (item.id === keys[0]) {
                children = item.content[values[2]].children
              }
            }
            // 初始化子菜单
            this.menuChildren[keys[0]] = {
              id: keys[0],
              children
            }
            // 重置选择的父菜单的index
            this.$set(this.checkerValues[keys[0]], 1, values[2])
            // 显示子菜单
            this.showChildren(values[2], keys[0])
            this.$set(this.checkerValues[keys[0]], 2, values[1])
          } else {
            this.$set(this.checkerValues[keys[0]], 0, values[0])
          }
        }
      })
    },
    // 该组件展开之后的回调，允许组件外部调用
    expand () {
      this._initData()
    },
    preventDefault (e) {
      e.preventDefault()
      return false
    },
    // 折叠菜单栏
    unExpand () {
      this.$emit('input', false)
    },
    // 重置所有 checker 为 false
    reset () {
      for (let id in this.checkerValues) {
        this.checkerValues[id] = []
        this.menuChildren[id] = { id: id, children: [] }
      }
    },
    // 选择
    chooseMenu (item, menu, index) {
      this.$set(this.checkerValues[menu.id], 0, item.value)
      if (menu.id === 'foreign') {
        // 选择只看国外时 area_id 清空
        this.checkerValues.area_id = []
      } else if (menu.id === 'area_id' && this.checkerValues.foreign) {
        // 选择看国内 foreign 清空
        this.checkerValues.foreign = []
      }
      // menu.type === 1 表示有下一级选项
      if (menu.type !== 1) return
      this.checkerValues[menu.id].length = 2
      // 返回当前的index给父组件，用于父组件初始化侧边栏选中状态传回
      this.$set(this.checkerValues[menu.id], 1, index)
      // 有二级选项的数据重置
      if (item.children) {
        this.menuChildren[menu.id] = {
          id: menu.id,
          children: item.children
        }
        this.showChildren(index, menu.id)
      } else {
        this.menuChildren[menu.id] = {
          id: menu.id,
          children: []
        }
      }
    },
    chooseChildMenu (item, menu) {
      this.$set(this.checkerValues[menu], 2, item.value)
      if (menu === 'foreign') {
        // 选择只看国外时 area_id 清空
        this.checkerValues.area_id = []
      } else if (menu === 'area_id' && this.checkerValues.foreign) {
        // 选择看国内 foreign 清空
        this.checkerValues.foreign = []
      }
    },
    // 在指定的位置下插入子选项
    showChildren (index, menu) {
      let line = (parseInt(index / 3) + 1) * 3
      const elements = document.getElementsByClassName(menu)
      const children = document.getElementById(`children-${menu}`)
      if (line > elements.length - 1) {
        line = elements.length - 1
        // 在指定元素之后插入元素
        elements[line].parentNode.appendChild(children)
      } else {
        // 在指定元素之前插入新元素
        elements[line].parentNode.insertBefore(children, elements[line])
      }
      this.$nextTick(() => {
        this.$refs.scroller.reset()
      })
    },
    confirm () {
      this.unExpand()
      this.$emit('on-change', this.checkerValues)
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-cate-side-bar
  color: $black1
  .menu-new-height
    height: 100px!important
  .menu-con-some-new-style
    padding-left: 20px
    padding-right: 20px
    padding-top: 12px
    height: 100px!important
    line-height: 37px!important
  .side-bar
    z-index: 2
    position: relative
    fixed: right top 184px
    bottom: 0
    width: 578px
    background-color: $white
    &.slide-left-enter-active, &.slide-left-leave-active
      transition: all .6s ease-in-out
    &.slide-left-enter, &.slide-left-leave-to
      transform: translate3d(578px, 0, 0)
      opacity: 0
    .cate-menu
      padding: 24px 19px 0 19px
      margin-bottom: 20px
      .menu-item
        padding-bottom: 30px
      .menu-title
        padding-left: 10px
        line-height: 37px
        font-size: 26px
        color: $black2
        margin-bottom: 28px
      .menu-content
        overflow-x: hidden
        display: flex
        flex-flow: wrap
        .menu
          width: 160px
          height: 64px
          margin: 0 10px 20px 10px
          .menu-con
            display: block
            width: 160px
            height: 64px
            font-size: 26px
            color: $black2
            text-align: center
            line-height: 64px
            background-color: $grey-menu
            border-radius: 4px
            .icon
              font-size: 0
            &.selected
              position: relative
              color: $orange
              background-color: rgba(247, 181, 44, .2)
              .icon
                absolute: right -5px bottom
                width: 50px
                height: 32px
                font-size: 42px
          &.disabled
            color: $grey4
            background-color: $white
        .menu-children
          overflow-x: hidden
          display: flex
          flex-flow: wrap
          width: 100%
          .menu-child
            width: 160px
            height: 64px
            margin: 0 10px 20px 10px
            border: 2px solid $grey6
            color: $grey3
            font-size: 24px
            text-align: center
            line-height: 64px
            border-radius: 4px
            .icon
              font-size: 0
            &.selected
              position: relative
              color: $orange
              border: 2px solid $orange
              .icon
                absolute: right -7px bottom -3px
                width: 50px
                height: 32px
                font-size: 42px
    .cate-buttons
      absolute: left bottom
      width: 100%
      font-size: 0
      .btn-reset
        display: inline-block
        vertical-align: top
        width: 216px
        height: 88px
        line-height: 88px
        text-align: center
        font-size: 28px
        color: $orange
        background-color: $orange1
      .btn-confirm
        display: inline-block
        vertical-align: top
        width: 362px
        height: 88px
        line-height: 88px
        text-align: center
        font-size: 28px
        color: $white
        background-color: $orange
  .mask
    z-index: 1
    fixed: left top 184px
    width: 100%
    height: 100%
    background-color: rgba(33, 33, 33, 0.7)
    &.fade-enter-active, &.fade-leave-active
      transition: all 0.5s ease-in-out
    &.fade-enter, &.fade-leave-to
      opacity: 0
</style>
