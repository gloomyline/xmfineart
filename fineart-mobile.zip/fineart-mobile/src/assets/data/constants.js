import config from '@/../config/index.js'

// different url domain of corresponding environment server
const env = process.env.NODE_ENV === 'development'
  ? 'dev' : process.env.NODE_ENV === 'production'
    ? 'build' : 'test'

/**
 * @comment: 常量定义文件
 * @author: alan_wang
 * @date: 11/10/2018
 * @time: 20:21:45
 */

export const MESSAGE_DURATION = 3
export const TOAST_DURATION = 3
export const LOADING_TEXT = '加载中...'

export const TIMER_COUNTER = 60

export const COMPONENT_PREFIX = 'FineArt'

export const A_MAP_Key = '768d15d6a7eefa4341fc9219e2818aee'
export const A_MAP_DEFAULT_ZOOM_INDEX = 11
export const MAP_CATE_MARKERS_NUMBER_PER_SWIPER = 18
export const MAP_POSITION_MARKER_WIDTH = 13
export const MAP_POSITION_MARKER_HEIGHT = 29
export const MAP_MARKER_COMMON_WIDTH = 30
export const MAP_MARKER_COMMON_HEIGHT = 30
export const MAP_MARKER_ACTIVE_WIDTH = 34
export const MAP_MARKER_ACTIVE_HEIGHT = 34
export const MAP_TOUCH_MOVE_DISTANCE = 30
export const MAP_BUILDING_MARKER_COMMON_WIDTH = 30
export const MAP_BUILDING_MARKER_COMMON_HEIGHT = 30
export const MAP_BUILDING_MARKER_ACTIVE_WIDTH = 40
export const MAP_BUILDING_MARKER_ACTIVE_HEIGHT = 40
export const MAP_REPRESENT_MARKER_COMMON_WIDTH = 40
export const MAP_REPRESENT_MARKER_COMMON_HEIGHT = 48
export const MAP_REPRESENT_MARKER_ACTIVE_WIDTH = 44
export const MAP_REPRESENT_MARKER_ACTIVE_HEIGHT = 52

export const BACK_URL = '__FA_BACK_URL__'
export const WX_PAY_OPENID = '__FA_WX_PAY_OPENID__'
export const USER_CURRENT_POSITION = '__FA_USER_CURRENT_POSITION__'
export const WX_CODE = '__FA_WX_CODE__'

// 用户地理位置有效时间, 单位 ms
export const POSITION_ACTIVE_TIME = 5 * 60 * 1000

// 关注后禁用连续点击时间
export const COLLECT_MESSAGE_DURATION = 2000

// 获取不同环境下不同的域名
export const API_ADDRESS = config[env].apiAddress
export const CACHE_ADDRESS = config[env].cacheAddress

// wechat
export const WX_APP_ID = 'wxdab546b67f307a20'
// wechat sdk share data
export const SHARE_DATA = {
  index: { // 首页
    title: '斐艺，建筑“滴滴”',
    desc: '斐艺(Fine Art)，连接建筑各方资源，进行系统整合，建立全面专业的资源数据库，输出设计/建造/开发的能力。',
    link: '', // will be written by vue wx plugin in different hash path
    imgUrl: 'https://static.xmfineart.com/m-static/wx-share-imgs/img-share-fine-art-logo.png',
    type: 'link',
    dataUrl: ''
  },
  mall: {
    title: '斐艺购',
    desc: '建筑商城，产品&服务一应俱全！',
    link: '', // will be written by vue wx plugin in different hash path
    imgUrl: 'https://static.xmfineart.com/m-static/wx-share-imgs/img-share-fine-art-mall.png',
    type: 'link',
    dataUrl: ''
  },
  map: {
    title: '斐艺地图',
    desc: '大家都在使用的建筑“滴滴”，加入斐艺地图，链接整个建筑行业',
    link: '', // will be written by vue wx plugin in different hash path
    imgUrl: 'https://static.xmfineart.com/m-static/wx-share-imgs/img-share-fine-art-didi.png',
    type: 'link',
    dataUrl: ''
  },
  building: {
    title: '斐艺建筑',
    desc: '地标特色建筑数据库，链接建筑各方资源，进行系统有效地整合',
    link: '', // will be written by vue wx plugin in different hash path
    imgUrl: 'https://static.xmfineart.com/m-static/wx-share-imgs/img-share-fine-art-building.png',
    type: 'link',
    dataUrl: ''
  },
  resource: {
    title: '斐艺资源',
    desc: '设计/建造/开发/资管优质资源的在线共享数据库',
    link: '', // will be written by vue wx plugin in different hash path
    imgUrl: 'https://static.xmfineart.com/m-static/wx-share-imgs/img-share-fine-art-resource.png',
    type: 'link',
    dataUrl: ''
  },
  member: { // 首页
    title: '斐艺，建筑“滴滴”',
    desc: '斐艺(Fine Art)，连接建筑各方资源，进行系统整合，建立全面专业的资源数据库，输出设计/建造/开发的能力。',
    link: '', // will be written by vue wx plugin in different hash path
    imgUrl: 'https://static.xmfineart.com/m-static/wx-share-imgs/img-share-fine-art-logo.png',
    type: 'link',
    dataUrl: ''
  },
  house: { // 首页
    title: '美宅设计',
    desc: '斐艺美宅(Fine Art)，温暖的家。',
    link: '', // will be written by vue wx plugin in different hash path
    imgUrl: 'https://static.xmfineart.com/m-static/wx-share-imgs/img-share-fine-art-house.png',
    type: 'link',
    dataUrl: ''
  }
}
