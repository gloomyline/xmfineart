/**
 * @comment: 地图插件 api
 * @author: alan_wang
 * @date: 06/11/2018
 * @time: 10:27:01
 */
export default function (cls) {
  /**
   * 获取审核通过的地图标记列表
   * @param lng                     {String}      经度
   * @param lat                     {String}      纬度
   * @param distance                {String}      距离
   * @param map_marker_category_id  {String}      标记分类 id
   * @param is_representative       {Boolean}     是否是群组、代表
   * @returns {Promise<*|Array|default.props.results|{type, default}>}
   */
  cls.prototype.fetchMarkers = async ({
    lng = '',
    lat = '',
    distance = '',
    map_marker_category_id = '',
    is_representative
  } = {}) => {
    const response = await cls.request({
      url: '/map/marker/index',
      query: {
        lng,
        lat,
        distance,
        map_marker_category_id,
        is_representative: is_representative
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 添加标记
   * @param map_marker_category_id {String}           提交的标记分类 id
   * @param address                {String}           提交标记所在的地址
   * @param lng                    {String | Number}  提交标记所在的经度
   * @param lat                    {String | Number}  提交标记所在的纬度
   * @param name                   {String}           标记信息名字
   * @param mobile                 {String}           标记信息手机号
   * @param remark                 {String}           标记信息备注
   * @returns {Promise<*>}                            包裹服务端返回的 Promise
   */
  cls.prototype.addMarker = async ({ map_marker_category_id, address, lng, lat, name, mobile, remark = '' }) => {
    const response = await cls.request({
      url: '/map/marker/add',
      method: 'post',
      data: {
        lng,
        lat,
        name,
        remark,
        mobile,
        address,
        map_marker_category_id
      }
    })
    if (response.code === 200) {
      return response
    }
  }
}
