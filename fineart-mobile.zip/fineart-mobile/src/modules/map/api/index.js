/**
 * @comment:
 * @author: alan_wang
 * @date: 06/11/2018
 * @time: 10:23:46
 */
import {BaseApi} from '@/common/js/BaseApi'
import initMap from './mapPlugin.js'

class MapApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    MapApi.updateToken(MapApi.readTokenFromLocalStorage())
    initMap(MapApi)
  }
}

export default new MapApi()
