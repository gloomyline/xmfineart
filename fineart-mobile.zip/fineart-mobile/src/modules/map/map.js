/*
* @Author: Alan
* @Date:   2018-09-06 20:11:35
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-10 14:21:30
*/
// import flexible mobile layout
import 'amfe-flexible'
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import store from '@/store'
import router from './router'
import Map from './Map.vue'
import { VueMap } from '@/common/js/Map.js'
import { TOAST_DURATION, SHARE_DATA } from 'assets/data/constants.js'
import { VueLocalStorage } from '@/common/js/LocalStorage'
import { WXPlugin } from '@/common/js/vue-wx.js'
import { goLogin } from '@/common/js/utils'

// common style files
import '@/common/styles/index.styl'

// vux components register
import { Scroller, Swiper, SwiperItem, Spinner, Tab, TabItem, ToastPlugin, LoadingPlugin, XButton } from 'vux'
import {API_ADDRESS} from 'assets/data/constants'
Vue.component('scroller', Scroller)
Vue.component('swiper', Swiper)
Vue.component('swiper-item', SwiperItem)
Vue.component('spinner', Spinner)
Vue.component('tab', Tab)
Vue.component('tab-item', TabItem)
Vue.component('x-button', XButton)

const dpr = window.devicePixelRatio >= 3 ? 3 : 2
// env constants
Vue.prototype.$env = {
  dpr,
  remUnit: dpr === 3 ? 41.4 : 37.5
}

// Toast default opts
const toastOpts = {
  position: 'bottom',
  width: '134px',
  time: TOAST_DURATION * 1000,
  type: 'text'
}
Vue.use(ToastPlugin, toastOpts)
// Loading plugin
Vue.use(LoadingPlugin)

// FMap plugin
Vue.use(VueMap)

Vue.use(VueLocalStorage)

// router global hook
router.beforeEach((to, from, next) => {
  const user = Vue.localStorage.getUser()
  if (user && user.isLogin && user.token) {
    if (Object.keys(store.state.memberProfile).length === 0) {
      store.dispatch('fetchAccountProfile')
    }
  }
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // this route requires auth, check if logged in
    // if not, break route change, open login modal.
    if (user && user.isLogin) { // user status is valid, go to corresponding path
      next()
    } else { // not login or is out of date
      next(false)
      // 前往登录、注册页
      goLogin()
    }
  } else {
    next() // 确保一定要调用 next()
  }
})

// wx js sdk
Vue.use(WXPlugin, { shareData: SHARE_DATA.map, module: 'map' })
// 使用 vue wx 插件更新页面的分享内容
router.afterEach((to) => {
  const location = window.location
  const pageLink = location.href.replace(location.hash, '')
  const _link = `${pageLink}#${to.path}`
  const link = `${API_ADDRESS}/sys/wechat/share?url=${encodeURIComponent(_link)}`
  Vue.wx.updateShareData('map', { link })
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  router,
  template: '<Map/>',
  components: { Map }
})
