<template>
  <div :class="classes">
    <!--阴影部分-->
    <!--<div class="shadow"></div>-->
    <!-- map 容器 -->
    <fine-art-head title="斐艺地图" style="z-index:16" v-show="isHeadShow" @close-func="closeNav"></fine-art-head>
    <div class="map-container" id="map">
      <div class="discovery-btn-location" @click="location"><span class="icon"></span></div>
    </div>
    <!-- box 容器 -->
    <div class="box-pop-container">
      <transition name="fade-in" mode="out-in">
        <!-- box 探索、发现 -->
        <div class="box pop-discovery-join" :class="{up: isAppCollectionShow}" v-if="popStatus === 0" :key="0">
          <!-- 上方探索、发现入口 -->
          <div class="top">
            <h3 class="address">
              <span class="icon fy-icon-my-address"></span>
              <span class="txt-address">{{ userCurrentAddress }}</span>
            </h3>
            <div class="btn-discovery-join-wrap">
              <x-button
                type="primary"
                class="btn-discovery-join"
                @click.native="popStatus = 1">
                <div class="icon-search-wrap">
                  <span class="icon-search"></span>
                </div>
                <span class="label">寻找 / 加入</span>
              </x-button>
            </div>
            <div class="btn-add-wrap" @click="toggleAppCollectionShow">
              <div class="btn-add" :class="{ rotated: isAppCollectionShow }"></div>
            </div>
          </div>
          <!-- 下方应用集 -->
          <div class="bottom">
            <swiper dots-position="center">
              <swiper-item class="apps-list first">
                <div class="app-list">
                  <a class="app-item" href="mall.html#/groupon/100">
                    <span class="icon icon-group-buy"></span>
                    <p class="name text-center">团购</p>
                  </a>
                </div>
              </swiper-item>
            </swiper>
          </div>
        </div>
        <!-- 分类滑动容器 -->
        <div class="box pop-cate-swiper" v-else-if="popStatus === 1" :key="1">
          <!-- 上方状态栏，包含已选择分类，了解更多入口，以及返回探索发现 -->
          <div class="state-bar">
            <h3 class="selected-cate-state">已选择：{{ selectedCates }}</h3>
            <div class="more" v-if="introduction_show_status" @click="knownMoreShowHandle">
              <span class="icon icon-question-round"></span>
              <span class="txt">了解更多</span>
            </div>
            <div class="btn-close" @click="popStatus = 0"><span class="icon fy-icon-off"></span></div>
          </div>
          <!-- 二级分类 swiper 容器 -->
          <div class="swiper-wrap">
            <swiper :height="cateSwiperHeight" :show-dots="false" :duration="1" v-model="secondCateIndex" class="cate-swiper">
              <swiper-item v-for="swiper in swipers" :key="swiper.id">
                <ul class="cate-list">
                  <li class="cate-item" :class="{active: selectedCateId === cate.id}" v-for="cate in swiper.cateList" :key="cate.id" @click="chooseSecCate(cate)">
                    <img :src="cate.icon_url" width="29" height="29">
                    <p class="name">{{ cate.name }}</p>
                  </li>
                </ul>
              </swiper-item>
            </swiper>
            <div class="swiper-indicators text-center">
              <span class="indicator" :class="{ active: firstCateSwiperIdx === i - 1 }" v-for="i in firstCateSwiperLen" :key="i">{{ i }}</span>
            </div>
          </div>
          <!-- 一级分类导航 -->
          <tab class="first-cate-tabs" v-model="firstCateIndex" :animate="false" :line-width="0">
            <tab-item class="text-center" active-class="active" v-for="tab in tabs" :key="tab.id">
              <img :src="tab.icon_url" width="25" height="25">
            </tab-item>
          </tab>
          <div class="btn btn-join" @click="join" :class="{'btn-join-active': selectedCateId}">加入</div>
          <div class="btn btn-discovery" @click="discovery" :class="{'btn-discovery-active': selectedCateId}">寻找</div>
        </div>
        <!-- 单元信息卡片 -->
        <div class="box pop-unit-info" v-else-if="popStatus === 2" :key="2">
          <div class="btn-close" @click="closePopUnitInfo"><span class="fy-icon-off"></span></div>
          <div class="avatar-wrap">
            <img class="avatar" :src="selectedMarkerInfo.resource_url && selectedMarkerInfo.resource_logo ? selectedMarkerInfo.resource_logo : defaultMarkerInfoAvatar" width="100%" height="100%">
          </div>
          <h3 class="title">
            <span class="name">{{ selectedMarkerInfo.name }}</span>
            <div class="store-link" v-if="selectedMarkerInfo.store_id" @click="toStoreDetail(selectedMarkerInfo.store_id)">
              <span class="icon-store"></span>
            </div>
          </h3>
          <div class="tags"><span class="tag">{{ selectedMarkerInfo.category_name }}</span></div>
          <div class="address">
            <span class="icon fy-icon-location"></span>
            <span class="full-address">{{ selectedMarkerInfo.address }}</span>
          </div>
          <div class="mobile">
            <span class="icon fy-icon-iphone"></span>
            <span class="mobile">{{ selectedMarkerInfo.mobile | mobileFormater }}</span>
          </div>
          <div class="btns">
            <a class="btn btn-contact-platform" href="tel:15259268926">
              <span class="label">联系平台</span>
            </a>
            <div class="btn btn-person-home-page" @click="goHomePage" v-if="selectedMarkerInfo.resource_url">
              <span class="label">进入主页</span>
            </div>
            <div class="btn btn-person-home-page" @click="openHomeIntroShowHandle" v-else>
              <span class="label">开通主页</span>
            </div>
          </div>
        </div>
        <!-- 普通标记添加表单 -->
        <div class="box pop-normal-form" v-else-if="popStatus === 3" :key="3">
          <div class="title">
            <div class="btn-return" @click="popStatus = 1"><span class="icon fy-icon-arrow-right"></span></div>
            <h3 class="cate-name">{{ selectedCateName }}</h3>
            <div class="more" v-if="introduction_show_status" @click="knownMoreShowHandle">
              <span class="icon icon-know-more"></span>
              <span class="label">了解更多</span>
              <span class="icon fy-icon-arrow-right"></span>
            </div>
          </div>
          <div class="input-wrap company-name"><input v-model.trim="normalForm.name" type="text" placeholder="输入公司名称/姓名" @blur="blur"></div>
          <div class="input-wrap mobile"><input v-model.trim.number="normalForm.mobile" type="tel" placeholder="输入手机号" @blur="blur"></div>
          <x-button type="primary" @click.native="submitJoinForm">提交</x-button>
        </div>
        <!-- 通用标记添加表单 -->
        <div class="box pop-common-form" v-else-if="popStatus === 4" :key="4">
          <h3 class="address">
            <span class="icon fy-icon-my-address"></span>
            <span class="txt-address">{{ userCurrentAddress }}</span>
          </h3>
          <div class="input-wrap company-name"><input v-model.trim="commonForm.name" type="text" placeholder="输入公司名称/姓名" @blur="blur"></div>
          <div class="input-wrap mobile"><input v-model.trim.number="commonForm.mobile" type="tel" placeholder="输入手机号" @blur="blur"></div>
          <div class="input-wrap remark"><input v-model.trim="commonForm.remark" type="text" placeholder="填写备注" @blur="blur"></div>
          <x-button type="primary" @click.native="submitCommonForm">提交</x-button>
          <div class="btn-close" @click="close"><span class="icon fy-icon-off"></span></div>
        </div>
        <!-- 标记添加提交结果 -->
        <div class="box pop-form-result" v-else-if="popStatus === 5" :key="5">
          <h3 class="title">
            <span class="icon"></span>
            <span class="txt">提交成功</span>
          </h3>
          <p class="fineart-token-activity">客服审核通过后，您的信息即可在地图上展示</p>
          <x-button class="btn-go-fineart-token" type="primary" @click.native="close">确定</x-button>
          <div class="btn-close" @click="close"><span class="icon fy-icon-off"></span></div>
        </div>
      </transition>
    </div>
    <!-- 会员中心 -->
    <div class="member-center">
      <div class="btn-open-member" @click="isMemberExpanded = true"><span class="icon icon-member"></span></div>
      <transition name="fade">
        <div class="member-mask"
             v-show="isMemberExpanded"
             @touchmove="preventScroll($event)"
             @click="isMemberExpanded = false"></div>
      </transition>
      <transition name="slide">
        <div class="member-menu-wrap" v-show="isMemberExpanded" @touchmove="preventScroll($event)">
          <side-bar @slide-left="isMemberExpanded = false" :status="isMemberExpanded"></side-bar>
        </div>
      </transition>
    </div>
    <!-- 返回首页 -->
    <div class="btn-back-home" @click="openNav()">
      <span class="icon"
            :class="[isOpen ? 'icon-close-home' : 'icon-back-home']"></span>
      <i class="icon-triangle" v-show="isOpen"></i>
      <ul class="nav-wrap" :class="{'expanded': isOpen}">
        <li class="nav-item" v-for="(nav, index) in navList" :key="index">
          <a :href="nav.link">{{nav.label}}</a>
        </li>
      </ul>
    </div>
    <!-- 遮罩 -->
    <div class="mask" v-show="isMaskShow" @touchend="toggleAppCollectionShow"></div>
    <!--开通主页介绍弹窗-->
    <transition name="fade">
      <div class="common-mask"
           v-show="isOpenHomeIntroShow"
           @touchmove="preventScroll($event)"
           @click="openHomeIntroShowHandle">
      </div>
    </transition>
    <transition name="fade">
        <div class="intro-container" v-show="isOpenHomeIntroShow" @touchmove="preventScroll($event)">
         <!--上部图标-->
          <div class="top-icon">
            <div class="quote-wrap"><span class="quote"></span></div>
            <div class="cancel-wrap" @click="openHomeIntroShowHandle"><span class="cancel"></span></div>
          </div>
          <!--主体介绍内容-->
          <div class="intro">
            <div class="how-to-open">如何开通服务</div>
            <div class="how-to-open-en">How to Open Home Page Service</div>
            <div class="brief-intro">
              开通个人主页，建立在线名片。<br>
              连接你的作品、案例、动态。<br>
              一键分享，连接整个建筑行业，告别无效宣传。
            </div>
            <div class="open-flow">开通流程</div>
            <div class="triangle"></div>
            <ul class="flow">
              <li><div class="num"><span class="icon-one"></span></div>注册/登录斐艺账号</li>
              <li><div class="num"><span class="icon-two"></span></div>进行实名认证</li>
              <li><div class="num"><span class="icon-three"></span></div>在[会员中心]开通主页</li>
              <li><div class="num"><span class="icon-four"></span></div>在[地图管理]绑定主页</li>
            </ul>
            <div class="fineart-wrap"><span class="fineart"></span></div>
          </div>
          <!--按钮-->
          <div class="button" @click="goTORegiOrLogin">
            马上注册/登录
          </div>
        </div>
    </transition>
    <!--了解更多介绍弹窗-->
    <transition name="fade">
      <div class="common-mask"
           v-show="isKnownMoreShow"
           @touchmove="preventScroll($event)"
           @click="knownMoreShowHandle">
      </div>
    </transition>
    <transition name="fade">
      <div class="known-more-container" v-show="isKnownMoreShow" @touchmove="preventScroll($event)">
        <!--上部图标-->
        <div class="top-icon">
          <div class="quote-wrap"><span class="quote"></span></div>
          <div class="cancel-wrap" @click="knownMoreShowHandle"><span class="cancel"></span></div>
        </div>
        <!--主体介绍内容-->
        <div class="intro">
          <cube-scroll
          ref="scroller"
          :options="options">
            <div v-html="introduction"></div>
          </cube-scroll>
        </div>
      </div>
    </transition>
    <!--测试用放大缩小按钮-->
    <!--<div class="test-buttons">-->
      <!--<div class="zoom-out" @click="zoomOut">放大</div>-->
      <!--<div class="zoom-in" @click="zoomIn">缩小</div>-->
    <!--</div>-->
  </div>
</template>

<script>
import {
  COMPONENT_PREFIX,
  MAP_CATE_MARKERS_NUMBER_PER_SWIPER,
  MAP_MARKER_ACTIVE_HEIGHT, MAP_MARKER_ACTIVE_WIDTH,
  MAP_MARKER_COMMON_HEIGHT,
  MAP_MARKER_COMMON_WIDTH,
  MAP_POSITION_MARKER_HEIGHT,
  MAP_POSITION_MARKER_WIDTH,
  MAP_TOUCH_MOVE_DISTANCE,
  MAP_REPRESENT_MARKER_COMMON_WIDTH,
  MAP_REPRESENT_MARKER_COMMON_HEIGHT,
  MAP_REPRESENT_MARKER_ACTIVE_WIDTH,
  MAP_REPRESENT_MARKER_ACTIVE_HEIGHT
} from '@/assets/data/constants'
import {
  MAP_PLEASE_SELECT_CATE,
  MAP_COMPANY_NAME_NOT_EMPTY,
  MAP_MOBILE_NOT_EMPTY,
  MAP_MOBILE_NOT_VALID
} from '@/assets/data/message'
import { deepClone, hyphenCase } from '@/common/js/utils'
import { getMapMarkerCategory } from '@/common/js/loadScript'

import { SideBar, FineArtHead } from 'components'
import { Scroll } from 'cube-ui'

import api from 'modules/map/api'

// 弹窗状态
//
// 探索、发现
// const DISCOVERY_FIND = 0
// // 分类选择
// const CATE_SWIPER = 1
// // 信息查看
// const UNIT_INFO = 2
// // 个人表单
// const PERSON_FORM = 3
// // 组织表单
// const ORGANIZATION_FORM = 4
// // 表单提交结果
// const FORM_RESULT = 5

export default {
  name: `${COMPONENT_PREFIX}PageDiscoveryJoin`,
  components: {
    SideBar,
    'cube-scroll': Scroll,
    FineArtHead

  },
  data () {
    return {
      // 展开导航
      isOpen: false,
      navList: [
        {
          label: '首页',
          link: 'index.html'
        },
        {
          label: '建筑"滴滴"',
          link: 'map.html'
        },
        {
          label: '斐艺购',
          link: 'mall.html'
        },
        {
          label: '斐艺建筑',
          link: 'building.html'
        },
        {
          label: '斐艺资源',
          link: 'resource.html'
        },
        {
          label: '官方微信',
          link: 'index.html#/focus-us'
        }
      ],
      // 会员中心侧边栏是否展开
      isMemberExpanded: false,
      // 弹窗状态, 0:寻找加入 1：选择分类 2：选中标记点详情 3：普通标记添加表单 4：通用标记添加表单 5：标记添加提交结果
      popStatus: 0,
      // 应用集是否显示
      isAppCollectionShow: false,
      // 分类列表数据
      cates: [],
      // 一级分类列表
      tabs: [],
      // 一级分类数据列表
      firstCates: [],
      // 一级分类索引
      firstCateIndex: 0,
      // 二级分类 swiper 列表
      swipers: [],
      // 二级分类数据列表
      secondCates: [],
      // 二级分类列表索引
      secondCateIndex: 0,
      // 高德地图实例
      mapInstance: null,
      // 用户初始地理位置
      userInitPosition: null,
      // 用户当前地理位置
      userCurrentPosition: { lng: '', lat: '' },
      // 用户当前地址
      userCurrentAddress: '',
      // 地图上当前位置的标记 AMap.Marker
      positionMarker: null,
      // 当前地图上添加标记列表 Array<AMap.Marker>
      addedMarkers: [],
      // 获取标记列表数据提交的表单
      markerListConfig: {
        // 经度
        lng: null,
        // 维度
        lat: null,
        // 范围半径
        distance: '100000',
        // 选择的标记 cate ID
        map_marker_category_id: '',
        // 是否是省代表
        is_representative: ''
      },
      // 当前选中标记信息
      selectedMarkerInfo: {},
      // 当前选中的地图标记 target
      selectedMarker: null,
      // 选中的分类 id
      selectedCateId: null,
      // 普通标记添加表单
      normalForm: {
        name: '',
        mobile: ''
      },
      // 通用标记添加表单
      commonForm: {
        name: '',
        mobile: '',
        remark: ''
      },
      // 是否弹出开通主页介绍弹窗
      isOpenHomeIntroShow: false,
      // 测试用变量
      zoomNum: 11,
      // 是否显示了解更多内容
      isKnownMoreShow: false,
      // 旧的的比例尺,初始化为5公里
      oldZoom: 11,
      // 是否需要请求api
      isRequestApi: true,
      // 普通标记点
      comMarkers: [],
      // 代表标记点
      representMarkers: [],
      // 要重新渲染的普通标记点
      recoverComMarkers: [],
      // 要重新渲染的代表标记点
      recoverRepMarkers: [],
      options: {
        scrollbar: true,
        startY: 0,
        scrollY: true
      },
      introduction: '',
      isHeadShow: false
    }
  },
  created () {
    this._initPop()
    this._initMap()
  },
  mounted () {
  },
  beforeDestroy () {
    this.$fMap.destory()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-discovery-join`
    },
    swiperHeight () {
      return `${5.8 * this.$env.remUnit}px`
    },
    cateSwiperHeight () {
      return `${(380 / 2) * (this.$env.remUnit / 37.5)}px`
    },
    // 标记信息弹窗默认头像
    defaultMarkerInfoAvatar () {
      return require(`assets/imgs/map/icon-marker-info-default-avatar@${this.$env.dpr}x.png`)
    },
    isMaskShow () {
      return (this.popStatus === 0 && this.isAppCollectionShow) || (this.popStatus !== 0 && this.popStatus !== 2 && this.popStatus !== 1 && this.popStatus !== 4)
    },
    // 选中的一级分类+二级分类
    selectedCates () {
      if (!this.selectedCateId) return ''
      const selectedCate = this.secondCates.find(cate => {
        return cate.id === this.selectedCateId
      })
      return `${selectedCate.name}`
    },
    // 是否显示'了解更多'提示
    introduction_show_status () {
      if (!this.selectedCateId) return false
      const selectedCate = this.secondCates.find(cate => {
        return cate.id === this.selectedCateId
      })
      return selectedCate.introduction_show_status
    },
    selectedCateName () {
      if (!this.selectedCateId) return ''
      return (this.secondCates.find(cate => { return cate.id === this.selectedCateId })).name
    },
    // 当前一级分类中 swiper 的索引
    firstCateSwiperIdx () {
      const secondCateSwiper = this.swipers[this.secondCateIndex]
      return Number.parseInt(secondCateSwiper.id.split('-')[1])
    },
    // 当前一级分类中 swipers 的个数
    firstCateSwiperLen () {
      return Math.ceil(this.tabs[this.firstCateIndex].son.length / MAP_CATE_MARKERS_NUMBER_PER_SWIPER)
    }
  },
  watch: {
    markerListConfig: {
      deep: true,
      async handler () {
        const lng = this.markerListConfig.lng
        const lat = this.markerListConfig.lat
        if (!lng || !lat || this.popStatus === 4 || !this.isRequestApi) {
          this.isRequestApi = true
          return
        }
        const markerList = await api.fetchMarkers(this.markerListConfig)
        this.addMarkers(markerList)
        this.positionMarker.setTop(true)
      }
    },
    isMemberExpanded (newVal) {
      const vm = this
      if (newVal) {
        document.addEventListener('mousewheel', vm.preventScroll, false)
      } else {
        document.removeEventListener('mousewheel', vm.preventScroll, false)
      }
    },
    firstCateIndex (newIdx) {
      this.selectedCateId = null // 切换tabs时重置selectedCateId为null
      const swiperId = `${newIdx}-0`
      for (let i = 0, len = this.swipers.length; i < len; ++i) {
        const swiper = this.swipers[i]
        if (swiper.id === swiperId) {
          return (this.secondCateIndex = i)
        }
      }
    },
    secondCateIndex (newIdx) {
      const swiper = this.swipers[newIdx]
      this.firstCateIndex = Number.parseInt(swiper.id.split('-')[0])
    }
  },
  methods: {
    openNav () {
      this.isHeadShow = !this.isHeadShow
      window.setTimeout(() => {
        document.getElementById('rightFunc').click() // 手动触发单击事件，弹出导航菜单。setTimeout为了保留导航菜单弹出动画效果
      }, 200)
    },
    closeNav () {
      window.setTimeout(() => {
        this.isHeadShow = !this.isHeadShow
      }, 300)
    },
    // 初始化弹窗，主要用于通用提交
    _initPop () {
      const isCommonJoin = this.$route.name === 'CommonJoin'
      if (isCommonJoin) {
        this.popStatus = 4
        this.markerListConfig.map_marker_category_id = 31
        // TODO: add common category this moment
      }
    },
    // 左边栏以及导航栏弹窗弹出时，阻止弹窗触发滚动事件
    preventScroll (e) {
      e.preventDefault()
      return false
    },
    // 添加定位点标记
    _initPositionMarker (mapInstance) {
      const icon = require(`assets/imgs/icon-map-select@${this.$env.dpr}x.png`)
      const positionMarker = this.positionMarker = this.$fMap.createMarker(icon, {
        w: MAP_POSITION_MARKER_WIDTH,
        h: MAP_POSITION_MARKER_HEIGHT
      })
      mapInstance.add(positionMarker)
      mapInstance.positionMarker = positionMarker
      // 初始化定位点位置
      this.$fMap.mapGeoLocal()
    },
    // 绑定地图事件
    _bindEvents (mapInstance) {
      // 绑定地图点击事件
      mapInstance.on('click', async (data) => {
        this.isOpen = false // 点击地图关闭导航
        mapInstance.positionMarker.setTop(true)
        this.userCurrentPosition = data.lnglat
        const position = [data.lnglat.lng, data.lnglat.lat]
        this.$fMap.mapGeoLocal(position)
        const address = await this.$fMap.getAddress(this.userCurrentPosition)
        // 更新当前用户地址
        this.userCurrentAddress = address.fullAddress
      })
      // 绑定地图缩放事件, 监听缩放比例的变化,(双指)缩放
      mapInstance.on('zoomchange', async () => {
        if (this.oldZoom > 7) {
          // 上一个比例尺在100公里以下，下一个比例尺大于等于100公里，清除地图上100公里以下标记点，请求大于100公里的数据
          if (mapInstance.getZoom() <= 7) {
            if (this.mapInstance && this.comMarkers) {
              this.mapInstance.remove(this.comMarkers)
            }
            this.markerListConfig.is_representative = '200'
            this.isRequestApi = true
          } else { // 上一个比例尺在100公里以下，下一个比例尺也在100以下,不清除数据,也请求数据
            this.isRequestApi = false
          }
        } else { // 上一个比例尺大于等于100公里，下一个比例尺大于仍等于100公里，不清除数据，也不请求数据
          if (mapInstance.getZoom() <= 7) {
            this.isRequestApi = false
          } else { // 上一个比例尺大于等于100公里，下一个比例尺小于100公里，清除100公里以上标记点，恢复原先数据，再请求数据
            if (this.mapInstance && this.representMarkers) {
              this.mapInstance.remove(this.representMarkers)
            }
            // 恢复原先数据
            this.recoverComMarkers.length === 0 ? this.mapInstance.add(this.comMarkers) : this.mapInstance.add(this.recoverComMarkers)
            this.markerListConfig.is_representative = ''
            this.isRequestApi = true
          }
        }
        // 存储当前比例尺
        this.oldZoom = mapInstance.getZoom()
        const position = mapInstance.getCenter()
        this.userCurrentPosition = position
        this.$fMap.mapGeoLocal([position.lng, position.lat])
        this.userCurrentAddress = (await this.$fMap.getAddress(position)).fullAddress
        this.markerListConfig = {
          ...this.markerListConfig,
          ...{
            lng: this.userCurrentPosition.lng,
            lat: this.userCurrentPosition.lat
          }
        }
      })
      // 绑定(单指)触摸移动事件
      mapInstance.on('touchstart', ev => {
        this.sp = ev.pixel
      })
      mapInstance.on('touchend', async ev => {
        this.ep = ev.pixel
        const position = mapInstance.getCenter()
        this.userCurrentPosition = position
        this.$fMap.mapGeoLocal([position.lng, position.lat])
        this.userCurrentAddress = (await this.$fMap.getAddress(position)).fullAddress
        const distance = Math.pow(Math.pow(this.ep.x - this.sp.x, 2) + Math.pow(this.ep.y - this.sp.y, 2), 1 / 2)
        // 移动地图时只有在移动距离大于设定值并且是请求小于100公里以下数据时才进行数据请求
        if (distance >= MAP_TOUCH_MOVE_DISTANCE && this.markerListConfig.is_representative !== '200') {
          this.markerListConfig = {
            ...this.markerListConfig,
            ...{
              lng: this.userCurrentPosition.lng,
              lat: this.userCurrentPosition.lat
            }
          }
        }
      })
    },
    // 初始化地图实例
    async _initMapInstance () {
      try {
        // 创建地图实例
        const mapInstance = await this.$fMap.createMap('map') // 去掉this，比例尺就从默认的10变为自定义的11？
        // 设置地图主题样式 - 远山黛
        mapInstance.setMapStyle('amap://styles/whitesmoke')
        this._initPositionMarker(mapInstance)
        this._bindEvents(mapInstance)
        // 初始化缩放比例尺样式
        this.$nextTick(() => {
          const scaleControl = this.$el.querySelector('.amap-scalecontrol')
          scaleControl.style.left = '15px'
          scaleControl.style.bottom = '115px'
        })
        // 获取当前用户地理位置
        const position = this.userCurrentPosition = await this.$fMap.geoLocation()
        this.userInitPosition = deepClone(position)
        // 获取当前用户地址信息
        const address = await this.$fMap.getAddress(this.userCurrentPosition)
        this.userCurrentAddress = address.fullAddress
        return mapInstance
      } catch (e) {
        console.log('creating map instance:', e)
        // 创建地图实例出错的话刷新当前页，重新创建
        window.location.reload()
      }
    },
    // 初始化地图
    async _initMap () {
      this.mapInstance = await this._initMapInstance()
      // 标记分类数据
      const cateData = this.cates = await getMapMarkerCategory()
      this.formatCateData(cateData)
      // 获取当前地理位置附近所有的标记数据
      this.markerListConfig.lng = this.userCurrentPosition.lng
      this.markerListConfig.lat = this.userCurrentPosition.lat
    },
    // 添加 markers 到地图上
    addMarkers (markerList) {
      // 格式化二级分类方法
      const formatSecondCates = (secondCates) => {
        const ret = {}
        secondCates.forEach(cate => {
          ret[cate.id] = cate
        })
        return ret
      }
      const secondCates = formatSecondCates(this.secondCates)
      // 获取高德地图 AMap 类
      const AMap = this.$fMap.Map
      // 创建地图标记点方法
      const createMarkerIcon = (iconUrl, { w, h }) => {
        return new AMap.Icon({
          size: new AMap.Size(w, h),
          image: iconUrl,
          imageSize: new AMap.Size(w, h)
        })
      }
      markerList.forEach(item => {
        if (item.category_id === '32') return // 过滤掉通用信息和已加入的对象
        let isHasSameMarder = false
        if (this.markerListConfig.is_representative !== '200') { // 只有在100公里以下才进行数据过滤
          this.comMarkers.forEach((comMarker) => {
            if (comMarker.uniqueId === item.id) {
              isHasSameMarder = true
            }
          })
        }
        if (isHasSameMarder) return
        // 代表图标地址
        const representIconUrl = require(`../../../assets/imgs/map/icon-represent@${this.$env.dpr}x.png`)
        // 普通标记图标地址
        const _iconUrl = secondCates[item.category_id].icon_url
        // 判断选择的是代表点还是非代表点，选择不同的标记点宽度高度
        const COMMON_WIDTH = this.markerListConfig.is_representative === '200' ? MAP_REPRESENT_MARKER_COMMON_WIDTH : MAP_MARKER_COMMON_WIDTH
        const COMMON_HEIGHT = this.markerListConfig.is_representative === '200' ? MAP_REPRESENT_MARKER_COMMON_HEIGHT : MAP_MARKER_COMMON_HEIGHT
        const ACTIVE_WIDTH = this.markerListConfig.is_representative === '200' ? MAP_REPRESENT_MARKER_ACTIVE_WIDTH : MAP_MARKER_ACTIVE_WIDTH
        const ACTIVE_HEIGHT = this.markerListConfig.is_representative === '200' ? MAP_REPRESENT_MARKER_ACTIVE_HEIGHT : MAP_MARKER_ACTIVE_HEIGHT
        // 根据是否是代表点选用不同图片创建标记
        const marker = this.$fMap.createMarker(this.markerListConfig.is_representative === '200' ? representIconUrl : _iconUrl, {
          w: COMMON_WIDTH,
          h: COMMON_HEIGHT
        })
        marker.id = item.category_id
        marker.uniqueId = item.id
        this.mapInstance.add(marker)
        marker.setPosition([item.lng, item.lat])
        // 绑定地图标记点click
        marker.on('click', mapEventOpts => {
          // update 当前选中地图标记信息
          this.selectedMarkerInfo = item
          // 显示标记信息弹框
          if (!this.popStatus !== 2) {
            this.popStatus = 2
          }
          // 当前选中的地图标记
          const target = mapEventOpts.target
          // 将之前选择的地图标记点大小恢复为为选中时的大小方法
          const inactive = () => {
            const previousMarkerId = this.selectedMarker.id
            const previousIconUrl = this.markerListConfig.is_representative === '200'
              ? representIconUrl : secondCates[previousMarkerId].icon_url
            this.selectedMarker.setIcon(createMarkerIcon(previousIconUrl, {
              w: COMMON_WIDTH,
              h: COMMON_HEIGHT
            }))
          }
          // 恢复上一个处于激活状态地图标记的状态
          if (this.selectedMarker) {
            inactive()
          }
          // 突出显示选中地图标记
          const iconUrl = this.markerListConfig.is_representative === '200' ? representIconUrl : _iconUrl
          target.setTop(true)
          target.setIcon(createMarkerIcon(iconUrl, {
            w: ACTIVE_WIDTH,
            h: ACTIVE_HEIGHT
          }))
          target.inactive = inactive
          this.selectedMarker = target // 添加选中的地图标记点
        }, this)
        // 维护已添加的 markers，以便清除重新添加
        this.addedMarkers.push(marker)
        if (this.markerListConfig.is_representative === '200') {
          this.representMarkers.push(marker)
        } else {
          this.comMarkers.push(marker)
        }
      })
    },
    // 格式化一级、二级分类列表数据
    formatCateData (cateData) {
      // 一级分类数据
      let firstCate = []
      // 二级分类数据
      const secondCate = []
      for (let k in cateData) {
        if (cateData[k].id !== '31') { // 过滤掉通用信息
          firstCate.push(cateData[k])
        }
      }
      const compareFn = (a, b) => (Number.parseInt(a.id) - Number.parseInt(b.id))
      firstCate.sort(compareFn)
      // 挂载一级分类数据列表到 vm
      this.firstCates = firstCate
      // 初始化一级分类 tabs
      this.tabs = firstCate
      firstCate = firstCate.map(item => {
        const sons = item.son
        item.son = []
        for (let k in sons) {
          const son = sons[k]
          item.son.push(son)
          secondCate.push(son)
        }
        // item.son.sort(compareFn) 去掉此行代码，不对二级分类进行按id排序
        return item
      })
      // 挂载二级分类数据列表到 vm
      this.secondCates = secondCate
      // 初始化二级分类 swipers
      const swipers = []
      firstCate.forEach((item, index) => {
        const firstId = index
        const cates = deepClone(item.son)
        let secondId = 0
        while (cates.length >= MAP_CATE_MARKERS_NUMBER_PER_SWIPER) {
          const swiperItem = {
            id: `${firstId}-${secondId}`,
            cateList: cates.splice(0, MAP_CATE_MARKERS_NUMBER_PER_SWIPER)
          }
          swipers.push(swiperItem)
          ++secondId
        }
        swipers.push({ id: `${firstId}-${secondId}`, cateList: cates })
      })
      this.swipers = swipers
    },
    // 定位到当前用户位置，返回用户初始定位位置
    async location () {
      const position = [this.userInitPosition.lng, this.userInitPosition.lat]
      this.$fMap.setZoom(16)
      this.$fMap.mapGeoLocal(position)
      this.userCurrentPosition = this.userInitPosition
      this.markerListConfig = {
        ...this.markerListConfig,
        lng: this.userCurrentPosition.lng,
        lat: this.userCurrentPosition.lat
      }
      this.userCurrentAddress = (await this.$fMap.getAddress(position)).fullAddress
    },
    // 切换显示、隐藏应用集
    toggleAppCollectionShow () {
      this.isAppCollectionShow = !this.isAppCollectionShow
    },
    // 前往个人主页绑定
    goHomePage () {
      window.location = this.selectedMarkerInfo.resource_url
    },
    // 联系平台
    contactPlatform () {
      console.log('contact platform')
    },
    // 加入
    join () {
      // 校验是否已选择了标记分类，已选择前往加入表单提交弹窗，否则弹出 toast 提示
      if (!this.selectedCateId) {
        if (this.validatingCate) return
        this.validatingCate = true
        const vm = this
        return this.$store.commit('ADD_MESSAGE', {
          msg: MAP_PLEASE_SELECT_CATE,
          cb () { vm.validatingCate = false }
        })
      }
      this.popStatus = 3
    },
    // 普通加入表单提交
    async submitJoinForm () {
      // 表单校验
      if (!this.normalForm.name) {
        this.$store.commit('ADD_MESSAGE', { msg: MAP_COMPANY_NAME_NOT_EMPTY })
      }
      if (!this.normalForm.mobile) {
        this.$store.commit('ADD_MESSAGE', { msg: MAP_MOBILE_NOT_EMPTY })
      }
      if (!/^1\d{10}$/.test(this.normalForm.mobile)) {
        this.$store.commit('ADD_MESSAGE', { msg: MAP_MOBILE_NOT_VALID })
      }
      const response = await api.addMarker({
        lng: this.userCurrentPosition.lng,
        lat: this.userCurrentPosition.lat,
        name: this.normalForm.name,
        mobile: this.normalForm.mobile,
        address: this.userCurrentAddress,
        map_marker_category_id: this.selectedCateId
      })
      if (response.code === 200) { // 弹出提交成功弹窗
        this.popStatus = 5
      } else { // 显示提交失败 toast
        this.$store.commit('ADD_MESSAGE', { msg: response.msg })
      }
    },
    // 通用加入表单提交
    async submitCommonForm () {
      // 表单校验
      if (!this.commonForm.name) {
        this.$store.commit('ADD_MESSAGE', { msg: MAP_COMPANY_NAME_NOT_EMPTY })
      }
      if (!this.commonForm.mobile) {
        this.$store.commit('ADD_MESSAGE', { msg: MAP_MOBILE_NOT_EMPTY })
      }
      if (!/^1\d{10}$/.test(this.commonForm.mobile)) {
        this.$store.commit('ADD_MESSAGE', { msg: MAP_MOBILE_NOT_VALID })
      }
      // 返回值处理
      const response = await api.addMarker({
        lng: this.userCurrentPosition.lng,
        lat: this.userCurrentPosition.lat,
        name: this.commonForm.name,
        mobile: this.commonForm.mobile,
        remark: this.commonForm.remark,
        address: this.userCurrentAddress,
        map_marker_category_id: this.markerListConfig.map_marker_category_id
      })
      if (response.code === 200) { // 弹出提交成功弹窗
        this.popStatus = 5
      } else { // 显示提交失败 toast
        this.$store.commit('ADD_MESSAGE', { msg: response.msg })
      }
    },
    // 发现
    discovery () {
      this.recoverRepMarkers = []
      this.recoverComMarkers = []
      // 添加选中分类的标记点
      this.representMarkers.forEach(item => {
        if (item.id === this.selectedCateId) {
          this.recoverRepMarkers.push(item)
        }
      })
      this.comMarkers.forEach(item => {
        if (item.id === this.selectedCateId) {
          this.recoverComMarkers.push(item)
        }
      })
      if (this.markerListConfig.is_representative === '200') {
        // 清空地图上标记点
        if (this.mapInstance && this.representMarkers) {
          this.mapInstance.remove(this.representMarkers)
        }
        this.mapInstance.add(this.recoverRepMarkers)
      } else {
        // 清空地图上标记点
        if (this.mapInstance && this.comMarkers) {
          this.mapInstance.remove(this.comMarkers)
        }
        this.mapInstance.add(this.recoverComMarkers)
      }
      this.markerListConfig.map_marker_category_id = this.selectedCateId
      this.popStatus = 0
    },
    // 去领取斐艺数字货币
    goFineartToken () {
      console.log('go and fetch fineart token.')
    },
    // 前往首页
    goBackHome () {
      window.location = 'index.html'
    },
    closePopUnitInfo () {
      this.popStatus = 0
      this.$nextTick(() => {
        this.selectedMarker.inactive()
      })
    },
    openHomeIntroShowHandle () {
      this.isOpenHomeIntroShow = !this.isOpenHomeIntroShow
    },
    goTORegiOrLogin () {
      window.location = 'member.html#/login'
    },
    close () {
      this.popStatus = 0
      this.markerListConfig.map_marker_category_id = ''
    },
    knownMoreShowHandle () {
      this.isKnownMoreShow = !this.isKnownMoreShow
      this.$nextTick(() => { // 加载完DOM后手动刷新滚动，避免异步加载图片时计算不出滚动高度导致滚动失效
        this.$refs.scroller.refresh()
      })
    },
    zoomOut () {
      this.mapInstance.zoomOut()
    },
    zoomIn () {
      this.mapInstance.zoomIn()
    },
    chooseSecCate (item) {
      this.selectedCateId = item.id
      if (!this.selectedCateId) return false
      const selectedCate = this.secondCates.find(cate => {
        return cate.id === this.selectedCateId
      })
      this.introduction = selectedCate.introduction
    },
    blur () {
      document.body && (document.body.scrollTop = document.body.scrollTop)
    },
    toStoreDetail (storeId) {
      window.location = `/mall.html#/store-detail/${storeId}`
    }
  },
  filters: {
    mobileFormater (mobile) {
      return `${mobile.slice(0, 3)}****${mobile.slice(-4)}`
    }
  }
}
</script>

<style lang="stylus">
  @import "../../../common/styles/1PX.styl"

  .{$cls_prefix}-page-discovery-join
    absolute: left top
    bottom: 0
    width: 100%
    color: $black
    .shadow
      height: 50px
      width: 750px
      opacity: 0.1379
      background: linear-gradient(180deg,rgba(143,143,143,1) 0%,rgba(216,216,216,0) 100%)
    .map-container
      height: 100%
      z-index: 1
      .discovery-btn-location
        absolute: right 10px bottom 202px left 0!important
        width: 100px
        height: 100px
        z-index: 130
        .icon
          inline-icon(100px, 100px)
          bg-img('../../../assets/imgs/map/icon-location')
    .box-pop-container
      absolute: left bottom
      width: 100%
      z-index: 10
      .box
        width: 100%
        background-color: $white
        border-radius: 20px 20px 0 0
        box-shadow: 0 -2px 30px 0 rgba(0, 0, 0, 0.14)
        &.fade-in-enter-active, &.fade-in-leave-active
          transition: all 0.4s ease-in-out
        &.fade-in-enter, &.fade-in-leave-to
          opacity: 0
          transform: translate3d(0, 190px, 0)
      .pop-discovery-join
        position: fixed
        bottom: -420px
        transition: all 0.4s ease-in-out
        box-shadow:0px -2px 30px 0px rgba(0,0,0,0.14);
        &.up
          bottom: 0
        .top
          font-size: 0
          padding: 0 50px 30px 50px
          .address
            padding: 26px 0 22px 0
            font-size: 0
            color: $grey3
            .fy-icon-my-address
              display: inline-block
              vertical-align: middle
              margin-right: 8px
              font-size: 30px
            .txt-address
              display: inline-block
              vertical-align: middle
              font-size: 24px
              width: 520px
              {ellipse}
          .btn-discovery-join-wrap
            display: inline-block
            vertical-align: middle
            width: 540px
            height: 80px
            margin-right: 34px
            .btn-discovery-join
              height: 100%
              line-height: 80px
              text-align: center
              padding: 0
              font-size: 0
              border-radius: 14px
              box-shadow:0px 4px 12px 0px rgba(232,216,181,1)
              .icon-search-wrap
                display: inline-block
                vertical-align: middle
                height: 30px
                width: 30px
                .icon-search
                  inline-icon(30px, 30px)
                  bg-img('../../../assets/imgs/map/icon-search')
              .label
                display: inline-block
                vertical-align: middle
                font-size: 30px
                font-weight: 700
                margin-left: 14px
          .btn-add-wrap
            display: inline-block
            vertical-align: middle
            height: 76px
            width: 76px
            box-shadow:0px 4px 12px 0px rgba(182,188,206,1);
            border-radius:38px;
            background:rgba(103,116,157,1);
            position: relative
            .btn-add
              position: absolute
              left: 36px
              top: 21px
              display: inline-block
              background: $white
              height: 30px
              width: 4px
              border-radius: 3px
              transform: rotate(0deg)
              transition: transform 0.3s ease-in
              &:after
                background: $white
                content: ""
                height: 30px
                left: 0
                position: absolute
                top: 0
                width: 4px
                transform: rotateZ(90deg)
                border-radius: 3px
              &.rotated
                transform: rotate(135deg)
        .bottom
          background-color: $grey5
          .apps-list
            padding: 40px 65px 0 65px
            &.first
              overflow: hidden
              .app-list
                margin-right: -60px
                font-size: 0
                .app-item
                  display: inline-block
                  vertical-align: top
                  margin-right: 60px
                  .icon
                    margin-bottom: 8px
                    inline-icon(110px, 110px)
                    &.icon-group-buy
                      bg-img('../../../assets/imgs/map/icon-group-buy')
                    &.icon-finance
                      bg-img('../../../assets/imgs/map/icon-finance')
                  .name
                    line-height: 30px
                    font-size: 22px
                    color: $black1
          .vux-swiper
            height: 420px!important
      .pop-cate-swiper
        position: relative
        &.fade-in-enter, &.fade-in-leave-to
          opacity: 0
          transform: translate3d(0, 580px, 0)
        .state-bar
          position: relative
          width: 100%
          height: 106px
          .selected-cate-state
            padding: 36px 0 36px 30px
            line-height: 33px
            font-size: 24px
            color: $black1
          .more
            absolute: top 32px right 108px
            padding: 4px
            font-size: 0
            .icon-question-round
              inline-icon(28px, 28px)
              vertical-align: middle
              margin-right: 5px
              bg-img('../../../assets/imgs/map/icon-question-round')
            .txt
              display: inline-block
              vertical-align: middle
              line-height: 33px
              font-size: 24px
              color: $black2
          .btn-close
            absolute: top 32px right 32px
            padding: 8px
            font-size: 0
            .fy-icon-off
              font-size: 26px
              color: $grey2
        .swiper-wrap
          position: relative
          .swiper-indicators
            absolute: left bottom
            width: 100%
            padding: 10px
            font-size: 0
            .indicator
              display: inline-block
              vertical-align: top
              width: 12px
              height: 12px
              margin-right: 14px
              border-radius: 50%
              background-color: $grey7
              &.active
                background-color: $orange
        .cate-swiper
          background-color: $grey5
          .vux-swiper
            .vux-swiper-item
              overflow: hidden
              padding: 20px 30px 0 30px
              .cate-list
                display: flex
                flex-wrap: wrap
                margin-right: -30px
                .cate-item
                  flex: 0 0 90px
                  width: 90px
                  margin: 0 30px 10px 0
                  padding-top: 10px
                  text-align: center
                  font-size: 24px
                  border: 2px solid transparent
                  border-radius: 2px
                  &.active
                    border-color: $orange
                  .name
                    width: 100%
                    line-height: 25px
                    margin: 2px 0 8px 0
                    font-size: 18px
                    color: $black1
                    {ellipse}
        .first-cate-tabs
          font-size: 0
          .vux-tab-container, .vux-tab
            height: 94px
          .vux-tab-item
            flex: 0 0 100px
            height: 104px
            padding-top: 14px
            &.active
              background-color: $grey5
        .btn
          absolute: right 180px bottom 14px
          width: 140px
          height: 60px
          line-height: 60px
          text-align: center
          font-size: 26px
          border-radius: 8px
          &.btn-join
            color: $grey2
            border: 1.4px solid $grey9
          &.btn-join-active
            color: $orange
            border: 1.4px solid $orange
          &.btn-discovery
            right: 30px
            font-size: 26px
            color: $grey2
            background-color: $grey10
          &.btn-discovery-active
            background-color: $orange
            color: $white
      .pop-unit-info
        position: relative
        padding: 0 40px 40px 40px
        &.fade-in-enter, &.fade-in-leave-to
          opacity: 0
          transform: translate3d(0, 370px, 0)
        .btn-close
          absolute: top 24px right 24px
          padding: 8px
          font-size: 0
          .fy-icon-off
            font-size: 24px
            color: $grey2
        .avatar-wrap
          absolute: left 27px top -48px
          width: 156px
          height: 156px
          padding: 6px 13px 20px 13px
          .avatar
            border-radius: 12px
            box-shadow: 0 4px 20px 0 rgba(40, 40, 40, 0.5)
        .title
          margin-bottom: 13px
          padding: 30px 0 36px 146px
          font-size: 0
          .name
            display: inline-block
            vertical-align: middle
            line-height: 42px
            margin-right: 10px
            font-size: 30px
            font-weight: 500
            color: $black
          .store-link
            display: inline-block
            vertical-align: top
            padding: 4px
            .icon-store
              inline-icon(42px, 36px)
              bg-img('../../../assets/imgs/map/icon-card-store')
        .tags
          margin-bottom: 34px
          font-size: 0
          .tag
            display: inline-block
            height: 100%
            line-height: 30px
            padding: 0 8px
            font-size: 20px
            color: $grey3
            border-radius: 4px
            background-color: $grey5
        .address
          margin-bottom: 39px
          font-size: 0
          .fy-icon-location
            display: inline-block
            vertical-align: top
            margin-top: 6px
            margin-right: 14px
            font-size: 26px
          .full-address
            display: inline-block
            vertical-align: top
            width: 620px
            line-height: 38px
            font-size: 24px
            color: $grey3
        .mobile
          font-size: 0
          margin-top:-10px
          .fy-icon-iphone
            display: inline-block
            vertical-align: bottom
            margin-right: 8px
            font-size: 26px
          .mobile
            display: inline-block
            vertical-align: middle
            font-size: 24px
            color: $grey3
        .btns
          absolute: right 40px bottom 28px
          width: 100%
          height: 60px
          font-size: 0
          .btn
            float: right
            display: inline-block
            vertical-align: top
            height: 100%
            line-height: 60px
            text-align: center
            font-size: 24px
            border-radius: 12px
          .btn-person-home-page
            position: relative
            width: 164px
            margin-right: 10px
            font-size: 0
            color: $orange
            border: 1.4px solid $orange
            .icon-home-page
              inline-icon(28px, 28px)
              vertical-align: middle
              margin-right: 10px
              bg-img('../../../assets/imgs/map/icon-home-page')
            .label
              display: inline-block
              vertical-align: middle
              font-size: 24px
          .btn-contact-platform
            width: 164px
            color: $white
            background-color: $orange
      .input-wrap
        width: 100%
        margin-bottom: 20px
        input
          width: 100%
          height: 80px
          text-align: center
          font-size: 28px
          color: $black1
          border: none
          outline: none
          background-color: $grey5
          border-radius: 10px
          &:focus
            outline: none
      .pop-normal-form
        padding: 44px 30px 30px 30px
        .title
          position: relative
          padding-left: 70px
          margin-bottom: 50px
          .btn-return
            absolute: left top
            padding: 8px
            font-size: 0
            transform: scaleX(-1)
            .fy-icon-arrow-right
              font-size: 28px
              color: $grey2
          .cate-name
            line-height: 45px
            font-size: 30px
            font-weight: 500
            color: $black1
          .more
            absolute: right 30px top
            width: 168px
            height: 50px
            line-height: 50px
            padding-left: 36px
            font-size: 0
            color: $orange
            border-radius: 25px
            background-color: #FEF5E3
            .icon-know-more
              absolute: left -46px top -18px
              inline-icon(86px, 86px)
              bg-img('../../../assets/imgs/map/icon-know-more')
            .label
              display: inline-block
              vertical-align: middle
              line-height: 33px
              margin-right: 6px
              font-size: 24px
            .fy-icon-arrow-right
              display: inline-block
              vertical-align: middle
              font-size: 17px
      .pop-common-form
        position: relative
        padding: 0 30px 30px 30px
        .address
          padding: 26px 0 22px 0
          font-size: 0
          color: $black2
          .fy-icon-my-address
            display: inline-block
            vertical-align: middle
            margin-right: 8px
            font-size: 30px
          .txt-address
            display: inline-block
            vertical-align: middle
            width: 620px
            font-size: 24px
            {ellipse}
        .btn-close
          absolute: right 22px top 12px
          padding: 18px
          font-size: 0
          .fy-icon-off
            font-size: 26px
            color: $grey2
      .pop-form-result
        position: relative
        padding: 40px 30px 30px 30px
        .btn-close
          absolute: right 22px top 22px
          padding: 18px
          font-size: 0
          .fy-icon-off
            font-size: 26px
            color: $grey2
        .title
          padding: 20px 0
          font-size: 0
          text-align: center
          .icon
            inline-icon(36px, 37px)
            vertical-align: middle
            margin-right: 14px
            bg-img('../../../assets/imgs/map/icon-success')
          .txt
            display: inline-block
            vertical-align: middle
            line-height: 48px
            font-size: 34px
            font-weight: 500
            color: $black1
        .fineart-token-activity
          width: 470px
          margin: 0 auto 37px auto
          line-height: 37px
          text-align: center
          font-size: 26px
          color: $grey3
        .btn-go-fineart-token:after
          border-color: $orange
    .member-center
      .btn-open-member
        absolute: left 27px top 18px
        padding: 12px
        font-size: 0
        z-index: 15
        .icon-member
          inline-icon(54px, 54px)
          bg-img('../../../assets/imgs/map/icon-member')
      .member-mask
        absolute: left top
        width: 100%
        height: 100%
        background-color: rgba(33, 33, 33, 0.6)
        z-index: 16
        &.fade-enter-active, &.fade-leave-active
          transition: opacity .8s ease
        &.fade-enter, &.fade-leave-to
          opacity: 0
      .member-menu-wrap
        absolute: left top
        width: 460px
        height: 100%
        z-index: 17
        &.slide-enter-active
          transition: all 0.8s ease
        &.slide-leave-active
          transition all .6s cubic-bezier(1, .4, .71, 1.52)
        &.slide-enter, &.slide-leave-to
          transform: translate3d(-460px, 0, 0)
        .member-menu
          width: 100%
          height: 100%
          background-color: $white
    .btn-back-home
      absolute: right 27px top 18px
      padding: 12px
      font-size: 0
      z-index: 15
      .icon-back-home
        inline-icon(54px, 54px)
        bg-img('../../../assets/imgs/map/icon-back-home')
      .icon-close-home
        inline-icon(54px, 54px)
        bg-img('../../../assets/imgs/map/icon-close-home')
      .icon-triangle
        absolute: right 22px top 72px
        display: block
        width: 0
        height: 0
        border-width: 0 0 7px 21px
        border-style: solid
        border-color:transparent transparent $purple
      .nav-wrap
        absolute: right 22px top 78px
        width: 200px
        max-height: 0
        background-color: $purple
        border-radius: 12px 0 12px 12px
        transition: all 0.6s cubic-bezier(0, 1, 0, 1) -.1s
        overflow: hidden
        &.expanded
          max-height: 999px
          transition-timing-function: cubic-bezier(.5, 0, 1, 0)
          transition-delay: 0
        .nav-item
          border-bottom: 1.4px solid $violet
          &>a
            display: block
            height: 81px
            padding-left: 46px
            color: $white
            font-size: 26px
            line-height: 81px
          &:last-child
            border: none
    .mask
      absolute: left top
      width: 100%
      height: 100%
      background: transparent
      z-index: 5
    .common-mask
      fixed: left top
      width: 100%
      height: 100%
      background-color: rgba(33, 33, 33, 0.6)
      z-index: 10
      &.fade-enter-active, &.fade-leave-active
        transition: opacity .8s ease
      &.fade-enter, &.fade-leave-to
        opacity: 0
    .intro-container
      width: 650px
      height: 975px
      background: linear-gradient(224deg,rgba(210,232,232,1) 0%,rgba(180,211,231,1) 100%)
      position: absolute
      top: 50%
      left: 50%
      margin-left: -325px
      margin-top: -487.5px
      z-index: 15
      padding-left: 37px
      padding-right: 37px
      &.fade-enter-active, &.fade-leave-active
        transition: opacity .8s ease
      &.fade-enter, &.fade-leave-to
        opacity: 0
      .top-icon
        height: 98px
        position: relative
        .quote-wrap
          height: 34px
          width: 34px
          position: absolute
          top: 33px
          .quote
            inline-icon(34px, 34px)
            bg-img('../../../assets/imgs/map/icon-quote')
        .cancel-wrap
          height: 27px
          width: 27px
          position: absolute
          top: 36px
          right: 0
          .cancel
            inline-icon(27px, 27px)
            bg-img('../../../assets/imgs/map/icon-cancel')
      .intro
        height: 718px
        background: #fff
        opacity: 0.8
        padding: 53px 48px 0 48px
        position: relative
        .how-to-open
          width: 304px
          height: 53px
          font-size: 38px
          font-family: PingFangSC-Semibold
          font-weight: 600
          color: $black1
          line-height: 53px
        .triangle
          width: 0
          height: 0
          border-top: 10px solid rgba(102,102,102,1)
          border-right: 10px solid transparent
        .how-to-open-en
          width: 438px
          height: 36px
          font-size: 20px
          font-family: PingFangSC-Regular
          font-weight: 400
          color: $grey2
          line-height: 28px
          margin-top: 14px
        .brief-intro
          width: 480px
          height: 98px
          font-size: 24px
          font-family: PingFangSC-Regular
          font-weight: 400
          color: $grey3
          line-height: 33px
          margin-top: 30px
        .open-flow
          width: 116px
          height: 39px
          background: $black2
          font-size: 22px
          font-family: PingFangSC-Regular
          font-weight: 400
          color: $white
          line-height: 39px
          margin-top: 93px
          text-align: center
        .flow
          font-size: 24px
          font-family: PingFangSC-Regular
          font-weight: 400;
          color: $black1
          margin-top: 39px
          li
            height: 33px
            line-height: 33px
            margin-bottom: 22px
            .num
              width: 24px
              height: 24px
              border: 1px solid $black1
              border-radius: 12px
              display: inline-block
              line-height: 24px
              text-align: center
              margin-right: 14px
              .icon-one
                margin-top: 3px
                inline-icon(16px, 16px)
                bg-img('../../../assets/imgs/map/icon-one')
              .icon-two
                margin-top: 3px
                inline-icon(16px, 16px)
                bg-img('../../../assets/imgs/map/icon-two')
              .icon-three
                margin-top: 3px
                inline-icon(16px, 16px)
                bg-img('../../../assets/imgs/map/icon-three')
               .icon-four
                margin-top: 3px
                inline-icon(16px, 16px)
                bg-img('../../../assets/imgs/map/icon-four')
        .fineart-wrap
          height: 315px
          width: 24px
          position: absolute
          bottom: 72px
          right: 48px
          .fineart
            inline-icon(24px, 315px)
            bg-img('../../../assets/imgs/map/icon-fineart')
      .button
        height:84px;
        background:rgba(247,181,44,1)
        box-shadow:0px 8px 14px 0px rgba(88,149,176,0.25)
        font-size: 30px
        line-height: 84px
        text-align: center
        color: $white
        font-weight:500
        font-family:PingFangSC-Medium
    .known-more-container
      width: 650px
      height: 975px
      background: linear-gradient(224deg,rgba(210,232,232,1) 0%,rgba(180,211,231,1) 100%)
      position: absolute
      top: 50%
      left: 50%
      margin-left: -325px
      margin-top: -487.5px
      z-index: 15
      padding-left: 37px
      padding-right: 37px
      &.fade-enter-active, &.fade-leave-active
        transition: opacity .8s ease
      &.fade-enter, &.fade-leave-to
        opacity: 0
      .top-icon
        height: 98px
        position: relative
        .quote-wrap
          height: 34px
          width: 34px
          position: absolute
          top: 33px
          .quote
            inline-icon(34px, 34px)
            bg-img('../../../assets/imgs/map/icon-quote')
        .cancel-wrap
          height: 27px
          width: 27px
          position: absolute
          top: 36px
          right: 0
          .cancel
            inline-icon(27px, 27px)
            bg-img('../../../assets/imgs/map/icon-cancel')
      .intro
        height: 800px
        background: #fff
        opacity: 0.8
        font-size: 24px
        font-family: PingFangSC-Regular
        font-weight: 400
        line-height: 33px
        color: $grey3
        overflow: hidden
        img
          display: block
          max-width: 100%
          margin: 0 auto
          & + br
            display: none
        p
          padding: 0 30px
        .bscroll-vertical-scrollbar
          opacity: 1!important
    .test-buttons
      position: absolute
      bottom: 340px
      right: 30px
      font-size: 24px
      z-index: 130
      .zoom-out , .zoom-in
        display: inline-block
        width: 80px
        height: 50px
        border: 1.4px solid $grey3
        text-align: center
        line-height: 50px
</style>
