/**
 * @comment:
 * @author: alan_wang
 * @date: 01/11/2018
 * @time: 20:29:02
 */

import Vue from 'vue'
import VueRouter from 'vue-router'

import DiscoveryJoin from 'modules/map/pages/DiscoveryJoin.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'DiscoveryJoin',
    component: DiscoveryJoin
  },
  {
    path: '/common-join',
    name: 'CommonJoin',
    component: DiscoveryJoin
  }
]

export default new VueRouter({ routes })
