/*
* @Author: Alan
* @Date:   2018-09-07 10:53:06
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-07 10:59:22
*/
import Vue from 'vue'
import VueRouter from 'vue-router'

import BuildingHome from 'modules/building/pages/BuildingHome.vue'
import BuildingDetail from 'modules/building/pages/BuildingDetail.vue'
import BuildingAddCase from 'modules/building/pages/BuildingAddCase.vue'
import BuildingMap from 'modules/building/pages/BuildingMap.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'BuildingHome',
    component: BuildingHome,
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/building-map/:lng/:lat/:id',
    name: 'BuildingMap',
    component: BuildingMap,
    props: true
  },
  {
    path: '/building-detail/:id',
    name: 'BuildingDetail',
    component: BuildingDetail,
    props: true
  },
  {
    path: '/building-add-case/:buildingId/:buildingCode',
    name: 'BuildingAddCase',
    component: BuildingAddCase,
    meta: {
      requiresAuth: true
    },
    props: true
  }
]

export default new VueRouter({ routes })
