import {BaseApi} from '@/common/js/BaseApi'
import buildingHomeApi from './buildingHomeApi.js'

class BuildingApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    BuildingApi.updateToken(BuildingApi.readTokenFromLocalStorage())
    buildingHomeApi(BuildingApi)
  }
}

const _instance = new BuildingApi()

export default _instance
