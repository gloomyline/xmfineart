<template>
  <div :class="classes">
    <div class="building-img">
      <swiper class="building-swiper"
              dots-position="center"
              :auto="true"
              :loop="true"
              :interval="5000"
              :duration="500"
              :aspect-ratio="420/750">
        <swiper-item
          class="building-swiper-item"
          v-for="(item, index) in buildingDetail.images" :key="index">
          <img :src="item.url" width="100%" height="100%">
        </swiper-item>
      </swiper>
    </div>
    <div class="building-info">
      <div class="name-collection-cell">
        <div class="building-name">{{ buildingDetail.name}}</div>
        <div class="building-collection" @click="changeIsCollect()">
          <span class="btn-icon" :class="buildingDetail.my_collect_status?'fy-icon-sel-follow':'fy-icon-nor-follow'"></span>
          <span class="btn-text" v-if="!buildingDetail.my_collect_status">关注建筑</span>
          <span class="btn-text origin" v-else>已关注</span>
        </div>
      </div>
      <p class="attr-item category">
        <label class="attr-label">类型</label>
        <span class="attr-value"><span v-for="(item, index) in buildingDetail.category" :key="index">{{ item }}</span></span>
      </p>
      <p class="attr-item developer">
        <label class="attr-label">开发商</label>
        <span class="attr-value">{{ buildingDetail.developer }}</span>
      </p>
      <p class="attr-item design">
        <label class="attr-label">建筑设计</label>
        <span class="attr-value">{{ buildingDetail.design }}</span>
      </p>
      <p class="attr-item address" @click="goToMapPage(buildingDetail.lng, buildingDetail.lat, buildingDetail.id)">
        <label class="attr-label">地址</label>
        <span class="attr-value"><span v-for="(item, index) in buildingDetail.region" :key="index">{{ item }}</span>{{ buildingDetail.address }}</span>
        <span class="btn-icon fy-icon-arrow-right"></span>
      </p>
    </div>
    <div class="fy-divider"></div>
    <div class="building-intro">
      <p class="title">简介</p>
      <p class="introduction" v-html="buildingDetail.introduction"></p>
      <p class="btn-cell">
        <x-button class="fy-btn"
                  type="default"
                  mini plain
                  @click.native="joinRecord()"><span class="btn-icon fy-icon-fill"></span>我有参与</x-button>
      </p>
    </div>
    <div class="fy-divider"></div>
    <div class="building-member-record">
      <tab class="fy-tab"
           :line-width="1"
           :value="0"
           custom-bar-width="0">
        <tab-item class="tab-item">参与记录</tab-item>
      </tab>
      <ul class="record-list" v-if="buildingDetail.case&&buildingDetail.case.length">
        <li class="record-item-card fy-1px-b" v-for="(item, index) in buildingDetail.case" :key="index" :id="`anchor${item.resource_id}`">
          <a class="resource-info" :href="routes(item)">
            <img class="resource-logo" :src="item.resource_logo" width="100%" height="100%"/>
            <div class="name-subtitle-wrap">
              <a class="resource-name">{{ item.resource_name}}</a>
              <p class="resource-subtitle">{{ item.resource_subtitle }}</p>
            </div>
          </a>
          <div class="service-type-time">
            <span class="service-type"><i class="fy-icon-type"></i>{{ item.service_type }}</span>
            <span class="service-time" v-if="item.start_at && item.end_at"><i class="fy-icon-time"></i>{{item.start_at}}至{{item.end_at}}</span>
          </div>
          <div class="service-content" v-show="!item.showDetail">
            <!-- 缩略 -->
            <div class="content-wrap">
              <p class="content-text" v-if="item.content_text">{{ item.content_text }}</p>
              <div class="content-img">
                <div class="img-wrap" v-for="(val, i) in item.content_image" :key="i">
                  <img :src="val" width="100%" height="100%">
                </div>
              </div>
              <x-button
                class="show-more" plain mini
                @click.native="showMore(index)"
                v-if="item.textMore || item.content_image.length">展开更多<i class="fy-icon-open"></i></x-button>
            </div>
          </div>
          <!-- 查看详情 -->
          <div class="service-content" v-show="item.showDetail">
            <div class="content-html" v-html="item.content"></div>
            <x-button class="hide-more"
                      plain  mini
                      @click.native="hideMore(index)">收起<i class="fy-icon-open"></i></x-button>
          </div>
        </li>
      </ul>
      <!-- 为空时显示提示 -->
      <fine-art-empty v-if="buildingDetail.case&&!buildingDetail.case.length"></fine-art-empty>
    </div>
    <!-- 实名认证提示弹窗 -->
    <div v-transfer-dom>
      <confirm v-model="authTipModal"
               title="温馨提示"
               confirm-text="现在去认证"
               cancel-text="下次再说"
               @on-confirm="goToAuth">
        <p>目前仅接受已开通主页的用户参与。</p>
        <p>您需要先<em>实名认证</em>，然后开通<em>主页</em>，再前来参与</p>
      </confirm>
    </div>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, COLLECT_MESSAGE_DURATION } from '@/assets/data/constants'
import { FineArtEmpty, FineArtLoginTip } from '@/components'
import { hyphenCase } from '@/common/js/utils'
import * as MSG from 'assets/data/message.js'
import api from 'modules/building/api'
import { mapState } from 'vuex'
import Vue from 'vue'

export default {
  name: `${COMPONENT_PREFIX}BuildingDetail`,
  data () {
    return {
      buildingDetail: {},
      authTipModal: false,
      loginTipModal: false,
      // 用户审核通过主页
      openResourceHome: false,
      apiProcessing: false // API请求处理中
    }
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '建筑详情')
    this.initBuilding()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-building-detail`
    },
    ...mapState(['isLogin'])
  },
  methods: {
    // 前往实名认证页面
    goToAuth () {
      window.location = 'member.html#/auth'
    },
    // 我有参与
    joinRecord () {
      if (this.isLogin) {
        // 用户主页判断
        this.checkHome()
      } else {
        this.loginTipModal = true
      }
    },
    // 检测是否开通主页
    async checkHome () {
      let accountResourceList = await api.fetchAccountResourceList()
      for (let item in accountResourceList) {
        if (accountResourceList[item].status === '300') {
          this.openResourceHome = true
          break
        }
      }
      if (this.openResourceHome) {
        this.$router.push(`/building-add-case/${this.buildingDetail.id}/${this.buildingDetail.code}`)
      } else {
        this.authTipModal = true
      }
    },
    _updateShare () {
      const vm = this
      this.oldShare = this.$wx.shareData
      this.$wx.updateShareData('building', {
        title: vm.buildingDetail.name,
        desc: vm.buildingDetail.introduction
      })
    },
    // 获取建筑详情数据
    async initBuilding () {
      this.buildingDetail = await api.fetchBuildingDetail(this.id)
      this._updateShare()
      this.buildingDetail.design = this.buildingDetail.design ? this.buildingDetail.design : '-'
      this.buildingDetail.developer = this.buildingDetail.developer ? this.buildingDetail.developer : '-'
      if (this.buildingDetail.case.length > 0) {
        for (let item in this.buildingDetail.case) {
          this.buildingDetail.case[item].content_image.splice(3)
          if (this.buildingDetail.case[item].content_text.length >= 45) {
            this.buildingDetail.case[item].content_text = this.buildingDetail.case[item].content_text.substr(0, 45) + '...'
            this.buildingDetail.case[item].textMore = true
          }
          Vue.set(this.buildingDetail.case[item], 'showDetail', false)
        }
      }
      if (!this.$route.hash.substring(1)) return
      let anchorId = '#anchor' + this.$route.hash.substring(1)
      this.$nextTick(() => {
        this.goAnchor(anchorId)
      })
    },
    // 锚点定位
    goAnchor (selector) {
      let anchor = this.$el.querySelector(selector)
      document.documentElement.scrollTop = anchor.offsetTop - 20 // 补偿头部遮挡部分
    },
    // 关注或取消关注
    async changeIsCollect () {
      // 判断是否登录
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      if (this.apiProcessing) {
        return false
      }
      this.apiProcessing = true
      this.result = await api.buildingCollect(this.id)
      if (this.result.code === 200) {
        this.buildingDetail.my_collect_status = !this.buildingDetail.my_collect_status
        // 提示关注成功或取消关注成功
        if (this.buildingDetail.my_collect_status) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    },
    // 点击显示更多
    showMore (index) {
      this.buildingDetail.case[index].showDetail = true
    },
    // 收起
    hideMore (index) {
      this.buildingDetail.case[index].showDetail = false
      let anchorId = '#anchor' + this.buildingDetail.case[index].resource_id
      this.goAnchor(anchorId)
    },
    // 资源主页路径
    routes (item) {
      let path = ''
      switch (item.resource_mode) {
      case '100':
        path = 'person'
        break
      case '200':
        path = 'company'
        break
      case '300':
        path = 'supplier'
        break
      case '400':
        path = 'brand'
        break
      case '500':
        path = 'decorator'
        break
      }
      return `/resource.html#/${path}-home/${item.resource_id}`
    },
    // 前往地图页面，显示当前建筑所在位置
    goToMapPage (lng, lat, id) {
      this.$router.push(`/building-map/${lng}/${lat}/${id}`)
    }
  },
  components: {
    FineArtEmpty,
    FineArtLoginTip
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-building-detail
  .building-swiper-item
    background: $grey5
  .fy-divider
    width: 100%
    height: 20px
    background-color: $grey5
  .building-img
    width: 100%
    height: 420px
    .vux-indicator
      .vux-icon-dot
        width: 12px
        height: 12px
        border-radius: 50%
        opacity: 0.6
        &.active
          opacity: 1
  .building-info
    width: 100%
    .name-collection-cell
      display: flex
      padding: 30px
      height: 125px
      align-items: center
      justify-content: space-between
      .building-name
        height: 50px
        width: 590px
        color: $black1
        font-size: 30px
        line-height: 50px
        border-right: 2px dashed $grey6
        {ellipse}
      .building-collection
        width: 153px
        height: 80px
        display: flex
        align-items: center
        flex-direction: column
        .btn-icon
          font-size: 33px
        .btn-text
          color: $grey3
          font-size: 24px
          margin-top: 13px
          &.origin
            color: $orange
    .attr-item
      display: flex
      padding: 0 30px
      margin-bottom: 23px
      align-items: baseline
      .attr-label
        height: 37px
        line-height: 37px
        font-size: 26px
        color: $black1
        margin-right: 28px
        text-align-justify(104px)
      .attr-value
        font-size: 24px
        color: $black2
        max-width: 500px
        line-height: 33px
      .fy-icon-arrow-right
        right: 0
        width: 37px
        height: 37px
        line-height: 37px
        color: $grey6
        font-size: 22px
        position: absolute
        padding-right: 30px
        display: inline-block
      &:last-child
        margin-bottom: 35px
  .building-intro
    padding: 30px
    .title
      color: $black1
      font-size: 28px
      font-weight: 500
      height: 40px
      line-height: 40px
      margin-bottom: 20px
    .introduction
      color: $black2
      font-size: 26px
      line-height: 45px
      margin-bottom: 30px
    .btn-cell
      .fy-btn
        margin: 0
        padding: 0
        width: 198px
        height: 66px
        color: $black2
        border-color: $grey
        .btn-icon
          font-size: 28px
          margin-right: 10px
          vertical-align: middle
  .building-member-record
    .fy-tab
      margin: 0 30px
      border-bottom: 2px solid $grey
      .tab-item
        flex: none
        width: auto
        padding: 0 20px
        background: none
        position: relative
        font-size: 30px
        &:after
          content: ''
          width: 100%
          height: 4px
          absolute: bottom left
          background: $orange
    .record-list
      padding: 0 30px
      .record-item-card
        padding: 30px 0
        &:last-child::after
          display: none
        .resource-info
          height: 80px
          display: flex
          .resource-logo
            height: 80px
            width: 80px
            border-radius: 50%
            margin-right: 20px
            box-shadow: 3px 3px 6px rgba(0,0,0,0.15)
          .name-subtitle-wrap
            height: 80px
            display: flex
            padding: 5px 0
            flex-direction: column
            justify-content: space-between
            .resource-name
              font-size: 28px
              color: $orange
            .resource-subtitle
              max-width: 580px
              color: $grey3
              font-size: 24px
              {ellipse}
        .service-type-time
          color: $black2
          display: flex
          font-size: 26px
          margin: 20px 0 20px 100px
          justify-content: space-between
          i
            padding-right: 15px
        .service-content
          margin-left: 100px
          .content-text
            color: $grey3
            font-size: 24px
            margin-bottom: 10px
            line-height: 42px
          .content-img
            display: flex
            .img-wrap
              width: 139px
              height: 130px
              margin-right: 21px
              background-color: $grey5
          .content-html
            width: 100%
            color: $grey3
            font-size: 26px
            line-height: 42px
            overflow: hidden
            img
              width: 100%
          .show-more, .hide-more
            padding: 0
            border: none
            color: $grey2
            font-size: 24px
            margin-top: 10px
            font-weight: 500
            .fy-icon-open
              margin-left: 15px
            .fy-icon-open:before
              color: $grey2
              font-weight: 500
          .show-more .fy-icon-open:before
            display: inline-block
            transform: rotate(180deg)
</style>
