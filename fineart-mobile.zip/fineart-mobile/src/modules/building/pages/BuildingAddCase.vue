<template>
  <div :class="classes">
    <group class="add-case-wrap" label-align="left">
      <popup-picker
        title="选择主页"
        placeholder="请选择主页"
        v-model="recordModel.resource_id_array"
        :columns="2"
        show-name
        :data="homeList"
        ref="resoursePicker"
        @on-change="onResourceChange"
        is-link></popup-picker>
      <x-input
        title="服务类型"
        placeholder='如"建筑设计"'
        placeholder-align="right"
        v-model="recordModel.service_type"
        text-align="right"
        :show-clear="false" ></x-input>
      <!-- 服务起始时间-->
      <datetime
        v-model="recordModel.start_at"
        format="YYYY-MM"
        placeholder="请选择"
        title="服务起始时间"></datetime>
      <!-- 服务结束时间 -->
      <datetime
        v-model="recordModel.end_at"
        format="YYYY-MM"
        placeholder="请选择"
        title="服务结束时间"></datetime>
      <!-- 服务详情 -->
      <h3 class="label-span">服务详情</h3>
      <x-textarea :rows="6" v-model="recordModel.content"></x-textarea>
      <x-button class="save-btn" type="primary" @click.native="handleSubmit()">保存并返回</x-button>
      <x-button class="cancel-btn" type="default" plain @click.native="goBack()">取消</x-button>
    </group>
    <!--当前主页已参与过提示弹窗-->
    <div v-transfer-dom>
      <confirm v-model="homeTipModal"
               title="温馨提示"
               confirm-text="我知道了"
               :show-cancel-button="false"
               @on-confirm="homeTipModal = false">
        <p>您账号当前主页在该建筑已经参与过了，不能重复参与。</p>
        <p>如需要编辑某个案例，可前往<em>主页</em>，点击<em>编辑</em>按钮。</p>
      </confirm>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import { Datetime } from 'vux'
import resourceApi from 'modules/resources/api'
import buildingApi from 'modules/building/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}PageBuildingAddCase`,
  data () {
    return {
      homeList: [],
      recordModel: {
        resource_id_array: [],
        resource_id: '', // 主页资源ID
        service_type: '', // <string>必须，服务类型
        content: '', // <string>必须，服务内容
        building_code: '', // 建筑code
        start_at: '', // <string>开始时间
        end_at: ''// <string>结束时间
      },
      recordModelRule: {
        resource_id: [{ required: true, message: '请选择主页' }],
        service_type: [{ required: true, message: '请输入服务类型' }],
        start_at: [{ required: true, message: '请选择起始时间' }],
        end_at: [{ required: true, message: '请选择结束时间' }],
        content: [{ required: true, message: '请输入服务详情' }]
      },
      homeTipModal: false
    }
  },
  props: {
    buildingCode: {
      type: String,
      required: true
    },
    buildingId: {
      type: String,
      required: true
    }
  },
  created () {
    this.$wx.updateShareData('building', {})
    this.$store.commit('MODIFY_PAGE_NAME', '添加建筑')
    this.recordModel.building_code = this.buildingCode
    this.initHomeList()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-building-add-case`
    }
  },
  methods: {
    async initHomeList () {
      let list = []
      let resourceList = await resourceApi.fetchServiceHomeList()
      for (let index in resourceList) {
        if (resourceList[index].status === '300') {
          let item = {name: '', value: ''}
          item.name = resourceList[index].mode_name + '：' + resourceList[index].name
          item.value = resourceList[index].id
          list.push(item)
        }
      }
      this.homeList = list
    },
    async handleSubmit () {
      const rules = await validate(this.recordModel, this.recordModelRule)
      if (!rules) return
      // 添加结束时间不能大于当前时间
      const endDate = new Date(Date.parse(this.recordModel.end_at.replace(/-/g, '/')))
      const curDate = new Date()
      if (endDate > curDate) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.GLOBAL_ENDDAY_BIGGER_THAN_NOWDAY, type: 'warn' })
        return
      }
      // 检测会员是否已经添加过相应的资源案例
      let result = await buildingApi.fetchBuildingResourceCaseCount({
        resource_id: this.recordModel.resource_id,
        building_code: this.recordModel.building_code
      })
      if (Number.parseInt(result.count) !== 0) {
        this.homeTipModal = true
        return false
      }

      // 生成资源案例
      this.result = await resourceApi.insertResourceCase(this.recordModel)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['BUILDING_ADD_CASE_SUCCESS'], type: 'success' })
        this.$router.push(`/building-detail/${this.buildingId}`)
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'warn' })
      }
    },
    goBack () {
      this.$router.push(`/building-detail/${this.buildingId}`)
    },
    onResourceChange () {
      this.recordModel.resource_id = this.recordModel.resource_id_array[0]
    }
  },
  components: {
    Datetime
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-building-add-case
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      padding: 0
      height: 98px
      &.vux-x-textarea
        padding: 20px
        height: 263px
        border: 1PX solid $grey
        .weui-textarea
          padding: 0
    .label-span
      color: $black1
      font-size: 30px
      height: 98px
      line-height: 98px
    .cancel-btn
      color: $grey3
      font-weight: 300
      margin-top: 30px
      border-color: $grey
    .save-btn
      margin-top: 30px
</style>
