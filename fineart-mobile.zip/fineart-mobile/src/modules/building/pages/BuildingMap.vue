<template>
  <div :class="classes">
    <div id="buliding-map" class="map-container">
      <div class="btn-location" @click="location"><span class="icon"></span></div>
      <div class="point-center"><span class="icon"></span></div>
    </div>
    <transition name="slide-up">
      <div class="pop-info-card" v-show="isPopShow">
        <div class="thumbnail-wrap">
          <div class="thumbnail"><img :src="selectedMarkerInfo.thumbnail" width="100%" height="100%"></div>
        </div>
        <div class="descriptions" @click="goToDetail(selectedMarkerInfo.id)">
          <h3 class="name">{{ selectedMarkerInfo.name }}</h3>
          <p class="tags"><span class="tag" v-for="tag in Object.values(selectedMarkerInfo.category)" :key="tag">{{ tag }}</span></p>
          <p class="address"><span class="icon fy-icon-location"></span> {{ selectedMarkerInfo.area_desc }}</p>
        </div>
        <div class="btn-close" @click="closePop"><span class="icon fy-icon-off"></span></div>
        <div class="icon-link-wrap"><span class="icon-link fy-icon-arrow-right"></span></div>
      </div>
    </transition>
  </div>
</template>

<script>
import {
  COMPONENT_PREFIX,
  MAP_BUILDING_MARKER_COMMON_WIDTH,
  MAP_BUILDING_MARKER_COMMON_HEIGHT,
  MAP_BUILDING_MARKER_ACTIVE_WIDTH,
  MAP_BUILDING_MARKER_ACTIVE_HEIGHT
} from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils'

import api from 'modules/building/api'

export default {
  name: `${COMPONENT_PREFIX}PageBuildingMap`,
  data () {
    return {
      map: null, // 地图实例
      buildings: [], // 建筑列表
      markers: [], // 添加的markers
      markerSet: {}, // 添加的 marker 集合：building 建筑
      selectedMarker: {}, // 当前选中的地图标记
      selectedMarkerInfo: {
        thumbnail: '',
        name: '',
        category: {},
        address: '建筑详细地址'
      }, // 当前选中的标记信息
      isPopShow: false, // 是否显示信息卡片弹窗
      pageConfig: {
        // 建筑列表当前所加载分页
        page: 1,
        lng: null,
        lat: null,
        // 关键词
        keyword: '',
        category_id: '',
        foreign: 0, // 是否只看国外，0：否；1：是
        area_id: '',
        sort: 'distance_asc'
      },
      // 上一次地图中心点所在经纬度
      historyLngLat: null
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '建筑地图')
    this._initMap()

    // 更新微信分享内容
    this.$wx.updateShareData('building', {})
  },
  beforeDestroy () {
    this.$fMap.destory()
  },
  props: ['lng', 'lat', 'id'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-building-map`
    }
  },
  methods: {
    async _initMap () {
      try {
        this.map = await this._initMapInstance()
        this.bindEvents(this.map)
        const response = await api.fetchBuildingList(this.pageConfig)
        this.buildings = response.data
        this.addMarkers()
        this.$fMap.setZoom(16)
        this._initPopInfo()
      } catch (e) {
        window.location.reload()
      }
    },
    async _initMapInstance () {
      try {
        const map = await this.$fMap.createMap('buliding-map')
        // 设置地图主题样式 - 远山黛
        map.setMapStyle('amap://styles/whitesmoke')
        // 初始化地图中心点, 指定店铺位置，否则使用用户当前位置
        if (Number.parseInt(this.id) !== 0) {
          map.setCenter([this.lng, this.lat])
          this.pageConfig.lng = this.lng
          this.pageConfig.lat = this.lat
        } else {
          const position = await this.$fMap.geoLocation()
          this.pageConfig.lng = position.lng
          this.pageConfig.lat = position.lat
          map.setCenter([position.lng, position.lat])
        }
        // 初始化缩放比例尺样式
        this.$nextTick(() => {
          const scaleControl = this.$el.querySelector('.amap-scalecontrol')
          scaleControl.style.left = '15px'
          scaleControl.style.bottom = '15px'
        })
        // 初始化时，储存当前地图中心点地理位置
        this.historyLngLat = [this.pageConfig.lng, this.pageConfig.lat]
        return map
      } catch (e) {
        console.log(e)
        window.location.reload()
      }
    },
    createIcon (isActive = false) {
      const AMap = this.$fMap.Map
      if (isActive) {
        return new AMap.Icon({
          size: new AMap.Size(MAP_BUILDING_MARKER_ACTIVE_WIDTH, MAP_BUILDING_MARKER_ACTIVE_HEIGHT),
          image: require('assets/imgs/building/icon-map-building.png'),
          imageSize: new AMap.Size(MAP_BUILDING_MARKER_ACTIVE_WIDTH, MAP_BUILDING_MARKER_ACTIVE_HEIGHT)
        })
      }
      return new AMap.Icon({
        size: new AMap.Size(MAP_BUILDING_MARKER_COMMON_WIDTH, MAP_BUILDING_MARKER_COMMON_HEIGHT),
        image: require('assets/imgs/building/icon-map-building.png'),
        imageSize: new AMap.Size(MAP_BUILDING_MARKER_COMMON_WIDTH, MAP_BUILDING_MARKER_COMMON_HEIGHT)
      })
    },
    inactive () {
      const AMap = this.$fMap.Map
      this.selectedMarker.setIcon(this.createIcon(), {
        w: MAP_BUILDING_MARKER_COMMON_WIDTH,
        h: MAP_BUILDING_MARKER_COMMON_HEIGHT
      })
      this.selectedMarker.setOffset(new AMap.Pixel(-(MAP_BUILDING_MARKER_COMMON_WIDTH / 2), -MAP_BUILDING_MARKER_COMMON_HEIGHT))
      this.selectedMarker.isActive = false
    },
    active (target) {
      const AMap = this.$fMap.Map
      // 选中状态下的建筑标记图标
      const activeIcon = this.createIcon(true)
      // 恢复上一个处于激活状态地图标记的状态
      if (this.selectedMarker.id) this.inactive()
      // 突出显示选中地图标记
      target.setTop(true)
      target.setIcon(activeIcon, {
        w: MAP_BUILDING_MARKER_ACTIVE_WIDTH,
        h: MAP_BUILDING_MARKER_ACTIVE_HEIGHT
      })
      target.setOffset(new AMap.Pixel(-(MAP_BUILDING_MARKER_ACTIVE_WIDTH / 2), -MAP_BUILDING_MARKER_ACTIVE_HEIGHT))
      target.isActive = true
      this.selectedMarker = target
    },
    bindClickToMarker (marker) {
      marker.on('click', opts => {
        // update 当前选中地图标记信息
        this.selectedMarkerInfo = marker.info
        // update 当前信息卡片弹窗显示状态
        if (marker.id === this.selectedMarker.id && this.selectedMarker.isActive) {
          this.inactive()
          this.isPopShow = !this.isPopShow
        } else {
          this.isPopShow = true
          // 当前选中的地图标记
          const target = opts.target
          this.active(target)
        }
      }, this)
    },
    addMarkers () {
      const AMap = this.$fMap.Map
      // 未选中状态下的建筑标记图标
      const icon = this.createIcon()
      this.buildings.forEach(item => {
        let isHasSameMarder = false
        this.markers.forEach((markers) => {
          if (markers.id === item.id) {
            isHasSameMarder = true
          }
        })
        if (isHasSameMarder) return
        const marker = new AMap.Marker({
          icon: icon,
          offset: new AMap.Pixel(-(MAP_BUILDING_MARKER_COMMON_WIDTH / 2), -MAP_BUILDING_MARKER_COMMON_HEIGHT),
          position: [item.lng, item.lat]
        })
        marker.id = item.id
        marker.info = item
        this.bindClickToMarker(marker)
        this.map.add(marker)
        this.markers.push(marker)
      })
    },
    bindEvents (map) {
      // 获取中心点坐标
      map.on('moveend', async () => {
        const centerPt = map.getCenter()
        this.pageConfig.lng = centerPt.lng
        this.pageConfig.lat = centerPt.lat
        const response = await api.fetchBuildingList(this.pageConfig)
        this.buildings = response.data
        this.addMarkers()
      })

      // 点击地图
      map.on('click', () => {
        if (this.isPopShow) {
          this.isPopShow = false
          this.inactive()
        }
      })
    },
    _initPopInfo () {
      const buildingId = this.id
      this.markers.forEach(marker => {
        if (marker.id === buildingId) {
          this.active(marker)
          this.selectedMarkerInfo = marker.info
          this.isPopShow = true
        }
      })
    },
    location () {
      this.$fMap.setZoom(16)
      this.$fMap.mapGeoLocal()
    },
    closePop () {
      this.inactive()
      this.isPopShow = false
    },
    goToDetail (id) {
      this.$router.push(`/building-detail/${id}`)
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-building-map
  fixed: left top
  bottom: 0
  width: 100%
  color: $black1
  .map-container
    height: 100%
    z-index: 1
    .btn-location
      absolute: right 10px bottom 10px left 0!important
      width: 100px
      height: 100px
      z-index: 130
      .icon
        inline-icon(100px, 100px)
        bg-img('../../../assets/imgs/map/icon-location')
    .point-center
      position: absolute
      left: 50%
      top: 50%
      margin: -58px 0 0 -14px
      pointer-events: none
      z-index: 140
      .icon
        inline-icon(26px, 58px)
        bg-img('../../../assets/imgs/icon-map-select')
  .pop-info-card
    absolute: left bottom
    width: 100%
    padding: 40px
    font-size: 0
    background-color: $white
    border-radius: 12px 12px 0 0
    box-shadow: 0 -2px 30px 0 rgba(0, 0, 0, 0.14)
    z-index: 2
    &.slide-up-enter-active, &.slide-up-leave-active
      transition: all 0.3s ease-in
    &.slide-up-enter, &.slide-up-leave-to
      opacity: 0
      transform: translate3d(0, 280px, 0)
    .thumbnail-wrap
      display: inline-block
      vertical-align: top
      width: 200px
      .thumbnail
        width: 100%
        height: 200x
    .descriptions
      display: inline-block
      vertical-align: top
      width: 450px
      padding-left: 30px
      padding-top: 24px
      .name
        font-size: 30px
        font-weight: 500
        line-height: 42px
        margin-bottom: 20px
      .tags
        height: 32px
        font-size: 22px
        margin-bottom: 20px
        .tag
          display: inline-block
          line-height: 32px
          padding: 0 10px
          font-size: 22px
          color: $orange
          border: 1px solid $orange
          border-radius: 4px
      .address
        width: 100%
        font-size: 20px
        color: $grey3
        {ellipse}
        .fy-icon-location
          display: inline-block
          vertical-align: top
          font-size: 24px
    .btn-close
      absolute: top 22px right 22px
      padding: 8px
      font-size: 0
      .fy-icon-off
        font-size: 32px
        color: $grey2
    .icon-link-wrap
      absolute: top 50% right 22px
      margin-top: -22px
      padding: 8px
      .fy-icon-arrow-right
        font-size: 28px
        color: $grey2
</style>
