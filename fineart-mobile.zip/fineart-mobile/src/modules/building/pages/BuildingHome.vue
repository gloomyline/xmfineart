<template>
  <div :class="classes">
    <!-- 头部搜索框 -->
    <fine-art-search class="building-list-search-bar" @search="search" @filter="expandCateSideBar" ref="refSearch"></fine-art-search>
    <!-- 建筑列表容器 -->
    <fine-art-scroller
      ref="scroller"
      class="building-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="buildings.data"
      :has-data="hasData"
      :has-more="buildings.has_next">
      <div class="building-list-wrap">
        <div class="building-list">
          <div
            :key="index"
            class="building-item fy-1px-b"
            v-for="(building, index) in buildings.data"
            @click="goDetail(building.id)">
            <div class="img-wrap">
              <img :src="building.thumbnail" width="100%" height="100%">
            </div>
            <div class="info">
              <p class="name">{{ building.name }}</p>
              <p class="tag">
                <span>{{ building.category[building.building_category_id] }}</span>
              </p>
              <div class="position">
                <i class="fy-icon-location"></i>
                <div class="attr-value">{{ building.area_desc }}</div>
                <span class="distance" >{{building.distance}}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
    <!-- 右侧边栏 -->
    <fine-art-cate-side-bar ref="sidebar" @on-change="filter" :menu-data="menuData" :sidebar-values = "sidebarValues" v-model="isCateSideBarExpanded"></fine-art-cate-side-bar>
    <!-- 不显示的地图容器 -->
    <div class="map" id="map"></div>
    <!--建筑地图跳转悬浮按钮-->
    <div class="go-to-building-map" v-if="buildings.data && buildings.data.length > 0">
      <router-link to="/building-map/0/0/0"><img src="../../../assets/imgs/building/icon-go-to-map@3x.png" width="64" height="64"></router-link>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, USER_CURRENT_POSITION, POSITION_ACTIVE_TIME } from '@/assets/data/constants'
import { hyphenCase, makeNewLink, resolveUrlQuery } from '@/common/js/utils'
import { getBuildingCategory, getArea } from '@/common/js/loadScript'
import { FineArtCateSideBar, FineArtSearch, FineArtScroller } from 'components'
import api from 'modules/building/api'

export default {
  name: `${COMPONENT_PREFIX}PageBuildingList`,
  data () {
    return {
      // 右边分类菜单栏展开与否，默认不展开
      isCateSideBarExpanded: false,
      // 建筑列表数据
      buildings: [],
      pageConfig: {
        // 建筑列表当前所加载分页
        page: 1,
        // 关键词
        keyword: '',
        category_id: '',
        foreign: 0, // 是否只看国外，0：否；1：是
        area_id: 1, // 1 => 中国所有区域， 值为空表示所有区域，包括国内，国内
        lng: null,
        lat: null,
        sort: 'distance_asc'
      },
      // 当前配置条件下是否还有下一页数据
      has_next: true,
      // 右边分类栏菜单栏列表数据
      menuData: [],
      // 路由中带有的侧边栏搜索值
      sidebarValues: {},
      // 侧边栏返回的values值
      values: {}
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-building-list`
    },
    hasData () {
      return this.buildings.total > 0
    }
  },
  async created () {
    let searchParams = this.$route.query
    // 当路由里带有搜索指，初始化相关页面搜索值
    if (Object.keys(searchParams).length !== 0) {
      if (searchParams.keywords) {
        this.pageConfig.keyword = searchParams.keywords
        delete searchParams['keywords']
      }
      this.pageConfig = {...this.pageConfig, ...resolveUrlQuery(searchParams)}
      this.sidebarValues = searchParams
    }
    this._initCateSideMenus()
    await this._getCurrentPosition()
    this.fetchBuildingList()
    // 初始化分享链接
    const link = makeNewLink(this.pageConfig.keyword, searchParams, this.$route.path, 2)
    this.$wx.updateShareData('building', {
      link
    })
    this.$nextTick(() => {
      this.$refs.refSearch.setSearchValue(this.pageConfig.keyword)
    })
  },
  activated () {
    this.$store.commit('MODIFY_PAGE_NAME', '斐艺建筑')
  },
  methods: {
    // 获取用户当前地理位置
    async _getCurrentPosition () {
      let position = this.$localStorage.get(USER_CURRENT_POSITION)
      if (!position) {
        try {
          await this.$fMap.createMap('map')
          // 用户当前地理位置
          position = await this.$fMap.geoLocation()
          // 存储获取到的用户的地理位置
          this.$localStorage.set(USER_CURRENT_POSITION, position, POSITION_ACTIVE_TIME + Date.now())
          this.pageConfig.lng = position.lng
          this.pageConfig.lat = position.lat
        } catch (e) {
          // console.log(e)
          window.location.reload()
        }
      } else {
        this.pageConfig.lng = position.lng
        this.pageConfig.lat = position.lat
      }
    },
    goDetail (id) {
      this.$router.push({path: `/building-detail/${id}`})
    },
    // 前往地图页面，显示用户所在位置周边建筑
    goToMapPage () {
      this.$router.push(`/building-map/${this.pageConfig.lng}/${this.pageConfig.lat}/0`)
    },
    focus () {
      this.$refs.searchInput.focus()
    },
    // 展开右边菜单栏
    expandCateSideBar () {
      if (this.isCateSideBarExpanded) return
      this.isCateSideBarExpanded = true
      this.$nextTick(() => {
        this.$refs.sidebar.expand()
      })
    },
    // 请求初始化右边栏分类菜单
    async _initCateSideMenus () {
      // TODO: 这里使用 Promise.all method 同时加载分类和区域数据，避免数据阻塞
      Promise.all([getBuildingCategory(), getArea()]).then(values => {
        // 建筑类型
        const cates = {id: 'category_id', title: '建筑类型', type: 0, content: values[0]}
        // 建筑所在区域
        const foreignItem = [{
          label: '只看国外',
          value: 1
        }]
        const areas = {id: 'area_id', title: '地区', type: 1, content: values[1]}
        const otherAreas = {id: 'foreign', title: '其他地区', type: 0, content: foreignItem}
        this.menuData = [cates, areas, otherAreas]
      })
    },
    // 搜索
    async search (keyword) {
      this.pageConfig.page = 1
      this.pageConfig.keyword = keyword
      this.sidebarValues = {}
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('building', {
        link
      })
      // 关键词为空，只看国内区域的建筑数据
      this.pageConfig.area_id = keyword ? '' : 1
      await this.fetchBuildingList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    // 加在更多建筑列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.buildings.has_next) return cb()

      this.pageConfig.page = this.buildings.current_page + 1
      // 建筑列表分页
      let dataList = await api.fetchBuildingList(this.pageConfig)
      for (let index in dataList.data) {
        this.buildings.data.push(dataList.data[index])
      }
      this.buildings.current_page = dataList.current_page
      this.buildings.has_next = dataList.has_next
    },
    // 刷新当前建筑列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.fetchBuildingList()
      cb()
    },
    // 选择完成分类菜单
    async filter (values) {
      // 重置传回至侧边栏的值为空，表示不用初始化
      this.sidebarValues = {}
      // 将values赋值给data里的values，用于用户点击查询时重新拼接url
      this.values = values
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('building', {
        link
      })
      this.pageConfig.sort = values.area_id.length > 0 || values.foreign.length > 0 ? 'default' : 'distance_asc'
      this.pageConfig.area_id = values.area_id.length > 0 ? (values.area_id.length > 2 ? values.area_id[2] : values.area_id[0]) : ''
      this.pageConfig.category_id = values.category_id[0] || ''
      this.pageConfig.foreign = values.foreign[0] || '0'
      this.pageConfig.page = 1

      await this.fetchBuildingList()
      // update scroll
      this.$nextTick(() => { this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce') })
    },
    async fetchBuildingList () {
      this.buildings = await api.fetchBuildingList({...this.pageConfig, page: 1})
    }
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-building-list
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  .building-list-scroller
    .building-list-wrap
      .building-list
        .building-item
          padding: 30px 0 33px 0
          margin: 0 30px 0 30px
          display: flex
          flex-direction: row
          justify-content: left
          position: relative
          .img-wrap
            width: 200px
            height: 200px
            background: $grey5
            img
              min-height: 200px
              min-width: 200px
          .info
            position: relative
            margin-left: 30px
            flex-grow: 2
            .name
              width: 450px
              color: $black1
              margin: 22px 0
              font-size: 30px
              line-height: 42px
              background: transparent
              {ellipse}
            .tag
              font-size: 0
              margin-bottom: 22px
              span
                display: inline-block
                padding: 4px 8px
                font-size: 24px
                color: $grey3
                border: 1.4px solid $grey2
            .position
              color: $grey3
              font-size: 24px
              line-height:33px
              display: flex
              align-items: center
              .fy-icon-location
                margin-right: 7px
                vertical-align: baseline
              .attr-value
                display: inline-block
                width: 350px
                {ellipse}
              .distance
                position: absolute
                right: 0
                color: $grey2
  .go-to-building-map
    width: 130px
    height: 130px
    fixed: right 22px bottom 22px
    &>a
      display: block
</style>
