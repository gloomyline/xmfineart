export default function (cls) {
  /**
   * 获取设计师列表
   *
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param mode {Integer} 资源模型，100=独立设计师（优秀个人），200=独立机构（优秀公司）
   * @param area_id {Integer} 地区ID
   * @param design_price {Integer} 设计费
   */
  cls.prototype.fetchDesignerList = async function ({ page, keyword, mode, area_id, design_price }) {
    const response = await cls.request({
      url: '/resource/designer/search',
      query: {
        page,
        keyword,
        mode,
        area_id,
        design_price
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * 获取图库列表
   *
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param cate_id_a {Integer} 风格分类ID
   * @param cate_id_b {Integer} 空间分类ID
   */
  cls.prototype.fetchPortfolioList = async function ({ page, keyword, cate_id_a, cate_id_b }) {
    const response = await cls.request({
      url: '/resource/designer/portfolio',
      query: {
        page,
        keyword,
        cate_id_a,
        cate_id_b
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * 获取设计师筛选条件
   *
   */
  cls.prototype.fetchDesignerCondition = async function () {
    const response = await cls.request({
      url: '/resource/designer/condition',
      query: {
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * 获取美宅推荐
   */
  cls.prototype.fetchRecommend = async function ({page}) {
    const response = await cls.request({
      url: '/resource/feed/design-list',
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * 获取美宅关注
   */
  cls.prototype.fetchFollow = async function ({page}) {
    const response = await cls.request({
      url: '/resource/member/feed/collect/design-list',
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * 点赞和取消点赞
   *
   * @param object_type {Integer} 资源对象类型 200=作品，300=动态
   * @param object_id {Integer} 资源对象Id
   * @returns {Promise<*|Array>}
   */
  cls.prototype.likeOrNotLike = async function (object_type, object_id) {
    const response = await cls.request({
      url: '/resource/member/like/${object_type}/${object_id}',
      params: {object_type, object_id}
    })
    return response.code
  }
}
