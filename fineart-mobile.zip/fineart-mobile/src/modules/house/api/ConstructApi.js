export default function (cls) {
  /**
   * 美宅施工预约
   * @param name
   * @param mobile
   * @param address
   * @returns {Promise.<*>}
   */
  cls.prototype.houseSubscribe = async function ({ name, mobile, address }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/house/subscribe',
      data: {
        name,
        mobile,
        address
      }
    })

    return response
  }
}
