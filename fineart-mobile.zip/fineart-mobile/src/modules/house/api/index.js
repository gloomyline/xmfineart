import {BaseApi} from '@/common/js/BaseApi'
import HouseDesignApi from './HouseDesignApi.js'
import ConstructApi from './ConstructApi.js'

class HouseApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    HouseApi.updateToken(HouseApi.readTokenFromLocalStorage())
    HouseDesignApi(HouseApi)
    ConstructApi(HouseApi)
  }
}

const _instance = new HouseApi()

export default _instance
