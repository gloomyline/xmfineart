/*
* @Author: Alan
* @Date:   2018-09-07 10:53:06
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-07 10:59:22
*/
import Vue from 'vue'
import VueRouter from 'vue-router'

import HouseDesign from 'modules/house/pages/HouseDesign.vue'
import FindDesigner from 'modules/house/pages/FindDesigner.vue'
import MapStore from 'modules/house/pages/MapStore.vue'
import Construct from 'modules/house/pages/Construct.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: {
      name: 'HouseDesign'
    }
  },
  {
    path: '/design/:pageTab?',
    name: 'HouseDesign',
    component: HouseDesign,
    meta: {
      keepAlive: true
    },
    props: true
  },
  {
    path: '/find-designer',
    name: 'FindDesigner',
    component: FindDesigner
  },
  {
    path: '/map-store',
    name: 'MapStore',
    component: MapStore,
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/construct',
    name: 'Construct',
    component: Construct
  }
]

export default new VueRouter({ routes })
