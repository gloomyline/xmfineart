<template>
  <div :class="classes">
    <!-- 头部搜索框 -->
    <fine-art-search class="map-store-list-search-bar" @search="search" @filter="expandCateSideBar"></fine-art-search>
    <cube-scroll
      ref="scroller"
      @pulling-up="loadMore"
      @pulling-down="refreshList"
      :data="mapStores.data"
      :options="scrollOptions"
      class="map-store-list-scroller" v-if="hasData">
      <div class="dynamic-wrap">
        <div class="map-store-list">
          <a :href="`/resource.html#/production-detail/${item.id}`" class="map-store-item" v-for="(item, index) in mapStores.data" :key="index" v-if="index % 2 === 0">
            <img class="img-wrap" :src="item.thumbnail | imgFilters" @load="onImgLoad">
            <div class="style-name">{{item.title  | labelFormatter(16) }}</div>
            <div class="pfofile-company">
              <div class="last-img-wrap" :style="{'background-image':  'url(' + item.resource.resource_logo + ')'}">
              </div>
              <div class="company">{{item.resource.resource_name}}</div>
            </div>
          </a>
        </div>
        <div class="map-store-list">
          <a :href="`/resource.html#/production-detail/${item.id}`" class="map-store-item" v-for="(item, index) in mapStores.data" :key="index" v-if="index % 2 !== 0">
            <img class="img-wrap" :src="item.thumbnail | imgFilters" @load="onImgLoad">
            <div class="style-name">{{item.title  | labelFormatter(16) }}</div>
            <div class="pfofile-company">
              <div class="last-img-wrap" :style="{'background-image':  'url(' + item.resource.resource_logo + ')'}">
              </div>
              <div class="company">{{item.resource.resource_name}}</div>
            </div>
          </a>
        </div>
      </div>
    </cube-scroll>
    <fine-art-empty v-else></fine-art-empty>
    <!-- 右侧边栏 -->
    <fine-art-cate-side-bar ref="sidebar" @on-change="filter" :menu-data="menuData" :sidebar-values = "sidebarValues" v-model="isCateSideBarExpanded"></fine-art-cate-side-bar>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase, makeNewLink, resolveUrlQuery } from '@/common/js/utils.js'
import { FineArtCateSideBar, FineArtSearch, FineArtScroller, FineArtEmpty } from 'components'
import api from 'modules/house/api'
import { Scroll } from 'cube-ui'
import { getPortfolioCategory } from '@/common/js/loadScript'
export default {
  name: `${COMPONENT_PREFIX}MapStore`,
  data () {
    return {
      // 右边分类菜单栏展开与否，默认不展开
      isCateSideBarExpanded: false,
      imgSrc: require('assets/imgs/home/img-about-us.png'),
      // 图库列表数据
      mapStores: [],
      pageConfig: {
        // 图库列表当前所加载分页
        page: 1,
        // 关键词
        keyword: '',
        cate_id_a: '',
        cate_id_b: ''
      },
      // 当前配置条件下是否还有下一页数据
      has_next: true,
      // 右边分类栏菜单栏列表数据
      menuData: [],
      // 路由中带有的侧边栏搜索值
      sidebarValues: {},
      // 侧边栏返回的values值
      values: {},
      scrollOptions: {
        pullDownRefresh: {
          threshold: 30,
          txt: '加载完成'
        },
        pullUpLoad: {
          threshold: 30,
          txt: {
            more: '加载完成',
            noMore: '-- END --'
          }
        }
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-map-store`
    },
    hasData () {
      return this.mapStores.total > 0
    }
  },
  methods: {
    // 展开右边菜单栏
    expandCateSideBar () {
      if (this.isCateSideBarExpanded) return
      this.isCateSideBarExpanded = true
      this.$nextTick(() => {
        this.$refs.sidebar.expand()
      })
    },
    // 请求初始化右边栏分类菜单
    async _initCateSideMenus () {
      const values = await getPortfolioCategory()
      // 风格类型
      const styles = {id: 'style_id', title: values[0].label, type: 1, content: values[0].children}
      const spaces = {id: 'space_id', title: values[1].label, type: 1, content: values[1].children}
      this.menuData = [styles, spaces]
    },
    // 搜索
    async search (keyword) {
      this.pageConfig.page = 1
      this.pageConfig.keyword = keyword
      this.sidebarValues = {}
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('index', {
        link
      })
      await this.fetchPortfolioList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    onImgLoad () {
      this.$refs.scroller.refresh()
    },
    // 加载更多图库列表数据
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.mapStores.has_next) {
        return this.$refs.scroller.forceUpdate()
      }
      this.pageConfig.page = this.mapStores.current_page + 1
      // 建筑列表分页
      let dataList = await api.fetchPortfolioList(this.pageConfig)
      for (let index in dataList.data) {
        this.mapStores.data.push(dataList.data[index])
      }
      this.mapStores.current_page = dataList.current_page
      this.mapStores.has_next = dataList.has_next
      this.$nextTick(() => {
        this.$refs.scroller.forceUpdate()
      })
    },
    // 刷新当前图库列表数据
    async refreshList () {
      this.pageConfig.page = 1
      this.fetchPortfolioList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    // 选择完成分类菜单
    async filter (values) {
      // 重置传回至侧边栏的值为空，表示不用初始化
      this.sidebarValues = {}
      // 将values赋值给data里的values，用于用户点击查询时重新拼接url
      this.values = values
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('index', {
        link
      })
      this.pageConfig.cate_id_a = values.style_id[0] || ''
      this.pageConfig.cate_id_b = values.space_id[0] || ''
      this.pageConfig.page = 1
      await this.fetchPortfolioList()
      // update scroll
      this.$nextTick(() => { this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce') })
    },
    async fetchPortfolioList () {
      this.mapStores = (await api.fetchPortfolioList({...this.pageConfig, page: 1}))
    }
  },
  async created () {
    let searchParams = this.$route.query
    // 当路由里带有搜索指，初始化相关页面搜索值
    if (Object.keys(searchParams).length !== 0) {
      if (searchParams.keywords) {
        this.pageConfig.keyword = searchParams.keywords
        delete searchParams['keywords']
      }
      this.pageConfig = {...this.pageConfig, ...resolveUrlQuery(searchParams)}
      this.sidebarValues = searchParams
    }
    this.$store.commit('MODIFY_PAGE_NAME', '图库')
    this._initCateSideMenus()
    this.fetchPortfolioList()
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    },
    imgFilters (item) {
      if (item) {
        return item
      } else {
        return 'https://cdn.fa.com/upload/images/2018/12/10/5c0e29f725d10.png'
      }
    }
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller,
    'cube-scroll': Scroll,
    FineArtEmpty
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-map-store
    .map-store-list-scroller
      fixed: left top 184px
      bottom: 0
      width: 100%
      color: $black
      .dynamic-wrap
        display: flex
        justify-content: space-between
        padding-bottom: 40px
      .map-store-list
        padding: 0 30px 0 30px
        overflow:hidden
        .map-store-item
          display: block
          width: 334px
          margin-top: 30px
          .img-wrap
            display: block
            width: 334px
            border-radius: 10px
          .style-name
            height: 33px
            font-size: 24px
            font-family: PingFangSC-Regular
            font-weight: 400
            color: rgba(102,102,102,1)
            line-height: 33px
            margin-top: 20px
          .pfofile-company
            display: flex
            flex-direction: row
            justify-content: flex-start
            align-items: center
            margin-top: 20px
            .last-img-wrap
              inline-icon(30px, 30px)
              height: 30px
              width:  30px
              border-radius: 15px
              overflow: hidden
            .company
              height: 29px
              font-size: 21px
              font-family: PingFangSC-Regular
              font-weight: 400
              color: rgba(153,153,153,1)
              line-height: 29px
              margin-left: 10px
      .cube-pullup-wrapper
        padding-bottom: 184px
        .before-trigger
          font-size: 26px
          color: $grey
      .cube-pulldown-wrapper
        .after-trigger
          .cube-pulldown-loaded
            font-size: 26px
            color: $grey
      .cube-loading-spinners
        width: 48px
        height: 48px
      .cube-scroll-list-wrapper
        background-color: $white
</style>
