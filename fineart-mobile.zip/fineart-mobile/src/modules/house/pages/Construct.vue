<template>
  <div :class="classes">
    <!-- 图片展示区 -->
    <div class="pic1"></div>
    <div class="pic2"></div>
    <div class="pic3"></div>
    <div class="pic4"></div>
    <div class="pic5"></div>
    <div class="pic6"></div>
    <div class="pic7"></div>
    <!-- 表单 -->
    <div class="form">
       <form action="javascript: void(0)">
      <div class="input-wrap">
        <input type="text" placeholder="姓名" v-model="name">
      </div>
      <div class="input-wrap">
        <input type="tel" placeholder="手机号" v-model="mobile">
      </div>
      <div class="input-wrap">
        <input type="text" placeholder="所在城市" v-model="address">
      </div>
       </form>
      <div class="sub-btn" @click="houseSubscribe">在线预约</div>
      <div class="static-text"><div class="icon-tel"></div>贵宾热线 <a href="tel:010-65566870">010-65566870</a> </div>
    </div>
    <div class="footer-text">北京斐艺美宅装饰科技有限公司<br>北京市朝阳区高碑店东区30号楼京润国际中心1201</div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import {
  HOUSE_SUBSCRIBE_NAME_NOT_EMPTY,
  HOUSE_SUBSCRIBE_MOBILE_INVALID,
  HOUSE_SUBSCRIBE_ADDRESS_NOT_EMPTY,
  HOUSE_SUBSCRIBE_SUCCESS,
  HOUSE_SUBSCRIBE_FAILED
} from '@/assets/data/message'
import { hyphenCase } from '@/common/js/utils.js'
import api from 'modules/house/api'

export default {
  name: `${COMPONENT_PREFIX}construct`,
  data () {
    return {
      imgSrc: require('assets/imgs/home/img-about-us.png'),
      name: '',
      mobile: '',
      address: ''
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-construct`
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '美宅施工')
    this.$wx.updateShareData('house', {
      title: '美宅施工',
      desc: '斐艺美宅（Fine Art），顶级高端定制。'
    })
  },
  methods: {
    // 预约表单提交
    async houseSubscribe () {
      // 表单校验
      if (!this.name) {
        this.$store.commit('ADD_MESSAGE', { msg: HOUSE_SUBSCRIBE_NAME_NOT_EMPTY })
        return false
      }
      if (!this.mobile) {
        this.$store.commit('ADD_MESSAGE', { msg: HOUSE_SUBSCRIBE_MOBILE_INVALID })
        return false
      }
      if (!/^1\d{10}$/.test(this.mobile)) {
        this.$store.commit('ADD_MESSAGE', { msg: HOUSE_SUBSCRIBE_MOBILE_INVALID })
        return false
      }
      if (!this.address) {
        this.$store.commit('ADD_MESSAGE', { msg: HOUSE_SUBSCRIBE_ADDRESS_NOT_EMPTY })
        return false
      }
      // 返回值处理
      const response = await api.houseSubscribe({
        name: this.name,
        mobile: this.mobile,
        address: this.address
      })
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: HOUSE_SUBSCRIBE_SUCCESS })
        this.name = ''
        this.mobile = ''
        this.address = ''
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: HOUSE_SUBSCRIBE_FAILED })
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-construct
  .pic1
    inline-icon(750px,899px)
    bg-img('../../../assets/imgs/house/construct-pic1')
    margin-bottom: 79px
  .pic2
    inline-icon(750px,449px)
    bg-img('../../../assets/imgs/house/construct-pic2')
    margin-bottom: 10px
  .pic3
    inline-icon(750px,753px)
    bg-img('../../../assets/imgs/house/construct-pic3')
    margin-bottom: 10px
  .pic4
    inline-icon(750px,1180px)
    bg-img('../../../assets/imgs/house/construct-pic4')
    margin-bottom: 83px
  .pic5
    inline-icon(750px,944px)
    bg-img('../../../assets/imgs/house/construct-pic5')
    margin-bottom: 80px
  .pic6
    inline-icon(750px,1152px)
    bg-img('../../../assets/imgs/house/construct-pic6')
    margin-bottom: 109px
  .pic7
    inline-icon(750px,1320px)
    bg-img('../../../assets/imgs/house/construct-pic7')
    margin-bottom: 69px
  .form
    padding: 78px 108px 20px 108px
    background-color: $grey5
    .input-wrap
      width: 420px
      border-bottom: 1px solid $grey2
      padding: 30px 0 12px 0
      margin-left: 58px
      & input
        background-color: transparent
        width: 420px
        font-size: 28px
        line-height: 48px
        outline: none
        border: none
        caret-color: $orange
      input::-webkit-input-placeholder
        font-size: 28px
        color: $black2
    .sub-btn
      width: 420px
      height: 76px
      box-shadow:0px 4px 14px 0px rgba(247,181,44,0.48)
      border-radius: 4px
      background: $orange
      font-size: 30px
      font-weight: 500
      color: $white
      line-height: 76px
      text-align: center
      margin: 36px 0 34px 58px
    .static-text
      height: 33px
      font-size: 24px
      font-weight: 400
      color: $orange
      line-height: 33px
      margin-left: 114px
      .icon-tel
        inline-icon(22px,22px)
        bg-img('../../../assets/imgs/house/icon-tel')
        vertical-align: -2px
        margin-right: 6px
      a
        height: 33px
        font-size: 24px
        font-weight: 400
        color: $orange
        line-height: 33px
.footer-text
  height: 124px
  font-size: 24px
  color: $grey2
  line-height: 38px
  text-align: center
  background-color: $grey5
  padding: 20px auto 28px
</style>
