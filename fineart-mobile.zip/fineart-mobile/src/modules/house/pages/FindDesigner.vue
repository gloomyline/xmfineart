<template>
  <div :class="classes">
    <!-- 头部搜索框 -->
    <fine-art-search class="building-list-search-bar" @search="search" @filter="expandCateSideBar"></fine-art-search>
    <!--设计师列表-->
    <fine-art-scroller
      ref="scroller"
      class="designer-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="designers.data"
      :has-data="hasData"
      :has-more="designers.has_next">
    <div class="designer-list">
      <div class="designer-item" v-for="(item, index) in designers.data" :key="index" @click="toResDetail(item)">
        <div class="img-ava-wrap">
          <img :src="item.logo" width="100%" height="100%">
        </div>
        <div class="other-info">
          <div class="header">
            <div class="name-adress-des">
              <div class="name-adress">
                <span class="name">{{item.name | labelFormatter(9) }}</span>
                <div class="img-wrap">
                </div>
                <span class="adress">{{ item.region.length > 2 ? `${item.region.substring(0, 2)}` : item.region}}</span>
              </div>
              <div class="describe">
                {{item.subtitle}}
              </div>
            </div>
            <div class="price">{{item.design_price}}</div>
          </div>
          <!--图片区-->
          <div class="find-designer-picture">
            <div class="pic-item" v-for="(pic_item, index) in item.portfolio_images" :key="index" :class="{'mar-left': index % 3 > 0}" v-if="index < 3">
              <img :src="pic_item.portfolio_image_url" width="100%" height="100%">
              <div class="mask" v-if="index === 2">
                <div class="minddle-text">
                  <div class="text">
                    更多作品
                  </div>
                  <div class="arrow"></div>
                </div>
              </div>
            </div>
          </div>
          <!--标签点赞区-->
          <div class="find-designer-tag">
            <div v-if="item.tags.length > 0">
            <div class="tag-item">
              <div class="item" v-for="(tag_item, index) in item.tags" :key="index">{{tag_item.tag}}</div>
            </div>
            </div>
            <div class="tag-item" style="background-color: rgb(255,255,255)" v-else>
            </div>
          </div>
          <div class="praise" :class="{'dColor': item.isPraise}">
            <span class="static-text">获赞</span> <span class="praiseNum">{{item.like_num}}</span>
          </div>
        </div>
      </div>
    </div>
    </fine-art-scroller>
    <!-- 右侧边栏 -->
    <fine-art-cate-side-bar ref="sidebar" @on-change="filter" :menu-data="menuData" :sidebar-values = "sidebarValues" v-model="isCateSideBarExpanded"></fine-art-cate-side-bar>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase, makeNewLink, resolveUrlQuery } from '@/common/js/utils.js'
import { FineArtCateSideBar, FineArtSearch, FineArtScroller } from 'components'
import api from 'modules/house/api'
import { getArea } from '@/common/js/loadScript'
export default {
  name: `${COMPONENT_PREFIX}FindDesigner`,
  data () {
    return {
      imgSrc: require('assets/imgs/home/img-about-us.png'),
      // 右边分类菜单栏展开与否，默认不展开
      isCateSideBarExpanded: false,
      // 设计师列表数据
      designers: [],
      pageConfig: {
        // 设计师列表当前所加载分页
        page: 1,
        // 关键词
        keyword: '',
        mode: '',
        area_id: '',
        design_price: ''
      },
      // 当前配置条件下是否还有下一页数据
      has_next: true,
      // 右边分类栏菜单栏列表数据
      menuData: [],
      // 路由中带有的侧边栏搜索值
      sidebarValues: {},
      // 侧边栏返回的values值
      values: {}
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-find-designer`
    },
    hasData () {
      return this.designers.total > 0
    }
  },
  async created () {
    let searchParams = this.$route.query
    // 当路由里带有搜索指，初始化相关页面搜索值
    if (Object.keys(searchParams).length !== 0) {
      if (searchParams.keywords) {
        this.pageConfig.keyword = searchParams.keywords
        delete searchParams['keywords']
      }
      this.pageConfig = {...this.pageConfig, ...resolveUrlQuery(searchParams)}
      this.sidebarValues = searchParams
    }
    this.$store.commit('MODIFY_PAGE_NAME', '找设计师')
    this._initCateSideMenus()
    this.fetchDesignerList()
  },
  methods: {
    // 展开右边菜单栏
    expandCateSideBar () {
      if (this.isCateSideBarExpanded) return
      this.isCateSideBarExpanded = true
      this.$nextTick(() => {
        this.$refs.sidebar.expand()
      })
    },
    // 请求初始化右边栏分类菜单
    async _initCateSideMenus () {
      // 获取设计师筛选条件
      const condition = await api.fetchDesignerCondition()
      // 获取地区分类
      const area = await getArea()
      // 构建侧边栏数据
      let mode = []
      let designPrice = []
      for (let attr in condition.mode) {
        mode.push({label: condition.mode[attr], value: attr})
      }
      for (let attr in condition.design_price) {
        designPrice.push({label: condition.design_price[attr], value: attr})
      }
      const modes = {id: 'mode_id', title: '设计师类型', type: 0, content: mode}
      const designPrices = {id: 'designprices_id', title: '设计费', type: 0, cssType: 1, content: designPrice}
      const areas = {id: 'area_id', title: '地区', type: 1, content: area}
      this.menuData = [ modes, designPrices, areas ]
    },
    // 搜索
    async search (keyword) {
      this.pageConfig.page = 1
      this.pageConfig.keyword = keyword
      this.sidebarValues = {}
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('index', {
        link
      })
      await this.fetchDesignerList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    // 加在更多设计师列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.designers.has_next) return cb()

      this.pageConfig.page = this.designers.current_page + 1
      // 设计师列表分页
      let dataList = await api.fetchDesignerList(this.pageConfig)
      for (let index in dataList.data) {
        this.designers.data.push(dataList.data[index])
      }
      this.designers.current_page = dataList.current_page
      this.designers.has_next = dataList.has_next
    },
    // 刷新当前设计师列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.fetchDesignerList()
      cb()
    },
    // 选择完成分类菜单
    async filter (values) {
      // 重置传回至侧边栏的值为空，表示不用初始化
      this.sidebarValues = {}
      // 将values赋值给data里的values，用于用户点击查询时重新拼接url
      this.values = values
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('index', {
        link
      })
      this.pageConfig.mode = values.mode_id[0] || ''
      this.pageConfig.design_price = values.designprices_id[0] || ''
      this.pageConfig.area_id = values.area_id.length > 0 ? (values.area_id.length > 2 ? values.area_id[2] : values.area_id[0]) : ''
      this.pageConfig.page = 1

      await this.fetchDesignerList()
      // update scroll
      this.$nextTick(() => { this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce') })
    },
    async fetchDesignerList () {
      this.designers = (await api.fetchDesignerList({...this.pageConfig, page: 1}))
    },
    toResDetail (item) {
      window.location = item.mode === '100' ? `/resource.html#/person-home/${item.id}/production` : `/resource.html#/company-home/${item.id}/production`
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-find-designer
    .designer-list
      .designer-item
        padding: 40px 30px 57px 30px
        border-bottom: solid 1.4px $grey
        display: flex
        flex-direction: row
        justify-content: flex-start
        align-items: start
        position: relative
        .img-ava-wrap
          height: 100px
          width: 100px
          border-radius: 50px
          overflow: hidden
        .other-info
          margin-left: 26px
          flex-grow: 2
          .header
            .name-adress-des
              .name-adress
                display: flex
                flex-direction: row
                justify-content:flex-start
                align-items: center
                .name
                  height: 42px
                  font-size: 30px
                  font-family: PingFangSC-Regular
                  font-weight: 500
                  color: $black1
                  line-height: 42px
                .img-wrap
                  inline-icon(22px,21px)
                  bg-img('../../../assets/imgs/house/icon-grlocation')
                  margin-left: 20px
                .adress
                  height: 30px
                  font-size: 22px
                  font-family: PingFangSC-Regular
                  font-weight: 400
                  color: $black1
                  line-height: 30px
                  margin-left: 10px
              .describe
                height: 33px
                font-size: 24px
                font-family: PingFangSC-Regular
                font-weight: 400
                color: $grey3
                line-height: 33px
                margin-top: 6px
            .price
              height: 30px
              font-size: 24px
              font-family: PingFangSC-Regular
              font-weight: 400;
              color: $grey3
              line-height: 30px
              absolute: right 32px top 44px
          .find-designer-picture
            display: flex
            flex-direction: row
            justify-content: left
            align-items: center
            flex-wrap: wrap
            margin-top: 20px
            .mar-left
              margin-left: 10px
            .pic-item
              width: 178px
              height: 178px
              border-radius: 6px
              overflow: hidden
              position: relative
              .mask
                width: 178px
                height: 178px
                background: rgba(169,169,169,0.86)
                border-radius: 6px
                position: absolute
                top: 0
                left: 0
                padding-top: 73px
                padding-bottom: 73px
                .minddle-text
                  position: absolute
                  width: 100%
                  height: 33px
                  line-height: 33px
                  font-size: 24px
                  font-weight: 600
                  color: $white
                  text-align: center
                  .text
                    display: inline-block
                  .arrow
                    width: 14px
                    height: 14px
                    border-top: 3px solid $white
                    border-right: 3px solid $white
                    transform: rotate(45deg)
                    display: inline-block
                    margin-bottom: 1px
          .find-designer-tag
            margin-left: -10px
            margin-top: 20px
            .tag-item
              display: flex
              flex-direction: row
              justify-content:flex-start
              align-items: center
              flex-wrap: wrap
              .item
                font-size: 20px
                font-weight: 400
                color: $grey3
                background: rgba(241,241,241,1)
                border-radius: 4px
                overflow: hidden
                margin-left: 10px
                margin-bottom: 10px
                text-middle: 5px 14px
          .praise
            height: 30px
            font-size: 22px
            font-weight: 400
            color: $grey2
            line-height: 30px
            text-align: right
            width: 100%
            padding-right: 10px
            .dColor
              color: $orange
</style>
