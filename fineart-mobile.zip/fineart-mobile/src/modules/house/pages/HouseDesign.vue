<template>
  <div :class="classes">
    <!--首部图片-->
    <div class="img-wrap">
      <img src="../../../assets/imgs/house/house-ads-01.png" width="100%" height="100%">
    </div>
    <!--服务-->
    <div class="list">
      <router-link :to="{path: '/find-designer'}">
      <div class="item">
        <div class="img-wrap">
          <img src="../../../assets/imgs/house/icon-designer@2x.png" width="100%" height="100%">
        </div>
        <div class="static-text">找设计师</div>
      </div>
      </router-link>
      <router-link :to="{path: '/map-store'}">
      <div class="item">
        <div class="img-wrap">
          <img src="../../../assets/imgs/house/icon-map-store@2x.png" width="100%" height="100%">
        </div>
        <div class="static-text">图库</div>
      </div>
      </router-link>
      <router-link :to="{path: '/construct'}">
      <div class="item">
        <div class="img-wrap">
          <img src="../../../assets/imgs/house/icon-construct@2x.png" width="100%" height="100%">
        </div>
        <div class="static-text">美宅施工</div>
      </div>
      </router-link>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--推荐和关注tab-->
    <div class="tab">
      <div class="concern" :class="{'font-black': curTab === 'follow'}" @click="changeTab('follow')">关注</div>
      <div class="recommend" :class="{'font-black': curTab === 'recommend'}" @click="changeTab('recommend')">推荐</div>
    </div>
    <!--推荐和关注列表-->
    <div class="rc-list" v-if="listShow.data.length > 0">
      <!--名字，地址等相关信息-->
      <div class="rc-item" v-for="(item, index) in listShow.data" :key="index" >
        <div class="rc-header">
          <div class="photo" @click="goResourceHome(item.resource_id, item.resource_mode)">
            <img :src="item.resource_logo" width="100%" height="100%">
          </div>
          <div class="name-adress-date">
            <div class="name-adress">
              <span class="name">{{item.resource_name}}</span>
              <div class="img-wrap" v-if="item.area"></div>
              <span class="adress">{{item.area}}</span>
            </div>
            <div class="date">
              {{item.publish_date}}
            </div>
          </div>
          <!--<div class="distance">2.5km</div>-->
        </div>
        <!--图片区:区分只有1张图片-->
        <div class="rc-picture" v-if="item.images.length > 1">
          <div class="pic-item" v-for="(pic_item, index) in item.images" :key="index" :class="{'mar-left': index % 3 > 0}">
            <img :src="pic_item" width="100%" height="100%" @click="previewImage(item.images_big, index)">
          </div>
        </div>
        <div class="rc-picture" v-else-if="item.images[0]">
          <div class="pic-one">
            <img :src="item.images[0]" width="100%" height="100%" @click="previewImage(item.images_big, index)">
          </div>
        </div>
        <div class="introduction" v-if="item.introduction">{{item.introduction}}</div>
      <!--标签点赞区-->
        <div class="tag-like">
          <ul class="tag-list">
            <li class="tag" v-for="(tag, indexTag) in item.tags" :key="indexTag">{{tag.name}}</li>
          </ul>
          <div class="give-like" :class="{'is-active': item.like_status}" @click="likeOrNotLike(item)">
            <span class="icon icon-like"></span>
            <span class="number" v-if="item.like_num">{{item.like_num}}</span>
          </div>
        </div>
    </div>
    </div>
    <fine-art-empty v-else></fine-art-empty>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase, goLogin } from '@/common/js/utils.js'
import api from 'modules/house/api'
import { FineArtEmpty, FineArtLoginTip } from 'components'
export default {
  name: `${COMPONENT_PREFIX}HomeDesign`,
  data () {
    return {
      loginTipModal: false,
      imgSrc: require('assets/imgs/home/img-about-us.png'),
      curTab: 1,
      listShow: {data: []},
      recommendList: [], // 推荐列表
      followList: [], // 关注列表
      pageConfig: {
        page: 1
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-home-design`
    },
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  props: ['pageTab'],
  methods: {
    // 预览图片
    previewImage (images, index) {
      this.$wx.previewImage(
        {
          current: images[index], // 当前显示图片的http链接
          urls: images // 需要预览的图片http链接列表
        }
      )
    },
    async fetchList () {
      this.recommendList = await api.fetchRecommend(this.pageConfig)
      if (this.isLogin) {
        this.followList = await api.fetchFollow(this.pageConfig)
      }
      this.listShow = this.curTab === 'follow' ? this.followList : this.recommendList
    },
    changeTab (value) {
      if (value === 'follow' && !this.isLogin) {
        this.loginTipModal = true
        return
      }
      this.curTab = value
      this.$router.push({ path: '/design/' + this.curTab })
      this.listShow = this.curTab === 'follow' ? this.followList : this.recommendList
    },
    async likeOrNotLike (item) {
      if (!this.isLogin) {
        this.loginTipModal = true
        return true
      }
      const result = await api.likeOrNotLike('300', item.id)
      // 点赞或者取消点赞成功
      if (result === 200) {
        if (item.like_status) {
          item.like_num = parseInt(item.like_num) - 1
        } else {
          item.like_num = parseInt(item.like_num) + 1
        }
        item.like_status = !item.like_status
      }
    },
    // 去资源主页（关于我）
    goResourceHome (resourceId, resourceMode) {
      switch (resourceMode) {
      case '100':
        window.location = `/resource.html#/person-home/${resourceId}`
        break
      case '200':
        window.location = `/resource.html#/company-home/${resourceId}`
        break
      }
    },
    // 前往登录页面
    goToLogin () {
      goLogin()
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '美宅设计')
    this.$wx.updateShareData('house', {})
    if (this.pageTab === 'follow') {
      this.curTab = 'follow'
      if (!this.isLogin) {
        this.goToLogin()
      }
    } else {
      this.curTab = 'recommend'
    }
    this.fetchList()
  },
  components: {
    FineArtEmpty,
    FineArtLoginTip
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-home-design
    .img-wrap
      height: 360px
      width: 750px
      img
        max-width: 100%
        min-height: 100%
    .list
      padding: 43px 117px 40px 117px
      display: flex
      flex-direction: row
      justify-content: space-between
      align-items: center
      .item
        .img-wrap
          height: 88px
          width: 88px
        .static-text
          height: 30px
          font-size: 22px
          font-family: PingFangSC-Regular
          font-weight: 400
          color: $black2
          line-height: 30px
          text-align: center
          margin-top: 16px
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .tab
      overflow: hidden
      padding: 30px
      .recommend, .concern
        display: inline-block
        font-size: 28px
        font-family: PingFangSC-Medium
        font-weight: 500
        color: $grey3
        line-height: 40px
        float: right
        width: 98px
        padding-right: 20px
        padding-left: 20px
        text-align: center
      .recommend
        border-right: solid 2px $grey
      .font-black
        color: $black1
    .rc-list
      margin-top: -10px
      .rc-item
        position: relative
        padding:40px 30px 40px 30px
        border-bottom: solid 1.4px $grey
        .rc-header
          display: flex
          flex-direction: row
          justify-content: flex-start
          align-items: center
          position: relative
          .photo
            height: 70px
            width: 70px
            border-radius: 35px
            overflow: hidden
          .name-adress-date
            margin-left: 20px
            .name-adress
              display: flex
              flex-direction: row
              justify-content: flex-sta
              align-items: center
              .name
                height: 40px
                font-size: 28px
                font-weight: 400
                color: $black1
                line-height: 40px
              .img-wrap
                inline-icon(20px,21px)
                bg-img('../../../assets/imgs/house/icon-grlocation')
                margin-left: 20px
                margin-right: 11px
              .adress
                height: 30px
                font-size: 22px
                font-weight: 400
                color: $black1
                line-height: 30px
            .date
              height: 33px
              font-size: 24px
              font-family: PingFangSC-Regular
              font-weight: 400
              color: $grey3
              line-height: 33px
          .distance
            height: 33px
            font-size: 24px
            font-family: PingFangSC-Regular
            font-weight: 400;
            color: $grey2
            line-height: 33px
            absolute: right 0 top 14px
        .rc-picture
          display: flex
          flex-direction: row
          justify-content: left
          align-items: center
          flex-wrap: wrap
          margin-top: 30px
          .mar-left
            margin-left: 10px
          .pic-item
            width: 222px
            height: 222px
            border-radius: 6px
            margin-bottom: 12px
            overflow: hidden
          .pic-one
            width: 690px
            max-height: 1000px
            border-radius: 6px
            margin-bottom: 12px
            overflow: hidden
        .tag-like
          display: flex
          justify-content: space-between
          .tag-list
            display: flex
            .tag
              margin-right: 10px
              font-size: 20px
              color: $grey3
              background-color: $grey5
              border-radius: 6px
              text-middle: 5px 14px
              &.delete
                color: $violet
                font-size: 22px
                background-color: transparent
          .give-like
            display: flex
            height: 40px
            margin-right: 10px
            .number
              color: $grey2
              font-size: 22px
              line-height: 30px
              margin-top: -10px
              &:empty
                display: none
            .icon
              display: inline-block
              width: 40px
              height: 40px
              margin-right: 6px
              &.icon-like
                background: url('../../../assets/imgs/resource/icon-give-like@2x.png') center center no-repeat
                background-size: 40px auto
            &.is-active
              .number
                color: $orange
              .icon-like
                background: url('../../../assets/imgs/resource/icon-give-like-orange@2x.png') center center no-repeat
                background-size: 40px auto
          .praise-grthumbs
            inline-icon(38px,34px)
            bg-img('../../../assets/imgs/house/icon-grthumbs')
            position: absolute
            right: 70px
            bottom: 32px
          .praise-grthumbssel
            inline-icon(38px,34px)
            bg-img('../../../assets/imgs/house/icon-grthumbssel')
            position: absolute
            right: 70px
            bottom: 32px
          .praiseNum
            position: absolute
            right: 52px
            bottom: 46px
            height: 30px
            font-size: 22px
            font-family: PingFangSC-Regular
            font-weight: 400
            color: $grey2
            line-height: 30px
          .dColor
            color: $orange
        .introduction
          font-size: 28px
          font-family: PingFangSC-Regular
          font-weight: 400
          color: $black1
          line-height: 40px
          margin-top: 18px
          margin-bottom: 18px
</style>
