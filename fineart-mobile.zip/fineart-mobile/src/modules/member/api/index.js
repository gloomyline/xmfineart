/**
 * @comment: member api instance
 * @author: alan_wang
 * @date: 11/10/2018
 * @time: 14:01:35
 */
import {BaseApi} from '@/common/js/BaseApi'
import initAuth from './initAuth.js'
import addressApi from './addressApi'
import mapApi from './mapApi'
import orderApi from './orderApi'
import commentApi from './commentApi'
import expressApi from './expressApi'
import resourceApi from './resourceApi'
import ossApi from './ossApi.js'
import collectApi from './collectApi.js'
import grouponApi from './grouponApi.js'

class MemberApi extends BaseApi {
  static token

  // 会员中心模块用户登录凭证
  constructor () {
    super()
    this._init()
  }

  _init () {
    MemberApi.updateToken(MemberApi.readTokenFromLocalStorage())
    initAuth(MemberApi)
    mapApi(MemberApi)
    addressApi(MemberApi)
    orderApi(MemberApi)
    commentApi(MemberApi)
    expressApi(MemberApi)
    resourceApi(MemberApi)
    ossApi(MemberApi)
    collectApi(MemberApi)
    grouponApi(MemberApi)
  }
}

const memberApi = new MemberApi()

export default memberApi
