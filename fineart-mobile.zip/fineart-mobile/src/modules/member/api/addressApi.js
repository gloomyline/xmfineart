export default function (cls) {
  // 地址添加
  cls.prototype.addressAdd = async function ({ name, mobile, sys_area_id, address, zip_code, is_default }) {
    const response = await cls.request({
      method: 'post',
      url: '/account/address/add',
      data: {
        name,
        mobile,
        sys_area_id,
        address,
        zip_code,
        is_default
      }
    })

    return response
  }
  // 地址编辑
  cls.prototype.addressEdit = async function ({ id, name, mobile, sys_area_id, address, zip_code, is_default }) {
    const response = await cls.request({
      method: 'post',
      url: '/account/address/edit',
      data: {
        id,
        name,
        mobile,
        sys_area_id,
        address,
        zip_code,
        is_default
      }
    })

    return response
  }
  // 地址删除
  cls.prototype.addressDel = async function (id) {
    const response = await cls.request({
      url: '/account/address/delete/${id}',
      params: {
        id
      }
    })

    return response
  }
  // 获取地址列表
  cls.prototype.addressFetchList = async function () {
    const response = await cls.request({
      url: '/account/address'
    })

    return response.results
  }
  // 获取默认地址
  cls.prototype.addressFetchDefault = async function () {
    const response = await cls.request({
      url: '/account/address'
    })

    if (response.code === 200) {
      return response.results.find((val) => {
        return val.is_default === true
      })
    }
  }
}
