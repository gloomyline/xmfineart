export default function (cls) {
  // 获取快递详情
  cls.prototype.expressDetail = async function (code, company) {
    const response = await cls.request({
      url: '/mall/express/detail',
      query: {
        code,
        company
      }
    })

    return response.results
  }
}
