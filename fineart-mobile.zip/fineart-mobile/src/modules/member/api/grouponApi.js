export default function (cls) {
  // 我发布的团购
  cls.prototype.fetchGrouponMyList = async function ({ page }) {
    const response = await cls.request({
      url: '/mall/groupon/my-list',
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 我参与的团购
  cls.prototype.fetchGrouponMyApply = async function ({ page }) {
    const response = await cls.request({
      url: '/mall/groupon/my-apply-list',
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 上下架该团购 300 => 上架，400=>下架
  cls.prototype.handleGrouponStatus = async function ({ groupon_id, status }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/groupon/status',
      data: {
        groupon_id,
        status
      }
    })
    return response
  }
  // 团购绑定商品
  cls.prototype.handleGrouponBind = async function ({ groupon_id, mall_goods_id, mall_store_id }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/groupon/bind',
      data: {
        groupon_id,
        mall_goods_id,
        mall_store_id
      }
    })
    return response
  }
  // 获取自有商品
  cls.prototype.fetchMemberGoods = async function ({ page, keyword, goods_id = '' }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/goods/search/member',
      data: {
        page,
        keyword,
        goods_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
}
