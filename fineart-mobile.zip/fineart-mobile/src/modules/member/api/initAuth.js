/**
 * @comment: member login api
 * @author: alan_wang
 * @date: 11/10/2018
 * @time: 14:03:55
 */
export default function (cls) {
  /**
   * 会员注册
   * @param mobile            {String}        注册手机号码
   * @param password          {String}        密码
   * @param password_confirm  {String}        确认密码
   * @param code              {String}        短信验证码
   * @param is_agree          {Boolean|[0|1]} 是否通用用户注册协议，0不同意，1同意，默认同意
   * @returns {Promise<*>}
   */
  cls.prototype.register = ({ mobile, password, code, is_agree = 1 }) => {
    return cls.request({
      method: 'post',
      url: '/account/register',
      data: { mobile, password, code, is_agree }
    })
  }

  /**
   * 会员登录
   * @param mobile             {String}       登录手机号码
   * @param password           {String}       登录密码
   * @returns {Promise<String>}               resolve(登录成功文言)
   */
  cls.prototype.login = async ({ mobile, password }) => {
    const response = await cls.request({
      method: 'post',
      url: '/account/login',
      data: { mobile, password }
    })
    // 登录成功，获取到用户登录凭证 token 之后
    if (response.code === 200) {
      // 存储 token 到 localStorage
      const tokenData = {
        value: response.results.token,
        expired: response.results.expired_timestamp
      }
      cls.saveTokenToLocalStorage(tokenData)
      // 挂载 token 到实例上
      cls.token = response.results.token
      return response
    }
  }

  /**
   * 获取会员账户信息, 需要 token
   * @returns {Promise<*>}      data.code // 200=成功
   */
  cls.prototype.fetchAccountProfile = async () => {
    const response = await cls.request({
      url: '/account/profile'
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 保存会员账户信息, 需要 token
   * @returns {Promise<*>}      data.code // 200=成功
   */
  cls.prototype.updateAccountProfile = async ({avatar, nickname, gender, email}) => {
    const response = await cls.request({
      method: 'post',
      url: '/account/profile/save',
      data: {
        avatar,
        nickname,
        gender,
        email
      }
    })
    return response
  }

  /**
   * 会员实名认证, 需要 token
   * @returns {Promise<*>}      data.code // 200=成功
   */
  cls.prototype.accountProfileAuthRealName = async ({realname, idcard, bankcard, code}) => {
    const response = await cls.request({
      method: 'post',
      url: '/account/profile/auth/realname',
      data: {
        realname,
        idcard,
        bankcard,
        code
      }
    })
    return response
  }

  /**
   * 会员手机号码修改步骤1, 需要 token
   * @returns {Promise<*>}      data.code // 200=成功
   */
  cls.prototype.accountProfileResetMobileStep1 = async (code) => {
    const response = await cls.request({
      method: 'post',
      url: '/account/profile/reset/mobile/step1',
      data: {
        code
      }
    })
    return response
  }

  /**
   * 会员手机号码修改步骤2, 需要 token
   * @returns {Promise<*>}      data.code // 200=成功
   */
  cls.prototype.accountProfileResetMobileStep2 = async ({mobile, code}) => {
    const response = await cls.request({
      method: 'post',
      url: '/account/profile/reset/mobile/step2',
      data: {
        mobile,
        code
      }
    })
    return response
  }

  /**
   * 退出登录
   * @returns {Promise<*>}
   */
  cls.prototype.logout = () => {
    return cls.request({
      url: '/account/logout',
      headers: { 'auth-token': cls.token }
    })
  }

  /**
   * 请求发送短信验证码
   * @param type               {Number}       验证码类型：201-注册，202-重置，203-重置手机1，204-重置手机2，205-实名认证，206-认领地图标记
   * @param mobile             {String}       手机号码
   * @returns                  {Promise<*>}
   */
  cls.prototype.fetchCode = ({ type = 201, mobile }) => {
    return cls.request({
      url: '/account/sms/code/${type}/${mobile}',
      params: { type, mobile }
    })
  }

  /**
   * 忘记密码，重置登录密码
   * @param mobile             {String}       用户账号手机号
   * @param password           {String}       新的登录密码
   * @param password_confirm   {String}       确认新的用户密码
   * @param code               {String}       重置密码短信验证码
   * @returns {Promise<*>}
   */
  cls.prototype.resetPassword = ({ mobile, password, password_confirm, code }) => {
    return cls.request({
      method: 'post',
      url: '/account/reset/pw',
      data: { mobile, password, password_confirm, code }
    })
  }

  /**
   * 获取扫码登录的二维码
   * @returns {Promise<*>}
   */
  cls.prototype.fetchLoginQR = () => {
    return cls.request({
      url: '/account/login/qrcode/create'
    })
  }

  /**
   * 验证扫码登录结果, 需要 token
   * @returns {Promise<*>}      data.code // 200=成功，404=二维码过期，201=会员未执行扫码并确定登录，500=其他错误
   */
  cls.prototype.checkQRLogin = () => {
    return cls.request({
      url: '/account/login/qrcode'
    })
  }
  /**
   * 获取会员基本信息, 需要 token
   * @returns {Promise<*>}      data.code // 200=成功，404=二维码过期，201=会员未执行扫码并确定登录，500=其他错误
   */
  cls.prototype.fetchAccountProfile = () => {
    return cls.request({
      url: '/account/profile'
    })
  }
  /**
   * 会员解除微信绑定
   */
  cls.prototype.memberUnbindWx = () => {
    return cls.request({
      url: '/account/wechat/unbind'
    })
  }
  /**
   * 绑定微信相关信息
   */
  cls.prototype.memberBindWx = ({openid_wx, avatar, nickname, gender}) => {
    return cls.request({
      method: 'post',
      url: '/profile/bind/wx',
      data: {openid_wx, avatar, nickname, gender}
    })
  }
  /* 微信登录 */
  cls.prototype.wxLogin = async ({ code }) => {
    const response = await cls.request({
      method: 'post',
      url: '/account/wechat/login/mob',
      data: { code }
    })
    if (response.code === 200 && response.results.token) {
      // 存储 token 到 localStorage
      const tokenData = {
        value: response.results.token,
        expired: response.results.expired_timestamp
      }
      cls.saveTokenToLocalStorage(tokenData)
      // 挂载 token 到实例上
      cls.token = response.results.token
    }
    return response
  }
  /* 微信绑定 */
  cls.prototype.wxBind = ({ code, type = 'mp' }) => {
    return cls.request({
      method: 'post',
      url: '/account/wechat/bind',
      data: { code, type }
    })
  }
}
