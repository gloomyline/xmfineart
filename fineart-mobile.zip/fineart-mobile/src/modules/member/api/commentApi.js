export default function (cls) {
  // 获取订单评价列表
  cls.prototype.fetchCommentList = async function (page) {
    const response = await cls.request({
      url: '/mall/goods/comment/list',
      query: { page }
    })

    return response.results
  }

  // 获取我当前管理店铺的自有商品的评价列表
  cls.prototype.fetchStoreCommentList = async function (page) {
    const response = await cls.request({
      url: '/mall/goods/comment/self-list',
      query: { page }
    })

    return response.results
  }

  // 商家回复商品评价
  cls.prototype.commentReply = async function ({ id, content }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/goods/comment/reply',
      data: {
        id,
        content
      }
    })

    return response
  }

  // 登录会员评价指定商品
  cls.prototype.insertMemberGoodsComment = async function ({ code, content, score, comment_images }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/goods/comment/add',
      data: {
        code,
        content,
        score,
        'comment_images[]': comment_images
      }
    })

    return response
  }
}
