export default function (cls) {
  /**
   * 获取会员的已开通的资源列表
   *
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.resourceMyList = async function () {
    const response = await cls.request({
      url: '/resource/member/index'
    })

    return response
  }

  /**
   * 我的资源详情
   *
   * @param id {Integer} 资源ID
   * @param mode Integer} 资源模型
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.resourceMyDetail = async function (id, mode) {
    const response = await cls.request({
      url: '/resource/member/detail/${id}/${mode}',
      params: {
        id,
        mode
      }
    })

    return response.results
  }

  /**
   * 个人主页-资源申请
   *
   * @param mode {Integer} 资源类型，mode：优秀个人: 100，优秀公司: 200，优秀供应商: 300，优秀品牌: 400
   * @param logo {String}个人头像
   * @param name {String} 姓名
   * @param gender {String}性别
   * @param subtitle {String} 介绍自己
   * @param introduction {String} 个人简介
   * @param email {String} 邮箱
   * @param mobile {String} 联系电话
   * @param sys_area_id {Integer} 地区ID
   * @param address {String} 详细地址
   * @param resource_category_id {Integer} 资源类型
   * @param lng {Float} 位置经度
   * @param lat {Float} 位置纬度
   * @returns {Promise<*>}
   */
  cls.prototype.insertPersonHomeResource = async function (mode, { logo, name, gender, subtitle, introduction, resource_category_id, email, mobile, sys_area_id, address, lng, lat, design_price = '' }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/apply/${mode}',
      params: {
        mode
      },
      data: {
        logo,
        name,
        gender,
        subtitle,
        introduction,
        resource_category_id,
        email,
        mobile,
        sys_area_id,
        address,
        lng,
        lat,
        design_price
      }
    })

    return response
  }

  /**
   * 新增资源(公司，供应商，品牌)
   *
   * @param mode {Integer} 资源类型，mode：优秀个人: 100，优秀公司: 200，优秀供应商: 300，优秀品牌: 400
   * @param logo {String}企业头像
   * @param name {String} 企业名称
   * @param subtitle {String} 企业副标题
   * @param introduction 简介
   * @param resource_category_id {Integer} 资源类型
   * @param email {String} 邮箱
   * @param mobile {String} 联系电话
   * @param sys_area_id {Integer} 地区ID
   * @param address {String} 详细地址
   * @param lng {Float} 位置经度
   * @param lat {Float} 位置纬度
   * @param contact_name 联系人名称
   * @param license 企业营业执照
   * @returns {Promise<*>}
   */
  cls.prototype.resourceApplyCommon = async function (mode, { logo, name, subtitle, introduction, resource_category_id, email, mobile, sys_area_id, address, lng, lat, contact_name, license, design_price = '' }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/apply/${mode}',
      params: {
        mode
      },
      data: {
        logo,
        name,
        subtitle,
        introduction,
        resource_category_id,
        email,
        mobile,
        sys_area_id,
        address,
        lng,
        lat,
        contact_name,
        license,
        design_price
      }
    })

    return response
  }
}
