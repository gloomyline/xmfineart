export default function (cls) {
  /**
   * 我的订单列表
   *
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param status {Integer} 订单状态
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.orderMyList = async function ({page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/order/buyer',
      query: {
        page,
        keyword,
        status
      }
    })

    return response.results
  }

  /**
   * 我的订单详情
   *
   * @param id {Integer} 订单ID
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.orderMyDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/order/buyer/detail/${id}',
      params: { id }
    })

    return response.results
  }

  /**
   * 买家变更订单状态
   *
   * @param id {Integer} 订单ID
   * @param status {Integer} 订单状态
   * @returns {Promise<*>}
   */
  cls.prototype.orderBuyerUpdateStatus = async function (id, status) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/order/buyer/status',
      data: { id, status }
    })

    return response
  }

  /**
   * 卖家订单列表
   *
   * @param store_id {Integer}
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param status {Integer} 订单状态
   * @returns {Promise<*>}
   */
  cls.prototype.orderSellerList = async function (store_id, {page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/order/seller',
      query: {
        store_id,
        page,
        keyword,
        status
      }
    })

    return response
  }

  /**
   * 卖家订单详情
   *
   * @param id {Integer} 订单ID
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.orderSellerDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/order/seller/detail/${id}',
      params: {
        id
      }
    })

    return response.results
  }

  /**
   * 卖家发货
   *
   * @param id {Integer} 订单ID
   * @param express_code {String} 物流单号
   * @param express_company {String} 物流公司
   * @returns {Promise<*>}
   */
  cls.prototype.orderSellerSendOut = async function ({id, express_code, express_company}) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/order/seller/send-out',
      data: {
        id,
        express_code,
        express_company
      }
    })

    return response
  }

  /**
   * 卖家调整订单金额
   *
   * @param order_id {Integer} 订单ID
   * @param price {Float} 订单金额
   * @returns {Promise<*>}
   */
  cls.prototype.orderSellerPriceAdjust = async function (order_id, price) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/order/seller/adjust',
      data: {
        id: order_id,
        price: price
      }
    })

    return response
  }

  /**
   * 卖家订单列表-代理商品
   *
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param status {Integer} 订单状态
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.orderSellerAgentList = async function ({page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/order/seller/agent',
      query: {
        page,
        keyword,
        status
      }
    })

    return response.results
  }

  /**
   * 卖家订单列表-推广商品
   *
   * @param page {Integer} 分页号
   * @param keyword {String} 搜索关键字
   * @param status {Integer} 订单状态
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.orderSellerPromotionList = async function ({page, keyword, status}) {
    const response = await cls.request({
      url: '/mall/promotion/order',
      query: {
        page,
        keyword,
        status
      }
    })

    return response.results
  }

  /**
   * 售后详情
   *
   * @param id {Integer} 售后申请id
   * @returns {Promise<*>}
   */
  cls.prototype.orderServiceDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/service/buyer/${id}',
      params: {
        id
      }
    })

    return response.results
  }

  /**
   * 申请订单售后
   *
   * @param code {string} 订单号
   * @param apply_operate {string} 申请售后类型
   * @param  apply_reason {string} 问题描述
   * @returns {Promise<*>}
   */
  cls.prototype.orderServiceApply = async function ({code, apply_operate, apply_reason}) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/service/buyer/add',
      data: {
        code,
        apply_operate,
        apply_reason
      }
    })

    return response
  }
}
