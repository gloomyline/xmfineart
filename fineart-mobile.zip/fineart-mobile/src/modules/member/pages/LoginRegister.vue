<template>
  <div :class="classes">
    <img class="bg-img" src="https://cdn.xmfineart.com/upload/default/bg-login-register.jpg" width="100%" height="100%">
    <div class="tabs-login-register">
      <div class="tabs-wrap" :class="{'slide-left': selectedFormType === 1}">
        <span class="tab tab-login" :class="{active: selectedFormType === 0}" @click="selectForm(0)">登录</span>
        <span class="tab tab-register" :class="{active: selectedFormType === 1}" @click="selectForm(1)">注册</span>
      </div>
    </div>
    <div class="form-container">
      <form class="form-login" v-show="selectedFormType === 0">
        <div class="form-item fy-1px-b mobile">
          <input v-model.trim="loginModel.mobile" type="number" placeholder="输入手机号码">
        </div>
        <div class="form-item fy-1px-b password">
          <input v-model.trim="loginModel.password" type="password" placeholder="输入密码">
        </div>
        <div class="form-item reset-password">
          <a class="btn-go-wx-login" @click.prevent="goToWxLogin">微信登录</a>
          <a class="btn-reset-password" @click.prevent="goToResetPassword">重置密码</a>
        </div>
        <div class="form-item next">
          <x-button class="btn-next" @click.native.prevent="login"><span class="fy-icon-next-step"></span></x-button>
        </div>
      </form>
      <form class="form-register" v-show="selectedFormType === 1">
        <div class="form-item fy-1px-b mobile">
          <input v-model.trim="registerModel.mobile" type="number" placeholder="输入手机号码">
        </div>
        <div class="form-item fy-1px-b code">
          <input v-model.trim="registerModel.code" type="number" placeholder="输入短信验证码">
          <span class="btn-fetch-code fy-1px-l" :class="{ counting }" @click="fetchCode">{{ btnLabel }}</span>
        </div>
        <div class="form-item fy-1px-b password">
          <input v-model.trim="registerModel.password" type="password" placeholder="输入密码">
        </div>
        <div class="form-item protocol">
          <div class="vux-check-icon" @click="isAgreeProtocol = !isAgreeProtocol">
            <i class="weui-icon fy-icon-sel-check" v-show="isAgreeProtocol"></i>
            <i class="weui-icon weui_icon_circle weui-icon-circle" v-show="!isAgreeProtocol"></i>
          </div>
          <a class="link-protocol" @click.prevent="goToProtocol">已阅读且同意遵守《斐艺平台用户协议》</a>
        </div>
        <div class="form-item next">
          <x-button class="btn-next" @click.native.prevent="register"><span class="fy-icon-next-step"></span></x-button>
        </div>
        <div class="form-item go-login">
          <x-button plain class="btn-login" @click.native.prevent="selectForm(0)">已有账号&nbsp;&nbsp;去登录</x-button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, TIMER_COUNTER, BACK_URL, WX_PAY_OPENID, WX_CODE } from '@/assets/data/constants'
import { hyphenCase, emptyFunc, getQuery } from '@/common/js/utils'

import api from 'modules/member/api'

import {
  GLOBAL_LOGIN_SUCCESS,
  GLOBAL_REGISTER_SUCCESS,
  GLOBAL_PASSWORD_INVALID_LENGTH,
  GLOBAL_PASSWORD_INVALID_FORMAT,
  GLOBAL_MOBILE_EMPTY,
  GLOBAL_MOBILE_INVALID,
  GLOBAL_CODE_EMPTY,
  GLOBAL_AGREE_PROTOCOL
} from 'assets/data/message'

export default {
  name: `${COMPONENT_PREFIX}PageLoginRegister`,
  data () {
    return {
      // 选中的表单类型, 0 => 登录, 1 => 注册
      selectedFormType: 0,
      // 登录表单
      loginModel: {
        // 登录手机号
        mobile: '',
        // 登录密码
        password: ''
      },
      registerModel: {
        // 注册手机号
        mobile: '',
        // 短信验证码
        code: '',
        // 注册密码
        password: ''
      },
      // 计数器当前值
      seconds: 0,
      // 是否同意注册协议，默认同意
      isAgreeProtocol: true
    }
  },
  created () {
    this._handleCode()
  },
  beforeDestroy () {
    if (this.timer) {
      this.stopCount(this.timer)
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-login-register`
    },
    counting () {
      return this.seconds > 0
    },
    btnLabel () {
      return this.counting ? `${this.seconds}s` : '获取'
    }
  },
  methods: {
    // https://m.xmfineart.com/member.html#/login?code=oo6-7swJLVYlPoCjMGJJMutBI2QY
    async _handleCode () {
      try {
        const code = getQuery('code')
        if (!code) return
        // 如果code值相同，不做任何操作。
        if (this.$localStorage.get(WX_CODE) === code) return
        // 存储code
        this.$localStorage.set(WX_CODE, code, 24 * 60 * 60 * 1000 + Date.now())
        const response = await api.wxLogin({code})
        if (response.code === 200) {
          // 缓存用户 openid 于 localStorage 中
          const openId = response.results.openid
          this.$localStorage.set(WX_PAY_OPENID, openId, 24 * 60 * 60 * 1000 + Date.now())
          // 是自动登录，返回信息具有 token
          const that = this
          if (response.results.token && response.results.expired_timestamp) {
            this.$store.commit('ADD_MESSAGE', {
              type: 'success',
              msg: GLOBAL_LOGIN_SUCCESS,
              cb () {
                that.$store.dispatch('fetchAccountProfile')
                // 返回到缓存在 localStorage 中的前一个历史页
                const url = that.$localStorage.get(BACK_URL)
                // 判断前一个历史页是否是login页 是 -- 跳转到首页，否 -- 跳转到前一个历史页
                if (!url || url.search('login') !== -1) {
                  window.location = '/index.html'
                } else {
                  window.location = url
                }
              }
            })
          }
        } else if (response.code === 405) {
          console.log(response.msg)
        }
      } catch (err) {
        this.debugInfo = JSON.stringify(err)
      }
    },
    // 置空表单数据
    changeEmpty (obj) {
      if (Object.keys(obj).length === 0) return
      for (let key in obj) {
        obj[key] = ''
      }
    },
    // 选择指定表单
    selectForm (formType) {
      if (this.timer) {
        this.stopCount(this.timer)
        this.seconds = 0
      }
      // 切换表单类型时置空表单数据
      this.changeEmpty(this.registerModel)
      this.changeEmpty(this.loginModel)
      // 如果重复选中当前的表单，不修改当前选中的表单类型
      if (this.selectedFormType === formType) return
      this.selectedFormType = formType
    },
    goToResetPassword () {
      this.$router.push('/reset-password')
    },
    goToProtocol () {
      this.$router.push('/protocol')
    },
    validate (prop, { cb = emptyFunc, validator = emptyFunc }) {
      const props = prop.split('.')
      const model = props[0]
      const property = props[1]
      const _prop = this[model][property]
      const result = validator.call(this, _prop)
      if (!result.isOk) {
        this.$store.commit('ADD_MESSAGE', { msg: result.error, cb })
        return false
      }
      return true
    },
    validateMobile (model) {
      return this.validate(`${model}.mobile`, {
        validator (mobile) {
          if (mobile === '') {
            return {isOk: false, error: GLOBAL_MOBILE_EMPTY}
          }
          if (!/^1\d{10}$/.test(mobile)) {
            return {isOk: false, error: GLOBAL_MOBILE_INVALID}
          }
          return {isOk: true}
        }
      })
    },
    validatePassword (model) {
      return this.validate(`${model}.password`, {
        validator (password) {
          if (password === '') {
            return {isOk: false, error: GLOBAL_PASSWORD_INVALID_LENGTH}
          }
          if (password.length < 6 || password.length > 15) {
            return {isOk: false, error: GLOBAL_PASSWORD_INVALID_LENGTH}
          }
          if (!(/^[\w!@#$%^&*.,]+$/.test(password))) {
            return {isOk: false, error: GLOBAL_PASSWORD_INVALID_FORMAT}
          }
          return {isOk: true}
        }
      })
    },
    // 校验登录表单
    validateLogin () {
      const mobileResult = this.validateMobile('loginModel')
      if (!mobileResult) { // 手机号校验未通过
        return mobileResult
      } else { // 手机号校验通过
        return this.validatePassword('loginModel')
      }
    },
    // 点击'登录'事件 handler
    async login () {
      // 登录表单验证
      const result = this.validateLogin()
      // 校验未通过
      if (!result) return
      // 否则发起登录请求
      const response = await api.login(this.loginModel)
      const that = this
      // 处理请求响应结果
      if (response && response.code === 200) {
        this.$store.commit('ADD_MESSAGE', {
          type: 'success',
          msg: GLOBAL_LOGIN_SUCCESS,
          cb () {
            that.$store.dispatch('fetchAccountProfile')
            that.$store.commit('LOGIN')
            // 返回到缓存在 localStorage 中的前一个历史页
            const url = that.$localStorage.get(BACK_URL)

            // 判断前一个历史页是否是login页 是 -- 跳转到首页，否 -- 跳转到前一个历史页
            if ((url && url.search('login') !== -1) || !url) {
              window.location = 'index.html'
            } else {
              window.location = url
            }
          }
        })
      }
    },
    validateRegister () {
      // 注册手机号校验
      const mobileResult = this.validateMobile('registerModel')
      if (!mobileResult) {
        return mobileResult
      }
      // 注册验证码校验
      const codeResult = this.validate('registerModel.code', {
        validator (code) {
          if (code === '') {
            return {isOk: false, error: GLOBAL_CODE_EMPTY}
          }
          return {isOk: true}
        }
      })
      if (!codeResult) {
        return codeResult
      }
      // 注册密码校验
      const passwordResult = this.validatePassword('registerModel')
      if (!passwordResult) {
        return passwordResult
      }
      // 注册协议是否同意校验
      if (!this.isAgreeProtocol) {
        this.$store.commit('ADD_MESSAGE', {
          msg: GLOBAL_AGREE_PROTOCOL
        })
        return false
      }
      return true
    },
    // 点击'注册'事件 handler
    async register () {
      // 注册表单验证
      if (!this.validateRegister()) return
      // 发起注册请求
      const response = await api.register(this.registerModel)
      // 处理请求响应结果
      if (response.code === 200) {
        const _vm = this
        this.$store.commit('ADD_MESSAGE', {
          type: 'success',
          msg: GLOBAL_REGISTER_SUCCESS,
          cb () {
            _vm.selectedFormType = 0
          }
        })
      }
    },
    startCount () {
      // 初始化获取短信验证码计数器
      this.seconds = TIMER_COUNTER
      this.timer = setInterval(() => {
        if (this.seconds <= 0) {
          clearInterval(this.timer)
        }
        --this.seconds
      }, 1000)
    },
    stopCount (timerId) {
      clearInterval(timerId)
    },
    // 点击'获取'事件 handler
    async fetchCode () {
      // 校验注册表单中手机号
      const result = this.validateMobile('registerModel')
      // 未通过的话不进行下列操作
      if (!result) return
      // 如果计数器正在计数，终止接下来的操作
      if (this.seconds > 0) return
      // 请求发送注册短信验证码
      const res = await api.fetchCode({ mobile: this.registerModel.mobile })
      if (res.code === 200) {
        this.startCount()
      }
    },
    // 跳转到微信授权登录
    goToWxLogin () {
      window.location = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxdab546b67f307a20&redirect_uri=https%3A%2F%2Fm.xmfineart.com%2Fmember.html%23%2Flogin&response_type=code&scope=snsapi_userinfo&state=auto_login#wechat_redirect'
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-login-register
  absolute: left top 94px
  width: 100%
  height: 100%
  .bg-img
    absolute: left top
    z-index: -1
  .tabs-login-register
    padding-top: 76px
    margin-bottom: 87px /* 标签与表单之间距离 */
    font-size: 0
    .tabs-wrap
      display: inline-block
      transform: translate3d(332px, 0, 0)
      transition: all .4s ease-in-out
      &.slide-left
        transform: translate3d(176px, 0, 0)
      .tab
        display: inline-block
        vertical-align: top
        width: 86px
        height: 48px
        line-height: 56px
        margin-right: 64px
        font-size: 40px
        font-weight: 600
        color: rgba(255, 255, 255, 0.6)
        &:last-child
          margin-right: 0
        &.active
          position: relative
          color: $white
          &:after
            content: ' '
            absolute: left 20px bottom -22px
            width: 40px
            height: 8px
            background-color: $orange
  .form-container
    padding: 0 113px
    .form-login
      .form-item
        &.reset-password
          margin-top: 0
          margin-bottom: 233px /* 重置密码与下一步按钮之间间距 */
          line-height: 34px
          padding: 20px 0 0 0
          font-size: 24px
          font-weight: 300
          color: $white
          .btn-reset-password
            width: 49%
            display: inline-block
            text-align: right
          .btn-go-wx-login
            width: 49%
            display: inline-block
            text-align: left
    .form-register
      .code
        position: relative
        .btn-fetch-code
          absolute: right top 28px
          width: 108px
          height: 42px
          line-height: 42px
          padding-left: 31px
          font-size: 30px
          color: $white
          &.counting
            color: rgba(255, 255, 255, 0.6)
      .password
        margin-bottom: 88px /* 注册表单密码输入框与用户协议间距 */
      .protocol
        margin: 0 0 30px 0
        padding: 0
        font-size: 0
        .vux-check-icon
          display: inline-block
          vertical-align: top
          width: 46px
          height: 46px
          line-height: 46px
          margin-right: 12px
          .fy-icon-sel-check
            line-height: 46px
            font-size: 38px
            &:before
              padding: 0 0.2em
        .link-protocol
          display: inline-block
          vertical-align: top
          line-height: 46px
          font-size: 24px
          color: $white
    .form-item
      margin-top: 26px
      font-size: 0
      &.next
        margin-top: 0
        padding: 0
        .weui-btn
          display: flex
          align-items: center
          justify-content: center
          height: 88px
          padding: 0
          font-size: 60px
          color: $white
          background-color: $orange
      &.go-login
        padding: 0
        .weui-btn
          border: 0
          color: $orange
          text-decoration: underline
      input
        width: 100%
        height: 40px
        padding: 28px 0
        line-height: 50px
        text-align: center
        font-size: 36px
        color: $white
        border: none
        outline: none
        caret-color: $white
        background-color: transparent
        &:focus
          outline: none
        &::-webkit-input-placeholder
          color: rgba(255, 255, 255, 0.7)
          font-size: 30px
</style>
