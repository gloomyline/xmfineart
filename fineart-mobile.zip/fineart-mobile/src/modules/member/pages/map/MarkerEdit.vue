<template>
  <div :class="classes">
    <div class="edit-item type-name">
      <span class="type">{{ marker.category_name }}</span>
      <span class="name">{{ marker.name }}</span>
    </div>
    <div class="edit-item mobile"><span class="text">{{ marker.mobile }}</span></div>
    <group class="resource"><popup-radio placeholder="请选择绑定资源" :options="resources" v-model="currentResource"></popup-radio></group>
    <group class="store"><popup-radio placeholder="请选择绑定店铺" :options="stores" v-model="currentStore"></popup-radio></group>
    <x-button type="primary" class="btn-confirm" @click.native="confirmHandler">确定</x-button>
  </div>
</template>

<script>
/**
 * comment: 地图标记编辑页
 */

import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import {
  ACCOUNT_MAP_MARKER_BIND_OK,
  ACCOUNT_MAP_RES_OR_STORE_EMPTY
} from 'assets/data/message'

import api from 'modules/member/api'

export default {
  name: `${COMPONENT_PREFIX}PageMarkerEdit`,
  data () {
    return {
      // 我的地图标记列表
      markers: [],
      // 当前正在编辑的地图标记
      marker: {
      },
      // 当前用户所有可以绑定的资源
      resources: [],
      // 当前用户所选的资源 `resource_id`
      currentResource: '',
      // 当前用户可绑定的店铺列表
      stores: [],
      // 当前用户所选的店铺 `store_id`
      currentStore: ''
    }
  },
  props: ['id'],
  created () {
    this.fetchMyMarkers()
    this.fetchResources()
    this.fetchStores()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-marker-edit`
    }
  },
  methods: {
    async fetchMyMarkers () {
      this.markers = (await api.fetchMyMarkerList()).data
      this.marker = this.markers.find(marker => marker.id === this.id)
      this.currentResource = this.marker.resource_id
      this.currentStore = this.marker.store_id
    },
    async fetchResources () {
      const results = await api.fetchResourceListForMarker()
      results.forEach(resource => {
        const item = {}
        item.key = resource.resource_id
        item.value = resource.resource_name
        this.resources.push(item)
      })
    },
    async fetchStores () {
      const results = await api.fetchStores()
      results.forEach(store => {
        const item = {}
        item.key = store.store_id
        item.value = store.store_name
        this.stores.push(item)
      })
    },
    // 确定按钮点击句柄
    async confirmHandler () {
      if (this.currentResource || this.currentStore) {
        const data = {
          marker_id: this.marker.id,
          name: this.marker.name,
          mobile: this.marker.mobile,
          resource_id: this.currentResource || '',
          store_id: this.currentStore || ''
        }
        const response = await api.editMyMarker(data)
        if (response.code === 200) {
          const vm = this
          this.$store.commit('ADD_MESSAGE', {
            type: 'success',
            msg: ACCOUNT_MAP_MARKER_BIND_OK,
            cb () {
              vm.$router.push('/map-manage/edit-marker')
            }
          })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: ACCOUNT_MAP_RES_OR_STORE_EMPTY, type: 'warn' })
          return false
        }
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-marker-edit
  padding: 30px
  font-size: 28px
  color: $black2
  .edit-item
    overflow: hidden
    height: 88px
    line-height: 88px
    padding: 0 38px
    margin-bottom: 30px
    border: 1.4px solid $grey
    border-radius: 4px
  .resource, .store
    .weui-cells
      margin-top: 0
      margin-bottom: 30px
      .weui-cell
        height: 88px
        padding: 0 44px 0 38px
        border: 1.4px solid $grey
        border-radius: 4px
        &:after
          display: none
          border: none
        .weui-cell__ft
          width: 100%
          height: 88px
          text-align: left
          line-height: 88px
          &:after
            transform: rotate(135deg)
  .btn-confirm
    font-family: PingFangSC, Microsoft Yahei
    font-size: 30px
.weui-cell_radio.weui-check__label
  height: 98px
  padding: 0 30px
  font-size: 28px
  border-bottom: 1px solid $grey
</style>
