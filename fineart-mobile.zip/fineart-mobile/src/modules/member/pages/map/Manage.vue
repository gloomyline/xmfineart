<template>
  <div :class="classes">
    <div class="tab-wrap">
      <tab class="tabs-menu" v-model="tabIndex" :line-width="2" custom-bar-width="50px">
        <tab-item>绑定地图标记</tab-item>
        <tab-item>编辑地图标记</tab-item>
      </tab>
    </div>
    <div class="map-manage-container">
      <transition :name="slideAnimation" mode="out-in">
        <router-view></router-view>
      </transition>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'

export default {
  name: `${COMPONENT_PREFIX}PageMapManage`,
  components: {},
  data () {
    return {
      // 0 => 绑定地图，1 => 编辑地图
      tabIndex: 0
    }
  },
  created () {
    this._initManage()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-map-manage`
    },
    slideAnimation () {
      return `slide-${this.tabIndex ? 'left' : 'right'}`
    }
  },
  watch: {
    tabIndex (newIdx) {
      if (!newIdx) { // 绑定地图标记
        this.$router.push('/map-manage/bind-marker')
      } else {
        this.$router.push('/map-manage/edit-marker')
      }
    }
  },
  methods: {
    _initManage () {
      this.$store.commit('MODIFY_PAGE_NAME', '地图管理')
      const routeName = this.$route.name
      if (routeName === 'BindMarker') {
        this.tabIndex = 0
      }
      if (routeName === 'EditMarker') {
        this.tabIndex = 1
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-map-manage
  color: $black1
  .tab-wrap
    background-color: #F2F2F2
    padding-bottom: 28px
    .tabs-menu
      margin: 0
  .map-manage-container
    .slide-left-enter-active,
    .slide-right-enter-active
      transition: all 0.2s ease-in
    .slide-left-enter
      transform: translate3d(-100%, 0, 0)
      opacity: 0.4
    .slide-right-enter
      transform: translate3d(100%, 0, 0)
      opacity: 0.4
</style>
