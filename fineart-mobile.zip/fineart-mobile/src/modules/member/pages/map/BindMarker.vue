<template>
  <div :class="classes">
    <group class="search-form">
      <x-input
        name="mobile"
        class="mobile"
        title="手机号码"
        keyboard="number"
        :show-clear="false"
        placeholder="请输入手机号码"
        v-model="searchForm.mobile"></x-input>
      <div class="fy-1px-b"></div>
      <x-input
        class="code"
        title="短信验证码"
        v-model="searchForm.code"
        :show-clear="false"
        placeholder="请输入短信验证码">
        <x-button
          plain mini
          slot="right"
          type="primary"
          :disabled="counting"
          class="btn-code fy-1px-l"
          @click.native="fetchCode">{{ codeBtnLabel }}</x-button>
      </x-input>
      <div class="fy-1px-b"></div>
      <x-button class="btn-search" type="primary" @click.native="search">搜索信息</x-button>
    </group>
    <div class="search-results" v-if="isSearchResultsShow">
      <h3 class="title">
        <span class="label">搜索结果</span>
        <span class="tip">手机号码匹配且未绑定主页</span>
      </h3>
      <ul class="markers">
        <li class="marker" v-for="marker in markers" :key="marker.id">
          <h4 class="name">{{ marker.name }}</h4>
          <div class="desc-list">
            <div class="desc-item type">
              <span class="label">类&nbsp;&nbsp;&nbsp;型：</span>
              <span class="value">{{ marker.category_name }}</span>
            </div>
            <div class="desc-item mobile">
              <span class="label">手机号：</span>
              <span class="value">{{ marker.mobile }}</span>
            </div>
          </div>
          <group class="bind-operations">
            <span class="label">绑定到：</span>
            <popup-radio
              placeholder="选择主页"
              class="radio-resource"
              :readonly="marker.isBinded"
              v-model="resource[marker.id]"
              :options="resources[marker.id]"></popup-radio>
              <span class="label">绑定到：</span>
              <popup-radio
                placeholder="选择店铺"
                class="radio-resource"
                :readonly="marker.isBinded"
                v-model="store[marker.id]"
                :options="stores[marker.id]"></popup-radio>
            <x-button
              plain
              type="primary"
              class="btn-confirm"
              :disabled="marker.isBinded"
              @click.native="bindResourceToMarker(marker.id)">{{ marker.isBinded ? '已绑定' : '确定' }}</x-button>
          </group>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, TIMER_COUNTER } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import {
  GLOBAL_CODE_EMPTY,
  GLOBAL_MOBILE_EMPTY,
  GLOBAL_MOBILE_INVALID,
  ACCOUNT_MAP_MARKER_BIND_OK,
  ACCOUNT_MAP_RES_OR_STORE_EMPTY
} from '@/assets/data/message'
import api from 'modules/member/api'

export default {
  name: `${COMPONENT_PREFIX}MapBindMarker`,
  components: {
  },
  data () {
    return {
      searchForm: {
        // 注册手机号
        mobile: '',
        // 短信验证码
        code: ''
      },
      // 计数器当前值
      seconds: 0,
      // 搜索到的当前未绑定的地图 marker
      markers: [],
      // 用户所有资源列表
      resources: {},
      // 各 marker 对应的资源
      resource: {},
      // 用户所有店铺列表
      stores: {},
      // 各 marker 对应的店铺
      store: {},
      isSearchResultsShow: false
    }
  },
  created () {
  },
  activated () {
  },
  beforeDestroy () {
    this._reset()
    if (this.timer) {
      this.stopCount(this.timer)
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-map-bind-marker`
    },
    counting () {
      return this.seconds > 0
    },
    codeBtnLabel () {
      return this.counting ? `${this.seconds}s` : '获取验证码'
    },
    scrollHeight () {
      return '-200'
    }
  },
  methods: {
    // 重置搜索结果
    _reset () {
      this.markers = []
      this.resources = []
      this.resource = {}
      this.isSearchResultsShow = false
    },
    // 发送短信倒计时
    startCount () {
      // 初始化获取短信验证码计数器
      this.seconds = TIMER_COUNTER
      this.timer = setInterval(() => {
        if (this.seconds <= 0) {
          clearInterval(this.timer)
        }
        --this.seconds
      }, 1000)
    },
    // 停止短信倒计时
    stopCount (timerId) {
      clearInterval(timerId)
    },
    // 校验表单中手机号
    validateMobile () {
      if (!this.searchForm.mobile) {
        this.$store.commit('ADD_MESSAGE', { msg: GLOBAL_MOBILE_EMPTY })
        return false
      }
      if (!(/^1\d{10}$/.test(this.searchForm.mobile))) {
        this.$store.commit('ADD_MESSaGE', { msg: GLOBAL_MOBILE_INVALID })
        return false
      }
      return true
    },
    // 点击'获取验证码'事件 handler
    async fetchCode () {
      // 手机校验未通过
      if (!this.validateMobile()) return
      // 计数器正在计数中
      if (this.seconds > 0) return
      // 请求发送注册短信验证码
      const res = await api.fetchCode({ type: 206, mobile: this.searchForm.mobile })
      if (res.code === 200) {
        this.startCount()
      }
    },
    // 初始化资源列表
    async _initResource () {
      const results = await api.fetchResourceListForMarker()
      const ret = []
      results.forEach(item => {
        const _item = {}
        _item.key = item.resource_id
        _item.value = item.resource_name
        ret.push(_item)
      })
      if (this.markers.length > 0) {
        this.markers.forEach(item => {
          // initialize all of markers which are corresponding with resources ，make them be reactive
          this.$set(this.resource, item.id, '')
          this.$set(this.resources, item.id, ret)
        })
      }
    },
    // 初始化店铺列表
    async _initStore () {
      const results = await api.fetchStores()
      const ret = []
      results.forEach(item => {
        const _item = {}
        _item.key = item.store_id
        _item.value = item.store_name
        ret.push(_item)
      })
      if (this.markers.length > 0) {
        this.markers.forEach(item => {
          // initialize all of markers which are corresponding with resources ，make them be reactive
          this.$set(this.store, item.id, '')
          this.$set(this.stores, item.id, ret)
        })
      }
    },
    async search () {
      // 手机校验未通过
      if (!this.validateMobile()) return
      // 验证码不可为空
      if (!this.searchForm.code) {
        return this.$store.commit('ADD_MESSAGE', { msg: GLOBAL_CODE_EMPTY })
      }
      const results = await api.fetchMapMarkerList(this.searchForm)
      this.markers = results.data.map(item => {
        item.isBinded = false
        return item
      })
      this.verifiedMobile = this.searchForm.mobile
      this._initResource()
      this._initStore()
      // 显示搜索结果
      this.isSearchResultsShow = true
    },
    // 在 marker 上绑定资源
    async bindResourceToMarker (markerId) {
      const resource_id = this.resource[markerId]
      const store_id = this.store[markerId]
      if (resource_id || store_id) {
        const data = {
          mobile: this.verifiedMobile,
          marker_id: markerId,
          resource_id: resource_id,
          store_id: store_id
        }
        const response = await api.bindResourceAndMarker(data)
        if (response.code === 200) {
          // 禁用资源选择 和 确定按钮
          const marker = this.markers.find(marker => marker.id === markerId)
          marker.isBinded = true
          this.$store.commit('ADD_MESSAGE', { msg: ACCOUNT_MAP_MARKER_BIND_OK, type: 'success' })
        }
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: ACCOUNT_MAP_RES_OR_STORE_EMPTY, type: 'warn' })
        return false
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-map-bind-marker
  .search-form
    margin-bottom: 14px
    .weui-cells
      margin: 0
      padding: 0 30px
    .weui-cell
      padding: 30px 0
      .weui-cell__ft
        .weui-icon-clear
          margin-right: 8px
          display: inline-block
          vertical-align: middle
    .btn-code
      display: inline-block
      vertical-align: middle
      font-size: 28px
      border: none
    .btn-search
      margin-top: 30px
  .search-results
    padding: 0 30px
    .title
      padding: 36px 0 36px 10px
      font-size: 0
      line-height: 40px
      .label
        display: inline-block
        vertical-align: top
        margin-right: 20px
        font-size: 28px
        color: $black1
      .tip
        display: inline-block
        vertical-align: top
        font-size: 24px
        color: $grey2
    .markers
      .marker
        margin-bottom: 30px
        padding: 26px 30px 30px 30px
        border: 1.4px solid $grey
        border-radius: 4px
        &:after
          border-radius: 8px
          pointer-events: none
        .name
          line-height: 40px
          margin-bottom: 27px
          font-size: 28px
          color: $black1
        .desc-list
          padding-bottom: 30px
          border-bottom: 1.4px dashed $grey
          .desc-item
            line-height: 37px
            margin-bottom: 30px
            font-size: 26px
            color: $grey2
            &:last-child
              margin: 0
        .bind-operations
          .label
            display: inline-block
            vertical-align: top
            margin: 26px 0 22px 0
            font-size: 28px
            color: $grey3
          .weui-cells
            margin-top: 0
            .btn-confirm
              border-width: 1.4px
            .weui-cell
              height: 88px
              border: 1.4px solid $grey
              border-radius: 4px
              &:after
                display: none
              .weui-cell__ft
                width: 100%
                height: 88px
                text-align: left
                line-height: 88px
                &:after
                  transform: rotate(135deg)
          .radio-resource
            margin-bottom: 28px
.weui-cell_radio.weui-check__label
  height: 98px
  padding: 0 30px
  font-size: 28px
  border-bottom: 1px solid $grey
</style>
