<template>
  <div :class="classes">
    <!-- map 容器 -->
    <div class="map-container" id="map">
      <div class="btn-location" @click="location"><span class="icon"></span></div>
    </div>
    <div class="marker-relocation">
      <group class="fy-1px-b"><cell title="地区" class="address" :value="userCurrentAddress"></cell></group>
      <group class="fy-1px-b"><x-input title="详细地址" v-model="userInputAddress" class="detail-address" text-align="right" :show-clear="false" placeholder="请填写详细地址"></x-input></group>
      <div class="tip"><span class="label">温馨提示：</span><span class="text">如[详细地址]有误，可手动修改；提供准备的位置，有助于获取更多业务机会。</span></div>
      <x-button type="primary" @click.native="relocation">保存并返回</x-button>
    </div>
  </div>
</template>

<script>
import {
  COMPONENT_PREFIX,
  MAP_TOUCH_MOVE_DISTANCE,
  MAP_POSITION_MARKER_WIDTH,
  MAP_POSITION_MARKER_HEIGHT
} from '@/assets/data/constants'
import { ACCOUNT_MAP_MARKER_RELOCATION_OK } from 'assets/data/message'
import { hyphenCase, deepClone } from '@/common/js/utils'

import api from 'modules/member/api'

export default {
  name: `${COMPONENT_PREFIX}PageMarkerRelocation`,
  data () {
    return {
      mapInstance: null,
      // 地图初始化时用户定位
      userInitPosition: {},
      // 当前用户定位
      userCurrentPosition: {},
      // 当前用户地址(接口返回)
      address: {
        address: '',
        city: '',
        district: '', // 行政区
        fullAddress: '',
        province: ''
      }
    }
  },
  created () {
    this._initMap()
    this.$store.commit('MODIFY_PAGE_NAME', '重新定位')
  },
  props: ['id'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-marker-relocation`
    },
    // 当前用户地址
    userCurrentAddress () {
      const address = this.address
      return `${address.province}${address.city}${address.district}`
    },
    // 用户填写详细地址
    userInputAddress: {
      set (val) {
        this.address.address = val
      },
      get () {
        return this.address.address
      }
    }
  },
  methods: {
    // 绑定地图事件
    _bindEvents (mapInstance) {
      // 绑定地图点击事件
      mapInstance.on('click', async (data) => {
        mapInstance.positionMarker.setTop(true)
        this.userCurrentPosition = data.lnglat
        const position = [data.lnglat.lng, data.lnglat.lat]
        this.$fMap.mapGeoLocal(position)
        // 更新当前用户地址
        this.address = await this.$fMap.getAddress(this.userCurrentPosition)
      })
      // 绑定地图缩放事件, 监听缩放比例的变化,(双指)缩放
      mapInstance.on('zoomchange', async () => {
        // 小于100公里处理
        if (mapInstance.getZoom() > 7 && this.markerListConfig.is_representative) {
          this.markerListConfig.is_representative = false
        }
        // 大于100公里处理
        if (mapInstance.getZoom() <= 7 && !this.markerListConfig.is_representative) {
          this.markerListConfig.is_representative = true
        }
        const position = mapInstance.getCenter()
        this.userCurrentPosition = position
        this.$fMap.mapGeoLocal([position.lng, position.lat])
        this.address = await this.$fMap.getAddress(position)
      })
      // 绑定(单指)触摸移动事件
      mapInstance.on('touchstart', ev => {
        this.sp = ev.pixel
      })
      mapInstance.on('touchend', async ev => {
        this.ep = ev.pixel
        const distance = Math.pow(Math.pow(this.ep.x - this.sp.x, 2) + Math.pow(this.ep.y - this.sp.y, 2), 1 / 2)
        if (distance >= MAP_TOUCH_MOVE_DISTANCE) {
          const position = mapInstance.getCenter()
          this.userCurrentPosition = position
          this.$fMap.mapGeoLocal([position.lng, position.lat])
          this.address = await this.$fMap.getAddress(position)
        }
      })
    },
    // 添加定位点标记
    _initPositionMarker (mapInstance) {
      const dpr = window.devicePixelRatio >= 3 ? 3 : 2
      const icon = require(`assets/imgs/icon-map-select@${dpr}x.png`)
      const positionMarker = this.positionMarker = this.$fMap.createMarker(icon, {
        w: MAP_POSITION_MARKER_WIDTH,
        h: MAP_POSITION_MARKER_HEIGHT
      })
      mapInstance.add(positionMarker)
      mapInstance.positionMarker = positionMarker
      // 初始化定位点位置
      this.$fMap.mapGeoLocal()
    },
    async _initMap () {
      try {
        // 创建地图实例
        const mapInstance = await this.$fMap.createMap('map', this)
        // 设置地图主题样式 - 远山黛
        mapInstance.setMapStyle('amap://styles/whitesmoke')
        // 初始化缩放比例尺样式
        this.$nextTick(() => {
          const scaleControl = this.$el.querySelector('.amap-scalecontrol')
          scaleControl.style.left = '15px'
          scaleControl.style.bottom = '168px'
        })
        this._initPositionMarker(mapInstance)
        this._bindEvents(mapInstance)
        // 获取当前用户地理位置
        const position = this.userCurrentPosition = await this.$fMap.geoLocation()
        this.userInitPosition = deepClone(position)
        // 获取当前用户地址信息
        this.address = await this.$fMap.getAddress(position)
        this.mapInstance = mapInstance
      } catch (e) {
        // 创建地图实例出错的话刷新当前页，
        window.location.reload()
      }
    },
    // 重新定位当前用户位置
    async location () {
      const position = [this.userInitPosition.lng, this.userInitPosition.lat]
      this.$fMap.mapGeoLocal(position)
      this.userCurrentPosition = this.userInitPosition
      this.address = await this.$fMap.getAddress(position)
    },
    // 提交重新定位表单
    async relocation () {
      const data = {
        marker_id: this.id,
        lng: this.userCurrentPosition.lng,
        lat: this.userCurrentPosition.lat,
        address: `${this.userCurrentAddress}${this.userInputAddress}`
      }
      const res = await api.relocationMyMarker(data)
      if (res.code === 200) {
        const vm = this
        this.$store.commit('ADD_MESSAGE', {
          msg: ACCOUNT_MAP_MARKER_RELOCATION_OK,
          type: 'success',
          cb () {
            vm.$router.push('/map-manage/edit-marker')
          }
        })
      }
    }
  }
}
</script>

<style lang="stylus">
.fine-art-page-marker-relocation
  fixed: left top
  bottom: 0
  width: 100%
  color: $black1
  .map-container
    height: 80%
    z-index: 1
    .btn-location
      absolute: right 30px bottom 310px
      width: 100px
      height: 100px
      z-index: 130
      .icon
        inline-icon(100px, 100px)
        bg-img('../../../../assets/imgs/map/icon-location')
  .marker-relocation
    absolute: left bottom
    width: 100%
    height: 550px
    padding: 6px 30px 30px 30px
    color: $black1
    z-index: 10
    background-color: $white
    .weui-cells
      margin-top: 0
    .weui-cell
      height: 94px
      line-height: 94px
      padding: 0
    .address .weui-cell__ft
      width: 80%
      font-size: 28px
      color: $black1
      {ellipse}
    .detail-address
      input
        {ellipse}
    .tip
      margin-top: 20px
      margin-bottom: 30px
      line-height: 48px
      font-size: 0
      .label
        margin-right: 8px
        font-size: 24px
        font-weight: 500
        color: #747474
      .text
        font-size: 24px
        color: $grey2
</style>
