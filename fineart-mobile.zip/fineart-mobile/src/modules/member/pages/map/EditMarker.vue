<template>
  <div :class="classes">
    <div v-if="markers.length === 0">
      <fine-art-empty></fine-art-empty>
    </div>
    <ul class="markers" v-else>
      <li class="marker" v-for="marker in markers" :key="marker.id">
        <h3 class="title">{{ marker.name }}</h3>
        <div class="desc-list">
          <div class="desc-item type">
            <span class="label">类型：</span>
            <span class="value">{{ marker.category_name }}</span>
          </div>
          <div class="desc-item mobile">
            <span class="label">手机号：</span>
            <span class="value">{{ marker.mobile }}</span>
          </div>
          <div class="desc-item link">
            <span class="label">绑定到：</span>
            <span class="value">{{ convert2resource(marker.resource_id) }}</span>
          </div>
          <div class="desc-item link">
            <span class="label">绑定到：</span>
            <span class="value">{{ convert2store(marker.store_id) }}</span>
          </div>
        </div>
        <div class="modify-links">
          <div class="modify-link delete" @click="deleteMaker(marker.id)">
            <span class="icon fy-icon-trash-grey"></span>
            <span class="label">删除</span>
          </div>
          <router-link class="modify-link re-location" :to="`/marker-relocation/${marker.id}`">
            <span class="icon icon-refresh"></span>
            <span class="label">重新定位</span>
          </router-link>
          <router-link class="modify-link edit" :to="`/marker-edit/${marker.id}`">
            <span class="icon fy-icon-pen"></span>
            <span class="label">编辑</span>
          </router-link>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
/**
 * comment: 地图标记编辑列表页
 */
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtEmpty } from 'components'

import api from 'modules/member/api'

export default {
  name: `${COMPONENT_PREFIX}MapEditMarker`,
  data () {
    return {
      // 我的标记列表
      markers: [],
      // 我的资源列表
      resources: [],
      // 我的店铺列表
      stores: []
    }
  },
  created () {
    this.fetchMyMarkerList()
    this.fetchResourceList()
    this.fetchStoreList()
  },
  beforeDestroy () {
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-map-edit-marker`
    }
  },
  methods: {
    async fetchMyMarkerList () {
      const response = await api.fetchMyMarkerList()
      this.markers = response.data
    },
    async fetchResourceList () {
      this.resources = await api.fetchResourceListForMarker()
    },
    async fetchStoreList () {
      this.stores = await api.fetchStores()
    },
    // 将标记的 resource id 转换成其名称
    convert2resource (resourceId) {
      if (!resourceId && this.resources.length === 0) return ''
      const resource = this.resources.find(res => res.resource_id === resourceId)
      if (!resource) return ''
      return resource.resource_name
    },
    // 将标记的 store id 转换成其名称
    convert2store (storeId) {
      if (!storeId && this.stores.length === 0) return ''
      const store = this.stores.find(res => res.store_id === storeId)
      if (!store) return ''
      return store.store_name
    },
    deleteMaker (id) {
      const vm = this
      const indexOf = (prop, array) => {
        for (let i = 0, len = array.length; i < len; ++i) {
          if (array[i][prop] === prop) return i
        }
      }
      this.$vux.confirm.show({
        title: '确认删除吗？',
        confirmText: '确定',
        cancelText: '取消',
        closeOnConfirm: false,
        async onConfirm () {
          // send delete operation request
          const response = await api.deleteMyMarker(id)
          if (response.code === 200) {
            vm.$vux.confirm.hide()
            vm.markers.splice(indexOf(id, vm.markers), 1)
          }
        }
      })
    }
  },
  components: {
    FineArtEmpty
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-map-edit-marker
  padding-top: 30px
  color: $black1
  .markers
    padding: 0 30px
    .marker
      position: relative
      margin-bottom: 30px
      padding: 0 30px
      border: 1.4px solid $grey
      border-radius: 4px
      .title
        margin-bottom: 30px
        padding-top: 26px
        line-height: 40px
        font-size: 28px
        {ellipse}
      .desc-list
        margin-bottom: 20px
        .desc-item
          margin-bottom: 17px
          font-size: 0
          line-height: 40px
          color: $grey3
          &.link .value
            font-size: 30px
            color: $black2
          .label
            display: inline-block
            vertical-align: top
            font-size: 28px
          .value
            display: inline-block
            vertical-align: top
            font-size: 28px
      .modify-links
        display: flex
        padding: 28px 0
        border-top: 1.4px dashed $grey
        .modify-link
          flex: 1
          text-align: center
          font-size: 0
          color: $grey2
          &.re-location
            border-left: 1.4px solid $grey
            border-right: 1.4px solid $grey
          .icon
            display: inline-block
            vertical-align: middle
            margin-right: 22px
            font-size: 26px
            color: $orange
            &.icon-refresh
              inline-icon(26px, 28px)
              vertical-align: middle
              bg-img('../../../../assets/imgs/icon-refresh')
          .label
            display: inline-block
            vertical-align: middle
            line-height: 37px
            font-size: 26px
            color: $orange
</style>
