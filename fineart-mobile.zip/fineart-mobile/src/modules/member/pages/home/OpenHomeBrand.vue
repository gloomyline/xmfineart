<template>
  <div :class="classes">
    <!-- 头部提示信息 -->
    <div class="page-head">
      <p class="head-title">申请开通品牌持有者/厂商类型-企业主页</p>
      <p class="describe">填写如下基础信息用于平台审核，审核通过后为您创建 主页。在主页里，您还可添加参与案例等丰富内容。</p>
      <p class="apply-false-reason" v-if="openHomeForm.status === '200'">审核失败原因：{{ openHomeForm.reason }}</p>
    </div>
    <!-- 分割线 -->
    <div class="divider"></div>
    <!-- 开通公司主页表单 -->
    <div class="apply-info-wrap">
      <group label-align="left">
        <!-- 公司logo -->
        <cell title="公司logo" inline-desc="(尺寸300X300，大小不超过5M)">
          <fine-art-upload
            class="img-upload"
            width="155"
            height="155"
            :max-size="ossImage.max_size"
            :data="ossImage.data"
            :action="ossImage.host"
            :format="ossImage.format"
            :accept="ossImage.accept"
            :beforeUpload="beforeUploadImageLogo"
            :on-success="successImageLogo">
            <div class="upload-box" v-if="!this.openHomeForm.logo_cdn">
              <div class="fy-icon-camera"></div>
              <em>点击上传</em>
            </div>
            <img class="uploaded-img" v-else :src="this.openHomeForm.logo_cdn"/>
          </fine-art-upload>
        </cell>
        <!-- 公司 -->
        <x-input
          title="公司"
          placeholder="请填写公司名称"
          placeholder-align="right"
          text-align="right"
          v-model="openHomeForm.name"
          :show-clear="false"></x-input>
        <!-- 一句话介绍公司 -->
        <x-input
          title="一句话介绍"
          placeholder="一句话介绍公司的业务"
          placeholder-align="right"
          text-align="right"
          v-model="openHomeForm.subtitle"
          :show-clear="false"></x-input>
        <!-- 公司简介 -->
        <h3 class="label-span">品牌简介</h3>
        <x-textarea :rows="6" placeholder="请填写品牌简介" v-model="openHomeForm.introduction"></x-textarea>
        <!-- 分类 -->
        <fine-art-category :data-list="cateList" v-model="categoryText" @choice-cate="chooseCate"></fine-art-category>
        <!-- 营业执照 -->
        <cell title="营业执照" inline-desc="(照片用于审核，文件大小不超过5M)">
          <fine-art-upload
            class="img-upload"
            width="155"
            height="155"
            :max-size="ossImage.max_size"
            :data="ossImage.data"
            :action="ossImage.host"
            :format="ossImage.format"
            :accept="ossImage.accept"
            :beforeUpload="beforeUploadImageLicense"
            :on-success="successImageLicense">
            <div class="upload-box" v-if="!this.openHomeForm.license_cdn">
              <div class="fy-icon-camera"></div>
              <em>点击上传</em>
            </div>
            <img class="uploaded-img" v-else :src="this.openHomeForm.license_cdn"/>
          </fine-art-upload>
        </cell>
        <!-- 姓名 -->
        <x-input
          title="姓名"
          placeholder="请填写联系人姓名"
          placeholder-align="right"
          text-align="right"
          v-model="openHomeForm.contact_name"
          :show-clear="false" ></x-input>
        <!-- 邮箱 -->
        <x-input
          title="邮箱"
          placeholder='请填写联系邮箱'
          placeholder-align="right"
          text-align="right"
          v-model="openHomeForm.email"
          :show-clear="false" ></x-input>
        <!-- 手机号 -->
        <x-input
          title="手机号"
          :max="11"
          mask="99999999999"
          placeholder="请填写联系手机号"
          placeholder-align="right"
          text-align="right"
          v-model.trim.number="openHomeForm.mobile"
          :show-clear="false"></x-input>
        <x-input
          title="地区"
          placeholder-align="right"
          text-align="right"
          disabled
          v-model="openHomeForm.area"
          @click.native="showMap"
          :show-clear="false">
          <span slot="right" class="input-placeholder" v-if="!openHomeForm.area">请选择地区</span>
        </x-input>
        <x-input
          title="详细地址"
          placeholder-align="right"
          text-align="right"
          disabled
          @click.native="showMap"
          v-model="openHomeForm.address"
          :show-clear="false">
          <span slot="right" class="input-placeholder" v-if="!openHomeForm.address">请输入详细地址</span>
        </x-input>
        <!--地图插件 -->
        <fine-art-address v-model="isShowed"
                          :lng="point[0]"
                          :lat="point[1]"
                          @save-edit="changeHandler">
          <!-- 提示 -->
          <div slot="tip">
            <div class="tip">
              <span class="label">温馨提示：</span>
              <span class="text">设置您的常驻位置，如获取到的地址有误，请手动修改。系统会就近推送资源给需求方，准备定位有助于获得更多机会。</span>
            </div>
          </div>
        </fine-art-address>
        <!--提交-->
        <x-button class="submit-btn" type="primary" @click.native="handleSubmit()">提交</x-button>
      </group>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import { getResourceCategory, find } from '@/common/js/loadScript.js'
import { FineArtUpload, FineArtCategory, FineArtMap, FineArtAddress } from '@/components'
import * as MSG from 'assets/data/message.js'
import api from '@/modules/member/api'
import { mapMutations } from 'vuex'

export default {
  name: `${COMPONENT_PREFIX}PageOpenHomeBrand`,
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{10}$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      isShowed: false,
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      // 存放已申请该资源类型，资源id
      resourceId: this.$route.params.id,
      // 资源类型
      resourceMode: 400,
      openHomeForm: {
        area: '',
        logo: '', // 个人头像，必须
        logo_cdn: '',
        license: '',
        license_cdn: '',
        email: '', // 邮箱，必须
        name: '', // 姓名，必须
        introduction: '', // 个人简介，必须
        subtitle: '', // 一句话介绍，必须
        resource_category_id: '', // 分类ID，必须
        mobile: '', // 联系手机，必须
        sys_area_id: '', // 地区ID，必须
        address: '', // 详细地址，必须
        lng: '', // 经度，必须
        lat: '', // 纬度，必须
        contact_name: '',
        status: '100' // 审核结果 200 => 失败
      },
      openHomeRule: {
        logo: [
          { required: true, message: '请上传公司logo' }
        ],
        name: [
          { required: true, message: '请输入公司名称' }
        ],
        introduction: [
          { required: true, message: '请输入品牌简介' }
        ],
        subtitle: [
          { required: true, message: '请输入一句话介绍公司的业务' }
        ],
        resource_category_id: [
          { required: true, message: '请选择分类' }
        ],
        license: [
          { required: true, message: '请上传营业执照' }
        ],
        contact_name: [
          { required: true, message: '请输入联系人姓名' }
        ],
        email: [
          { required: true, message: '请输入邮箱' },
          { type: 'email', message: '邮箱格式不正确' }
        ],
        mobile: [
          { required: true, message: '请输入手机号' },
          mobileValidator
        ],
        address: [
          { required: true, message: '请输入详细地址' }
        ]
      },
      // 分类数组
      cateList: [],
      // 分类选中值
      category: [],
      // 分类选择值
      categoryText: '',
      // 经纬度
      point: []
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-open-home`
    }
  },
  created () {
    this.modifyPageName('申请企业主页')
    this.initCategory()
    this.initPage()
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    // 显示地图
    showMap () {
      this.isShowed = true
    },
    // 初始化页面，已申请过，获取填写申请表单数据
    async initPage () {
      if (this.resourceId !== undefined) {
        this.openHomeForm = await api.resourceMyDetail(this.resourceId, this.resourceMode)
        this.point = [this.openHomeForm.lng, this.openHomeForm.lat]
        this.openHomeForm.area = Object.values(this.openHomeForm.area_line).join(' / ')
        this.category = Object.keys(this.openHomeForm.category_line)
        let categoryArr = []
        for (let i in this.openHomeForm.category_line) {
          categoryArr.push(this.openHomeForm.category_line[i])
        }
        this.categoryText = categoryArr.join(' / ')
      }
    },
    // 图片上传之前
    async beforeUploadImageLogo (file) {
      this.ossImage = await api.ossParamsCreate(file, 'resource_logo', this.ossImage)
    },
    async beforeUploadImageLicense (file) {
      this.ossImage = await api.ossParamsCreate(file, 'resource_license', this.ossImage)
    },
    // 图片上传成功
    successImageLogo (res) {
      if (res.code === 200) {
        this.openHomeForm.logo_cdn = res.results.file_url_cdn
        this.openHomeForm.logo = res.results.file_url
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'warn'})
      }
    },
    successImageLicense (res) {
      if (res.code === 200) {
        this.openHomeForm.license_cdn = res.results.file_url_cdn
        this.openHomeForm.license = res.results.file_url
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg, type: 'warn'})
      }
    },
    // 获取分类数组
    async initCategory () {
      const response = await getResourceCategory()
      this.cateList = find(response, parseInt(this.resourceMode)).children
    },
    // 选中分类
    chooseCate (value) {
      this.openHomeForm.resource_category_id = value.pop()
    },
    // 地图改变位置
    changeHandler (val) {
      this.openHomeForm.lng = val.point[0]
      this.openHomeForm.lat = val.point[1]
      this.openHomeForm.area = `${val.province} / ${val.city} / ${val.district}`
      this.openHomeForm.address = val.address
      this.openHomeForm.sys_area_id = val.area_id
    },
    // 提交表单
    async handleSubmit () {
      const rules = await validate(this.openHomeForm, this.openHomeRule)
      if (!rules) return

      let res = await api.resourceApplyCommon(this.resourceMode, this.openHomeForm)
      if (res.code === 200) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_HOME_APPLY_SUCCESS'], type: 'success'})
        this.$router.push({path: '/choice-home'})
      }
    }
  },
  components: {
    FineArtMap,
    FineArtUpload,
    FineArtCategory,
    FineArtAddress
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-open-home
  width: 100%
  .page-head
    padding: 30px
    .head-title
      font-size: 30px
      color: $black1
      line-height: 42px
    .describe
      color: $black2
      font-size: 28px
      line-height: 48px
      margin-top: 27px
    .apply-false-reason
      color: $orange
      font-size: 28px
      line-height: 48px
      margin-top: 30px
  .divider
    width: 100%
    height: 20px
    background-color: $grey4
  .apply-info-wrap
    padding: 0 30px
    .weui-cell__bd
      overflow: hidden
  .weui-cells
    margin-top: 0
    .weui-cell
      min-height: 98px
      padding-left: 0
      padding-right: 0
    .vux-label-desc
      color: $grey3
      font-size: 24px
      margin-top:20px
    .vux-x-input.disabled .weui-input
      -webkit-text-fill-color: $black1
    .input-placeholder
      absolute: right 20px top 50%
      font-weight: 300
      font-size: 27px
      color: $grey2
      transform: translateY(-50%)
    .img-upload
      .upload-box
        absolute: top left
        display: flex
        flex-direction: column
        justify-content: center
        align-items: center
        width: 100%
        height: 100%
        border: 2px solid $grey
        .fy-icon-camera
          font-size: 42px
        em
          color: $grey2
          font-size: 24px
      .uploaded-img
        width: 100%
        height: 100%
    .vux-x-textarea
      padding: 24px
      height: 275px
      border: 2px solid $grey
      border-radius: 4px
    .label-span
      width: 100%
      height: 96px
      font-size: 30px
      line-height: 96px
    .submit-btn
      margin: 30px 0
</style>
