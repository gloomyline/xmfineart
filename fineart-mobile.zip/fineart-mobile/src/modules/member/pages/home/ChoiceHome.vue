<template>
  <div :class="classes">
    <!--线下店详情轮播图-->
    <fine-art-slide ref="slide">
      <ul class="home-list">
        <li class="home-item"
            :key="index"
            v-for="(item, index ) in homePageList">
          <div class="img-wrap"><img :src="item.bgImg"/></div>
          <div class="home-info">
            <p class="title">{{ item.titleText }}</p>
            <p class="mode-desc">{{ item.modeDesc }}</p>
            <div class="name-intro-wrap" :class="{'info-null' : !item.name}">
              <p class="name">{{ item.name }}</p>
              <p class="intro">{{ item.introduction | labelFormatter }}</p>
            </div>
          </div>
          <p class="handle-box">
            <x-button type="primary" v-if="item.status === null" @click.native="openHome(index)">申请开通</x-button>
            <x-button class="verifying" v-if="item.status === '100'" @click.native="openHome(index, item.id)">审核中</x-button>
            <x-button type="primary" v-if="item.status === '200'" @click.native="openHome(index, item.id)">审核失败</x-button>
            <x-button type="primary" v-if="item.status === '300'" @click.native="goDetail(index,item.id)">查看主页</x-button>
          </p>
        </li>
      </ul>
    </fine-art-slide>
    <div class="tip">根据您的需求，申请开通、管理主页。用户可以浏览您的主页，添加真实、完善的信息，可带来更多业务可能。</div>
    <!--实名认证提示弹窗-->
    <div v-transfer-dom>
      <fine-art-tip-modal v-model="authTipModal">
        <img slot="img" src="../../../../assets/imgs/auth-tip-bg@2x.png"/>
        <span slot="text">需完成账号实名认证才能继续使用该功能，如需请点击去认证</span>
        <x-button slot="foot" type="primary" @click.native="goToAuth">去认证</x-button>
      </fine-art-tip-modal>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { mapState, mapMutations } from 'vuex'
import { FineArtSlide, FineArtTipModal } from '@/components'
import api from 'modules/member/api/index.js'

export default {
  name: `${COMPONENT_PREFIX}PageChoiceHome`,
  data () {
    return {
      homePageList: { // 优秀个人=100，优秀公司=200，优秀供应商=300，优秀品牌=400
        '100': {
          bgImg: require('../../../../assets/imgs/member/choice-home-person.png'),
          titleText: '个人主页',
          modeDesc: '',
          name: '',
          introduction: '',
          status: null // null=未申请，100=待审核，200=审核失败，300=审核通过，400=隐藏
        },
        '200': {
          bgImg: require('../../../../assets/imgs/member/choice-home-company.png'),
          titleText: '公司主页',
          modeDesc: '设计、建造、运营类',
          name: '',
          introduction: '',
          status: null
        },
        '300': {
          bgImg: require('../../../../assets/imgs/member/choice-home-supplier.png'),
          titleText: '公司主页',
          modeDesc: '供应商、代理商、经销商类',
          name: '',
          introduction: '',
          status: null
        },
        '400': {
          bgImg: require('../../../../assets/imgs/member/choice-home-brand.png'),
          titleText: '公司主页',
          modeDesc: '品牌方、生产方类',
          name: '',
          introduction: '',
          status: null
        },
        '500': {
          bgImg: require('../../../../assets/imgs/member/choice-home-decorator.png'),
          titleText: '装修师主页',
          modeDesc: '',
          name: '',
          introduction: '',
          status: null
        }
      },
      authTipModal: false,
      dots: [],
      currentPageIndex: 0
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-choice-home`
    },
    ...mapState(['memberProfile'])
  },
  created () {
    this.initPage()
  },
  activated () {
    this.modifyPageName('选择主页')
    this.initPage()
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    async initPage () {
      let res = await api.resourceMyList()
      if (res.code === 200) {
        if (Object.keys(res.results).length > 0) {
          for (let key in res.results) {
            this.homePageList[key].id = res.results[key].id
            this.homePageList[key].status = res.results[key].status
            this.homePageList[key].name = res.results[key].name
            if (res.results[key].introduction) {
              this.homePageList[key].introduction = res.results[key].introduction.replace(/<\/?[^>]*>/g, '')
            }
          }
        }
      }
    },
    // 开通主页
    openHome (mode, id) {
      if (this.memberProfile.is_auth === '100') {
        this.authTipModal = true
      } else {
        if (id === undefined) {
          this.$router.push(`open-home/${mode}`)
        } else {
          this.$router.push(`open-home/${mode}/${id}`)
        }
      }
    },
    // 查看主页
    goDetail (mode, id) {
      switch (mode) {
      case '100':
        window.location = `/resource.html#/person-home/${id}`
        break
      case '200':
        window.location = `/resource.html#/company-home/${id}`
        break
      case '300':
        window.location = `/resource.html#/supplier-home/${id}`
        break
      case '400':
        window.location = `/resource.html#/brand-home/${id}`
        break
      case '500':
        window.location = `/resource.html#/decorator-home/${id}`
        break
      }
    },
    // 前往认证页面
    goToAuth () {
      this.authTipModal = false
      this.$router.push('/auth')
    }
  },
  filters: {
    labelFormatter (str = '', length = 35) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtSlide,
    FineArtTipModal
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-choice-home
  fixed: top 94px bottom left
  width: 750px
  display: flex
  flex-direction: column
  justify-content: space-around
  background: $grey5
  .tip
    width: 100%
    color: $grey3
    font-size: 24px
    line-height: 40px
    text-align: center
    padding:  25px 35px
  .home-list
    padding: 30px 62px
    width: max-content
    display: flex
    flex-direction: row
    flex-wrap: nowrap
  .home-item
    width: 600px!important
    height: 820px!important
    margin: 0 15px
    padding: 30px
    border-radius: 16px
    background: $white
    box-shadow:0px 2px 20px 0px rgba(0,0,0,0.08)
    .img-wrap
      width: 540px
      height: 266px
      overflow: hidden
      img
        width: 100%
    .home-info
      height: 334px
      width: 100%
      .title
        color: $black1
        font-size: 28px
        height: 40px
        line-height: 40px
        font-weight: 500
        margin: 30px 0 10px 0
        display: flex
        align-items: center
        justify-content: center
        &:before, &:after
          content: ''
          height: 1px
          width: 48px
          margin: 0 30px
          border-top: 1px solid $grey
      .mode-desc
        color: $grey3
        font-size: 26px
        height: 37px
        line-height: 37px
        text-align: center
        margin-bottom: 30px
      .name-intro-wrap
        width: 500px
        height: 217px
        margin: 0 auto
        border-radius: 10px
        background: $grey5
        padding: 37px 26px
        &.info-null
          background: url("../../../../assets/imgs/member/info-null.png")
          background-repeat: no-repeat
          background-size: contain
          background-position-x: center
        .name
          color: $black1
          font-size: 30px
          line-height: 42px
          padding-bottom: 20px
          font-weight: 600
          text-align: center
        .intro
          color: $grey3
          font-size: 24px
          line-height: 40px
          word-break: break-word
    .handle-box
      padding-top: 40px
      .weui-btn
        width: 340px
        font-size: 30px
        line-height: 80px
        border-radius: 40px
        box-shadow:0px 4px 14px 0px rgba(247,181,44,0.48)
        &.verifying
          color: $white
          background: $grey2
          box-shadow:0px 4px 14px 0px rgba(187,187,187,0.56)
</style>
