<template>
  <div :class="classes">
    <img class="bg-img" src="https://cdn.xmfineart.com/upload/default/bg-login-register.jpg" width="100%" height="100%">
    <h3 class="reset-title">重置密码</h3>
    <div class="form-container">
      <form class="form-reset">
        <div class="form-item fy-1px-b mobile">
          <input v-model.trim="resetForm.mobile" type="number" placeholder="输入手机号码">
        </div>
        <div class="form-item fy-1px-b code">
          <input v-model.trim="resetForm.code" type="number" placeholder="输入短信验证码">
          <span class="btn-fetch-code fy-1px-l" :class="{ counting }" @click="fetchCode">{{ btnLabel }}</span>
        </div>
        <div class="form-item fy-1px-b">
          <input v-model.trim="resetForm.password" type="password" placeholder="输入密码">
        </div>
        <div class="form-item fy-1px-b password">
          <input v-model.trim="resetForm.password_confirm" type="password" placeholder="再次输入密码">
        </div>
      </form>
      <div class="form-item next">
        <x-button @click.native.prevent="resetPwd" class="btn-next">确认重置</x-button>
      </div>
      <div class="form-item go-login">
        <x-button plain class="btn-login" link="/login">[去登录]</x-button>
      </div>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, TIMER_COUNTER } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import api from 'modules/member/api'
import { GLOBAL_RESET_SUCCESS } from '@/assets/data/message'
export default {
  name: 'resetPassword',
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{10}$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    const passwordValidator = (rule, value, cb) => {
      if (!(/^[\w!@#$%^&*.,]+$/.test(value))) {
        cb(new Error('密码只能由英文字母、数字、!@#$%^&*.,组成！'))
      } else {
        cb()
      }
    }
    const passwordConfirmValidator = (rule, value, cb) => {
      if (String(value) !== String(this.resetForm.password)) {
        cb(new Error('两次输入的密码不一致！'))
      } else {
        cb()
      }
    }
    return {
      // 重置密码数据
      resetForm: {
        mobile: '',
        password: '',
        password_confirm: '',
        code: ''
      },
      // 验证手机号
      mobileRules: {
        mobile: [{
          required: true,
          message: '手机号不可为空！'
        }, {
          // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
          validator: mobileValidator
        }]
      },
      // 校验规则
      resetRules: {
        mobile: [{
          required: true,
          message: '手机号不可为空！'
        }, {
          // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
          validator: mobileValidator
        }],
        code: [{
          required: true,
          message: '短信验证码不可为空！'
        }],
        password: [{
          required: true,
          message: '密码不可为空！'
        }, {
          type: 'string',
          min: 6,
          max: 15,
          message: '密码长度必需小于15个字符，且大于6个字符！'
        }, {
          validator: passwordValidator
        }],
        password_confirm: [{
          required: true,
          message: '密码不可为空！'
        }, {
          validator: passwordConfirmValidator
        }]
      },
      // 计数器当前值
      seconds: 0
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-reset-password`
    },
    counting () {
      return this.seconds > 0
    },
    btnLabel () {
      return this.counting ? `${this.seconds}s` : '获取'
    }
  },
  beforeDestroy () {
    if (this.timer) {
      this.stopCount(this.timer)
    }
  },
  methods: {
    // 获取验证码
    async fetchCode () {
      const rules = await validate(this.resetForm, this.mobileRules)
      if (!rules) return
      if (this.seconds > 0) return
      // 请求发送重置密码短信验证码
      const res = await api.fetchCode({ type: 202, mobile: this.resetForm.mobile })
      if (res.code === 200) {
        this.startCount()
      }
    },
    // 确认重置密码
    async resetPwd () {
      const vm = this
      const rules = await validate(this.resetForm, this.resetRules)
      if (!rules) return
      const res = await api.resetPassword(this.resetForm)
      if (res.code === 200) {
        this.$store.commit('ADD_MESSAGE', {
          msg: GLOBAL_RESET_SUCCESS,
          type: 'success',
          cb () {
            vm.$router.push({ path: '/login' })
          }
        })
      }
    },
    startCount () {
      // 初始化获取短信验证码计数器
      this.seconds = TIMER_COUNTER
      this.timer = setInterval(() => {
        if (this.seconds <= 0) {
          clearInterval(this.timer)
        }
        --this.seconds
      }, 1000)
    },
    stopCount (timerId) {
      clearInterval(timerId)
    }
  }
}
</script>

<style lang="stylus" scoped>
.{$cls_prefix}-page-reset-password
  color: $black1
  absolute: left top 94px
  width: 100%
  height: 100%
  .bg-img
    absolute: left top
    z-index: -1
  .reset-title
    margin: 78px 0
    color: $white
    font-size: 40px
    text-align: center
    font-weight: 500
  .form-container
    padding: 0 113px
    .form-reset
      .form-item
        &.code
          position: relative
          .btn-fetch-code
            absolute: right top 28px
            width: 108px
            height: 42px
            line-height: 42px
            padding-left: 31px
            font-size: 30px
            color: $white
            &.counting
              color: rgba(255, 255, 255, 0.6)
      .password
        margin-bottom: 74px
    .form-item
      margin-top: 26px
      font-size: 0
      &.next
        margin-top: 0
        padding: 0
        .weui-btn
          height: 88px
          padding: 0
          line-height: 88px
          font-size: 30px
          color: $white
          background-color: $orange
      &.go-login
        padding: 0
        .weui-btn
          border: 0
          color: $orange
          text-decoration: underline
      input
        width: 100%
        height: 40px
        padding: 28px 0
        line-height: 50px
        text-align: center
        font-size: 36px
        color: $white
        border: none
        outline: none
        caret-color: $white
        background-color: transparent
        &:focus
          outline: none
        &::-webkit-input-placeholder
          color: rgba(255, 255, 255, 0.7)
          font-size: 30px
</style>
