<template>
  <div :class="classes">
    <!--所购买商品信息-->
    <div class="selected-product">
      <div class="selected-item">
        <div class="product-detail">
          <div class="img-wrap">
            <img src="https://cdn.fa.com/uploadfile/images/2017/201708/20170801/598023c56ab5d.jpg" width="100%" height="100%">
          </div>
          <div class="detail">
            <p class="name">金士顿16G DDR4 2400内存条金 金士顿16G DDR4 2400内存条金</p>
            <div class="price-count">
              <div class="price">&yen;798.00</div>
              <div class="count">
                <div class="count-num">x1</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--售后申请类型-->
    <div class="sale-servcie-type">
      <div class="const-text">
        <span class="em-star">*</span>
        <span class="text">售后申请类型</span>
      </div>
      <div class="explain">
        请确认您与商家已协商好，确定申请售后服务。 请注意，在平台上只能申请一次。如后续需售后服务，请线下联系商家。
      </div>
      <div class="button">
        <div class="refund fy-1px">退款</div>
        <div class="change-goods fy-1px">换货</div>
      </div>
    </div>
    <div class="expalin-question">
      <span class="em-star">*</span>
      <span class="text">问题描述</span>
    </div>
    <div class="explain-ques-area fy-1px">
      <textarea  placeholder="请输入～"></textarea>
    </div>
    <div class="commit-button">提交</div>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { mapMutations } from 'vuex'

export default {
  name: `${COMPONENT_PREFIX}PageApllyForService`,
  data () {
    return {
    }
  },
  created () {
    this.modifyPageName('订单详情页')
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-apply-for-service`
    }
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    })
  },
  components: {
    mapMutations
  }
}
</script>
<style lang="stylus">
  .{$cls_prefix}-page-apply-for-service
    .selected-product
      .selected-item
        padding: 30px 30px 0 30px
        display: flex
        justify-content: left;
        flex-direction: row
        position: relative
        height: 220px
        .product-detail
          display: flex
          justify-content: left;
          flex-direction: row
          padding-bottom: 20px
          .img-wrap
            width: 160px
            height: 160px
            img
              min-width: 160px
              min-height: 160px
          .detail
            margin-left: 20px
            .name
              font-size: 28px
              line-height: 40px
              color: $black2
              width: 442px
            .price-count
              .price
                font-size: 26px
                line-height: 37px
                color: $black1
                position: absolute
                bottom: 22px
              .count
                position: absolute
                bottom: 22px
                right: 30px
                .count-num
                  font-size: 26px
                  line-height: 37px
                  color: $grey3
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .sale-servcie-type
      padding: 30px
      .const-text
        font-size: 26px
        line-height: 37px
        color: $black1
        .em-star
          color: $orange
      .explain
        margin-top: 16px
        font-size: 24px
        line-height: 33px
        color: $grey3
      .button
        margin-top: 30px
        .refund,.change-goods
          display: inline-block
          height:68px
          width: 334px
          line-height: 68px
          text-align: center
          font-size: 28px
         .refund.fy-1px:before
            border-color: $orange!important
        .refund
          color: $orange
        .change-goods
          color: $black2
    .expalin-question
      font-size: 26px
      line-height: 37px
      color: $black1
      padding: 30px
      .em-star
        color: $orange
    .explain-ques-area
      height: 275px
      width: 690px
      margin-left: 30px
      padding-left: 24px
      padding-top: 21px
      textarea
        width: 100%
        height: 100%
        padding: 0px
    .commit-button
      height: 80px;
      width: 690px;
      background-color: $orange
      font-size: 30px
      text-align: center
      line-height: 80px
      color: $white
      margin-left: 30px
      border-radius: 4px
      margin-top: 47px
</style>
