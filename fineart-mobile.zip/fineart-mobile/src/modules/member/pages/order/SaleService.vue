<template>
  <div :class="classes">
    <!--所购买商品信息-->
    <div class="selected-product">
      <div class="selected-item">
        <div class="product-detail">
          <div class="img-wrap">
            <img :src="orderDetail.goods_thumbnail" width="100%" height="100%">
          </div>
          <div class="detail">
            <p class="name">{{ orderDetail.goods_name }}</p>
            <div class="price-count">
              <div class="price">&yen;{{ orderDetail.pay_total }}</div>
              <div class="count">
                <div class="count-num">x{{ orderDetail.number }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--未申请申请-->
    <div class="apply" v-if="showData&&!orderDetail.service_id">
      <div class="service-type">
        <p class="title-text">售后申请类型</p>
        <p class="tip">请确认您与商家已协商好，确定申请售后服务。 请注意，在平台上只能申请一次。如后续需售后服务，请线下联系商家。</p>
        <div class="btn-wrap">
          <x-button
            mini plain
            class="service-type-btn"
            :class="{'is-active': applyOrderService.apply_operate === '100'}"
            @click.native=" applyOrderService.apply_operate = '100'">退款</x-button>
          <x-button
            mini plain
            class="service-type-btn"
            :class="{'is-active': applyOrderService.apply_operate === '200'}"
            @click.native=" applyOrderService.apply_operate = '200'">换货</x-button>
        </div>
      </div>
      <div class="apply-reason">
        <p class="title-text">问题描述</p>
        <x-textarea
          :rows="5"
          v-model="applyOrderService.apply_reason"
          placeholder="请输入～"></x-textarea>
      </div>
      <div class="handle-box">
        <x-button type="primary" @click.native="submitApply">提交</x-button>
      </div>
    </div>
    <!-- 已申请详情 -->
    <div class="sale-service-detail" v-if="showData&&orderDetail.service_id">
      <div class="service-type">
        <p class="title-text">售后申请类型</p>
        <p class="tip">请确认您与商家已协商好，确定申请售后服务。 请注意，在平台上只能申请一次。如后续需售后服务，请线下联系商家。</p>
        <p class="service-type-text red">{{ applyOperateText }}</p>
      </div>
      <div class="apply-reason">
        <p class="title-text">问题描述</p>
        <p class="apply-reason-text" v-html="orderService.apply_reason"></p>
      </div>
      <div class="service-result" v-if="orderService.handle_status !== '100'">
        <p class="title-text">售后处理结果</p>
        <div class="type">
          <p v-if="orderService.handle_status === '200'">退款金额：<span class="money">&yen;{{ orderService.refund }}</span></p>
          <p v-if="orderService.handle_status === '300'">换货</p>
          <p v-if="orderService.handle_status === '400'">取消售后</p>
        </div>
        <div class="status red" v-html="orderService.handle_reason"></div>
      </div>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import * as MSG from '@/assets/data/message'
import api from '@/modules/member/api/index.js'
import { mapMutations } from 'vuex'

export default {
  name: `${COMPONENT_PREFIX}PageSaleService`,
  data () {
    return {
      // 订单详情
      orderDetail: {},
      // 已申请、申请售后详情
      orderService: {
        handle_status: '200'
      },
      // 未申请、申请售后表单
      applyOrderService: {
        code: '',
        apply_operate: '',
        apply_reason: ''
      },
      showData: false
    }
  },
  props: ['orderId'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-sale-service`
    },
    applyOperateText () {
      return this.orderService.apply_operate === '100' ? '退款' : '换货'
    }
  },
  created () {
    this.modifyPageName('订单详情页')
    this.initPage()
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    // 获取商品详情、售后信息
    async initPage () {
      this.orderDetail = await api.orderMyDetail(this.orderId)
      if (!this.orderDetail.service_id) {
        this.applyOrderService.code = this.orderDetail.code
      } else {
        this.orderService = await api.orderServiceDetail(this.orderDetail.service_id)
      }
      this.showData = true
    },
    // 提交售后申请
    async submitApply () {
      let response = await api.orderServiceApply(this.applyOrderService)
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_ORDER_SERVICE_SUCCESS'], type: 'success' })
        this.$router.push({path: '/my-order'})
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-sale-service
  width: 100%
  .divider
    width: 100%
    height: 20px
    background-color: $grey4
  .selected-product
    .selected-item
      padding: 30px 30px 0 30px
      display: flex
      justify-content: left;
      flex-direction: row
      .product-detail
        display: flex
        justify-content: left;
        flex-direction: row
        position: relative
        padding-bottom: 20px
        .img-wrap
          width: 160px
          height: 160px
          img
            min-width: 160px
            min-height: 160px
        .detail
          width: 510px
          margin-left: 20px
          .name
            padding-top: 10px
            font-size: 28px
            line-height: 40px
            color: $black2
          .price-count
            position: absolute
            bottom: 35px
            display: flex
            justify-content: space-between
            width: 510px
            .price
              font-size: 26px
              line-height: 37px
              color: $black1
            .count
              .count-num
                font-size: 26px
                line-height: 37px
                color: $grey3
  .sale-service-detail, .apply
    padding: 30px
    .title-text
      color: $black1
      font-size: 26px
      height: 37px
      line-height: 37px
      margin-bottom: 16px
    .red
      color: $red
    .service-type, .apply-reason, .service-result
      margin-bottom: 50px
    .service-type
      .tip
        color: $grey3
        font-size: 24px
        line-height: 33px
      .service-type-text
        font-size: 26px
        padding: 40px 0
    .apply-reason .apply-reason-text
      color: $black2
      font-size: 26px
      line-height: 48px
    .service-result
      .type, .status
        padding: 22px
        line-height: 37px
        background: #FDF9EF
      .type
        color: $black2
        font-size: 26px
        margin-bottom: 27px
        .money
          color: $orange
          font-size: 28px
      .status
        font-size: 24px
  /* 未申请 */
  .apply
    .title-text:before
      content: '*'
      color: $orange
    .service-type
      margin-bottom: 60px
      .service-type-btn
        width: 334px
        height: 68px
        color: $black2
        font-size: 28px
        border-radius: 4px
        border: 2px solid $grey6
        &.is-active
          color: $orange
          border-color: $orange
    .apply-reason
      .title-text
        margin-bottom: 30px
      .vux-x-textarea
        height: 275px
        padding: 20px
        font-size: 26px
        line-height: 1.5
        border: 2px solid $grey
</style>
