<template>
  <div :class="classes">
    <fine-art-scroller
      class="order-list-scroller"
      ref="scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :height="-94/75"
      :list="orderList.data"
      :has-data="hasData"
      :has-more="orderList.has_next"
      :last-page="orderList.last_page">
      <div class="order-wrap">
        <div v-for="(item, index) in orderList.data" :key="index">
          <div class="order-item">
            <div class="order-num fy-1px-b">订单号：{{item.code}}</div>
            <div @click="goToDetail(item.id)" class="goods-detail fy-1px-b">
              <div class="img-wrap">
                <img :src="item.goods_thumbnail" height="80%" width="80%">
              </div>
              <div class="name">{{item.goods_name}}</div>
              <div class="state-text">
                <span :class="{'red': item.status === '100','yellow': item.status === '200'}">{{item.status_desc}}</span>
              </div>
            </div>
            <div class="other-operation">
              <div class="price">实付：&yen;{{item.pay_total}}</div>
              <div class="order-service-btn">
                <router-link :to="`/sale-service/${item.id}`" class="grey" v-if="!item.service_id && ['200', '300', '400'].indexOf(item.status) >= 0">申请售后</router-link>
                <router-link :to="`/sale-service/${item.id}`" class="red" v-else-if="item.service_handle_status === '100'">售后处理中</router-link>
                <router-link :to="`/sale-service/${item.id}`" class="yellow" v-else-if="item.service_handle_status === '200'">已退款</router-link>
                <router-link :to="`/sale-service/${item.id}`" class="yellow" v-else-if="item.service_handle_status === '300'">已换货</router-link>
                <router-link :to="`/sale-service/${item.id}`" class="yellow" v-else-if="item.service_handle_status === '400'">取消售后</router-link>
              </div>
              <div class="btn-group" v-if="item.status !== '200' && item.status !== '400'">
                <div class="button cancel-btn" v-if="item.status === '100'" @click="goCancelConfirm(item)">
                  <span class="const-text">取消订单</span>
                </div>
                <div class="button" v-if="item.status === '100'">
                  <div @click="goPay(item.code)">
                    <span class="const-text">去付款</span>
                  </div>
                </div>
                <div class="button" v-if="item.status ===  '300'" @click="goReceiveConfirm(item)">确认收货</div>
                <div class="button" v-if="item.status === '500' && !item.comment_id">
                  <router-link
                    :to="`/order-comment/${item.id}`">
                    <span class="const-text">去评价</span>
                  </router-link>
                </div>
                <div class="button" v-if="item.status >= '400' && item.comment_id">
                  已评价
                </div>
              </div>
            </div>
          </div>
          <!--灰色线-->
          <div class="divider"></div>
        </div>
      </div>
    </fine-art-scroller>
    <div v-transfer-dom>
      <confirm v-model="cancelModal"
               title="取消订单确认"
               confirm-text="确定取消"
               cancel-text="下次再说"
               @on-confirm="goCancel">
        <p>您确定取消订单吗。</p>
      </confirm>
    </div>
    <div v-transfer-dom>
      <confirm v-model="receiveModal"
               title="订单确认收货"
               confirm-text="确定收货"
               cancel-text="下次再说"
               @on-confirm="goReceive">
        <p>您确定订单已收货吗。</p>
      </confirm>
    </div>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, fetchWXCodeForPay } from '@/common/js/utils'
import { FineArtSearch, FineArtScroller } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'

export default{
  name: `${COMPONENT_PREFIX}PageMyOrder`,
  data () {
    return {
      order: {},
      cancelModal: false,
      receiveModal: false,
      orderList: {
        data: [],
        current_page: 1,
        has_next: true,
        last_page: 1
      },
      pageConfig: {
        page: 1, // 页码
        keyword: '', // 搜索关键字，商品名称或者订单编号
        status: ''// 订单状态
      }
    }
  },
  created () {
    this.initPage()
  },
  activated () {
    this.$store.commit('MODIFY_PAGE_NAME', '我的订单')
  },
  methods: {
    goToDetail (id) {
      this.$router.push({path: `/order-detail/${id}`})
    },
    goPay (orderCode) {
      fetchWXCodeForPay(orderCode)
    },
    async initPage () {
      this.orderList = await api.orderMyList(this.pageConfig)
    },
    // 刷新当前预约新品列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.initPage()
      cb()
    },
    // 加在更多新品列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.orderList.has_next) {
        return cb()
      }

      this.pageConfig.page = this.orderList.current_page + 1
      // 资源列表分页
      let dataList = await api.orderMyList(this.pageConfig)
      this.orderList.data = [...this.orderList.data, ...dataList.data]
      this.orderList.current_page = dataList.current_page
      this.orderList.has_next = dataList.has_next
      cb()
    },
    goCancelConfirm (order) {
      this.order = order
      this.cancelModal = true
    },
    async goCancel () {
      let response = await api.orderBuyerUpdateStatus(this.order.id, 1000)
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_ORDER_CANCEL_SUCCESS'], type: 'success' })
        this.order.status = '1000'
        this.order.status_desc = '已取消'
      }
    },
    goReceiveConfirm (order) {
      this.order = order
      this.receiveModal = true
    },
    async goReceive () {
      let response = await api.orderBuyerUpdateStatus(this.order.id, 400)
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_ORDER_RECEIVE_SUCCESS'], type: 'success' })
        this.order.status = '400'
        this.order.status_desc = '交易成功'
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-my-order`
    },
    hasData () {
      return this.orderList.data.length > 0
    }
  },
  components: {
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-my-order
    .order-wrap div:last-child .divider
      display: none
    .red
      color: $red
    .yellow
      color: $orange
    .grey
      color: $grey3
    .order-item
      padding: 0 30px 0px 30px
      .order-num
        height: 82px
        font-size: 24px
        line-height: 82px
        color: $grey3
      .goods-detail
        display: flex
        flex-direction: row
        justify-content: space-between
        align-items: center
        padding: 20px 0 20px 0
        .img-wrap
          width: 30%
          img
            min-height: 160px
            min-width: 160px
        .name
          font-size: 28px
          line-height: 40px
          color: $black2
          width: 56%
          text-align: left
          margin-left: -30px
        .state-text
          font-size: 24px
          line-height: 33px
          width: 14%
          text-align: right
          color: $grey3
      .other-operation
        padding: 20px 0 20px 0
        display: flex
        flex-direction: row
        justify-content: space-between
        align-items: center
        .order-service-btn
          font-size: 24px
        .price
          font-size: 26px
          line-height: 37px
          color: $black1
        .btn-group
          display: flex
          &:empty
            display: none
          .button
            height: 56px
            width: 150px
            margin-left: 20px
            text-align: center
            vertical-align: center
            font-size: 26px
            line-height: 56px
            color: $white
            background-color: $orange
            border-radius: 4px
            &.cancel-btn
              border: 1.4px solid $grey2
              background-color: transparent
              .const-text
                color: $grey3
            .const-text
              color: $white
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
</style>
