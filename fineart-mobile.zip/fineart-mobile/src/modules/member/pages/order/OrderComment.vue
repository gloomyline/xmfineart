<template>
  <div :class="classes">
    <!--所购买商品信息-->
    <div class="selected-product">
      <div class="selected-item">
        <div class="product-detail">
          <div class="img-wrap">
            <img :src="orderDetail.goods_thumbnail" width="100%" height="100%">
          </div>
          <div class="detail">
            <p class="name">{{ orderDetail.goods_name }}</p>
            <div class="price-count">
              <div class="price">&yen;{{ orderDetail.pay_total }}</div>
              <div class="count">
                <div class="count-num">x{{ orderDetail.number }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--评分-->
    <div class="give-mark">
      <div class="const-text">评分</div>
      <rater v-model="comment.star" star="<span class='fy-icon-sel-collection'></span>" :margin="9" :font-size="16" active-color="#FFD374"></rater>
    </div>
    <!--评价框-->
    <div class="give-mark-area">
      <!--<textarea  placeholder="分享体验评价，给他人一个参考~"></textarea>-->
      <x-textarea
        placeholder='分享体验评价，给他人一个参考~'
        v-model="comment.content"
        :rows="8"
        required></x-textarea>
    </div>
    <!--上传图片区-->
    <div class="imgs">
      <!--图片展示区-->
      <div class="img-item fy-1px" v-for="(item, index) in comment.comment_images_cdn" :key="index" :class="{'mar-left': index % 3 > 0}">
        <img :src="item" width="100%" height="100%">
        <div class="delete-icon">
          <i class="fy-icon-off" @click="reduceImgs(index)"></i>
        </div>
      </div>
      <!--图片添加按钮-->
      <fine-art-upload
        class="add-img"
        :height = "214"
        :width = "214"
        v-if="comment.comment_images.length < 6"
        :max-size="ossImage.max_size"
        :data="ossImage.data"
        :action="ossImage.host"
        :format="ossImage.format"
        :accept="ossImage.accept"
        :beforeUpload="beforeUploadImage"
        :on-success="successImage"
        :class="{'mar-left': imgLength % 3 !== 0}">
        <div class="upload-box"></div>
      </fine-art-upload>
    </div>
    <div class="button" @click="handlerSubmit()">提交</div>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtUpload } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'

export default {
  name: `${COMPONENT_PREFIX}PageOrderdComment`,
  data () {
    return {
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      data4: 1,
      orderDetail: {},
      comment: {
        code: '',
        star: 5, // 商品评价星级
        content: '', // 商品评价内容
        score: 20, // 商品评价评分
        // 上传的图片，可以上传后放入该数组
        comment_images: [
        ],
        comment_images_cdn: [
        ]
      }
    }
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '订单评价')
    this.initPage()
  },
  watch: {
    comment: {
      handler: function (newVal) {
        newVal.score = newVal.star * 20
      },
      deep: true
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-order-comment`
    },
    imgLength () {
      return this.comment.comment_images_cdn.length
    }
  },
  methods: {
    // 图片上传之前
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'comment_image', this.ossImage)
    },
    // 图片上传成功，将图片地址加入comment_images，comment_images_cdn
    successImage (res) {
      this.comment.comment_images.push(res.results.file_url)
      this.comment.comment_images_cdn.push(res.results.file_url_cdn)
    },
    reduceImgs (index) {
      this.comment.comment_images.splice(index, 1)
      this.comment.comment_images_cdn.splice(index, 1)
    },
    async initPage () {
      this.orderDetail = await api.orderMyDetail(this.id)
      this.comment.code = this.orderDetail.code
    },
    async handlerSubmit () {
      if (!this.comment.star) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_ORDER_COMMENT_STAR_EMPTY'], type: 'warn' })
        return false
      }
      if (!this.comment.content) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_ORDER_COMMENT_CONTENT_EMPTY'], type: 'warn' })
        return false
      }
      this.result = await api.insertMemberGoodsComment(this.comment)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['ACCOUNT_ORDER_COMMENT_SUCCESS'], type: 'success'})
        this.$router.push({path: '/my-order'})
      }
    }
  },
  components: {
    FineArtUpload
  }
}
</script>
<style lang="stylus">
  .{$cls_prefix}-page-order-comment
    .selected-product
      .selected-item
        padding: 30px 30px 0 30px
        display: flex
        justify-content: left;
        flex-direction: row
        position: relative
        height: 220px
        .product-detail
          display: flex
          justify-content: left;
          flex-direction: row
          padding-bottom: 20px
          .img-wrap
            width: 160px
            height: 160px
            img
              min-width: 160px
              min-height: 160px
          .detail
            margin-left: 20px
            .name
              width: 442px
              padding-top: 10px
              font-size: 28px
              line-height: 40px
              color: $black2
            .price-count
              position: absolute
              bottom: 35px
              display: flex
              justify-content: space-between
              width: 510px
              .price
                font-size: 26px
                line-height: 37px
                color: $black1
              .count
                .count-num
                  font-size: 26px
                  line-height: 37px
                  color: $grey3
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .give-mark
      padding: 20px 30px 20px 30px
      display: flex
      flex-direction: row
      justify-content: space-between
      align-items: center
      position: relative
      .const-text
        font-size: 26px
        line-height: 37px
        color: $black2
      .star-rough
        height: 40px
        width: 284px
        text-align: right
        vertical-align: center
        font-size: 38px
        line-height: 40px
        color: $orange
    .give-mark-area
      width: 690px
      margin: 0 30px 0 30px
      border: 1.4px solid $grey
      border-radius: 4px
      .weui-cell
        height: 275px
        .weui-cell__bd
          height: 100%
          line-height: 48px
          textarea
            height: 100%
            padding: 0
    .imgs
      display: flex
      flex-direction: row
      justify-content: left
      align-items: center
      flex-wrap: wrap
      margin: 35px 30px 0 30px
      .mar-left
        margin-left: 24px
      .upload-box
        display: flex
        height: 214px
        width: 214px
        flex-direction: column
        justify-content: center
        align-items: center
        border-radius: 6px
        background: $greyF9 url('../../../../assets/imgs/mall/icon-tgupload.png') center center no-repeat
        background-size: 122px auto
      .add-img,.img-item
        height: 214px
        width: 214px
        margin-bottom: 24px
        font-size: 24px
        line-height: 33px
        color: $grey3
        text-align: center
        border-radius: 6px
        &>img
          border-radius: 6px
        .const-test
          margin-top: 8px
      .img-item
        position: relative
        .delete-icon
          absolute: top right
          height: 40px
          width: 40px
          border-radius: 0 6px 0 6px
          vertical-align: center
          background: rgba(102,102,102,0.7)
        .fy-icon-off
          color: $white
          font-size: 18px
          line-height: 40px
    .button
      height: 80px;
      width: 690px;
      background-color: $orange
      font-size: 30px
      text-align: center
      line-height: 80px
      color: $white
      margin-left: 30px
      border-radius: 4px
</style>
