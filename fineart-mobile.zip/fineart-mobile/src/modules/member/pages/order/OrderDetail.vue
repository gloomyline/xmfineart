<template>
  <div :class="classes">
    <!--装饰线-->
    <div class="decorate-line-wrap">
    </div>
    <!--买家信息-->
    <div class="buyer-info">
      <div class="name">{{ orderDetail.to_name | labelFormatter(3) }}</div>
      <div class="phone-address">
        <div class="phone">{{ orderDetail.to_mobile }}</div>
        <div class="address">{{ orderDetail.to_address_desc }}</div>
      </div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--所购买商品信息-->
    <div class="selected-product">
      <div class="selected-item">
        <a :href="`mall.html#/goods-detail/${orderDetail.goods_id}/${orderDetail.mall_store_id_order}`" class="product-detail fy-1px-b">
          <div class="img-wrap">
            <img :src="orderDetail.goods_thumbnail" width="100%" height="100%">
          </div>
          <div class="detail">
            <p class="name">{{ orderDetail.goods_name }}</p>
            <div class="price-count">
              <div class="price">&yen;{{ orderDetail.total }}</div>
              <div class="count">
                <div class="count-num">x{{ orderDetail.number }}</div>
              </div>
            </div>
          </div>
        </a>
      </div>
    </div>
    <div class="other-operation" v-if="orderDetail.status === '100'">
      <div class="const-text">待付款</div>
      <div class="button" @click="goCancelConfirm()">
        取消订单
      </div>
    </div>
    <div class="other-operation" v-else-if="orderDetail.status === '200'">
      <div class="const-text">待发货</div>
      <div class="button">
        <router-link :to="`/sale-service/${orderDetail.id}`" class="link-text">
          申请售后
        </router-link>
      </div>
    </div>
    <div class="other-operation" v-else-if="orderDetail.status === '300'">
      <div class="const-text">待收货</div>
      <div class="button">
        <router-link :to="`/sale-service/${orderDetail.id}`" class="link-text">
          申请售后
        </router-link>
      </div>
    </div>
    <div class="other-operation" v-else-if="orderDetail.status === '400'">
      <div class="const-text">已收货</div>
      <div class="button">
        <router-link :to="`/sale-service/${orderDetail.id}`" class="link-text">
          申请售后
        </router-link>
      </div>
    </div>
    <div class="other-operation" v-else-if="orderDetail.status === '500'">
      <div class="const-text">交易完成</div>
      <div class="button" v-if="!orderDetail.comment_id">
        <router-link :to="`/order-comment/${orderDetail.id}`" class="link-text">
         去评价
        </router-link>
      </div>
    </div>
    <div class="other-operation" v-else-if="orderDetail.status === '600'">
      <div class="const-text">已退货/换货</div>
    </div>
    <div class="other-operation" v-else-if="orderDetail.status === '1000'">
      <div class="const-text">已取消</div>
    </div>
    <div class="other-operation" v-else>
      <div class="const-text"></div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--订单号和下单时间-->
    <div class="order-num-and-time">
      <div class="num-and-time">
        <div>
          <span class="const-text">订 单 号 ：</span>
          <span class="num-text">{{ orderDetail.code }}</span>
        </div>
        <div class="time">
          <span class="const-text">下单时间：</span>
          <span class="num-text">{{ orderDetail.order_at }}</span>
        </div>
      </div>
      <div class="copy-button" @click="copyCode(orderDetail.code)">复制</div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--快递信息-->
    <div class="company-ship-order fy-1px-b">
      <div v-if="express.code">
        <span class="const-text">物流公司：</span>
        <span class="company-text">{{ express.name }}</span>
      </div>
      <div class="ship-order" v-if="express.code">
        <span class="const-text">运  单  号：</span>
        <span class="ship-order-text">{{ express.code }}</span>
      </div>
      <div class="info-card-content" v-else>暂无物流信息，请稍后查询</div>
      <div class="button" @click="showExpress = true">[获取最新动态]</div>
    </div>
    <!--物流信息-->
    <div class="ship-info fy-1px-l" v-if="showExpress">
      <div class="flow" v-for="(item, index) in express.list" :key="index">
        <div class="time">
          <p>{{item.time[0]}}</p>
          <p>{{item.time[1]}}</p>
        </div>
        <div class="info">{{item.content}}</div>
        <div class="circle"></div>
      </div>
    </div>
    <!--底部栏-->
    <div class="bottom-bar fy-1px-t">
      <div class="all-count">
        实付：<span class="price">&yen;{{ orderDetail.pay_total }}</span>
      </div>
      <div class="go-to-bill">
        <div v-if="orderDetail.status === '100'">
          <div @click="goPay(orderDetail.code)">
            <span class="const-text">去付款</span>
          </div>
        </div>
        <div v-else-if="orderDetail.status === '300'">
          <span class="const-text" @click="getGoodsConfirm">确认收货</span>
        </div>
      </div>
    </div>
    <div v-transfer-dom>
      <confirm v-model="cancelModal"
               title="取消订单确认"
               confirm-text="确定取消"
               cancel-text="下次再说"
               @on-confirm="goCancel">
        <p>您确定取消订单吗。</p>
      </confirm>
    </div>
    <div v-transfer-dom>
      <confirm v-model="getGoddsModal"
               title="收货确认"
               confirm-text="确认收货"
               cancel-text="取消"
               @on-confirm="getGoods">
        <p>您确认收到货物吗。</p>
      </confirm>
    </div>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtSearch, FineArtScroller } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'
import { GLOBAL_COPY_SUCCESS } from 'assets/data/message'
export default{
  name: `${COMPONENT_PREFIX}PageOrderDetail`,
  data () {
    return {
      cancelModal: false,
      orderDetail: {},
      express: {
        code: null,
        company: null,
        type: null,
        list: []
      },
      showExpress: false,
      getGoddsModal: false
    }
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '订单详情')
    this.initPage()
  },
  watch: {
    showExpress (newVal) {
      if (newVal) {
        this.fetchExpressDetail()
      }
    }
  },
  methods: {
    goPay (orderCode) {
      window.location = `mall.html#/payment/${orderCode}`
    },
    async initPage () {
      this.orderDetail = await api.orderMyDetail(this.id)
      if (this.orderDetail.express_code !== null) {
        this.express.code = this.orderDetail.express_code
        this.express.company = this.orderDetail.express_company
        this.express.name = this.$store.state.member.expressCompany[this.express.company]
      }
    },
    async fetchExpressDetail () {
      if (this.express.code && this.express.company) {
        let res = await api.expressDetail(this.express.code, this.express.company)
        if (res.list.length) {
          this.express.list = res.list
          this.express.list.map((item) => {
            item.time = item.time.trim().split(' ')
          })
        }
      }
    },
    goCancelConfirm () {
      this.cancelModal = true
    },
    getGoodsConfirm () {
      this.getGoddsModal = true
    },
    async goCancel () {
      let response = await api.orderBuyerUpdateStatus(this.id, 1000)
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_ORDER_CANCEL_SUCCESS'], type: 'success' })
        this.initPage()
      }
    },
    async getGoods () {
      let response = await api.orderBuyerUpdateStatus(this.id, 400)
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_ORDER_GET_GOODS_SUCCESS'], type: 'success' })
        this.initPage()
      }
    },
    copyCode (code) {
      this.$copyText(code).then((e) => {
        // copy success
        this.$store.commit('ADD_MESSAGE', {msg: GLOBAL_COPY_SUCCESS})
      }, (e) => {
        // copy fail
        console.log(e)
      })
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-order-detail`
    }
  },
  filters: {
    labelFormatter (str, length) {
      if (typeof str !== 'string') return
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-order-detail
    font-family: PingFangSC, Microsoft Yahei
    position: relative
    padding-bottom: 88px
    .decorate-line-wrap
      height: 12px
      background-image: url("../../../../assets/imgs/mall/icon-check-bill-decorate-line@2x.png")
      background-repeat: no-repeat
      background-size: cover
    .buyer-info
      padding: 30px
      display: flex
      flex-direction: row
      justify-content: left
      align-items: top
      .name
        font-size: 28px
        line-height: 40px
        color: $black1
      .phone-address
        margin-left: 20px
        .phone
          font-size: 28px
          line-height: 40px
          color: $black1
        .address
          font-size: 24px
          line-height: 33px
          color: $black2
          margin-top: 8px
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .selected-product
      .selected-item
        padding: 30px 30px 0 30px
        display: flex
        justify-content: left;
        flex-direction: row
        .product-detail
          display: flex
          justify-content: left;
          flex-direction: row
          position: relative
          padding-bottom: 30px
          .img-wrap
            width: 160px
            height: 160px
            img
              min-width: 160px
              min-height: 160px
          .detail
            width: 510px
            margin-left: 20px
            .name
              padding-top: 10px
              font-size: 28px
              line-height: 40px
              color: $black2
            .price-count
              position: absolute
              bottom: 35px
              display: flex
              justify-content: space-between
              width: 510px
              .price
                font-size: 26px
                line-height: 37px
                color: $black1
              .count
                .count-num
                  font-size: 26px
                  line-height: 37px
                  color: $grey3
    .other-operation
      padding: 20px 30px 20px 30px
      display: flex
      flex-direction: row
      justify-content: space-between
      align-items: center
      .const-text
        display: inline-block
        width: 110px
        font-size: 26px
        line-height: 37px
        color: $red
      .button
        height: 56px
        width: 150px
        text-align: center
        vertical-align: center
        font-size: 26px
        line-height: 56px
        border-radius: 4px
        border: 1.4px solid $grey2
        color: $grey3
        .link-text
          color: $grey3
    .order-num-and-time
      padding: 30px 30px 24px 30px
      display: flex
      flex-direction: row
      justify-content: space-between
      .num-and-time
        font-size: 24px
        line-height: 33px
        color: $grey3
        .time
          margin-top: 6px
      .copy-button
        height: 35px
        width: 70px
        font-size: 22px
        line-height: 35px
        border-radius: 4px
        text-align: center
        color: $grey3
        border: 1.4px solid $grey2
    .company-ship-order
      font-size: 24px
      line-height: 33px
      color: $grey3
      margin: 30px 30px 0px 30px
      padding-bottom: 24px
      .ship-order
        margin-top: 6px
    .bottom-bar
      position: fixed
      bottom: 0
      width: 100%
      height: 88px
      font-size: 0
      background-color: $white
      .all-count,.go-to-bill
        display: inline-block
        vertical-align: top
        text-align: center
        line-height: 88px
      .all-count
        width: 66%
        font-size: 28px
        color: $black2
        text-align: left
        padding-left: 30px
        .price
          font-size: 28px
          color: $orange
      .go-to-bill
        width: 34%
        background-color: $orange
        .const-text
          font-size: 28px
          color: $white
    .grey-area
      width: 100%
      height: 100%
      background-color: $grey4
    .ship-info
      margin: 21px 30px 0 30px
      .flow
        display: flex
        flex-direction: row
        justify-content: space-between
        align-items: top
        padding-left: 27px
        padding-bottom: 20px
        position: relative
        &:first-child
          .time,.info
            color: $black1
          .circle
            background-color: $orange
        .time,.info
          font-size: 24px
          line-height: 33px
          color: $grey3
        .time
          height: 66px
        .info
          width: 492px
          margin-left: 32px
        .circle
          width: 14px
          height: 14px
          border-radius: 7px
          background-color: $grey6
          position: absolute
          left: -7px
          top: 8px
</style>
