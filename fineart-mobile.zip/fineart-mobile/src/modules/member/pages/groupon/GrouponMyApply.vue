<template>
  <div :class="classes">
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="applyList.data"
      :has-data="hasData"
      :has-more="applyList.has_next">
      <div class="goods-list-wrap">
        <ul class="goods-list">
          <li class="goods-item"
              @click="goToGrouponDetail(item)"
              v-for="(item, index) in applyList.data"
              :key="index">
            <div class="img-wrap"><img :src="item.thumbnail" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ item.name }}</p>
              <p class="sub-title">团购属性：{{ item.attribute }}</p>
              <div class="info">
                <span class="price">{{ item.price }}</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtScroller } from '@/components'
import api from '@/modules/member/api'

export default {
  data () {
    return {
      name: `${COMPONENT_PREFIX}GrouponMyApply`,
      applyList: {
        data: [],
        total: 0,
        has_next: false
      },
      pageConfig: {
        page: 1
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-groupon-my-apply`
    },
    hasData () {
      return this.applyList.total > 0
    }
  },
  created () {
    this.initGrouponMyList()
  },
  methods: {
    // 初始化我发布的团购
    async initGrouponMyList () {
      this.applyList = await api.fetchGrouponMyApply(this.pageConfig)
    },
    // 刷新当前列表数据
    async refresh (cb) {
      this.initGrouponMyList()
      cb()
    },
    // 加在更多列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.applyList.has_next) return cb()
      this.pageConfig.page += 1
      const res = await api.fetchGrouponMyApply(this.pageConfig)
      this.applyList.data = [ ...this.applyList.data, ...res.data ]
      this.applyList.total = res.total
      this.applyList.has_next = res.has_next
      cb()
    },
    // 前往团购详情页
    goToGrouponDetail (item) {
      if (item.status === '300') {
        window.location = `mall.html#/groupon/detail/${item.id}`
      }
    }
  },
  components: {
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-groupon-my-apply
  background: $grey5
  .goods-list-scroller
    top: 194px
    .fine-art-empty
      width: 100%
      text-align:center
      absolute: top 0 bottom  0
    .cube-scroll-wrapper
      background: $grey5
    .cube-scroll-list-wrapper
      background: $grey5
      .goods-list
        display: flex
        flex-direction: column
        .goods-item
          display: flex
          width: 100%
          height: 240px
          padding: 30px
          background: $white
          border-bottom: 1px solid $grey
          &:last-child
            border: none
          .img-wrap
            width: 180px
            height: 180px
            overflow: hidden
            border-radius: 6px
            background: $grey4
          .desc
            font-size: 0
            width: 520px
            overflow: hidden
            margin-left: 20px
            padding-top: 10px
            .name
              margin-bottom: 20px
              line-height: 42px
              font-size: 30px
              color: $black1
              {ellipse}
            .sub-title
              width: 100%
              color: $grey2
              font-size: 24px
              line-height: 33px
              margin-bottom: 22px
              {ellipse}
            .info
              display: flex
              justify-content: space-between
              align-items: center
              .price
                line-height: 33px
                font-size: 24px
                color: $black2
</style>
