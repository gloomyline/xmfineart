<template>
  <div :class="classes">
    <div class="top-card">
      <!-- 搜索框 -->
      <div class="search-bar" v-if="!goods_id">
        <form class="search-box" action="javascript: void(0)">
          <span class="icon-search icon-search"></span>
          <input class="search-input" ref="inputEle" @keyup.13="initSearch()" v-model="pageConfig.keyword" type="search" placeholder="输入准确的商品名称搜索"/>
          <span class="icon" v-if="pageConfig.keyword" @click="clearKey">
          <i class="icon-clear"></i>
        </span>
        </form>
        <x-button type="primary" plain class="btn-cancel" @click.native="initSearch()">搜索</x-button>
      </div>
      <!-- 绑定的商品名称、tip -->
      <div class="bind-info">
        <p class="good-name">
          <span class="const-text">需要绑定的团购:</span>
          <span class="name">{{ grouponName | labelFormatter }}</span>
        </p>
        <!-- tip -->
        <div class="tip">本功能可将您发布的团购和您发布的商品绑定。绑定后，团购详情页将有[立即购买]按钮，用户点击可前往商品详情页，直接购买商品。</div>
      </div>
      <!-- 选择商品（状态为发布中） -->
      <p class="title">{{ titleText }}</p>
    </div>
    <!-- 获取的自有商品列表-->
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      :class= "{'is-bind': goods_id}"
      @refresh="initSearch"
      @load-more="loadMore"
      :list="goodsList.data"
      :has-data="hasData"
      :has-more="goodsList.has_next">
      <div class="goods-list-wrap">
        <ul class="goods-list">
          <li class="goods-item"
              :class="{'bind-goods-item': goods_id}"
              v-for="(item, index) in goodsList.data"
              :key="index">
            <div class="checker"
                 v-if="!goods_id"
                 @click="handleCheck(item)" >
              <check-icon :value="isChecked(item)"></check-icon>
            </div>
            <div class="goods-item-wrap" @click="goToGoodsDetail(item)">
              <div class="img-wrap"><img :src="item.goods_thumbnail" width="100%" height="100%"></div>
              <div class="desc">
                <p class="name">{{ item.goods_name | labelFormatter(29) }}</p>
                <p class="price">&yen;{{ item.goods_price }}</p>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </fine-art-scroller>
    <div class="handle-box" v-if="!goods_id && hasData">
      <x-button type="primary" @click.native="handleBind">绑定</x-button>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtScroller } from 'components'
import * as MSG from 'assets/data/message.js'
import api from '@/modules/member/api'

export default {
  data () {
    return {
      name: `${COMPONENT_PREFIX}PageGrouponBind`,
      goodsList: {
        data: [],
        total: 0,
        has_next: false
      },
      pageConfig: {
        page: 1,
        keyword: ''
      },
      // 绑定商品请求参数
      bindParam: {
        groupon_id: '', // 团购ID
        mall_goods_id: '', // 商品ID
        mall_store_id: '' // 店铺ID
      }
    }
  },
  props: ['id', 'goods_id'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-groupon-bind`
    },
    hasData () {
      return this.goodsList.total > 0
    },
    grouponName () {
      return this.$store.state.member.grouponName
    },
    titleText () {
      return this.goods_id ? '已绑定商品' : '选择商品（状态为发布中）'
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '绑定商品')
    this.initSearch()
  },
  methods: {
    // 初始化获取或搜索商品自由商品列表
    async initSearch (cb) {
      if (this.goods_id) {
        this.pageConfig.goods_id = this.goods_id
      }

      this.pageConfig.page = 1
      this.bindParam = {
        groupon_id: '',
        mall_goods_id: '',
        mall_store_id: ''
      }
      this.goodsList = await api.fetchMemberGoods(this.pageConfig)
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
      if (cb) {
        cb()
      }
    },
    // 加载更多
    async loadMore (cb) {
      if (!this.goodsList.has_next) return cb()
      this.pageConfig.page += 1
      const res = await api.fetchMemberGoods(this.pageConfig)
      this.goodsList.data = [ ...this.goodsList.data, ...res.data ]
      this.goodsList.total = res.total
      this.goodsList.has_next = res.has_next
      cb()
    },
    // 清除关键词
    clearKey () {
      this.pageConfig.keyword = ''
    },
    // 前往商品详情页
    goToGoodsDetail (item) {
      window.location = `mall.html#/goods-detail/${item.goods_id}/${item.store_id}`
    },
    // 选择商品
    handleCheck (item) {
      this.bindParam.mall_goods_id = item.goods_id
      this.bindParam.mall_store_id = item.store_id
    },
    isChecked (item) {
      return item.goods_id === this.bindParam.mall_goods_id && item.store_id === this.bindParam.mall_store_id
    },
    // 绑定商品
    async handleBind () {
      if (this.bindParam.mall_goods_id) {
        this.bindParam.groupon_id = this.id
        const res = await api.handleGrouponBind(this.bindParam)
        if (res.code === 200) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_GROUPON_BIND_SUCCESS'] })
        }
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: '请选择要绑定的商品' })
      }
    }
  },
  filters: {
    labelFormatter (str = '', length = 18) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-groupon-bind
  .top-card
    fixed: top 94px left
  .search-bar
    display: flex
    padding: 20px 0 0 30px
    .search-box
      display: flex
      width: 604px
      height: 66px
      border-radius: 34px
      background-color: $grey4
      .icon-search
        display: flex
        justify-content: center
        align-items: center
        width: 70px
        height: 66px
        background: url('../../../../assets/imgs/mall/icon-tgsearch.png') center center no-repeat
        background-size: 28px auto
      .icon
        display: flex
        justify-content: center
        align-items: center
        width: 76px
        height: 66px
        .icon-clear
          width: 28px
          height: 28px
          background-repeat: no-repeat
          background-size: cover
          bg-img('../../../../assets/imgs/mall/icon-clear')
      .search-input
        width: 478px
        height: 66px
        padding: 16px 0
        color: $black1
        font-size: 28px
        border: none
        outline: none
        background-color: rgba(0, 0, 0, 0)
        &::-webkit-input-placeholder
          font-size: 28px
          color: $grey2
    .btn-cancel.weui-btn
      width: 116px
      padding-right: 30px
      padding-left: 0
      text-align: right
      font-size: 28px
      line-height: 66px
      border: none
  .bind-info
    padding: 40px 30px 0 30px
    .good-name
      font-size: 26px
      line-height: 37px
      .const-text
        color: $grey3
      .name
        color: $black1
    .tip
      width: 100%
      color: $grey2
      font-size: 24px
      line-height: 33px
      background: $grey5
      padding: 20px 25px
      margin: 25px 0 50px 0
      border-radius: 4px
  .title
    color: $grey2
    font-size: 24px
    line-height: 33px
    padding: 0 30px
  .handle-box
    width: 100%
    padding: 30px
    fixed: bottom left
    .weui-btn
      line-height: 80px
  .goods-list-scroller
    top: 520px
    bottom: 150px
    &.is-bind
      top 420px
    .goods-list
      display: flex
      flex-direction: column
      .goods-item
        display: flex
        align-items: center
        width: 100%
        height: 220px
        padding: 0
        background: $white
        &.bind-goods-item
          padding: 30px
        &:last-child .goods-item-wrap
          border: none
        .checker
          padding: 0 30px
          .vux-check-icon
            margin: 0
            [class^="weui-icon"]
              font-size: 39px
              &:before
                margin: 0
        .goods-item-wrap
          display: flex
          width: 620px
          padding: 30px 0
          border-bottom: 1px solid $grey
          .img-wrap
            width: 160px
            height: 160px
            overflow: hidden
            background: $grey4
          .desc
            display: flex
            width: 442px
            margin: 8px 0 8px 20px
            flex-direction: column
            justify-content: space-between
            .name
              color: $black2
              font-size: 28px
              line-height: 40px
            .price
              color: $black1
              font-size: 26px
              line-height: 37px
</style>
