<template>
  <div :class="classes">
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="releaseList.data"
      :has-data="hasData"
      :has-more="releaseList.has_next">
      <div class="goods-list-wrap">
        <ul class="goods-list">
          <li class="goods-item"
              @click="goToGrouponDetail(item)"
              v-for="(item, index) in releaseList.data"
              :key="index">
            <div class="img-wrap"><img :src="item.thumbnail" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ item.name }}</p>
              <p class="sub-title">团购属性：{{ item.attribute }}</p>
              <div class="info">
                <span class="price">{{ item.price }}/{{ item.unit }}</span>
                <div class="handle-box">
                  <x-button disabled v-if="item.status === '100'">待审核</x-button>
                  <x-button disabled v-if="item.status === '200'">未审核通过</x-button>
                  <x-button plain
                            v-if="item.status === '300'"
                            @click.native.stop="handleGrouponStatus(item)">下架</x-button>
                  <x-button plain
                            v-if="item.status === '400'"
                            @click.native.stop="handleGrouponStatus(item)">上架</x-button>
                  <x-button type="primary"
                            @click.native.stop="gotoGrouponBind(item)">绑定商品</x-button>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </fine-art-scroller>
    <div class="bottom-bar" @click="goToGrouponRelease">发布团购</div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtScroller } from '@/components'
import * as MSG from 'assets/data/message.js'
import api from '@/modules/member/api'

export default {
  data () {
    return {
      name: `${COMPONENT_PREFIX}GrouponMyRelease`,
      releaseList: {
        data: [],
        total: 0,
        has_next: false
      },
      pageConfig: {
        page: 1
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-groupon-my-release`
    },
    hasData () {
      return this.releaseList.total > 0
    }
  },
  created () {
    this.initGrouponMyList()
  },
  methods: {
    // 初始化我发布的团购
    async initGrouponMyList () {
      this.releaseList = await api.fetchGrouponMyList(this.pageConfig)
    },
    // 刷新当前列表数据
    async refresh (cb) {
      this.initGrouponMyList()
      cb()
    },
    // 加在更多列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.releaseList.has_next) return cb()
      this.pageConfig.page += 1
      const res = await api.fetchGrouponMyList(this.pageConfig)
      this.releaseList.data = [ ...this.releaseList.data, ...res.data ]
      this.releaseList.total = res.total
      this.releaseList.has_next = res.has_next
      cb()
    },
    // 前往团购详情页
    goToGrouponDetail (item) {
      if (item.status === '300') {
        window.location = `mall.html#/groupon/detail/${item.id}`
      }
    },
    // 前往团购发布页面
    goToGrouponRelease () {
      window.location = `/mall.html#/groupon/release`
    },
    // 前往绑定商品
    gotoGrouponBind (item) {
      this.$store.commit('member/MODIFY_GROUPON_NAME', item.name)
      if (!item.mall_goods_id) {
        this.$router.push(`/groupon/bind/${item.id}`)
      } else {
        this.$router.push(`/groupon/bind/${item.id}/${item.mall_goods_id}`)
      }
    },
    // 团购下架、下架
    async handleGrouponStatus (item) {
      const status = item.status === '300' ? '400' : '300'
      const res = await api.handleGrouponStatus({ groupon_id: item.id, status: status })

      if (res.code === 200) {
        const text = item.status === '300' ? 'MALL_GROUPON_OFF_SUCCESS' : 'MALL_GROUPON_UP_SUCCESS'
        item.status = item.status === '300' ? '400' : '300'
        this.$store.commit('ADD_MESSAGE', { msg: MSG[text] })
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: res.msg})
      }
    }
  },
  components: {
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-groupon-my-release
  background: $grey5
  .goods-list-scroller
    top: 194px
    bottom: 88px
    .fine-art-empty
      width: 100%
      text-align:center
      absolute: top 0 bottom  0
    .cube-scroll-wrapper
      background: $grey5
    .cube-scroll-list-wrapper
      background: $grey5
      .goods-list
        display: flex
        flex-direction: column
        .goods-item
          display: flex
          width: 100%
          height: 240px
          padding: 30px
          background: $white
          border-bottom: 1px solid $grey
          &:last-child
            border: none
          .img-wrap
            width: 180px
            height: 180px
            overflow: hidden
            border-radius: 6px
            background: $grey4
          .desc
            font-size: 0
            width: 520px
            overflow: hidden
            margin-left: 20px
            padding-top: 10px
            .name
              margin-bottom: 20px
              line-height: 42px
              font-size: 30px
              color: $black1
              {ellipse}
            .sub-title
              width: 100%
              color: $grey2
              font-size: 24px
              line-height: 33px
              margin-bottom: 22px
              {ellipse}
            .info
              display: flex
              justify-content: space-between
              align-items: center
              .price
                line-height: 33px
                font-size: 24px
                color: $black2
              .handle-box
                .weui-btn
                  margin: 0 0 0 20px
                  padding: 0 20px
                  color: $grey3
                  width: auto
                  height: 50px
                  font-size: 24px
                  line-height: 50px
                  border: 1.4px solid $grey
                  display: inline-block
                  &.weui-btn_primary
                    border: 1.4px solid $orange
                    background: none
                    color: $orange
  .bottom-bar
    position: fixed
    bottom: 0
    width: 100%
    height: 88px
    line-height: 88px
    font-size: 28px
    z-index: 1
    color: $white
    background: $orange
    text-align: center
</style>
