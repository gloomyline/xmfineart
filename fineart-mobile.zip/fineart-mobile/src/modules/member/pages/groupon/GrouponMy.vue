<template>
  <div :class="classes">
    <!-- tab bar-->
    <tab class="tab-bar" :line-width="3" custom-bar-width="24px">
      <tab-item @on-item-click="handlerTab" :selected="selectIndex === 1">发布的团购</tab-item>
      <tab-item @on-item-click="handlerTab" :selected="selectIndex === 2">参与的团购</tab-item>
    </tab>
    <div class="divider"></div>
    <router-view></router-view>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'

export default {
  data () {
    return {
      name: `${COMPONENT_PREFIX}PageGrouponMy`
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-groupon-my`
    },
    selectIndex () {
      return this.$route.meta.tabIndex
    }
  },
  methods: {
    handlerTab (index) {
      let attribute = index === 0 ? 'release' : 'apply'
      this.$router.push(`/groupon/my/${attribute}`)
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-groupon-my
  fixed: top 94px left
  background: $grey5
  .divider
    width: 100%
    height: 20px
    background-color: $grey5
  .tab-bar
    width: 750px
    height: 80px
    padding-top: 0
    .vux-tab-container
      height: 80px
      .vux-tab
        height: 80px
        .vux-tab-item
          font-size: 30px
          color: $black2
          background: transparent
          &.vux-tab-selected
            color: $orange3
        .vux-tab-bar-inner
          background: $orange3
</style>
