<template>
  <div :class="classes">
    <group class="account-wrap" label-align="left">
      <cell title="头像" is-link>
        <fine-art-upload :width="70" :height="70"
                         :max-size="ossImage.max_size"
                         :data="ossImage.data"
                         :action="ossImage.host"
                         :format="ossImage.format"
                         :accept="ossImage.accept"
                         :beforeUpload="beforeUploadImage"
                         :on-success="successImage">
          <div class="avatar-wrap">
            <img :src="member.avatar_cdn"/>
          </div>
        </fine-art-upload>
      </cell>
      <x-input
        title="手机号码"
        placeholder='请输入手机号'
        placeholder-align="right"
        text-align="right"
        v-model="member.mobile"
        :show-clear="false"
        readonly></x-input>
      <x-input
        title="昵称"
        placeholder="请输入昵称"
        placeholder-align="right"
        text-align="right"
        :should-toast-error="false"
        :show-clear="false"
        v-model="member.nickname"></x-input>
      <popup-radio title="性别" :options="genderList" v-model="gender" placeholder="请选择性别"></popup-radio>
      <x-input
        title="邮箱"
        type="text"
        :should-toast-error="false"
        placeholder='请输入常用邮箱'
        placeholder-align="right"
        text-align="right"
        v-model="member.email"
        :show-clear="false" ></x-input>
      <cell title="实名认证">
        <div class="attr-status-wrap">
          <span v-if="member.is_auth === '100'" @click="goAuth()">未认证</span>
          <span class="orange" v-else>已认证</span>
        </div>
      </cell>
      <x-button class="save-btn" type="primary" @click.native="handleSubmit()">保存</x-button>
    </group>
    <p class="tip">注：以上信息不会同步到个人主页。仅用于[商品评价]等非实名评论功能。</p>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, deepClone, validate } from '@/common/js/utils'
import { mapMutations, mapState } from 'vuex'
import { FineArtUpload } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api/index.js'
export default {
  name: `${COMPONENT_PREFIX}PageAccount`,
  data () {
    return {
      genderList: [{
        key: '200',
        value: '男'
      }, {
        key: '300',
        value: '女'
      }],
      gender: '',
      member: {},
      memberRule: {
        nickname: [
          { required: true, message: '请填写昵称' }
        ],
        gender: [
          { required: true, message: '请选择性别' }
        ],
        email: [
          { required: true, message: '请填写邮箱' },
          { type: 'email', message: '请填写正确的邮箱' }
        ]
      },
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      }
    }
  },
  created () {
    this.initPage()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-account`
    },
    ...mapState(['memberProfile'])
  },
  watch: {
    memberProfile: {
      handler (newVal) {
        this.member = deepClone(newVal)
        this.gender = this.member.gender === '100' ? '' : this.member.gender
        this.member.email = this.member.email === null ? '' : this.member.email
        this.member.nickname = this.member.nickname === null ? '' : this.member.nickname
      },
      deep: true
    }
  },
  methods: {
    async initPage () {
      this.modifyPageName('账号信息')
      this.member = deepClone(this.memberProfile)
      this.gender = this.member.gender === '100' ? '' : this.member.gender
    },
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    // 图片上传之前
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'member_avatar', this.ossImage)
    },
    // 图片上传成功
    successImage (res) {
      this.member.avatar_cdn = res.results.file_url_cdn
      this.member.avatar = res.results.file_url
    },
    // 提交表单
    async handleSubmit () {
      this.member.gender = this.gender
      const rules = await validate(this.member, this.memberRule)
      if (rules) {
        let res = await api.updateAccountProfile(this.member)
        if (res.code === 200) {
          this.$store.dispatch('fetchAccountProfile')
          this.$store.commit('ADD_MESSAGE', {msg: MSG['ACCOUNT_INFO_SAVE_SUCCESS'], type: 'success'})
        }
      }
    },
    goAuth () {
      this.$router.push({path: '/auth'})
    }
  },
  components: {
    FineArtUpload
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-account
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      padding-left: 0
      padding-right: 0
      .weui-label, .vux-label
        color: $black2
      .attr-status-wrap span
        color: $grey2
        font-size: 26px
        //font-weight: 300
        &.orange
          color: $orange
        &.black
          color: $black1
      .avatar-wrap
        display: flex
        align-items: center
        img
          height: 70px
          width: 70px
          border-radius: 50%
    .save-btn
      margin-top: 30px
  .tip
    color: $grey8
    padding: 30px
    font-size: 24px
    line-height: 33px
.weui-cell_radio.weui-check__label
  height: 98px
  padding: 0 30px
  font-size: 28px
  border-bottom: 1px solid $grey
</style>
