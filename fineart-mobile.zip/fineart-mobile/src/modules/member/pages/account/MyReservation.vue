<template>
  <div :class="classes">
    <fine-art-scroller
      class="goods-list-scroller"
      ref="scroller"
      :height="-94/75"
      @refresh="refresh"
      @load-more="loadMore"
      :list="myReservationList.data"
      :has-data="pageConfig.total"
      :has-more="pageConfig.has_next"
      :last-page="pageConfig.last_page">
      <swipeout class="goods-list-wrap">
        <swipeout-item
          transition-mode="follow"
          underlay-color="#C7C7C7"
          v-for="(myReservation, index) in myReservationList.data"
          :key="index">
          <div slot="right-menu">
            <swipeout-button @click.native="del(myReservation.foreshow_id)" type="warn">删除</swipeout-button>
          </div>
          <a class="goods-detail fy-1px-b" slot="content"  :href="`mall.html#/fore-show-detail/${myReservation.foreshow_id}`">
            <div class="goods-img">
              <img :src="myReservation.thumbnail" width="100%" height="100%">
            </div>
            <p class="goods-name">{{ myReservation.name | labelFormatter(32) }}</p>
          </a>
        </swipeout-item>
      </swipeout>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtScroller } from 'components'
import { mapMutations } from 'vuex'
import api from 'modules/mall/api/index.js'
import * as MSG from 'assets/data/message.js'
export default {
  name: `${COMPONENT_PREFIX}PageMyReservation`,
  data () {
    return {
      pageConfig: {
        page: 1,
        total: false,
        has_next: false,
        last_page: 1
      },
      myReservationList: {
        data: []
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-my-reservation`
    }
  },
  created () {
    this.modifyPageName('我的预约')
    this.initPage()
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    // 刷新当前预约新品列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.initPage()
      cb()
    },
    // 加在更多新品列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.pageConfig.has_next) {
        return cb()
      }
      this.pageConfig.page++
      let res = await api.foreShowMyReservation(this.page)
      this.myReservationList.data = [...this.myReservationList.data, ...res.data]
      this.pageConfig.has_next = res.has_next
      cb()
    },
    async del (id) {
      let params = {id: id, operation: 200}
      this.result = await api.fetchForeShowReservation(params)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_DELETED_SUCCESS'], type: 'success' })
        this.myReservationList.data = this.myReservationList.data.filter(item => item.foreshow_id !== id)
      }
    },
    async initPage () {
      this.myReservationList = await api.foreShowMyReservation(this.pageConfig.page)
      this.pageConfig.has_next = this.myReservationList.has_next
      this.pageConfig.last_page = this.myReservationList.last_page
      this.pageConfig.total = Boolean(this.myReservationList.total)
    }
  },
  filters: {
    labelFormatter (str = '', length = 28) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-my-reservation
  fixed: left top 94px
  width: 100%
  .goods-detail
    width: 100%
    height: 220px
    padding: 30px
    display: flex
    align-items: center
    &.fy-1px-b
      bottom: 1px
    .goods-img
      height: 160px
      width: 160px
      margin-right: 30px
      background: $grey4
    .goods-name
      color: $black1
      font-size: 28px
      font-weight: 300
      max-width: 500px
      line-height: 42px
  .vux-swipeout-button-warn
    font-size: 30px
    background: $red !important
</style>
