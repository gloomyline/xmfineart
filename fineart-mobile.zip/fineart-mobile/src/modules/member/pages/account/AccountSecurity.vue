<template>
  <div :class="classes">
    <group class="account-security-wrap" label-align="left">
      <cell title="账号信息" is-link link="/account">
        <div class="attr-status-wrap">
          <span>去编辑</span>
        </div>
      </cell>
      <cell title="实名认证" is-link link="/auth">
        <div class="attr-status-wrap">
          <span class="orange" v-if="memberProfile.is_auth === '200'">已认证</span>
          <span v-else>未认证</span>
        </div>
      </cell>
      <cell title="更换手机" is-link link="/change-mobile">
        <div class="attr-status-wrap">
          <span class="black">{{ memberProfile.mobile }}</span>
        </div>
      </cell>
      <cell title="绑定微信" is-link>
        <div class="attr-status-wrap">
          <span @click="bindTipModal = true" v-if="!memberProfile.unionid">去绑定</span>
          <span class="black" @click="unBindTipModal = true" v-else>已绑定</span>
        </div>
      </cell>
    </group>
    <!--提示弹窗：微信绑定-->
    <div v-transfer-dom>
      <confirm
        title="绑定微信"
        v-model="bindTipModal"
        confirm-text="确认"
        @on-confirm="bindWeChat">
        <p>绑定微信后，使用微信账号登录斐艺平台</p>
      </confirm>
    </div>
    <!--提示弹窗：微信解除绑定-->
    <div v-transfer-dom>
      <confirm
        title="确认解绑"
        v-model="unBindTipModal"
        confirm-text="确认"
        @on-confirm="unbindWeChat">
        <p>解绑微信账号后将无法继续使用它登录斐艺平台。</p>
      </confirm>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, WX_APP_ID } from '@/assets/data/constants'
import { hyphenCase, getQuery } from '@/common/js/utils'
import { mapMutations } from 'vuex'
import api from 'modules/member/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}PageAccountSecurity`,
  data () {
    return {
      bindTipModal: false,
      unBindTipModal: false
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-account-security`
    },
    memberProfile () {
      return this.$store.state.memberProfile
    }
  },
  created () {
    this._handleWxCode()
    this.modifyPageName('账号安全')
    if (this.$route.query.status === 'true') {
      this.commitWeChatInfo()
    } else if (this.$route.query.status === 'false') {
      this.$store.commit('ADD_MESSAGE', { msg: MSG.ACCOUNT_BIND_WX_ERROR, type: 'warn' })
    }
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    // 获取微信绑定重定向是携带的 code 参数，向服务器发起微信绑定请求
    async _handleWxCode () {
      const code = getQuery('code')
      if (!code) return
      const response = await api.wxBind({ code })
      if (response.code === 200) {
        const vm = this
        this.$store.commit('ADD_MESSAGE', {
          type: 'success',
          msg: MSG.ACCOUNT_BIND_WX_SUCCESS,
          cb () { vm.$store.dispatch('fetchAccountProfile') }
        })
      }
    },
    async unbindWeChat () {
      let res = await api.memberUnbindWx()
      if (res.code === 200) {
        const vm = this
        this.$store.commit('ADD_MESSAGE', {
          type: 'success',
          msg: MSG.ACCOUNT_UNBIND_WX_SUCCESS,
          cb () { vm.$store.dispatch('fetchAccountProfile') }
        })
      }
    },
    bindWeChat () {
      const redirectUri = encodeURIComponent('https://m.xmfineart.com/member.html#/account-security')
      window.location = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${WX_APP_ID}&redirect_uri=${redirectUri}&response_type=code&scope=snsapi_userinfo&#wechat_redirect`
    },
    async commitWeChatInfo () {
      let wechat = {
        openid_wx: this.$route.query.openid,
        avatar: this.$route.query.headimgurl || '',
        nickname: this.$route.query.nickname || '',
        gender: this.$route.query.gender || ''
      }
      let res = api.memberBindWx(wechat)
      if (res.code === 200) {
        this.$store.dispatch('fetchAccountProfile')
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-account-security
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      padding-left: 0
      padding-right: 0
      .weui-label, .vux-label
        color: $black2
      .attr-status-wrap span
        color: $grey2
        font-size: 26px
        &.orange
          color: $orange
        &.black
          color: $black1
</style>
