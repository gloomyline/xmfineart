<template>
  <div :class="classes">
    <tab class="tabs-menu" :line-width="2">
      <tab-item
        :selected="item.route === activeName"
        v-for="(item, index) in routeList"
        :key="index"
        @on-item-click="goToPage(item.route)">{{ item.name }}</tab-item>
    </tab>
    <div class="collection-list-container">
      <keep-alive>
        <router-view></router-view>
      </keep-alive>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { mapMutations } from 'vuex'

export default {
  name: `${COMPONENT_PREFIX}PageMyCollection`,
  data () {
    return {
      routeList: [
        {
          name: '商品',
          route: '/my-collection/collection-goods'
        },
        {
          name: '店铺',
          route: '/my-collection/collection-store'
        },
        {
          name: '资源',
          route: '/my-collection/collection-resource'
        },
        {
          name: '建筑',
          route: '/my-collection/collection-building'
        },
        {
          name: '作品',
          route: '/my-collection/collection-production'
        }
      ]
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-my-collection`
    },
    activeName () {
      return this.$route.path
    }
  },
  created () {
    this.modifyPageName('我的关注')
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    goToPage (route) {
      this.$router.push(route)
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-my-collection
  fixed: left top 94px
  width: 100%
  height: 100%
  .vux-tab-item
    flex: 0 0 20%!important
</style>
