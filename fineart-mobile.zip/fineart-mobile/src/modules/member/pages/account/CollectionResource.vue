<template>
  <div :class="classes">
    <fine-art-scroller
      class="resource-list-scroller"
      ref="scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="resourceList.data"
      :has-data="pageConfig.total"
      :has-more="pageConfig.has_next"
      :last-page="pageConfig.last_page">
      <swipeout class="resource-list-wrap">
        <swipeout-item
          transition-mode="follow"
          underlay-color="#C7C7C7"
          v-for="(item, index) in resourceList.data"
          :key="index">
          <div slot="right-menu">
            <swipeout-button @click.native="del(item.id)" type="warn">删除</swipeout-button>
          </div>
          <a class="resource-detail fy-1px-b" slot="content" :href="resourcePath(item.id, item.mode)">
            <div class="resource-img">
              <img :src="item.thumbnail" width="100%" height="100%">
            </div>
            <div class="resource-info">
              <p class="resource-name">{{ item.name | labelFormatter(28) }}</p>
            </div>
          </a>
        </swipeout-item>
      </swipeout>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtScroller } from 'components'
import api from 'modules/member/api/index.js'
import apiResource from 'modules/resources/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}CollectionResource`,
  data () {
    return {
      pageConfig: {
        object_type: '100',
        page: 1,
        total: false,
        has_next: false,
        last_page: 1
      },
      resourceList: {
        data: []
      }
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '我关注的')
    this.initPage()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-collection-resource`
    }
  },
  methods: {
    async initPage () {
      this.resourceList = await api.collectResourceList(this.pageConfig)
      this.pageConfig.has_next = this.resourceList.has_next
      this.pageConfig.last_page = this.resourceList.last_page
      this.pageConfig.total = Boolean(this.resourceList.total)
    },
    // 加在更多建筑列表数据
    async loadMore (cb) {
      if (!this.pageConfig.has_next) return cb()
      this.pageConfig.page++
      let res = await api.collectResourceList(this.pageConfig)
      this.pageConfig.has_next = res.has_next
      this.resourceList.data = [...this.resourceList.data, ...res.data]
      cb()
    },
    // 资源路径
    resourcePath (id, mode) {
      let path = ''
      switch (mode) {
      case '100':
        path = 'person'
        break
      case '200':
        path = 'company'
        break
      case '300':
        path = 'supplier'
        break
      case '400':
        path = 'brand'
        break
      }
      return `/resource.html#/${path}-detail/${id}`
    },
    // 刷新当前建筑列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.initPage()
      cb()
    },
    // 取消关注/收藏
    async del (id) {
      let res = await apiResource.handleResourceCollect({object_type: 100, object_id: id})
      if (res.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        this.resourceList.data = this.resourceList.data.filter(item => item.id !== id)
      }
    }
  },
  filters: {
    labelFormatter (str = '', length = 28) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-collection-resource
  .resource-detail
    width: 100%
    height: 220px
    padding: 30px
    display: flex
    align-items: center
    &.fy-1px-b
      bottom: 1px
    .resource-img
      height: 160px
      width: 160px
      margin-right: 30px
      background: $grey4
    .resource-name
      color: $black1
      font-size: 30px
      font-weight: 300
      max-width: 500px
      line-height: 42px
      margin-bottom: 20px
    .resource-tag
      color: $grey3
      font-size: 24px
      font-weight: 300
  .vux-swipeout-button-warn
    font-size: 30px
    background: $red !important
</style>
