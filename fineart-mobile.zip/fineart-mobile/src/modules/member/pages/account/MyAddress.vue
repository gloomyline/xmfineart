<template>
  <div :class="classes">
      <fine-art-my-address
        :pageType="pageType"
        @handle-add="goAddAddr"></fine-art-my-address>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { mapMutations } from 'vuex'
import { FineArtMyAddress } from 'components'

export default {
  name: `${COMPONENT_PREFIX}PageMyAddress`,
  data () {
    return {
      pageType: 2
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-my-address`
    }
  },
  created () {
    this.modifyPageName('收货地址')
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    goAddAddr () {
      this.$router.push(
        {
          name: 'AddressAdd',
          params: {
            flag: 2 // 2表示添加地址
          }
        }
      )
    }
  },
  components: {
    FineArtMyAddress
  }
}
</script>
<style lang="stylus">
</style>
