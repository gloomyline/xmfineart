<template>
  <div :class="classes">
    <fine-art-address-add @before-close="beforeClose()"></fine-art-address-add>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtAddressAdd } from 'components'

export default {
  name: `${COMPONENT_PREFIX}PageAddressAdd`,
  data () {
    return {}
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-address-add`
    }
  },
  methods: {
    beforeClose () {
      this.$router.push({path: '/my-address'})
    }
  },
  components: {
    FineArtAddressAdd
  }
}
</script>

<style lang="stylus">
</style>
