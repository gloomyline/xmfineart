<template>
  <div :class="classes">
    <!-- 更换手机号：步骤1 -->
    <group class="change-mobile-wrap" label-align="left" v-if="!showStep2">
      <cell title="手机号码">
        <div class="attr-value">{{ memberProfile.mobile }}</div>
      </cell>
      <x-input
        title="短信验证码"
        placeholder="输入验证码"
        placeholder-align="right"
        text-align="right"
        v-model.trim="ChangeMobileItem1.code"
        :show-clear="false">
        <x-button
          class="send-code-btn"
          slot="right"
          type="default" mini
          :disabled="counting"
          @click.native="fetchCode(ChangeMobileItem1.type, memberProfile.mobile)">{{ btnLabel }}</x-button>
      </x-input>
      <x-button class="next-btn" type="primary" @click.native="nextStep()">下一步</x-button>
    </group>
    <!-- 更换手机号：步骤2 -->
    <group class="change-mobile-wrap" label-align="left" v-if="showStep2">
      <x-input
        title="手机号码"
        :max="11"
        mask="99999999999"
        :should-toast-error="false"
        placeholder="输入新手机号"
        placeholder-align="right"
        text-align="right"
        v-model.trim.number="ChangeMobileItem2.mobile"
        :show-clear="false"></x-input>
      <x-input
        title="短信验证码"
        placeholder="输入验证码"
        placeholder-align="right"
        text-align="right"
        v-model.trim="ChangeMobileItem2.code"
        :show-clear="false">
        <x-button
          class="send-code-btn"
          slot="right"
          type="default" mini
          :disabled="counting"
          @click.native="fetchCode(ChangeMobileItem2.type, ChangeMobileItem2.mobile)">{{ btnLabel }}</x-button>
      </x-input>
      <x-button class="save-btn" type="primary" @click.native="updateMobile()">确认绑定</x-button>
    </group>
  </div>
</template>
<script>
import { COMPONENT_PREFIX, TIMER_COUNTER } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import { mapMutations } from 'vuex'
import * as MSG from 'assets/data/message.js'
import api from 'modules/member/api'

export default {
  name: `${COMPONENT_PREFIX}PageChangMobile`,
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{9}\d$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      ChangeMobileItem1: {
        type: 203,
        code: ''
      },
      ChangeMobileItem2: {
        type: 204,
        mobile: '',
        code: ''
      },
      ChangeMobileRule1: {
        code: [{ required: true, message: '请输入短信验证码' }]
      },
      mobileRules: {
        mobile: [
          { required: true, message: '请输入新手机号' },
          // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
          { validator: mobileValidator }
        ]
      },
      ChangeMobileRule2: {
        mobile: [
          { required: true, message: '请输入新手机号' },
          // 使用定义的 mobileValidator 函数辅助对手机号码格式进行校验
          { validator: mobileValidator }
        ],
        code: [{ required: true, message: '请输入短信验证码' }]
      },
      showStep2: false,
      // 计数器当前值
      seconds: 0
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-change-mobile`
    },
    counting () {
      return this.seconds > 0
    },
    btnLabel () {
      return this.counting ? `${this.seconds}s` : '获取验证码'
    },
    memberProfile () {
      return this.$store.state.memberProfile
    }
  },
  created () {
    this.modifyPageName('更换手机号')
  },
  beforeDestroy () {
    if (this.timer) {
      this.stopCount(this.timer)
    }
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    async nextStep () {
      const rules = await validate(this.ChangeMobileItem1, this.ChangeMobileRule1)
      if (!rules) return
      this.result = await api.accountProfileResetMobileStep1(this.ChangeMobileItem1.code)
      if (this.result.code === 200) {
        this.stopCount()
        this.seconds = 0
        this.showStep2 = true
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'warn' })
      }
    },
    async updateMobile () {
      const rules = await validate(this.ChangeMobileItem2, this.ChangeMobileRule2)
      if (!rules) return

      this.result = await api.accountProfileResetMobileStep2(this.ChangeMobileItem2)
      if (Number.parseInt(this.result.code) === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['ACCOUNT_CHANGE_MOBILE_SUCCESS'], type: 'success' })
        this.$router.push({path: `/account`})
      } else {
        this.$store.commit('ADD_MESSAGE', { msg: this.result.msg, type: 'warn' })
      }
    },
    startCount () {
      // 初始化获取短信验证码计数器
      this.seconds = TIMER_COUNTER
      // this.$set('seconds', TIMER_COUNTER)
      this.timer = setInterval(() => {
        if (this.seconds <= 0) {
          clearInterval(this.timer)
        }
        --this.seconds
      }, 1000)
    },
    stopCount (timerId) {
      clearInterval(timerId)
    },
    // 点击'获取'事件 handler
    async fetchCode (type, mobile) {
      // 如果计数器正在计数，终止接下来的操作
      if (this.seconds > 0) return
      if (type === 204) {
        const rules = await validate(this.ChangeMobileItem2, this.mobileRules)
        if (!rules) return
      }
      // 请求发送注册短信验证码
      this.result = await api.fetchCode({ type, mobile })
      if (Number.parseInt(this.result.code) === 200) {
        this.startCount()
        this.$store.commit('ADD_MESSAGE', { msg: MSG['SEND_CODE_SUCCESS'], type: 'success' })
      }
    }
  }
}
</script>
<style lang="stylus">
.{$cls_prefix}-page-change-mobile
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      padding-left: 0
      padding-right: 0
      .weui-label, .vux-label
        color: $black2
      .black
        color: $black1
      .attr-value
        font-size: 28px
        color: $black1
        padding: 0 20px
      .send-code-btn
        width: 160px
        height: 54px
        border: 2px solid $grey8
        margin-left: 28px
        padding: 0
        line-height: 54px
        font-size: 24px
        color: $black2
        border-radius: 0
        background-color: $white
        &:after
          border-color: $grey8
    .save-btn, .next-btn
      margin-top: 30px
  .tip
    color: $grey8
    padding: 30px
    font-size: 24px
    line-height: 33px
</style>
