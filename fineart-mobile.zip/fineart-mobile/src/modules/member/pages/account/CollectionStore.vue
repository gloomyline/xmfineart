<template>
  <div :class="classes">
    <fine-art-scroller
      class="store-list-scroller"
      ref="scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="storeList.data"
      :has-data="pageConfig.total"
      :has-more="pageConfig.has_next"
      :last-page="pageConfig.last_page">
      <swipeout class="store-list-wrap" >
        <swipeout-item
          transition-mode="follow"
          underlay-color="#C7C7C7"
          v-for="(item, index) in storeList.data"
          :key="index">
          <div slot="right-menu">
            <swipeout-button @click.native="del(item.id)" type="warn">删除</swipeout-button>
          </div>
          <a class="store-detail fy-1px-b" slot="content" :href="`mall.html#/store-detail/${item.id}`">
            <div class="store-img">
              <img :src="item.thumbnail" width="100%" height="100%">
            </div>
            <div class="store-info">
              <a class="store-name">{{ item.name | labelFormatter(28) }}</a>
            </div>
          </a>
        </swipeout-item>
      </swipeout>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtScroller } from 'components'
import api from 'modules/member/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}CollectionStore`,
  data () {
    return {
      pageConfig: {
        page: 1,
        total: false,
        has_next: false,
        last_page: 1
      },
      storeList: {
        data: []
      }
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '我关注的')
    this.initPage()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-collection-store`
    }
  },
  methods: {
    async initPage () {
      this.storeList = await api.collectStoreList(this.pageConfig.page)
      this.pageConfig.has_next = this.storeList.has_next
      this.pageConfig.last_page = this.storeList.last_page
      this.pageConfig.total = Boolean(this.storeList.total)
    },
    // 加在更多建筑列表数据
    async loadMore (cb) {
      if (!this.pageConfig.has_next) return cb()
      this.pageConfig.page++
      let res = await api.collectStoreList(this.pageConfig.page)
      this.pageConfig.has_next = res.has_next
      this.storeList.data = [...this.storeList.data, ...res.data]
    },
    // 刷新当前建筑列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.initPage()
      cb()
    },
    async del (id) {
      let code = await api.collectStore(id)
      if (code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        this.storeList.data = this.storeList.data.filter(item => item.id !== id)
      }
    }
  },
  filters: {
    labelFormatter (str = '', length = 28) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-collection-store
  .store-detail
    width: 100%
    height: 220px
    padding: 30px
    display: flex
    align-items: center
    &.fy-1px-b
      bottom: 1px
    .store-img
      height: 160px
      width: 160px
      margin-right: 30px
      background: $grey4
    .store-info
      display: flex
      flex-direction: column
      .store-name
        color: $black1
        font-size: 30px
        font-weight: 300
        max-width: 500px
        line-height: 42px
        margin-bottom: 20px
      .store-tag
        font-size: 26px
        color: $black2
        font-weight: 300
        line-height: 36px
  .vux-swipeout-button-warn
    font-size: 30px
    background: $red !important
</style>
