    <template>
  <div :class="classes">
    <!-- 未实名认证 -->
    <group class="auth-wrap" label-align="left" v-if="member.is_auth === '100'">
      <cell title="手机号码">
        <div class="attr-value">{{ member.mobile }}</div>
      </cell>
      <x-input
        title="短信验证码"
        placeholder="验证码"
        placeholder-align="right"
        text-align="right"
        type="text"
        v-model="member.code"
        :show-clear="false">
        <x-button
          class="send-code-btn"
          slot="right"
          type="default" mini
          :disabled="counting"
          @click.native="fetchCode">{{ btnLabel }}</x-button>
      </x-input>
      <x-input
        title="姓名"
        :should-toast-error="false"
        placeholder='输入真实姓名'
        placeholder-align="right"
        text-align="right"
        v-model="member.realname"
        :show-clear="false" ></x-input>
      <x-input
        title="身份证号"
        placeholder='输入身份证号'
        placeholder-align="right"
        text-align="right"
        v-model="member.idcard"
        :show-clear="false" ></x-input>
      <x-input
        title="银行卡号"
        placeholder='输入银行卡号'
        placeholder-align="right"
        text-align="right"
        v-model="member.bankcard"
        :show-clear="false" ></x-input>
      <x-button class="save-btn" type="primary" @click.native="handleSubmit()">提交认证</x-button>
    </group>
    <!-- 已实名认证 -->
    <group class="auth-wrap" label-align="left" v-else>
      <cell title="姓名">
        <div class="attr-value">{{ member.realname }}</div>
      </cell>
      <cell title="手机号码">
        <div class="attr-value">{{ member.mobile }}</div>
      </cell>
      <cell title="身份证号">
        <div class="attr-value">{{ member.identity }}</div>
      </cell>
    </group>
    <p class="tip">说明：以上信息仅作为实名认证用，使用银行接口进行认证，不会以任何形式保存您的信息。</p>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, TIMER_COUNTER } from '@/assets/data/constants'
import { hyphenCase, deepClone, validate } from '@/common/js/utils'
import { mapMutations, mapState } from 'vuex'
import api from 'modules/member/api/index.js'

export default {
  name: `${COMPONENT_PREFIX}PageAuth`,
  data () {
    return {
      // 计数器当前值
      seconds: 0,
      member: {},
      memberRule: {
        code: [
          { required: true, message: '请输入短信验证码' }
        ],
        realname: [
          { required: true, message: '请填写真实姓名' }
        ],
        idcard: [
          { required: true, message: '请填写身份证号' }
        ],
        bankcard: [
          { required: true, message: '请填写银行卡号' }
        ]
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-auth`
    },
    counting () {
      return this.seconds > 0
    },
    btnLabel () {
      return this.counting ? `${this.seconds}s` : '获取验证码'
    },
    ...mapState(['memberProfile'])
  },
  watch: {
    memberProfile: {
      handler (newVal) {
        this.member = deepClone(newVal)
      },
      deep: true
    }
  },
  created () {
    this.member = deepClone(this.memberProfile)
    this.modifyPageName('实名认证')
  },
  beforeDestroy () {
    if (this.timer) {
      this.stopCount(this.timer)
    }
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    async handleSubmit () {
      const rules = await validate(this.member, this.memberRule)
      if (!rules) return
      this.res = await api.accountProfileAuthRealName(this.member)
      if (this.res.code === 200) {
        this.$store.dispatch('fetchAccountProfile')
        this.$router.push({path: '/account'})
      }
    },
    startCount () {
      // 初始化获取短信验证码计数器
      this.seconds = TIMER_COUNTER
      // this.$set('seconds', TIMER_COUNTER)
      this.timer = setInterval(() => {
        if (this.seconds <= 0) {
          clearInterval(this.timer)
        }
        --this.seconds
      }, 1000)
    },
    stopCount (timerId) {
      clearInterval(timerId)
    },
    // 点击'获取'事件 handler
    async fetchCode () {
      let res = await api.fetchCode({type: 205, mobile: this.member.mobile})
      if (res.code === 200) {
        // 如果计数器正在计数，终止接下来的操作
        if (this.seconds > 0) return
        this.startCount()
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-auth
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      height: 98px
      padding-left: 0
      padding-right: 0
      .weui-label, .vux-label
        color: $black2
      .black
        color: $black1
      .attr-value
        font-size: 28px
        color: $black1
        padding: 0 20px
      .send-code-btn
        width: 160px
        height: 54px
        border: 2px solid $grey8
        margin-left: 28px
        padding: 0
        font-size: 24px
        color: $black2
        line-height: 54px
        background-color: $white
        border-radius: 0
        &:after
          border-color: $grey8
    .save-btn
      margin-top: 30px
  .tip
    color: $grey8
    padding: 30px
    font-size: 24px
    line-height: 33px
</style>
