<template>
  <div :class="classes">
    <fine-art-scroller
      class="goods-list-scroller"
      ref="scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="goodsList.data"
      :has-data="pageConfig.total"
      :has-more="pageConfig.has_next"
      :last-page="pageConfig.last_page">
      <swipeout class="goods-list-wrap">
        <swipeout-item
          transition-mode="follow"
          underlay-color="#C7C7C7"
          v-for="(item, index) in goodsList.data"
          :key="index">
          <div slot="right-menu">
            <swipeout-button @click.native="del(item.id, item.store_id)" type="warn">删除</swipeout-button>
          </div>
          <a :href="`mall.html#/goods-detail/${item.id}/${item.store_id}`" class="goods-detail fy-1px-b" slot="content">
            <div class="goods-img">
              <img :src="item.thumbnail" width="100%" height="100%">
            </div>
            <p class="goods-name">{{ item.name | labelFormatter(32) }}</p>
          </a>
        </swipeout-item>
      </swipeout>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtScroller } from 'components'
import api from 'modules/member/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}CollectionGoods`,
  data () {
    return {
      pageConfig: {
        page: 1,
        total: false,
        last_page: 1,
        has_next: false
      },
      goodsList: {
        data: []
      }
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '我关注的')
    this.initPage()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-collection-goods`
    }
  },
  methods: {
    async initPage () {
      this.goodsList = await api.collectGoodsList(this.pageConfig.page)
      this.pageConfig.last_page = this.goodsList.last_page
      this.pageConfig.has_next = this.goodsList.has_next
      this.pageConfig.total = Boolean(this.goodsList.total)
    },
    // 加在更多建筑列表数据
    async loadMore (cb) {
      if (!this.pageConfig.has_next) {
        return cb()
      }
      this.pageConfig.page++
      let res = await api.collectGoodsList(this.pageConfig.page)
      this.pageConfig.has_next = res.has_next
      this.goodsList.data = [...this.goodsList.data, ...res.data]
    },
    // 刷新当前建筑列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.initPage()
      cb()
    },
    async del (goods_id, store_id) {
      let code = await api.collectGoods(goods_id, store_id)
      if (code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        this.goodsList.data = this.goodsList.data.filter(item => item.id !== goods_id || item.store_id !== store_id)
      }
    }
  },
  filters: {
    labelFormatter (str = '', length = 28) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-collection-goods
  .goods-detail
    width: 100%
    height: 220px
    padding: 30px
    display: flex
    align-items: center
    &.fy-1px-b
      bottom: 1px
    .goods-img
      height: 160px
      width: 160px
      margin-right: 30px
      background: $grey4
    .goods-name
      color: $black1
      font-size: 28px
      font-weight: 300
      max-width: 500px
      line-height: 42px
  .vux-swipeout-button-warn
    font-size: 30px
    background: $red !important
</style>
