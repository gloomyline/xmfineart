import Vue from 'vue'
import VueRouter from 'vue-router'

import Login from 'modules/member/pages/LoginRegister.vue'
import resetPassword from 'modules/member/pages/resetPassword.vue'
import Protocol from 'modules/member/pages/Protocol.vue'
// 地图管理
import MapManage from 'modules/member/pages/map/Manage.vue'
import BindMarker from 'modules/member/pages/map/BindMarker.vue'
import EditMarker from 'modules/member/pages/map/EditMarker.vue'
import MarkerRelocation from 'modules/member/pages/map/MarkerRelocation.vue'
import MarkerEdit from 'modules/member/pages/map/MarkerEdit.vue'
// 账号安全（账号信息、实名认证、修改号码）
import AccountSecurity from 'modules/member/pages/account/AccountSecurity.vue'
import Account from 'modules/member/pages/account/Account.vue'
import Auth from 'modules/member/pages/account/Auth.vue'
import ChangeMobile from 'modules/member/pages/account/ChangeMobile.vue'
// 我的关注（店铺、商品、建筑、资源）、我的预约
import MyCollection from 'modules/member/pages/account/MyCollection.vue'
import CollectionGoods from 'modules/member/pages/account/CollectionGoods.vue'
import CollectionStore from 'modules/member/pages/account/CollectionStore.vue'
import CollectionResource from 'modules/member/pages/account/CollectionResource.vue'
import CollectionProduction from 'modules/member/pages/account/CollectionProduction.vue'
import CollectionBuilding from 'modules/member/pages/account/CollectionBuilding.vue'
import MyReservation from 'modules/member/pages/account/MyReservation.vue'
// 主页管理、开通主页（个人、品牌、供应商、公司）
import ChoiceHome from 'modules/member/pages/home/ChoiceHome.vue'
import OpenHomeBrand from 'modules/member/pages/home/OpenHomeBrand.vue'
import OpenHomeCompany from 'modules/member/pages/home/OpenHomeCompany.vue'
import OpenHomePerson from 'modules/member/pages/home/OpenHomePerson.vue'
import OpenHomeSupplier from 'modules/member/pages/home/OpenHomeSupplier.vue'
import OpenHomeDecorator from 'modules/member/pages/home/OpenHomeDecorator.vue'
// 我的订单
import MyOrder from 'modules/member/pages/order/MyOrder.vue'
// 我的订单详情
import OrderDetail from 'modules/member/pages/order/OrderDetail.vue'
// 我的订单评价
import OrderComment from 'modules/member/pages/order/OrderComment.vue'
// 售后申请
import SaleService from 'modules/member/pages/order/SaleService.vue'
// 我的地址
import MyAddress from 'modules/member/pages/account/MyAddress.vue'
// 添加地址
import AddressAdd from 'modules/member/pages/account/AddressAdd.vue'
// 我的团购
import GrouponMy from 'modules/member/pages/groupon/GrouponMy.vue'
// 我的团购，发布的
import GrouponMyRelease from 'modules/member/pages/groupon/GrouponMyRelease.vue'
// 我的团购，参与的
import GrouponMyApply from 'modules/member/pages/groupon/GrouponMyApply.vue'
// 团购绑定商品
import GrouponBind from 'modules/member/pages/groupon/GrouponBind.vue'

Vue.use(VueRouter)

const routes = [
  {
    // 登录注册
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/reset-password',
    name: 'resetPassword',
    component: resetPassword
  },
  {
    path: '/protocol',
    name: 'Protocol',
    component: Protocol
  },
  {
    // 地图管理
    path: '/map-manage',
    name: 'MapManage',
    component: MapManage,
    meta: {
      requiresAuth: true
    },
    children: [
      {
        // 绑定标记
        path: 'bind-marker',
        name: 'BindMarker',
        component: BindMarker
      },
      {
        // 编辑标记
        path: 'edit-marker',
        name: 'EditMarker',
        component: EditMarker
      }
    ]
  },
  {
    // 重新定位地图标记
    path: '/marker-relocation/:id',
    name: 'MarkerRelocation',
    props: true,
    meta: {
      requiresAuth: true
    },
    component: MarkerRelocation
  },
  {
    // 编辑地图标记
    path: '/marker-edit/:id',
    name: 'MarkerEdit',
    props: true,
    meta: {
      requiresAuth: true
    },
    component: MarkerEdit
  },
  {
    path: '/account-security',
    name: 'AccountSecurity',
    meta: {
      requiresAuth: true
    },
    component: AccountSecurity
  },
  {
    path: '/account',
    name: 'Account',
    meta: {
      requiresAuth: true
    },
    component: Account
  },
  {
    path: '/auth',
    name: 'Auth',
    meta: {
      requiresAuth: true
    },
    component: Auth

  },
  {
    path: '/change-mobile',
    name: 'ChangeMobile',
    meta: {
      requiresAuth: true
    },
    component: ChangeMobile
  },
  {
    path: '/my-collection',
    name: 'MyCollection',
    meta: {
      requiresAuth: true
    },
    component: MyCollection,
    redirect: '/my-collection/collection-goods',
    children: [
      {
        path: 'collection-goods',
        name: 'CollectionGoods',
        component: CollectionGoods
      },
      {
        path: 'collection-store',
        name: 'CollectionStore',
        component: CollectionStore
      },
      {
        path: 'collection-resource',
        name: 'CollectionResource',
        component: CollectionResource
      },
      {
        path: 'collection-building',
        name: 'CollectionBuilding',
        component: CollectionBuilding
      },
      {
        path: 'collection-production',
        name: 'CollectionProduction',
        component: CollectionProduction
      }
    ]
  },
  {
    path: '/my-reservation',
    name: 'MyReservation',
    meta: {
      requiresAuth: true
    },
    component: MyReservation
  },
  {
    path: '/my-order',
    name: 'MyOrder',
    meta: {
      requiresAuth: true,
      keepAlive: true
    },
    component: MyOrder
  },
  {
    path: '/choice-home',
    name: 'ChoiceHome',
    meta: {
      requiresAuth: true,
      keepAlive: true
    },
    component: ChoiceHome
  },
  {
    path: '/open-home/100/:id?',
    name: 'OpenHomePerson',
    meta: {
      requiresAuth: true
    },
    component: OpenHomePerson
  },
  {
    path: '/open-home/200/:id?',
    name: 'OpenHomeCompany',
    meta: {
      requiresAuth: true
    },
    component: OpenHomeCompany
  },
  {
    path: '/open-home/300/:id?',
    name: 'OpenHomeSupplier',
    meta: {
      requiresAuth: true
    },
    component: OpenHomeSupplier
  },
  {
    path: '/open-home/400/:id?',
    name: 'OpenHomeBrand',
    meta: {
      requiresAuth: true
    },
    component: OpenHomeBrand
  },
  {
    path: '/open-home/500/:id?',
    name: 'OpenHomeDecorator',
    meta: {
      requiresAuth: true
    },
    component: OpenHomeDecorator
  },
  {
    path: '/order-detail/:id',
    name: 'OrderDetail',
    meta: {
      requiresAuth: true
    },
    component: OrderDetail,
    props: true
  },
  {
    path: '/order-comment/:id',
    name: 'OrderComment',
    meta: {
      requiresAuth: true
    },
    component: OrderComment,
    props: true
  },
  {
    path: '/sale-service/:orderId',
    name: 'SaleService',
    meta: {
      requiresAuth: true
    },
    component: SaleService,
    props: true
  },
  {
    path: '/my-address',
    name: 'MyAddress',
    meta: {
      requiresAuth: true
    },
    component: MyAddress
  },
  {
    path: '/address-add',
    name: 'AddressAdd',
    meta: {
      requiresAuth: true
    },
    component: AddressAdd
  },
  {
    path: '/groupon/my',
    name: 'GrouponMy',
    component: GrouponMy,
    meta: {
      requiresAuth: true
    },
    redirect: '/groupon/my/release',
    children: [
      {
        path: 'release',
        name: 'GrouponMyRelease',
        component: GrouponMyRelease,
        meta: {
          tabIndex: 1
        }
      },
      {
        path: 'apply',
        name: 'GrouponMyApply',
        component: GrouponMyApply,
        meta: {
          tabIndex: 2
        }
      }
    ]
  },
  {
    path: '/groupon/bind/:id/:goods_id?',
    name: 'GrouponBind',
    component: GrouponBind,
    meta: {
      requiresAuth: true
    },
    props: true
  }
]

export default new VueRouter({ routes })
