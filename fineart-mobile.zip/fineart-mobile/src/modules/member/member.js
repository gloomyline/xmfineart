// import flexible mobile layout
import 'amfe-flexible'
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import router from './router/index.js'
import store from '@/store'
import Member from './Member.vue'
import { VueMap } from '@/common/js/Map.js'
import { TOAST_DURATION, SHARE_DATA } from 'assets/data/constants.js'
import { VueLocalStorage } from '@/common/js/LocalStorage'
import VueClipboard from 'vue-clipboard2'
import { WXPlugin } from '@/common/js/vue-wx.js'

// common style files
import '@/common/styles/index.styl'

// vux components register
import {
  Cell,
  ConfirmPlugin,
  Group,
  XInput,
  XButton,
  XTextarea,
  CheckIcon,
  Checklist,
  PopupPicker,
  PopupRadio,
  Swiper,
  Swipeout,
  SwiperItem,
  SwipeoutItem,
  SwipeoutButton,
  Tab,
  TabItem,
  Confirm,
  Spinner,
  Scroller,
  LoadingPlugin,
  ToastPlugin,
  TransferDom,
  Rater
} from 'vux'
import {goLogin} from '@/common/js/utils'
import {API_ADDRESS} from 'assets/data/constants'

Vue.component('cell', Cell)
Vue.component('group', Group)
Vue.component('x-input', XInput)
Vue.component('x-button', XButton)
Vue.component('x-textarea', XTextarea)
Vue.component('check-icon', CheckIcon)
Vue.component('check-list', Checklist)
Vue.component('popup-picker', PopupPicker)
Vue.component('popup-radio', PopupRadio)
Vue.component('swiper', Swiper)
Vue.component('swipeout', Swipeout)
Vue.component('swiper-item', SwiperItem)
Vue.component('swipeout-item', SwipeoutItem)
Vue.component('swipeout-button', SwipeoutButton)
Vue.component('tab', Tab)
Vue.component('tab-item', TabItem)
Vue.component('confirm', Confirm)
Vue.component('spinner', Spinner)
Vue.component('scroller', Scroller)
Vue.directive('transfer-dom', TransferDom)
Vue.component('rater', Rater)

Vue.use(ConfirmPlugin)
// Toast default opts
const toastOpts = {
  position: 'bottom',
  width: '160px',
  time: TOAST_DURATION * 1000,
  type: 'text'
}
Vue.use(ToastPlugin, toastOpts)
// Loading plugin
Vue.use(LoadingPlugin)
// FMap plugin
Vue.use(VueMap)
Vue.use(VueLocalStorage)
// 复制到粘贴板
Vue.use(VueClipboard)

store.commit('member/MODIFY_IS_MEMBER')

// router global hook
router.beforeEach((to, from, next) => {
  const user = Vue.localStorage.getUser()
  if (user && user.isLogin && user.token) {
    if (Object.keys(store.state.memberProfile).length === 0) {
      store.dispatch('fetchAccountProfile')
    }
  }
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // this route requires auth, check if logged in
    // if not, break route change, open login modal.
    if (user && user.isLogin) { // user status is valid, go to corresponding path
      next()
    } else { // not login or is out of date
      next()
      goLogin()
    }
  } else {
    next() // 确保一定要调用 next()
  }
})

// wx js sdk
Vue.use(WXPlugin, { shareData: SHARE_DATA.member, module: 'member' })
// 使用 vue wx 插件更新页面的分享内容
router.afterEach((to) => {
  const location = window.location
  const pageLink = location.href.replace(location.hash, '')
  const _link = `${pageLink}#${to.path}`
  const link = `${API_ADDRESS}/sys/wechat/share?url=${encodeURIComponent(_link)}`
  Vue.wx.updateShareData('member', { link })
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  router,
  template: '<Member/>',
  components: { Member }
})
