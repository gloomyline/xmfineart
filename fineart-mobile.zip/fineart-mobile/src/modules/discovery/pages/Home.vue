<template>
  <div :class="classes">
    <fine-art-scroller
      class="discovery-scroll"
      @refresh="refreshFind"
      :height="-94/75"
      :list="discovery.data"
      @load-more="loadMore"
      :has-data="hasData">
      <ul class="discovery-list">
        <li  class="discovery-item fy-1px-b" v-for="(item, index) in discovery.data" :key="index">
          <div class="discovery-detail" @click="goToDetail(item.resource_id, item.resource_mode)">
            <div class="discovery-logo">
              <img :src="item.resource_logo">
            </div>
            <div class="detail">
              <div class="text">
                <h3 class="name">{{item.resource_name}}</h3>
                <span class="area" v-if="item.area">{{item.area}}</span>
              </div>
              <h4 class="time">{{item.created_at}}</h4>
            </div>
          </div>
          <!-- 作品图片集 -->
          <a :href="`resource.html#/production-detail/${item.object_id}`" class="product-pics" v-if="item.object_type === '200' && item.images && item.images.length">
            <swiper v-model="item.currentSwiperIndex"
                    class="product-pics-swiper"
                    dots-class="product-pics-swiper-dots"
                    dots-position="center"
                    :show-dots="false"
                    :aspect-ratio="750/750">
              <swiper-item class="product-pics-swiper-item" v-for="(img, indexImg) in item.images_big" :key="indexImg">
                <img :src="img" width="100%" @load="onRefresh">
              </swiper-item>
            </swiper>
            <div class="dots" v-if="item.images.length !== 1">{{item.currentSwiperIndex + 1}}/{{item.images.length}}</div>
          </a>
          <!-- 动态图片集 -->
          <div class="dynamic-pics" v-else-if="item.images && item.images.length">
            <ul class="pics-list">
              <li class="pic" v-for="(img, indexImg) in item.images" :key="indexImg" :class="{'is-one': item.images.length === 1}">
                <img v-if="item.images.length !== 1" :src="img" alt="" @load="onRefresh" @click="previewImage(item.images_big, indexImg)">
                <img v-else :src="item.images_big[0]" alt="" @load="onRefresh" @click="previewImage(item.images_big, indexImg)">
              </li>
            </ul>
          </div>
          <div class="discovery-info">
            <!-- 作品 标题 + 内容 -->
            <a :href="`resource.html#/production-detail/${item.object_id}`" class="info-wrap" v-if="item.object_type === '200'">
              <h3 class="product-info-name">{{item.title}}</h3>
              <div class="product-info-intro">{{item.introduction | labelFormatter(46)}}</div>
            </a>
            <!-- 动态 内容 -->
            <div class="dynamic-intro" v-else>{{item.introduction}}</div>
            <div class="tag-like">
              <ul class="discovery-info-tags-list">
                <li class="tag" v-for="(tag, indexTag) in item.categories" :key="indexTag">{{tag.name}}</li>
              </ul>
              <div class="attention-give-like">
                <div class="attention" v-if="item.object_type === '200'" :class="{'is-active': item.collection_status}" @click="handleCollect(item)">
                  <span class="icon icon-attention"></span>
                  <span class="number" v-if="item.collect_num">{{item.collect_num}}</span>
                </div>
                <div class="give-like" :class="{'is-active': item.like_status}" @click="handleLike(item)">
                  <span class="icon icon-like"></span>
                  <span class="number" v-if="item.like_num">{{item.like_num}}</span>
                </div>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </fine-art-scroller>
    <fine-art-foot-nav :is-choose="1"></fine-art-foot-nav>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtFootNav, FineArtScroller, FineArtLoginTip } from 'components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/resources/api'

export default {
  name: `${COMPONENT_PREFIX}PageDiscovery`,
  components: {
    FineArtFootNav,
    FineArtScroller,
    FineArtLoginTip
  },
  data () {
    return {
      loginTipModal: false,
      discovery: {
        data: [],
        has_next: false,
        current_page: 1
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-discovery`
    },
    hasData () {
      return true
    },
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '发现')
    this.getFindList({ page: 1 })
  },
  methods: {
    // 获取发现列表
    async getFindList ({ page = 1 }) {
      const response = await api.fetchFindList({ page })
      this._handleResponse(response)
    },
    // 处理 接口返回的数据
    _handleResponse (response, isConcat = false) {
      let arrList = []
      if (isConcat) {
        arrList = [...this.discovery.data, ...response.data]
      } else {
        arrList = response.data
      }
      for (let i = 0, max = arrList.length; i < max; i++) {
        arrList[i].currentSwiperIndex = 0
        arrList[i].collect_num = parseInt(arrList[i].collect_num)
        arrList[i].like_num = parseInt(arrList[i].like_num)
      }
      this.discovery.data = arrList
      this.discovery.current_page = response.current_page
      this.discovery.has_next = response.has_next
    },
    // 关注作品
    async handleCollect (item) {
      if (!this.isLogin) {
        this.loginTipModal = true
        return
      }
      const response = await api.handleResourceCollect({object_type: 200, object_id: item.object_id})
      if (response.code === 200) {
        item.collection_status = !item.collection_status
        if (item.collection_status) {
          item.collect_num += 1
        } else {
          item.collect_num -= 1
        }
        const MESSAGE_TEXT = !item.collection_status ? 'RESOURCE_PRODUCTION_CANCEL_COLLECT_SUCCESS' : 'RESOURCE_PRODUCTION_COLLECT_SUCCESS'
        this.$store.commit('ADD_MESSAGE', {msg: MSG[MESSAGE_TEXT], type: 'success'})
      }
    },
    // 点赞作品/动态
    async handleLike (item) {
      if (!this.isLogin) {
        this.loginTipModal = true
        return
      }
      const response = await api.handleResourceLike({object_type: item.object_type, object_id: item.object_id})
      if (response.code === 200) {
        item.like_status = !item.like_status
        if (item.like_status) {
          item.like_num += 1
        } else {
          item.like_num -= 1
        }
        const MESSAGE_TEXT = !item.like_status ? 'RESOURCE_PRODUCTION_CANCEL_LIKE_SUCCESS' : 'RESOURCE_PRODUCTION_LIKE_SUCCESS'
        this.$store.commit('ADD_MESSAGE', {msg: MSG[MESSAGE_TEXT], type: 'success'})
      }
    },
    // 加载更多列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.discovery.has_next) return cb()
      const response = await api.fetchFindList({ page: this.discovery.current_page + 1 })
      this._handleResponse(response, true)
    },
    onRefresh () {
      this.$refs.scroller && this.$refs.scroller.refresh()
    },
    // 刷新当前列表数据
    async refreshFind (cb) {
      const response = await api.fetchFindList({ page: 1 })
      this._handleResponse(response)
      cb()
    },
    // 前往主页详情
    goToDetail (id, mode) {
      let page = ''
      switch (mode) {
      case '100':
        page = `resource.html#/person-home/${id}`
        break
      case '200':
        page = `resource.html#/company-home/${id}`
        break
      case '300':
        page = `resource.html#/supplier-home/${id}`
        break
      case '400':
        page = `resource.html#/brand-home/${id}`
        break
      case '500':
        page = `resource.html#/decorator-home/${id}`
        break
      }
      window.location.href = page
    },
    // 预览图片
    previewImage (images, index) {
      this.$wx.previewImage(
        {
          current: images[index], // 当前显示图片的http链接
          urls: images // 需要预览的图片http链接列表
        }
      )
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  }
}
</script>

<style lang="stylus" scoped>
.{$cls_prefix}-page-discovery
  font-family:PingFangSC-Regular
  color: $black2
  .discovery-scroll
    bottom: 88px
  .discovery-list
    width: 100%
    .discovery-item
      .discovery-detail
        display: flex
        padding: 30px
        .discovery-logo
          width: 70px
          height: 70px
          margin-right: 20px
          border-radius: 50%
          &>img
            width: 70px
            height: 70px
            border-radius: 50%
        .detail
          flex: 1 0 auto
          .text
            display: flex
            align-items: center
            .name
              margin-right: 20px
              max-width: 480px
              color: $black1
              font-size: 28px
              line-height: 40px
              {ellipse}
            .area
              padding-left: 30px
              font-size: 22px
              color: $black1
              background: url('../../../assets/imgs/resource/icon-address@2x.png') 0 center no-repeat
              background-size: auto 22px
          .time
            color: $grey3
            font-size: 24px
      .product-pics
        position: relative
        display: block
        width: 100%
        margin-bottom: 30px
        background-color: $grey5
        .product-pics-swiper-item img
          absolute: left 50% top 50%
          transform: translate(-50%, -50%)
        .dots
          absolute: right 20px bottom 20px
          width: 80px
          font-size: 24px
          text-align: center
          color: $white
          background-color: rgba(51, 51, 51, 0.3)
          border-radius: 19px
          -webkit-transform: translateZ(0)
          text-middle: 5px
      .dynamic-pics
        overflow: hidden
        width: 100%
        padding: 0 30px
        margin-bottom: 30px
        .pics-list
          display: flex
          flex-wrap: wrap
          margin-right: -12px
          .pic
            width: 222px
            height: 222px
            margin: 0 12px 12px 0
            border-radius: 6px
            &>img
              display: block
              width: 100%
              height: 100%
              border-radius: 6px
            &.is-one
              width: 100%
              height: auto
              &>img
                display: block
                width: 100%
                height: auto
                border-radius:6px
      .discovery-info
        padding: 0 30px 40px 30px
        .info-wrap
          display: block
        .product-info-name
          margin-bottom: 14px
          font-size: 36px
          line-height: 50px
          color: $black1
          font-family: PingFangSC-Medium
          font-weight: 500
          {ellipse}
        .product-info-intro
          margin-bottom: 20px
          font-size: 28px
          line-height: 40px
          font-weight: 400
          color: $black1
        .dynamic-intro
          font-size: 28px
          font-weight: 400
          color: $black2
          line-height: 40px
          margin-bottom 20px
        &-tags-list
          display: flex
          flex-wrap: wrap
          .tag
            margin-right: 10px
            color: $grey3
            font-size: 20px
            background-color: $greyF1
            border-radius: 4px
            text-middle: 5px 14px
      .tag-like
        display: flex
        justify-content: space-between
      .attention-give-like
        display: flex
        justify-content: flex-end
        padding-right: 10px
        .attention
          margin-right: 66px
        .attention, .give-like
          display: flex
          height: 40px
        .number
          margin-top: -10px
          color: $grey2
          font-size: 22px
          line-height: 30px
          &:empty
            display: none
        .icon
          display: inline-block
          width: 40px
          height: 40px
          margin-right: 6px
          &.icon-attention
            background: url('../../../assets/imgs/resource/icon-attention@2x.png') center center no-repeat
            background-size: 40px auto
          &.icon-like
            background: url('../../../assets/imgs/resource/icon-give-like@2x.png') center center no-repeat
            background-size: 40px auto
        .is-active
          .number
            color: $orange
          .icon-attention
            background: url('../../../assets/imgs/resource/icon-attention-orange@2x.png') center center no-repeat
            background-size: 40px auto
          .icon-like
            background: url('../../../assets/imgs/resource/icon-give-like-orange@2x.png') center center no-repeat
            background-size: 40px auto
</style>
