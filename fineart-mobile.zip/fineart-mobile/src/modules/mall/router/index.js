/*
* @Author: Alan
* @Date:   2018-09-07 10:53:06
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-07 10:59:22
*/
import Vue from 'vue'
import VueRouter from 'vue-router'

// 斐艺购首页
import MallHome from 'modules/mall/pages/MallHome.vue'
// 斐艺购商品列表页
import GoodsList from 'modules/mall/pages/GoodsList.vue'
// 斐艺购商品详情页
import GoodsDetail from 'modules/mall/pages/GoodsDetail.vue'
// 斐艺购线下店列表页
import StoreList from 'modules/mall/pages/StoreList.vue'
// 斐艺购线下店地图
import StoreMap from 'modules/mall/pages/Map.vue'
// 斐艺新品预告列表
import ForeShow from 'modules/mall/pages/ForeShow.vue'
// 斐艺新品预告详细信息
import ForeShowDetail from 'modules/mall/pages/ForeShowDetail.vue'
// 斐艺线下商店详情
import StoreDetail from 'modules/mall/pages/StoreDetail.vue'
// 斐艺购购物车
import MallCart from 'modules/mall/pages/Cart.vue'
// 确认订单
import MallOrder from 'modules/mall/pages/MallOrder.vue'
// 选择支付
import Payment from 'modules/mall/pages/CheckPay.vue'
// 支付结果
import PayError from 'modules/mall/pages/PayError.vue'
// 团购
import Groupon from 'modules/mall/pages/Groupon.vue'
// 团购产品
import GrouponProduct from 'modules/mall/pages/GrouponProduct.vue'
// 团购服务
import GrouponService from 'modules/mall/pages/GrouponService.vue'
// 团购详情页
import GrouponDetail from 'modules/mall/pages/GrouponDetail.vue'
// 团购名单
import GrouponRoster from 'modules/mall/pages/GrouponRoster.vue'
// 团购发布
import GrouponRelease from 'modules/mall/pages/GrouponRelease.vue'
// 敬请期待页面
import Expectation from 'modules/index/pages/Expectation.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'MallHome',
    component: MallHome
  },
  {
    path: '/goods-list',
    name: 'GoodsList',
    component: GoodsList,
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/goods-detail/:id/:store_id',
    name: 'GoodsDetail',
    component: GoodsDetail,
    props: true
  },
  {
    path: '/store',
    name: 'Store',
    component: StoreList,
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/store-map/:storeId/:lng/:lat',
    name: 'StoreMap',
    component: StoreMap,
    props: true
  },
  {
    path: '/fore-show',
    name: 'ForeShow',
    component: ForeShow,
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/fore-show-detail/:id',
    name: 'ForeShowDetail',
    component: ForeShowDetail,
    props: true
  },
  {
    path: '/store-detail/:id',
    name: 'StoreDetail',
    component: StoreDetail,
    props: true
  },
  {
    path: '/mall-cart',
    name: 'MallCart',
    component: MallCart,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/mall-order',
    name: 'MallOrder',
    component: MallOrder,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/payment/:orderCode',
    name: 'Payment',
    component: Payment,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/pay-error/:code?',
    name: 'PayError',
    component: PayError
  },
  {
    path: '/groupon',
    name: 'Groupon',
    component: Groupon,
    redirect: {name: 'GrouponProduct'},
    children: [
      {
        path: '100',
        name: 'GrouponProduct',
        meta: {
          hideHead: true
        },
        component: GrouponProduct
      },
      {
        path: '200',
        name: 'GrouponService',
        meta: {
          hideHead: true
        },
        component: GrouponService
      }
    ]
  },
  {
    path: '/groupon/detail/:id',
    name: 'GrouponDetail',
    meta: {
      hideHead: true
    },
    component: GrouponDetail,
    props: true
  },
  {
    path: '/groupon/roster/:id',
    name: 'GrouponRoster',
    meta: {
      hideHead: true
    },
    component: GrouponRoster,
    props: true
  },
  {
    path: '/groupon/release',
    name: 'GrouponRelease',
    component: GrouponRelease,
    meta: {
      hideHead: true,
      requiresAuth: true
    },
    props: true
  },
  {
    path: '/expect',
    name: 'Expectation',
    component: Expectation
  }
]

export default new VueRouter({ routes })
