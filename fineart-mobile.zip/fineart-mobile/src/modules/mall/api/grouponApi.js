export default function (cls) {
  // 团购列表
  cls.prototype.fetchGrouponList = async function ({ page, keyword, category_id, attribute }) {
    const response = await cls.request({
      url: '/mall/groupon/list',
      query: {
        page,
        keyword,
        category_id,
        attribute
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 团购详情页
  cls.prototype.fetchGrouponDetail = async function ({ id }) {
    const response = await cls.request({
      url: `/mall/groupon/detail/${id}`
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 团购申请
  cls.prototype.grouponApply = async function ({ mall_groupon_id, name, mobile, num, remark }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/groupon/apply/add/',
      data: {
        mall_groupon_id,
        name,
        mobile,
        num,
        remark
      }
    })
    return response
  }
  // 参与团购会员列表
  cls.prototype.fetchGrouponApplyList = async function ({ page, groupon_id }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/groupon/apply/list',
      data: {
        page,
        groupon_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 发布团购
  cls.prototype.GrouponAdd = async function ({ name, subtitle, images, introduction, attribute, mall_groupon_category_id, price, unit, contact_name, contact_mobile }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/groupon/add',
      data: {
        name,
        subtitle,
        'images[]': images,
        introduction,
        attribute,
        mall_groupon_category_id,
        price,
        unit,
        contact_name,
        contact_mobile
      }
    })
    return response
  }
}
