import {BaseApi} from '@/common/js/BaseApi'
import mallHomeApi from './mallHomeApi.js'
import foreShow from './foreShow.js'
import GoodsApi from './goodsApi.js'
import storeApi from './storeApi.js'
import cartApi from './cartApi.js'
import orderApi from './orderApi.js'
import paymentApi from './paymentApi.js'
import wechatApi from './wechatApi.js'
import grouponApi from './grouponApi.js'
import ossApi from 'modules/member/api/ossApi.js'

class MallApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    MallApi.updateToken(MallApi.readTokenFromLocalStorage())
    mallHomeApi(MallApi)
    foreShow(MallApi)
    GoodsApi(MallApi)
    storeApi(MallApi)
    cartApi(MallApi)
    orderApi(MallApi)
    paymentApi(MallApi)
    wechatApi(MallApi)
    grouponApi(MallApi)
    ossApi(MallApi)
  }
}

const _instance = new MallApi()

export default _instance
