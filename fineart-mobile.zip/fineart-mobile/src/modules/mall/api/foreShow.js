/**
 * @comment:
 * @author: alan_wang
 * @date: 08/10/2018
 * @time: 17:24:24
 */

export default function (cls) {
  /**
   * 获取新品预告列表
   *
   * @param page {String} 分页号
   * @param keywords {String} 搜索关键字
   * @param sort {String} 排序
   * @returns {Promise<*|Array|default.props.results|{type, default}>}
   */
  cls.prototype.fetchForeShowList = async function ({ page, keywords, sort }) {
    const response = await cls.request({
      url: '/mall/foreshow/index',
      query: {
        page,
        keywords,
        sort
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取预约新品详情
   *
   * @param id {Integer} 新品ID
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.fetchForeShowDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/foreshow/${id}',
      params: { id }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 预约或者取消预约新品
   *
   * @param id {Integer} 新品ID
   * @param operation {Integer} 操作：100=预约，200=取消预约
   * @returns {Promise<*>}
   */
  cls.prototype.fetchForeShowReservation = async function ({ id, operation }) {
    const response = await cls.request({
      url: '/mall/foreshow/reservation/${id}/${operation}',
      params: {
        id,
        operation
      }
    })

    return response
  }

  /**
   * 获取我的预约新品
   *
   * @param page {Integer} 分页号
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.foreShowMyReservation = async function (page) {
    const response = await cls.request({
      url: '/mall/foreshow/reservation/list',
      query: { page }
    })

    return response.results
  }
}
