export default function (cls) {
  // 生成订单
  cls.prototype.orderAdd = async function (cartIds, addressId) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/order/buyer/add',
      data: {
        'cart_ids[]': cartIds,
        'address_id': addressId
      }
    })

    return response
  }
}
