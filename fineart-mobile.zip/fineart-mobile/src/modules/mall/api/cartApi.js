export default function (cls) {
  cls.prototype.fetchCartItemList = async function () {
    const response = await cls.request({
      url: '/mall/cart'
    })
    if (response.code === 200) {
      return response.results
    }
  }

  cls.prototype.fetchCartGoodsCount = function () {
    return cls.request({
      url: '/mall/cart/count'
    })
  }

  cls.prototype.addToCart = async function ({ goodsId, storeId, num }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/cart/add',
      data: {
        goods_id: goodsId,
        store_id: storeId,
        num: num
      }
    })

    return response
  }

  cls.prototype.delCartItem = async function (idArr) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/cart/del',
      data: {
        'id[]': idArr
      }
    })

    return response
  }

  cls.prototype.editCartItem = async function ({ id, num }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/cart/edit',
      data: {
        id: id,
        num: num
      }
    })

    return response
  }

  // 购物车结算
  cls.prototype.cartCheckout = async function (ids) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/cart/checkout',
      data: {
        'id[]': ids
      }
    })

    return response.results
  }
}
