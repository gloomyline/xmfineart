export default function (cls) {
  // 获取商品列表（搜索）
  cls.prototype.fetchGoodsList = async function ({ page, keywords, category_id, attribute, sort }) {
    const response = await cls.request({
      url: '/mall/goods/search',
      query: {
        page,
        keywords,
        category_id,
        attribute,
        sort
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 获取商品详情
  cls.prototype.fetchGoodsDetail = async function ({ goods_id, store_id }) {
    const response = await cls.request({
      url: '/mall/goods/detail/${goods_id}/${store_id}',
      params: {
        goods_id,
        store_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 获取商品评价列表
  cls.prototype.fetchGoodsComments = async function ({ page, goods_id, store_id }) {
    const response = await cls.request({
      method: 'post',
      url: '/mall/goods/comment/list',
      data: {
        page,
        goods_id,
        store_id
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  // 关注商品/取消关注
  cls.prototype.collectGoods = async function ({ goods_id, store_id }) {
    const response = await cls.request({
      url: '/mall/collect/goods/${goods_id}/${store_id}',
      params: { goods_id, store_id }
    })
    return response.code
  }
}
