
export default function (cls) {
  /**
   * 搜索获取线下店列表
   * @param page              当前分页
   * @param lng               用户所在经度
   * @param lat               用户所在纬度
   * @param keywords          搜索关键词
   * @param category_id       搜索分类
   * @param area_id           区域 id
   * @param sort              排序方式
   * @param is_representative 是否是代表
   * @returns {Promise<*|Array|default.props.results|{type, default}>}
   */
  cls.prototype.fetchStoreList = async function ({ page, lng, lat, keywords, category_id, area_id, sort, is_representative }) {
    const response = await cls.request({
      url: '/mall/store/search',
      query: {
        page,
        lng,
        lat,
        keywords,
        category_id,
        area_id,
        sort,
        is_representative
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取店铺详情
   * @param id        店铺 id
   * @returns {Promise<*|Array|default.props.results|{type, default}>}
   */
  cls.prototype.fetchStoreDetail = async function (id) {
    const response = await cls.request({
      url: '/mall/store/detail/${id}',
      params: { id }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 加入收藏店铺
   * @param id        店铺 id
   * @returns {Promise<*>}
   */
  cls.prototype.collectStore = async function (id) {
    const response = await cls.request({
      url: '/mall/collect/store/${id}',
      params: { id }
    })
    return response.code
  }

  /**
   * 获取店铺指定 tag 的商品列表
   * @param page            列表分页
   * @param store_id        店铺 id
   * @param tag             商品 tag
   * @returns {Promise<*|Array|default.props.results|{type, default}>}
   */
  cls.prototype.fetchStoreTagGoods = async function ({ page, store_id, tag }) {
    const response = await cls.request({
      url: '/mall/goods/search/store',
      query: {
        page,
        store_id,
        tag
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 获取店铺所有商品的 tag
   * @param store_id        店铺 id
   * @param is_all          是否获取全部
   * @returns {Promise<*|Array|default.props.results|{type, default}>}
   */
  cls.prototype.tagList = async function (store_id, is_all) {
    const response = await cls.request({
      url: '/mall/goods/tag/list',
      query: {
        store_id,
        is_all
      }
    })

    return response.results
  }
}
