export default function (cls) {
  // 生成微信支付二维码
  cls.prototype.wechatQrcode = async function (paymentCode) {
    const response = await cls.request({
      method: 'post',
      url: '/sys/payment/wx/qrcode',
      data: {
        'payment_code': paymentCode
      }
    })

    return response.results
  }

  // 生成移动端微信支付所需的js参数
  cls.prototype.wechatJs = function ({ paymentCode, openid = '', WXCode = '' }) {
    return cls.request({
      method: 'post',
      url: '/sys/payment/wx/js',
      data: {
        'payment_code': paymentCode,
        'wx_openid': openid,
        'wx_code': WXCode
      }
    })
  }
}
