<template>
  <div :class="classes">
    <!--订单详情-->
    <div class="bill-detail">
      <div class="const-text">
        订单详情
      </div>
      <div class="detail-item">
        <p class="const-text">商品名称</p>
        <p class="name">{{ order.abstract }}</p>
      </div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--支付方式-->
    <div class="choose-payment">
      <div class="const-text">选择付款方式</div>
      <div class="payment">
        <div class="img-wrap">
          <img src="../../../assets/imgs/mall/icon-weichat-pay@2x.png" width="100%" height="100%">
        </div>
        <span class="const-text">微信支付</span>
        <div class="checker">
          <check-icon :value.sync="wechat"></check-icon>
        </div>
      </div>
      <!--
      <div class="payment fy-1px">
        <div class="img-wrap">
          <img src="../../../assets/imgs/mall/icon-ali-pay@2x.png" width="100%" height="100%">
        </div>
        <span class="const-text">支付宝</span>
        <div class="checker">
          <check-icon :value.sync="alipay"></check-icon>
        </div>
      </div>
      <div class="payment fy-1px">
        <div class="img-wrap">
          <img src="../../../assets/imgs/mall/icon-union-pay@2x.png" width="100%" height="100%">
        </div>
        <span class="const-text">中国银联</span>
        <div class="checker">
          <check-icon :value.sync="bank"></check-icon>
        </div>
      </div>
      -->
    </div>
    <!--底部栏-->
    <div class="bottom-bar fy-1px-t">
      <div class="all-count">
        实付：<span class="price">&yen;{{ order.pay_total }}</span>
      </div>
      <div class="go-to-bill">
        <div @click="goPay">
          <span class="const-text">去付款</span>
        </div>
      </div>
    </div>
    <!-- 支付成功 -->
    <div v-transfer-dom>
      <confirm v-model="paySuccessModal"
               class="pay-modal"
               title=""
               confirm-text="查看订单"
               :show-cancel-button="false"
               @on-confirm="goToOrderPage">
        <div class="icon icon-success"></div>
        <p>支付成功</p>
      </confirm>
    </div>
    <!-- 支付失败 -->
    <div v-transfer-dom>
      <confirm v-model="payFailModal"
               class="pay-modal"
               title=""
               confirm-text="重新支付"
               cancel-text="查看该订单"
               @on-confirm="payFailModal = false"
               @on-cancel="goToOrderPage">
        <div class="icon icon-fail"></div>
        <p>支付失败</p>
      </confirm>
    </div>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, getQuery } from '@/common/js/utils'
import api from 'modules/mall/api/index.js'

export default{
  name: `${COMPONENT_PREFIX}PageChoosePay`,
  data () {
    return {
      order: {},
      orderCode: '',
      paymentCode: '',
      wechat: true,
      alipay: false,
      bank: false,
      channelType: 100,
      paySuccessModal: false,
      payFailModal: false,
      message: '',
      WXCode: null // 微信支付前获取微信 openid 前置安全码
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.WXCode = getQuery('code')
  },
  mounted () {
    this.initPage()
  },
  watch: {
    wechat: {
      handler (val) {
        this.changePayChannel('wechat', val)
      }
    },
    alipay: {
      handler (val) {
        this.changePayChannel('alipay', val)
      }
    },
    bank: {
      handler (val) {
        this.changePayChannel('bank', val)
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-choose-pay`
    }
  },
  methods: {
    async initPage () {
      this.orderCode = this.$route.params.orderCode
      this.order = await api.paymentPreview(this.orderCode)
    },
    changePayChannel (channel, val) {
      if (!val) {
        return
      }
      switch (channel) {
      case 'wechat':
        this.wechat = true
        this.alipay = false
        this.bank = false
        this.channelType = 100
        break
      case 'alipay':
        this.wechat = false
        this.alipay = true
        this.bank = false
        this.channelType = 200
        break
      case 'bank':
        this.wechat = false
        this.alipay = false
        this.bank = true
        this.channelType = 300
      }
    },
    async goPay () {
      // 跳转回页面的时候执行
      let res = await api.paymentAdd(this.orderCode, this.channelType)
      if (res.code === 200) {
        this.paymentCode = res.results.code
        if (this.wechat) {
          this.wechatPayCall()
        }
      }
    },
    async wechatPayCall () {
      let postData
      if (this.WXCode) {
        postData = { paymentCode: this.paymentCode, WXCode: this.WXCode }
      } else {
        let openid = this.$localStorage.get('__FA_WX_PAY_OPENID__')
        if (openid === null) {
          this.payFailModal = true
          return
        }
        postData = { paymentCode: this.paymentCode, openid }
      }
      const res = await api.wechatJs(postData)
      if (res.code === 200) {
        let data = res.results
        let vm = this
        const onBridgeReady = function () {
          /* eslint-disable */
          WeixinJSBridge.invoke(
            'getBrandWCPayRequest',
            {
              appId: data.appId,     //公众号名称，由商户传入
              timeStamp: data.timeStamp, //时间戳，自1970年以来的秒数
              nonceStr: data.nonceStr, //随机串
              package: data.package,
              signType: data.signType, //微信签名方式：
              paySign: data.paySign //微信签名
            },
            function (res) {
              if (res.err_msg === 'get_brand_wcpay_request:ok') {
                vm.paySuccessModal = true
              } else if (res.err_msg === 'get_brand_wcpay_request:fail') {
                vm.payFailModal = true
              }
            }
          )
        }

        if (typeof WeixinJSBridge === 'undefined') {
          if (document.addEventListener) {
            document.addEventListener('WeixinJSBridgeReady', onBridgeReady(), false)
          } else if (document.attachEvent) {
            document.attachEvent('WeixinJSBridgeReady', onBridgeReady())
            document.attachEvent('onWeixinJSBridgeReady', onBridgeReady())
          }
        } else {
          onBridgeReady()
        }
      }
    },
    // 查看订单
    goToOrderPage () {
      window.location = 'member.html#/my-order'
    }
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-choose-pay
    font-family: PingFangSC-Regular
    .bill-detail
      padding: 30px
      .const-text
        font-size: 28px
        line-height: 40px
        color: $black1
        padding-bottom: 20px
      .detail-item
        padding-top: 17px
        border-top: 2px dashed $grey
        .const-text
          font-size: 26px
          line-height: 37px
          color: $grey3
        .name
          font-size: 26px
          line-height: 37px
          color: $black2
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .choose-payment
      padding: 30px
      .const-text
        font-size: 28px
        line-height: 40px
        color: $black1
        padding: 0px 0px 13px 0px
      .payment
        display: flex;
        flex-direction: row
        justify-content: flex-start
        align-items: center
        vertical-align: center
        margin-top: 20px
        padding: 25px
        position: relative
        border: 1px solid $grey7
        .img-wrap
          width: 70px
          height: 70px
        .const-text
          font-size: 28px
          line-height: 40px
          color: $black2
          padding: 0
          margin-left: 10px
        .checker
          position: absolute
          right: 61px
          top: 50%
          transform: translateY(-50%)
    .bottom-bar
      position: fixed
      bottom: 0
      width: 100%
      height: 88px
      font-size: 0
      background-color: $white
      .all-count,.go-to-bill
        display: inline-block
        vertical-align: top
        text-align: center
        line-height: 88px
      .all-count
        width: 66%
        font-size: 28px
        color: $black2
        text-align: right
        padding-right: 30px
        .price
          font-size: 28px
          color: $orange
      .go-to-bill
        width: 34%
        background-color: $orange
        .const-text
          font-size: 28px
          color: $white
    .grey-area
      width: 100%
      height: 100%
      background-color: $grey4
.vux-confirm&.pay-modal .icon
    margin-bottom: 32px
    inline-icon(104px, 104px)
    &.icon-success
      bg-img('../../../assets/imgs/mall/icon-pay-success')
    &.icon-fail
      bg-img('../../../assets/imgs/mall/icon-pay-fail')
</style>
