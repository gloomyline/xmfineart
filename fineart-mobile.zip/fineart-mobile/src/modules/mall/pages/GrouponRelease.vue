<template>
  <div :class="classes">
    <groupon-head title="发布团购"></groupon-head>
    <group>
      <x-input v-model="releaseForm.name" type="text" :max="24" placeholder="请输入团购名称" :show-clear="false"></x-input>
      <x-textarea v-model="releaseForm.subtitle" :max="24" class="release-textarea" placeholder="简要介绍团购项目"></x-textarea>
    </group>
    <div class="upload-picture-wrap">
      <ul class="show-pic">
        <li class="pic" v-for="(img, index) in ossImageThumb" :key="index">
          <img :src="img" alt="">
          <i class="icon fy-icon-off" @click="deleteImage(index)"></i>
        </li>
        <li class="pic upload" v-show="ossImageThumb.length < 9">
          <fine-art-upload :width="214" :height="214"
                           :max-size="ossImage.max_size"
                           :data="ossImage.data"
                           :action="ossImage.host"
                           :format="ossImage.format"
                           :accept="ossImage.accept"
                           :beforeUpload="beforeUploadImage"
                           :on-success="successImage">
            <div class="upload-box"></div>
          </fine-art-upload>
        </li>
      </ul>
    </div>
    <x-textarea :max="512" v-model="releaseForm.introduction" class="detail-textarea" placeholder="请详细描述您的团购项目，包含产品/服务的介绍、特性、优势等等"></x-textarea>
    <!-- 选择属性 -->
    <div class="attribute-choose">
      <span class="label-span">属性</span>
      <checker class="choice" v-model="releaseForm.attribute" selected-item-class="choose-item">
        <checker-item value="100">
          <i class="icon"></i>
          <span class="fy-icon-check">
            <span class="path1"></span><span class="path2"></span><span class="path3"></span>
          </span>
          <span class="name">产品型(实物)</span>
        </checker-item>
        <checker-item value="200">
          <i class="icon"></i>
          <span class="fy-icon-check">
            <span class="path1"></span><span class="path2"></span><span class="path3"></span>
          </span>
          <span class="name">服务型(无实物)</span>
        </checker-item>
      </checker>
    </div>
    <!--分割线 -->
    <div class="fy-divider"></div>
    <group>
      <fine-art-category title="分类" v-model="cate" :data-list="cateList" @choice-cate="chooseCate"></fine-art-category>
      <x-input :max="12" v-model="releaseForm.price" type="text" title="团购价" placeholder="请输入团购价, 如 200元" placeholder-align="right" text-align="right" :show-clear="false"></x-input>
      <x-input :max="3" v-model="releaseForm.unit" type="text" title="单位" placeholder="请输入单位, 如 件" placeholder-align="right" text-align="right" :show-clear="false"></x-input>
      <x-input :max="24" v-model="releaseForm.contact_name" type="text" title="您的姓名" placeholder="请输入您的真实姓名" placeholder-align="right" text-align="right" :show-clear="false"></x-input>
      <x-input v-model="releaseForm.contact_mobile" type="number" title="联系电话" placeholder="请输入您的手机号码" placeholder-align="right" text-align="right" :show-clear="false"></x-input>
      <p class="tip">提示：客服审核后，您的团购即可发布。可在[参与名单]中查看参团用户名单。</p>
      <x-button class="save-btn" type="primary" @click.native="releaseGroupon">发布</x-button>
    </group>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import api from 'modules/mall/api'
import * as MSG from 'assets/data/message.js'
import { getGrouponCategory } from '@/common/js/loadScript'
import { Checker, CheckerItem } from 'vux'
import { GrouponHead, FineArtUpload, FineArtCategory } from 'components'
export default {
  name: `${COMPONENT_PREFIX}GrouponRelease`,
  components: {
    GrouponHead,
    FineArtUpload,
    FineArtCategory,
    Checker,
    CheckerItem
  },
  data () {
    const mobileValidator = (rule, value, cb) => {
      if (!(/^1\d{9}\d$/.test(value))) {
        cb(new Error('手机号格式不正确！'))
      } else {
        cb()
      }
    }
    return {
      cate: '',
      cateList: [],
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      ossImageThumb: [],
      releaseForm: {
        name: '',
        subtitle: '',
        images: [],
        introduction: '',
        attribute: '100',
        mall_groupon_category_id: '',
        price: '',
        unit: '',
        contact_name: '',
        contact_mobile: ''
      },
      releaseRule: {
        name: [
          { required: true, message: '请填写团购名称' }
        ],
        subtitle: [
          { required: true, message: '请填写团购简介' }
        ],
        images: [
          { required: true, type: 'array', min: 1, message: '请上传商品图' },
          { type: 'array', min: 1, max: 9, message: '请上传1~9张商品图' }
        ],
        introduction: [
          { required: true, message: '请填写团购描述' }
        ],
        mall_groupon_category_id: [
          { required: true, message: '请选择团购分类' }
        ],
        price: [
          { required: true, message: '请填写团购价' }
        ],
        unit: [
          { required: true, message: '请填写单位' }
        ],
        contact_name: [
          { required: true, message: '请填写您的姓名' }
        ],
        contact_mobile: [
          { required: true, message: '请填写手机号码' },
          mobileValidator
        ]
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-groupon-release`
    }
  },
  created () {
    this.init()
  },
  methods: {
    async init () {
      this.cateList = await getGrouponCategory()
    },
    deleteImage (index) {
      this.ossImageThumb.splice(index, 1)
      this.releaseForm.images.splice(index, 1)
    },
    // 图片上传之前
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'groupon_image', this.ossImage)
    },
    // 图片上传成功
    successImage (res) {
      this.ossImageThumb.push(res.results.file_url_cdn)
      this.releaseForm.images.push(res.results.file_url)
    },
    chooseCate (value) {
      this.releaseForm.mall_groupon_category_id = value.pop()
    },
    async releaseGroupon () {
      const rules = await validate(this.releaseForm, this.releaseRule)
      if (!rules) return
      const response = await api.GrouponAdd(this.releaseForm)
      if (response.code === 200) {
        const vm = this
        this.$store.commit('ADD_MESSAGE', {
          msg: MSG['MALL_GROUPON_ADD_SUCCESS'],
          type: 'success',
          cb () {
            vm.$router.push({path: `/groupon/${vm.releaseForm.attribute}`})
          }
        })
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: response.msg})
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-groupon-release
  padding: 0 0 34px 0
  color: $black1
  .fy-divider
    width: 100%
    height: 20px
    background-color: $grey5
  .weui-cells
    margin-top: 0
    padding: 0 30px
    .weui-cell
      padding: 0
      height: 100px
      .weui-label
        color: $black2
      &.release-textarea:after
        display: none !important
      &.vux-x-textarea
        height: 160px
        padding: 30px 0
        .weui-cell__bd
          height: 100%
          .weui-textarea-counter
            display: none
          .weui-textarea
            height: 100%
  .detail-textarea
    width: 690px
    height: 275px
    margin: 40px auto
    border: 1.4px solid $grey
    border-radius: 4px
    &.vux-x-textarea
      height: 275px
      padding: 20px 24px
      .weui-cell__bd
        height: 100%
        .weui-textarea-counter
          display: none
        .weui-textarea
          height: 100%
  .save-btn
    margin-top: 30px
  .upload-picture-wrap
    overflow: hidden
    padding: 0 30px
    .show-pic
      display: flex
      flex-flow: wrap
      margin-right: -24px
      .pic
        position: relative
        width: 214px
        height: 214px
        margin-right: 24px
        margin-bottom: 30px
        border-radius: 10px
        &>img
          display: block
          width: 214px
          height: 214px
          border-radius: 10px
        .icon
          absolute: right top
          width: 40px
          height: 40px
          text-align: center
          color: $white
          font-size: 18px
          line-height: 40px
          background-color: rgba(67, 67, 67, 0.7)
          border-radius: 0 10px 0 10px
    .upload-box
      width: 214px
      height: 214px
      background: $greyF9 url('../../../assets/imgs/mall/icon-tgupload.png') center center no-repeat
      background-size: 122px auto
      border-radius: 10px
  .attribute-choose
    display: flex
    justify-content: space-between
    align-items: center
    width: 100%
    padding: 0 30px
    margin-bottom: 40px
    .label-span
      color: $black2
      font-size: 28px
    .choice
      display: flex
      justify-content: space-between
      align-items: center
      width: 540px
      .vux-checker-item
        display: flex
        align-items: center
      .name
        font-size: 28px
        color: $grey3
      .icon
        width: 36px
        height: 36px
        margin-right: 13px
        border: 1.4px solid $grey3
        border-radius: 50%
      .fy-icon-check
        width: 36px
        height: 36px
        display: none
        font-size: 40px
        margin-right: 13px
      .choose-item
        .icon
          display: none
        .name
          color: $orange
        .fy-icon-check
          display: inline-block
  .tip
    margin-top: 30px
    color: $grey2
    font-size: 24px
    line-height: 33px
</style>
