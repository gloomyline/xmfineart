<template>
  <div :class="classes">
    <!--线下店详情轮播图-->
    <swiper
      :auto="true"
      :loop="true"
      :interval="5000"
      :duration="500"
      dots-position="center"
      :aspect-ratio="420/750">
      <swiper-item
        v-for="(item, index) in storeDetail.store_images_cdn" :key="index">
        <img :src="item" width="100%">
      </swiper-item>
    </swiper>
    <!-- 返回线下店列表 -->
    <div class="btn-back-to-goods" @click="goBack"></div>
    <div class="store-info-wrap">
      <!--线下店详情基本信息-->
      <div class="store-detail-basic-info fy-1px-b">
        <h3 class="name">{{ storeDetail.name }}</h3>
        <p class="sub-title">{{ storeDetail.subtitle }}</p>
      </div>
      <!--店铺介绍-->
      <div class="storeIntroduce fy-1px-b">
        <p class="const-text">
          店铺介绍
        </p>
        <div class="introduceDetail">
          <p>{{ storeDetail.introduction }}</p>
          <p class="onbusinessTimeAndCall">
          <span>
            店长 {{ storeDetail.manager }}
          </span>
            <span class="call">
            联系电话 {{ storeDetail.mobile }}
          </span>
          </p>
        </div>
      </div>
      <!--地址-->
      <router-link :to="`/store-map/${storeDetail.id}/${storeDetail.lng}/${storeDetail.lat}`" class="address">{{ storeDetail.address_desc }}<span class="icon fy-icon-arrow-right"></span></router-link>
    </div>
      <!--灰色线-->
    <div class="divider" ref="tabBarDivider"></div>
    <!--本店商品tab-->
    <div class="more-info">
      <tab :line-width="2" custom-bar-width="40px" default-color="#333" active-color="#F7B52C" :animate="false">
        <tab-item  :selected="seletedIndex === -1" @on-item-click="changeTag('', -1)">全部</tab-item>
        <tab-item  :selected="seletedIndex === id" v-for="(tagName, id) in tagList" :key="id" @on-item-click="changeTag(tagName, id)">{{ tagName }}</tab-item>
        <tab-item  disabled v-if="!tagIsAll && tagList.length">
          <div class="moreIcon" @click="tagUsedList(!tagIsAll)">
            <div class="img-wrap">
              <img class="icon" src="../../../assets/imgs/mall/icon-store-detail-more-goods@2x.png" height="100%" width="100%">
            </div>
          </div>
        </tab-item>
      </tab>
    </div>
    <!-- 本店商品列表容器 -->
    <cube-scroll
      ref="scroller"
      @pulling-up="loadMore"
      @scroll="scroll"
      @scroll-end="scrollEnd"
      :data="goodsList.data"
      :options="scrollOptions"
      :scroll-events="['scroll', 'scroll-end']"
      class="store-detail-scroller">
      <div class="store-detail-wrap" v-if="hasData">
        <div class="store-detail">
          <router-link
            class="store-detail-item"
            v-for="(foreGood, index) in goodsList.data"
            :key="index"
            :to="`/goods-detail/${foreGood.id}/${id}`">
            <div class="img-wrap"><img :src="foreGood.thumbnail" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ foreGood.name }}</p>
              <p class="tags">{{ foreGood.subtitle }}</p>
              <p class="price"><em>&yen;</em>{{ foreGood.price_norm }}</p>
            </div>
          </router-link>
        </div>
      </div>
      <fine-art-empty v-else></fine-art-empty>
    </cube-scroll>
    <!-- 底部菜单栏，收藏-->
    <div class="bottom-bar" ref="pageBottomBar">
      <div class="favorite fy-1px-r" @click="changeCollection">
        <div class="icon-wrap">
          <span class="icon fy-icon-sel-collection" v-if="hasCollected"></span>
          <span class="icon fy-icon-star-rough" v-else></span>
        </div>
        <p class="label" :class="{'origin': hasCollected}">{{ collectionText }}</p>
      </div>
      <div class="call-shopmanageer"><a class="call-shopphone" :href="`tel:${storeDetail.mobile}`">联系店长</a></div>
    </div>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>
<script>
import { COMPONENT_PREFIX, COLLECT_MESSAGE_DURATION } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { Scroll } from 'cube-ui'
import { FineArtEmpty, FineArtLoginTip } from '@/components'
import * as MSG from 'assets/data/message.js'
import api from 'modules/mall/api'

export default {
  name: `${COMPONENT_PREFIX}PageForeShowDetail`,
  data () {
    return {
      tagIsAll: false,
      storeDetail: [],
      tagList: ['', '', '', '', ''],
      goodsList: [],
      hasCollected: false,
      collectionText: '关注店铺',
      apiProcessing: false,
      pageConfig: {
        page: 1,
        store_id: '',
        tag: ''
      },
      seletedIndex: -1,
      loginTipModal: false,
      scrollOptions: {
        pullDownRefresh: false,
        pullUpLoad: {
          threshold: 30,
          txt: {
            more: '加载完成',
            noMore: '-- END --'
          }
        },
        scrollbar: true,
        bounce: { // 商品滚动容器回弹效果
          top: false,
          bottom: true,
          left: true,
          right: true
        }
      },
      isScrollDisabled: false,
      maxScrollTop: '', // 页面最大滚动高度
      threshold: 30 // 滚动阀值
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '店铺详情')
    this.fetchStoreDetail()
    this.tagUsedList()
    this.fetchStoreTagGoods()
    document.documentElement.scrollTop = window.pageYOffset = document.body.scrollTop = 0
  },
  mounted () {
    window.addEventListener('scroll', this.scrollHandler)
  },
  beforeDestroy () {
    window.addEventListener('scroll', this.scrollHandler)
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  watch: {
    'goodsList.data': {
      deep: true,
      handler (newVal) {
        const len = newVal.length
        if (len <= 4) {
          this.$refs.scroller.disable()
        } else {
          this.$refs.scroller.enable()
        }
      }
    },
    // 监听登录结果，登录成功则更新店铺详情数据
    isLogin (newVal) {
      if (newVal) {
        this.fetchStoreDetail()
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-store-detail`
    },
    hasData () {
      return this.goodsList.total > 0
    },
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  methods: {
    goBack () {
      document.referrer === '' ? this.$router.push({ path: '/store' }) : this.$router.go(-1)
    },
    _updateShare () {
      const vm = this
      this.$wx.updateShareData('mall', {
        title: vm.storeDetail.name,
        desc: vm.storeDetail.subtitle
      })
    },
    // 获取线下店信息
    async fetchStoreDetail () {
      this.storeDetail = await api.fetchStoreDetail(this.id)
      this._updateShare()
      this.changeCollectionBtn(this.storeDetail.has_collected)
      this.$nextTick(() => {
        const documentHeight = document.body.clientHeight // 页面高度
        const screenHeight = window.screen.height // 视口高度
        this.maxScrollTop = documentHeight - screenHeight // 页面最大滚动高度
      })
    },
    // 初始及变更标签时，获取商品列表，
    async fetchStoreTagGoods () {
      this.pageConfig.store_id = this.id
      this.goodsList = await api.fetchStoreTagGoods(this.pageConfig)
      this.$nextTick(() => {
        this.$refs.scroller.scrollTo(0, 0)
      })
    },
    // 初始获取标签列表
    async tagUsedList (is_all = false) {
      this.tagList = await api.tagList(this.id, is_all)
      this.$nextTick(() => {
        if (is_all) {
          this.tagIsAll = is_all
          this.seletedIndex = this.tagList - 1
        }
      })
    },
    // 变更标签
    changeTag (tag, tabIndex) {
      this.pageConfig.tag = tag
      this.seletedIndex = tabIndex
      this.fetchStoreTagGoods()
    },
    // 加在更多商品列表数据
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.goodsList.has_next) {
        return this.$refs.scroller.forceUpdate()
      }

      this.pageConfig.page = this.goodsList.current_page + 1
      // 商品列表分页
      let dataList = await api.fetchStoreTagGoods(this.pageConfig)
      for (let index in dataList.data) {
        this.goodsList.data.push(dataList.data[index])
      }
      this.goodsList.current_page = dataList.current_page
      this.goodsList.has_next = dataList.has_next
      this.$nextTick(() => {
        this.$refs.scroller.forceUpdate()
      })
    },
    // 变更关注状态
    async changeCollection () {
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      if (this.apiProcessing) {
        return false
      }
      this.apiProcessing = true
      let code = await api.collectStore(this.id)
      if (code === 200) {
        this.changeCollectionBtn(!this.hasCollected)
        if (this.hasCollected) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
      }
      setTimeout(() => {
        this.apiProcessing = false
      }, COLLECT_MESSAGE_DURATION)
    },
    changeCollectionBtn (status) {
      this.hasCollected = status
      this.collectionText = status ? '已关注' : '关注店铺'
    },
    scroll ({ x, y }) {
      this.sy = y
    },
    scrollEnd ({ x, y }) {
      this.ey = y
      if (this.ey <= this.sy && this.sy >= -10) {
        this.$refs.scroller.disable()
        this.isScrollDisabled = true
      }
    },
    scrollHandler (e) {
      const sTop = e.target.documentElement.scrollTop || e.target.body.scrollTop
      if (sTop >= this.maxScrollTop - this.threshold && this.isScrollDisabled) {
        this.$refs.scroller.enable()
        this.isScrollDisabled = false
      }
    }
  },
  // 从详情页返回列表页时把列表页的keepAlive值设置为true
  beforeRouteLeave (to, from, next) {
    if (to.path === '/store') {
      to.meta.keepAlive = true
    } else {
      to.meta.keepAlive = false
    }
    next()
  },
  components: {
    FineArtEmpty,
    FineArtLoginTip,
    'cube-scroll': Scroll
  }
}
</script>
<style lang="stylus">
  .{$cls_prefix}-page-store-detail
    position: relative
    padding-bottom: 88px
    font-family: PingFangSC-Regular
    .vux-swiper
      background: $grey4
    .btn-back-to-goods
      absolute: left 30px top 30px
      width: 56px
      height: 56px
      border-radius: 50%
      bg-img('../../../assets/imgs/mall/icon-go-back')
      background-size: cover
    .store-info-wrap
      padding: 30px
      .store-detail-basic-info
        padding-bottom: 30px
        .name
          color: $black1
          font-size: 34px
          margin-bottom: 10px
          line-height: 48px
        .sub-title
          font-size: 26px
          color: $grey3
          line-height: 37px
      .storeIntroduce
        padding: 30px 0
        .const-text
          color: $black1
          font-size: 28px
          line-height: 40px
          margin-bottom: 16px
        .introduceDetail
          font-size: 26px
          line-height:38px
          color: $grey3
          .onbusinessTimeAndCall
            margin-top: 40px
            .call
              display: block
      .address
        position: relative
        display: block
        font-size: 26px
        min-height: 37px
        line-height: 37px
        padding: 30px 92px 0 0
        color: $black2
        .fy-icon-arrow-right
          absolute: right 22px top 22px
          padding: 8px
          font-size: 32px
          color: $grey6
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .more-info
      font-size: 28px
      line-height: 40px
      margin-bottom: 20px
      .vux-tab-selected
        position: relative
        border-bottom: none !important
        background: linear-gradient(180deg, #e5e5e5, #e5e5e5, rgba(229, 229, 229, 0)) bottom left no-repeat !important
        background-size: 100% 1PX !important
        &:after
          width: 60px
          height: 3px
          background: $orange
          absolute: left 50% bottom
          transform: translateX(-50%)
          content: ''
      .moreIcon
        text-align: center
        vertical-align: center
      .img-wrap
        padding-top: 8px
        .icon
          max-width: 36px
    .subAtonceButton
      height: 88px
      background-color: $orange
      color: whites
      font-size: 30px
      display: inline-block
      width: 100%
      text-align: center
      line-height: 88px
      position: fixed
      bottom: 0
    .store-detail-scroller
      height: 900px
      .store-detail-wrap
        padding: 0 22px
        overflow-y: hidden
        .store-detail
          display: flex
          flex-wrap: wrap
          margin-right: -18px
          .store-detail-item
            width: 344px
            margin: 0 18px 35px 0
            .img-wrap
              width: 100%
              height: 344px
              margin-bottom: 20px
              background: $grey4
            .desc
              padding-left: 8px
              font-size: 0
              .name
                line-height: 40px
                margin-bottom: 4px
                font-size: 28px
                color: $black1
                {ellipse}
              .tags
                line-height: 33px
                margin-bottom: 8px
                font-size: 24px
                color: $grey3
                padding-right: 60px
                {ellipse}
              .price
                line-height: 37px
                font-size: 24px
                color: $orange
    .cube-pullup-wrapper
      .before-trigger
        font-size: 26px
        color: $grey
      .cube-pulldown-wrapper
        .after-trigger
          .cube-pulldown-loaded
            font-size: 26px
            color: $grey
      .cube-loading-spinners
        width: 48px
        height: 48px
    .bottom-bar
      position: fixed
      bottom: 0
      width: 100%
      height: 88px
      font-size: 0
      z-index: 11
      background-color: $white
      .favorite,.call-shopmanageer
        height: 100%
        display: inline-block
        vertical-align: top
        text-align: center
      .favorite
        width: 30%
        border-top: 1px $grey solid
        .icon-wrap
          padding-top: 14px
          margin-bottom: 6px
          font-size: 32px
          .fy-icon-sel-collection
            color: $orange
          img
            max-width: 60px
        .label
          font-size: 20px
          color: $black2
          &.origin
            color: $orange
        .fy-icon-sel-collection
          color: $yellow
      .call-shopmanageer
        width: 70%
        line-height: 88px
        font-size: 28px
        background-color: $orange
        .call-shopphone
          color: $white
          display: block
          width: 100%
          height: 100%
</style>
