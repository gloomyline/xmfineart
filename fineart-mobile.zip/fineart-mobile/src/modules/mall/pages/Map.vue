<template>
  <div :class="classes">
    <div class="map-container" id="store-map">
      <div class="btn-location" @click="location"><span class="icon"></span></div>
      <div class="point-center"><span class="icon"></span></div>
    </div>
    <transition name="slide-up">
      <div class="pop-info-card" v-show="isPopShow"  @click="goToDetail(selectedMarkerInfo.id)">
        <div class="thumbnail-wrap">
          <div class="thumbnail"><img :src="selectedMarkerInfo.thumbnail" width="100%" height="100%"></div>
        </div>
        <div class="descriptions">
          <h3 class="name">{{ selectedMarkerInfo.name |labelFormatter(13) }}</h3>
          <p class="tags">{{ selectedMarkerInfo.category_line }}</p>
          <div class="apply-link" v-if="selectedMarkerInfo.attribute === 300"></div>
          <p class="address" v-else>
            <span class="icon fy-icon-location"></span>
            <span class="address-text">{{ addressText |labelFormatter(31) }}</span>
          </p>
        </div>
        <div class="btn-close" @click.stop="closePop"><span class="icon fy-icon-off"></span></div>
        <div class="icon-link-wrap"><span class="icon-link fy-icon-arrow-right"></span></div>
      </div>
    </transition>
    <!--测试用放大缩小按钮-->
    <!--<div class="test-buttons">-->
      <!--<div class="zoom-out" @click="zoomOut">放大</div>-->
      <!--<div class="zoom-in" @click="zoomIn">缩小</div>-->
    <!--</div>-->
  </div>
</template>

<script>
import {
  COMPONENT_PREFIX,
  MAP_MARKER_COMMON_WIDTH,
  MAP_MARKER_COMMON_HEIGHT,
  MAP_MARKER_ACTIVE_WIDTH,
  MAP_MARKER_ACTIVE_HEIGHT
} from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils'

import api from 'modules/mall/api'

const MARKER_ENTITY = 200 // 实体店
const MARKER_PRE = 300 // 预开店
const MARKER_SELF = 400 // 自营店

export default {
  name: `${COMPONENT_PREFIX}PageMallMap`,
  data () {
    return {
      // 底部店铺信息卡片弹窗显示状态：true -> 显示，false -> 不显示
      isPopShow: false,
      // 页面配置
      pageConfig: {
        page: 1,
        lng: null,
        lat: null,
        keywords: '',
        category_id: '',
        area_id: '',
        is_representative: '',
        sort: 'distance_asc'
      },
      // 线下店列表
      stores: [],
      // 预创建标记集合
      markersSet: {},
      // 预创建标记图标集合
      iconsSet: {},
      // 已添加到地图上的标记
      markers: [],
      // 选中的标记信息
      selectedMarkerInfo: {},
      // 选中的标记
      selectedMarker: {
        isActive: false,
        info: {}
      },
      // 上一次地图中心点所在经纬度
      historyLngLat: null,
      // 地图实例
      map: null,
      oldZoom: 11,
      // 是否需要请求api
      isRequestApi: true,
      // 普通标记点
      comMarkers: [],
      // 代表标记点
      representMarkers: [],
      // 要重新渲染的普通标记点
      recoverComMarkers: [],
      // 要重新渲染的代表标记点
      recoverRepMarkers: []
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.$store.commit('MODIFY_PAGE_NAME', '斐艺购地图')
    this._initMap()
  },
  props: ['storeId', 'lng', 'lat'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-mall-map`
    },
    addressText () {
      return this.selectedMarkerInfo.area_line + this.selectedMarkerInfo.address
    }
  },
  watch: {
    stores () {
      try {
        this.addMarkers()
      } catch (e) {
        window.location.reload()
      }
    }
  },
  methods: {
    async _initMap () {
      this.map = await this._initMapInstance()
      this._bindEvents()
      this.initMarkersAndIcons()
      const response = await api.fetchStoreList(this.pageConfig)
      this.stores = response.data
    },
    async _initMapInstance () {
      try {
        const map = await this.$fMap.createMap('store-map')
        // 设置地图主题样式 - 远山黛
        map.setMapStyle('amap://styles/whitesmoke')
        // 初始化地图中心点, 指定店铺位置，否则使用用户当前位置
        if (Number.parseInt(this.storeId) !== 0) {
          map.setCenter([this.lng, this.lat])
          this.pageConfig.lng = this.lng
          this.pageConfig.lat = this.lat
        } else {
          const position = await this.$fMap.geoLocation()
          this.pageConfig.lng = position.lng
          this.pageConfig.lat = position.lat
          map.setCenter([position.lng, position.lat])
        }
        // 初始化缩放比例尺样式
        this.$nextTick(() => {
          const scaleControl = this.$el.querySelector('.amap-scalecontrol')
          scaleControl.style.left = '15px'
          scaleControl.style.bottom = '15px'
        })
        // 初始化时，储存当前地图中心点地理位置
        this.historyLngLat = [this.pageConfig.lng, this.pageConfig.lat]
        return map
      } catch (e) {
        window.location.reload()
      }
    },
    _bindEvents () {
      // 监听地图移动结束
      this.map.on('moveend', async () => {
        // 获取中心点坐标
        const centerPt = this.map.getBounds().getCenter()
        if (this.storeId != null && this.historyLngLat === null) return
        // 大于100公里不请求数据
        if (this.map.getZoom() <= 7) return
        // 限制距离更新数据
        if (Math.abs(this.historyLngLat[0] - centerPt.lng) < 2 &&
          Math.abs(this.historyLngLat[1] - centerPt.lat) < 2 && this.map.getZoom() >= 8) return
        // 更新最新坐标用于下次判断
        this.historyLngLat = [centerPt.lng, centerPt.lat]
        this.pageConfig.lng = centerPt.lng
        this.pageConfig.lat = centerPt.lat
        const response = await api.fetchStoreList(this.pageConfig)
        this.stores = response.data
      })

      // 监听地图放大缩小
      this.map.on('zoomchange', async () => {
        if (!this.storeId) return
        if (this.oldZoom > 7) {
          // 上一个比例尺在100公里以下，下一个比例尺大于等于100公里，清除地图上100公里以下标记点，请求大于100公里的数据
          if (this.map.getZoom() <= 7) {
            if (this.map && this.comMarkers) {
              this.map.remove(this.comMarkers)
            }
            this.pageConfig.is_representative = '200'
            const response = await api.fetchStoreList(this.pageConfig)
            this.stores = response.data
          } else { // 上一个比例尺在100公里以下，下一个比例尺也在100以下,不清除数据,也请求数据
            const response = await api.fetchStoreList(this.pageConfig)
            this.stores = response.data
          }
        } else { // 上一个比例尺大于等于100公里，下一个比例尺大于仍等于100公里，不清除数据，也不请求数据
          if (this.map.getZoom() <= 7) {
          } else { // 上一个比例尺大于等于100公里，下一个比例尺小于100公里，清除100公里以上标记点，恢复原先数据，再请求数据
            if (this.map && this.representMarkers) {
              this.map.remove(this.representMarkers)
            }
            // 恢复原先数据
            this.recoverComMarkers.length === 0 ? this.map.add(this.comMarkers) : this.map.add(this.recoverComMarkers)
            this.pageConfig.is_representative = ''
            const response = await api.fetchStoreList(this.pageConfig)
            this.stores = response.data
          }
        }
        // 存储当前比例尺
        this.oldZoom = this.map.getZoom()
      })

      // 监听地图点击
      this.map.on('click', () => {
        if (this.isPopShow) {
          this.isPopShow = false
          this.inactive()
        }
      })
    },
    createIcon (iconType, isActive = false) {
      const AMap = this.$fMap.Map
      const w = isActive ? MAP_MARKER_ACTIVE_WIDTH : MAP_MARKER_COMMON_WIDTH
      const h = isActive ? MAP_MARKER_ACTIVE_HEIGHT : MAP_MARKER_COMMON_HEIGHT
      let iconUrl = ''
      switch (iconType) {
      case MARKER_ENTITY:
        iconUrl = require('assets/imgs/mall/icon-marker-entity.png')
        break
      case MARKER_PRE:
        iconUrl = require('assets/imgs/mall/icon-marker-pre-opened.png')
        break
      case MARKER_SELF:
        iconUrl = require('assets/imgs/mall/icon-marker-self-support.png')
        break
      default:
        break
      }
      return new AMap.Icon({
        imageSize: new AMap.Size(w, h),
        image: iconUrl,
        size: new AMap.Size(w, h)
      })
    },
    // 初始化初始标记以及选中、未选中的 icon 集合
    initMarkersAndIcons () {
      const AMap = this.$fMap.Map
      const markerTypes = [MARKER_ENTITY, MARKER_PRE, MARKER_SELF]
      markerTypes.forEach(markerType => {
        const icon = this.createIcon(markerType)
        const iconActive = this.createIcon(markerType, true)
        const item = () => (new AMap.Marker({
          offset: new AMap.Pixel(-(MAP_MARKER_COMMON_WIDTH / 2), -MAP_MARKER_COMMON_HEIGHT),
          icon: icon
        }))
        this.iconsSet[markerType] = [icon, iconActive]
        this.markersSet[markerType] = item
      })
    },
    // 根据 store 列表数据在地图上添加店铺标记
    addMarkers () {
      this.stores.forEach(item => {
        let isHasSameMarder = false
        if (this.pageConfig.is_representative !== '200') { // 只有在100公里以下才进行数据过滤
          this.comMarkers.forEach((comMarker) => {
            if (comMarker.id === item.id) {
              isHasSameMarder = true
            }
          })
        }
        if (isHasSameMarder) return
        const marker = this.markersSet[item.attribute]()
        marker.info = item
        marker.id = item.id
        this.bindClickToMarker(marker)
        this.map.add(marker)
        marker.setPosition([item.lng, item.lat])
        this.markers.push(marker)
        if (this.pageConfig.is_representative === '200') {
          this.representMarkers.push(marker)
        } else {
          this.comMarkers.push(marker)
        }
      })
      this._initPopInfo()
    },
    // 给每一个标记绑定 click 事件
    bindClickToMarker (marker) {
      marker.on('click', opts => {
        // update 当前信息卡片弹窗显示状态
        if (marker.info.id === this.selectedMarkerInfo.id && this.selectedMarker.isActive) {
          this.inactive()
          this.isPopShow = !this.isPopShow
        } else {
          this.isPopShow = true
          // 当前选中的地图标记
          const target = opts.target
          this.active(target)
        }
      }, this)
    },
    // 恢复当前选中标记为普通状态
    inactive () {
      const AMap = this.$fMap.Map
      const attribute = this.selectedMarkerInfo.attribute
      this.selectedMarker.setIcon(this.iconsSet[attribute][0], {
        w: MAP_MARKER_COMMON_WIDTH,
        h: MAP_MARKER_COMMON_HEIGHT
      })
      this.selectedMarker.setOffset(new AMap.Pixel(-(MAP_MARKER_COMMON_WIDTH / 2), -MAP_MARKER_COMMON_HEIGHT))
      this.selectedMarker.isActive = false
    },
    // 激活当前选中标记
    active (target) {
      const AMap = this.$fMap.Map
      const attribute = target.info.attribute
      // 选中状态下的建筑标记图标
      const activeIcon = this.iconsSet[attribute][1]
      // 恢复上一个处于激活状态地图标记的状态
      if (this.selectedMarkerInfo.id) this.inactive()
      // 突出显示选中地图标记
      target.setTop(true)
      target.setIcon(activeIcon, {
        w: MAP_MARKER_ACTIVE_WIDTH,
        h: MAP_MARKER_ACTIVE_HEIGHT
      })
      target.setOffset(new AMap.Pixel(-(MAP_MARKER_ACTIVE_WIDTH / 2), -MAP_MARKER_ACTIVE_HEIGHT))
      target.isActive = true
      this.selectedMarker = target
      // update 当前选中地图标记信息
      this.selectedMarkerInfo = target.info
    },
    // 初始化信息卡片弹窗
    _initPopInfo () {
      const storeId = this.storeId
      for (let i = 0, len = this.markers.length; i < len; ++i) {
        const marker = this.markers[i]
        if (marker.info.id === storeId) {
          this.active(marker)
          this.selectedMarkerInfo = marker.info
          this.isPopShow = true
          break
        }
      }
    },
    // 定位
    location () {
      this.$fMap.setZoom(16)
      this.$fMap.mapGeoLocal()
    },
    // 前往店铺详情页
    goToDetail (id) {
      this.$router.push(`/store-detail/${id}`)
    },
    // 关闭信息卡片弹窗
    closePop () {
      this.inactive()
      this.isPopShow = false
    },
    zoomOut () {
      this.map.zoomOut()
    },
    zoomIn () {
      this.map.zoomIn()
    }
  },
  filters: {
    labelFormatter (str = '', length = 13) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-mall-map
  fixed: left top
  bottom: 0
  width: 100%
  background-color: $white
  color: $black1
  .map-container
    height: 100%
    z-index: 1
    .btn-location
      absolute: right 10px bottom 10px left 0!important
      width: 100px
      height: 100px
      z-index: 130
      .icon
        inline-icon(100px, 100px)
        bg-img('../../../assets/imgs/map/icon-location')
    .point-center
      position: absolute
      left: 50%
      top: 50%
      margin: -58px 0 0 -14px
      pointer-events: none
      z-index: 140
      .icon
        inline-icon(26px, 58px)
        bg-img('../../../assets/imgs/icon-map-select')
  .pop-info-card
    absolute: left bottom
    width: 100%
    padding: 40px
    font-size: 0
    background-color: $white
    border-radius: 12px 12px 0 0
    box-shadow: 0 -2px 30px 0 rgba(0, 0, 0, 0.14)
    z-index: 2
    &.slide-up-enter-active, &.slide-up-leave-active
      transition: all 0.3s ease-in
    &.slide-up-enter, &.slide-up-leave-to
      opacity: 0
      transform: translate3d(0, 280px, 0)
    .thumbnail-wrap
      display: inline-block
      vertical-align: top
      width: 200px
      .thumbnail
        width: 100%
        height: 200x
    .descriptions
      display: inline-block
      vertical-align: top
      width: 450px
      padding-left: 30px
      padding-top: 24px
      .name
        font-size: 30px
        font-weight: 500
        line-height: 42px
        margin-bottom: 20px
      .tags
        height: 32px
        font-size: 22px
        margin-bottom: 20px
        .tag
          display: inline-block
          line-height: 32px
          padding: 0 10px
          font-size: 22px
          color: $orange
          border: 1px solid $orange
          border-radius: 4px
      .address
        width: 100%
        font-size: 20px
        line-height: 34px
        color: $grey3
        display: flex
        align-items: baseline
        .fy-icon-location, .address-text
          display: inline-block
          vertical-align: top
          font-size: 24px
    .btn-close
      absolute: top right
      padding: 30px
      font-size: 0
      .fy-icon-off
        font-size: 32px
        color: $grey2
    .icon-link-wrap
      absolute: top 50% right 22px
      margin-top: -22px
      padding: 8px
      .fy-icon-arrow-right
        font-size: 28px
        color: $grey2
  .test-buttons
    position: absolute
    bottom: 340px
    right: 30px
    font-size: 24px
    z-index: 130
    .zoom-out , .zoom-in
      display: inline-block
      width: 80px
      height: 50px
      border: 1.4px solid $grey3
      text-align: center
      line-height: 50px
</style>
