<template>
  <div :class="classes">
    <div v-if="goodsOkLength === 0 && goodsNgLength === 0">
      <fine-art-empty></fine-art-empty>
    </div>
    <div class="goods-list-wrap" v-else>
      <swipeout class="ok-goods-list-wrap" >
        <swipeout-item
          transition-mode="follow"
          underlay-color="#C7C7C7"
          v-for="(item, index) in goodsOk" :key="index">
          <div slot="right-menu">
            <swipeout-button @click.native="deleteOkItem(index)" type="warn">删除</swipeout-button>
          </div>
          <!--已选商品-->
          <div class="selected-item" slot="content" >
            <div class="checker">
              <check-icon :value.sync="item.isChecked"></check-icon>
            </div>
            <div class="product-detail">
              <router-link class="img-wrap" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">
                <img :src="item.thumbnail_cdn" width="100%" height="100%">
              </router-link>
              <div class="detail">
                <router-link class="name" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">{{ item.name | labelFormatter(28) }}</router-link>
                <div class="price-count">
                  <div class="price">￥{{item.price_discount ? item.price_discount : item.price_norm}}</div>
                  <div class="count">
                    <table>
                      <tr>
                        <td class="reduce"  @click="reduce(index)"><i class="fy-icon-reduce"></i></td>
                        <td class="number"><input type="number" v-model="item.number" @change="editItemNumber(item.number,index)"></td>
                        <td class="add" @click="add(index)"><i class="fy-icon-add-grey"></i></td>
                      </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </swipeout-item>
      </swipeout>
      <!--失效商品-->
      <div class="past-dute-text" v-if="goodsNgLength > 0">以下商品已失效</div>
      <swipeout class="ng-goods-list-wrap" >
        <swipeout-item
          transition-mode="follow"
          underlay-color="#C7C7C7"
          v-for="(item, index) in goodsNg" :key="index">
          <div slot="right-menu">
            <swipeout-button @click.native="deleteNgItem(index)" type="warn">删除</swipeout-button>
          </div>
            <div class="selected-item" slot="content">
              <div class="checker">
                <div class="sold-out">下架</div>
              </div>
              <div class="product-detail" :class="{'fy-1px-b': index < goodsNgLength - 1}">
                <div class="img-wrap">
                  <img :src="item.thumbnail_cdn" width="100%" height="100%">
                </div>
                <div class="detail">
                  <p class="name">{{ item.name | labelFormatter(28) }}</p>
                  <div class="price-count">
                    <div class="price">&yen;{{ item.price_discount ? item.price_discount : item.price_norm }}</div>
                    <div class="count">
                      <div class="count-num">x{{ item.number }}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </swipeout-item>
      </swipeout>
      <!--底部栏-->
      <div class="bottom-bar fy-1px-t">
        <div class="select-all">
          <div class="checker">
            <check-icon :value.sync="isAllChecked"></check-icon>
          </div>
          <span>全选</span>
        </div>
        <div class="all-count">
          总计：<span class="price">&yen;{{ price_total }}</span>
        </div>
        <div class="go-to-bill">
          <span class="const-text" @click="goOrderConfirm()">去结算</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtEmpty } from 'components'
import api from 'modules/mall/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}PageCart`,
  data () {
    return {
      isAllChecked: true, // 是否全选
      goodsOk: [], // 有效商品
      goodsNg: [], // 无效商品
      price_total: '0.00' // 总计
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.initPage()
    this.$store.commit('MODIFY_PAGE_NAME', '购物车')
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-cart`
    },
    goodsOkLength () {
      return this.goodsOk.length
    },
    goodsNgLength () {
      return this.goodsNg.length
    }
  },
  watch: {
    goodsOk: {
      handler () {
        this.calculateTotalAndChecked()
      },
      deep: true
    },
    isAllChecked (newVal) {
      if (newVal) {
        this.checkAll(newVal)
      } else {
        let flag = 0
        for (let key in this.goodsOk) {
          flag += this.goodsOk[key].isChecked
        }
        if (flag === this.goodsOk.length) {
          this.checkAll(newVal)
        }
      }
    }
  },
  methods: {
    async initPage () {
      let results = await api.fetchCartItemList()
      for (let key in results.data) {
        let item = results.data[key]
        item.isChecked = true
        item.stock = Number.parseInt(item.stock)
        item.number = Number.parseInt(item.number)
        item.oldNumber = item.number
        item.delete = false
        if (item.status === '300' && item.stock > 0) {
          this.goodsOk.push(item)
        } else {
          this.goodsNg.push(item)
        }
      }
    },
    // 计算总计、选中状态、全选状态
    calculateTotalAndChecked () {
      this.price_total = 0
      this.isAllChecked = true
      for (let key in this.goodsOk) {
        if (this.goodsOk[key].isChecked) {
          this.price_total += this.goodsOk[key].price_discount ? parseFloat(this.goodsOk[key].price_discount) * this.goodsOk[key].number : parseFloat(this.goodsOk[key].price_norm) * this.goodsOk[key].number
        } else {
          this.isAllChecked = false
        }
      }
      this.price_total = parseFloat(this.price_total).toFixed(2)
    },
    add (index) {
      this.goodsOk[index].number++
      this.editItemNumber(this.goodsOk[index].number, index)
    },
    reduce (index) {
      if ((--this.goodsOk[index].number) === 0) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_LESS_THEN_ONE, type: 'warn' })
        this.goodsOk[index].number++
      } else {
        this.editItemNumber(this.goodsOk[index].number, index)
      }
    },
    // 全选/反选
    checkAll (val) {
      for (let key in this.goodsOk) {
        this.goodsOk[key].isChecked = val
      }
    },
    // 单个商品编辑数量
    /**
       * @param itemNum 商品数量
       * @param itemKey 商品数组索引
       * @returns {Promise<boolean>}
       */
    async editItemNumber (itemNum, itemKey) {
      let curItem = this.goodsOk[itemKey]
      // 发起API请求
      let response = await api.editCartItem({id: curItem.id, num: itemNum})
      if (response.code !== 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_EDIT_FAILED, type: 'warn' })
        // 请求失败，数据复原
        curItem.number = curItem.oldNumber
      } else {
        curItem.oldNumber = curItem.number
        console.log(curItem)
      }
      return true
    },
    // 删除单个有效商品
    async deleteOkItem (itemKey) {
      // 发起API请求
      this.goodsOk[itemKey].delete = true
      let result = await this.sendDeleteItem()
      if (result) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_DELETE_OK, type: 'success' })
      }
      return result
    },
    // 删除单个无效商品
    async deleteNgItem (itemKey) {
      this.goodsNg[itemKey].delete = true
      // 发起API请求
      let result = await this.sendDeleteItem()
      if (result) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_ITEM_DELETE_OK, type: 'success' })
      }
      return true
    },
    // 发送删除商品请求
    async sendDeleteItem () {
      // 获取要删除有效的商品ID
      let okIdArr = this.getItemIdArr(this.goodsOk)
      let ngIdArr = this.getItemIdArr(this.goodsNg)
      let deleteIdArr = okIdArr.concat(ngIdArr)
      let response = await api.delCartItem(deleteIdArr)
      if (response.code === 200) {
        // 本地删除有效的商品
        this.goodsOk = this.clearDeletedItems(this.goodsOk)
        // 本地删除无效的商品
        this.goodsNg = this.clearDeletedItems(this.goodsNg)
        // 更新 store mall 模块中购物车商品种类数量
        this.$store.dispatch('mall/fetchCartGoodsCount')
        return true
      } else {
        // 恢复商品的删除状态
        for (let key in this.goodsOk) {
          this.goodsOk[key].delete = false
        }
        for (let key in this.goodsNg) {
          this.goodsNg[key].delete = false
        }
        return false
      }
    },
    // 清除商品数组中要被删除的商品
    clearDeletedItems (items) {
      let itemList = []
      for (let key in items) {
        if (items[key].delete === false) {
          itemList.push(items[key])
        }
      }
      return itemList
    },
    // 获取商品的ID数组
    getItemIdArr (items) {
      let idArr = []
      for (let key in items) {
        if (items[key].delete) {
          idArr.push(items[key].id)
        }
      }
      return idArr
    },
    // 去确认订单(把当前选中的商品放入确认订单用的购物车ID数组)
    goOrderConfirm () {
      let cartItemIdArr = []
      for (let key in this.goodsOk) {
        if (this.goodsOk[key].isChecked) {
          cartItemIdArr.push(this.goodsOk[key].id)
        }
      }
      if (cartItemIdArr.length === 0) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_CART_CHECKOUT_EMPTY, type: 'warn' })
        return false
      }
      this.$store.commit('mall/MALL_CART_ITEM_ID_ARR', cartItemIdArr)
      this.$router.push({ path: '/mall-order' })
    }
  },
  filters: {
    labelFormatter (str = '', length = 28) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtEmpty
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-cart
    position: relative
    font-family: PingFangSC-Regular
  .divider
    display: block
    width: 100%
    height: 20px
    background-color: $grey4
  .vux-swipeout-item
    border-bottom: 20px solid $grey4
  .goods-list-wrap
    margin-bottom: 88px
  .selected-item
    padding: 30px
    display: flex
    align-items: center
    justify-content: left
    flex-direction: row
    .checker
      font-size: 0
      margin-right: 30px
      position: relative
      .vux-check-icon .weui-icon
        font-size: 39px
        &:before
          margin: 0
    .product-detail
      display: flex
      justify-content: left
      flex-direction: row
      position: relative
      .img-wrap
        height: 160px
        width: 160px
        background: $grey4
      .detail
        width: 442px
        margin-left:20px
        position: relative
        .name
          font-size: 28px
          line-height: 40px
          color: $black2
          margin-top: 8px
        .price-count
          .price
            font-size: 26px
            height:52px
            line-height: 52px
            color: $black1
            absolute: bottom left
          .count
            absolute: bottom right
            td
              height: 40px
              width: 48px
              font-size: 30px
              text-align: center
              line-height: 40px
              border: 2px solid #d9d9d9
            .number
              width: 62px
              font-size: 28px
              line-height: 40px
              color: $black2
              input
                width: 100%
                text-align:center
                padding: 0
                margin: 0
                border: none
            .reduce,.add
              padding-top: 5px
              font-size: 20px
            .count-num
              font-size: 26px
              line-height: 37px
              color: $grey3
  .past-dute-text
    height: 67px
    padding-top: 30px
    padding-left: 30px
    font-size: 26px
    line-height: 37px
    color: $black1
  .bottom-bar
    position: fixed
    bottom: 0
    width: 100%
    height: 88px
    font-size: 0
    background-color: $white
    .select-all,.all-count,.go-to-bill
      display: inline-block
      vertical-align: top
      text-align: center
      line-height: 88px
    .select-all
      width: 33%
      font-size: 28px
      color: $black2
      text-align: left
      .checker
        display: inline-block
        text-align: left
        .vux-check-icon
          margin-left: 39px
          .weui-icon-success
            font-size: 39px
          .weui-icon-circle
            font-size: 39px
          .weui-icon-success-circle
            font-size: 39px
    .all-count
      width: 33%
      font-size: 28px
      color: $black2
      .price
        font-size: 28px
        color: $orange
    .go-to-bill
      width: 34%
      background-color: $orange
      .const-text
        font-size: 28px
        color: $white
  .fy-1px,.fy-1px-b
    font-family: PingFangSC, Microsoft Yahei!important
  .ng-goods-list-wrap
    .selected-item
      padding-left: 0
    .checker
      width: 99px
      margin: 0
      text-align: center
      .sold-out
        color: $white
        font-size: 24px
        line-height: 28px
        border-radius: 4px
        text-align: center
        background: $grey2
        padding: 2px 8px
        display: inline-block
</style>
