<template>
  <div :class="classes">
    <!-- 头部搜索框 -->
    <div class="search-wrap fy-1px-b">
      <div class="box-input" @click="focus">
        <div class="icon icon-search" @click.stop="search"></div>
        <input ref="searchInput" @keyup.13="search" v-model="pageConfig.keywords" type="search" class="search-input" placeholder="输入关键词">
      </div>
    </div>
    <!-- 新品预告商品列表容器 -->
    <fine-art-scroller
      ref="scroller"
      class="fore-show-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="foreGoods.data"
      :has-data="hasData"
      :last-page="foreGoods.last_page"
      :has-more="foreGoods.has_next">
      <div class="fore-show-wrap">
        <div class="fore-show">
          <div
            class="fore-show-item"
            v-for="(foreGood, index) in foreGoods.data"
            :key="index"
            @click="goToDetail(foreGood.id)">
            <div class="img-wrap"><img :src="foreGood.thumbnail" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ foreGood.name }}</p>
              <p class="tags">{{ foreGood.subtitle }}</p>
              <p class="subscribe">{{ foreGood.reservations }}<span class="const-text">人已预约</span></p>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, makeNewLink } from '@/common/js/utils'
import { FineArtScroller } from 'components'
import api from 'modules/mall/api'

export default {
  name: `${COMPONENT_PREFIX}PageForeShow`,
  data () {
    return {
      // 预告商品列表数据
      foreGoods: [],
      pageConfig: {
        page: 1,
        keywords: '',
        sort: 'id_desc'
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-fore-show`
    },
    hasData () {
      return this.foreGoods.total > 0
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '新品预告')
    let searchParams = this.$route.query
    // 当路由里带有搜索指，初始化相关页面搜索值
    if (Object.keys(searchParams).length !== 0) {
      if (searchParams.keywords) {
        this.pageConfig.keywords = searchParams.keywords
        delete searchParams['keywords']
      }
    }
    this.fetchForeShowList()
    // 初始化分享链接
    const link = makeNewLink(this.pageConfig.keywords, searchParams, this.$route.path, 2)
    this.$wx.updateShareData('mall', {
      link
    })
  },
  // 修改列表页的meta值，false时再次进入页面会重新请求数据。
  beforeRouteLeave (to, from, next) {
    from.meta.keepAlive = false
    next()
  },
  methods: {
    goToDetail (id) {
      this.$router.push({path: `/fore-show-detail/${id}`})
    },
    async fetchForeShowList () {
      this.foreGoods = await api.fetchForeShowList(this.pageConfig)
    },
    // 刷新当前资源列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.fetchForeShowList()
      cb()
    },
    // 搜索
    async search () {
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keywords, {}, this.$route.path)
      this.$wx.updateShareData('mall', {
        link
      })
      this.pageConfig.page = 1
      await this.fetchForeShowList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    // 加在更多资源列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.foreGoods.has_next) return cb()
      this.pageConfig.page = this.foreGoods.current_page + 1
      // 资源列表分页
      let dataList = await api.fetchForeShowList(this.pageConfig)
      for (let index in dataList.data) {
        this.foreGoods.data.push(dataList.data[index])
      }
      this.foreGoods.current_page = dataList.current_page
      this.foreGoods.has_next = dataList.has_next
      this.foreGoods.last_page = dataList.last_page
    },
    focus () {
      this.$refs.searchInput.focus()
    }
  },
  components: {
    FineArtScroller
  }
}
</script>
<style lang="stylus">
  .{$cls_prefix}-page-fore-show
    fixed: left top 94px
    width: 100%
    height: 100%
    color: $black1
    .search-wrap
      padding: 14px 35px 14px 35px
      background: $white
      font-size: 0
      .box-input
        position: relative
        display: inline-block
        vertical-align: top
        width: 100%
        height: 62px
        border-radius: 31px
        background-color: $grey5
        .icon.icon-search
          absolute: top 17px left 29px
          padding: 8px
          font-size: 0
          inline-icon(24px, 24px)
          bg-img('../../../assets/imgs/icon-search')
        .search-input
          width: 446px
          height: 100%
          padding: 0
          border: none
          outline: none
          margin-left: 77px
          font-size: 26px
          color: $black1
          background-color: rgba(0, 0, 0, 0)
          caret-color: $orange!important
          &::placeholder
            color: $grey2
    .fore-show-scroller
      .fore-show-wrap
        padding: 0 22px
        overflow-y: hidden
        .fore-show
          display: flex
          flex-wrap: wrap
          margin-right: -18px
          .fore-show-item
            width: 344px
            margin: 0 18px 35px 0
            .img-wrap
              width: 100%
              height: 344px
              margin-bottom: 20px
              background: $grey4
            .desc
              padding-left: 8px
              font-size: 0
              .name
                line-height: 40px
                margin-bottom: 4px
                font-size: 28px
                color: $black1
                font-weight: 300
                {ellipse}
              .tags
                padding-right: 60px
                line-height: 33px
                margin-bottom: 8px
                font-size: 24px
                color: $grey3
                font-weight: 300
                {ellipse}
              .subscribe
                line-height: 37px
                font-size: 24px
                color: $orange
                font-weight: 500
                font-family: PingFangSC-Regular
                .const-text
                  color: $black2
</style>
