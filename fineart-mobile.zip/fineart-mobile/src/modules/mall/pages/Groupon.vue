<template>
  <div :class="classes">
    <groupon-head class="page-head">
      <x-button
        class="release-btn"
        slot="right"
        type="primary"
        @click.native="goToRelease">
        <span class="fy-icon-add-grey"></span>
        发布
      </x-button>
    </groupon-head>
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal">
        <div slot="tip-text">请先登录，目前只有会员登陆后才能发布团购</div>
      </fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { GrouponHead, FineArtLoginTip } from '@/components'
export default {
  name: `${COMPONENT_PREFIX}Groupon`,
  data () {
    return {
      isOpen: false,
      loginTipModal: false
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-groupon-list`
    },
    hasProductData () {
      return this.product.data.length > 0
    },
    hasServiceData () {
      return this.service.data.length > 0
    },
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  created () {
  },
  methods: {
    goToRelease () {
      if (this.isLogin) {
        this.$router.push({path: '/groupon/release'})
      } else {
        this.loginTipModal = true
      }
    }
  },
  beforeDestroy () {
    this.$store.commit('mall/MALL_CLEAR_GROUP_ON_SEARCH_VALUE')
  },
  components: {
    GrouponHead,
    FineArtLoginTip
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-groupon-list
  fixed: top 94px left
  width: 100%
  color: $black1
  .fy-side-bar
    .side-bar
      top: 194px
    .mask
      top: 194px
  .fy-divider
    width: 100%
    height: 20px
    background-color: $grey5
  .page-head
    .release-btn
      height: 50px
      line-height: 50px
      width: 115px
      font-size: 24px
      font-weight: 500
      padding: 0
      margin-right: 6px
      display: flex
      align-items: center
      justify-content: center
      .fy-icon-add-grey
        font-size: 26px
        margin-right: 7px
        &:before
          color: $white
</style>
