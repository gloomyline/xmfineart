<template>
  <div :class="classes">
    <!-- 头部搜索栏 -->
    <fine-art-search class="store-list-search-bar" @search="search" @filter="expandSideBar" ref="refSearch"></fine-art-search>
    <!-- 线下店列表滚动容器 -->
    <fine-art-scroller
      ref="scroller"
      :has-data="hasData"
      :list="stores"
      :has-more="has_next"
      @refresh="refresh"
      @load-more="loadMore">
      <div class="store-list-wrap">
        <div class="store-list">
          <div
            :key="item.id"
            class="store-item fy-1px-b"
            v-for="item in stores"
            @click="goToDetail(item.id)">
            <div class="img-wrap"><img :src="item.thumbnail" width="100%" height="100%"></div>
            <div class="info">
              <p class="name">{{ item.name | labelFormatter(24)}}</p>
              <span class="subtitle">{{ item.subtitle }}</span>
              <p class="distance">{{ item.distance }}</p>
              <p class="tag">
                <span v-if="item.category_line">{{ item.category_line }}</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
    <!-- 右侧边栏 -->
    <fine-art-cate-side-bar
      ref="sideBar"
      :menu-data="menuData" :sidebar-values="sidebarValues"
      @on-change="filter"
      v-model="isCateSideBarExpanded"></fine-art-cate-side-bar>
    <!-- 不显示的地图容器 -->
    <div class="map" id="map"></div>
    <div class="btn-switch-stores-mode" v-if="stores && stores.length > 0">
      <router-link to="/store-map/0/0/0"><img src="../../../assets/imgs/mall/img-map-mode-bg.png" width="100%" height="100%"></router-link>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, USER_CURRENT_POSITION, POSITION_ACTIVE_TIME } from '@/assets/data/constants'
import { hyphenCase, makeNewLink, resolveUrlQuery } from '@/common/js/utils'
import { getArea, getStoreCategory } from '@/common/js/loadScript'

import {FineArtCateSideBar, FineArtSearch, FineArtScroller} from 'components'

import api from 'modules/mall/api'

export default {
  name: `${COMPONENT_PREFIX}PageStoreList`,
  data () {
    return {
      // 线下店列表
      stores: [],
      // 线下店列表数据是否还有下一页
      has_next: false,
      // 右侧边菜单栏闭合、展开状态，默认闭合
      isCateSideBarExpanded: false,
      // 构造的右边栏列表数据
      menuData: [],
      // 请求线下店列表表单数据
      pageConfig: {
        // 当前分页
        page: 1,
        // 用户所在经度
        lng: null,
        // 用户所在纬度
        lat: null,
        // 搜索关键词
        keywords: '',
        // 分类 id
        category_id: '',
        // 地区 id
        area_id: 1,
        // 排序方式： 距离升序
        sort: 'distance_asc',
        is_representative: ''
      },
      // 路由中带有的侧边栏搜索值
      sidebarValues: {},
      // 侧边栏返回的values值
      values: {}
    }
  },
  created () {
    let searchParams = this.$route.query
    // 当路由里带有搜索指，初始化相关页面搜索值
    if (Object.keys(searchParams).length !== 0) {
      if (searchParams.keywords) {
        this.pageConfig.keywords = searchParams.keywords
        delete searchParams['keywords']
      }
      this.pageConfig = {...this.pageConfig, ...resolveUrlQuery(searchParams)}
      this.sidebarValues = searchParams
    }
    this._initStores()
    this._initSideBar()
    // 初始化分享链接
    const link = makeNewLink(this.pageConfig.keywords, searchParams, this.$route.path, 2)
    this.$wx.updateShareData('mall', {
      link
    })
    this.$nextTick(() => {
      this.$refs.refSearch.setSearchValue(this.pageConfig.keywords)
    })
  },
  activated () {
    this.$store.commit('MODIFY_PAGE_NAME', '同城建材')
  },
  beforeDestroy () {
    this.$fMap.destory()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-store-list`
    },
    hasData () {
      return this.stores.length > 0
    }
  },
  methods: {
    goToDetail (id) {
      this.$router.push({path: `/store-detail/${id}`})
    },
    // 处理搜索线下店接口的返回数据
    _handleResponse (res, isConcat = false) {
      this.stores = isConcat ? [...this.stores, ...res.data] : res.data
      this.has_next = res.has_next
      this.page = res.current_page
    },
    // 获取用户当前地理位置
    async _getCurrentPosition () {
      let position = this.$localStorage.get(USER_CURRENT_POSITION)
      if (!position) {
        try {
          await this.$fMap.createMap('map')
          // 用户当前地理位置
          position = await this.$fMap.geoLocation()
          // 存储获取到的用户的地理位置
          this.$localStorage.set(USER_CURRENT_POSITION, position, POSITION_ACTIVE_TIME + Date.now())
          this.pageConfig.lng = position.lng
          this.pageConfig.lat = position.lat
        } catch (e) {
          // console.log(e)
          window.location.reload()
        }
      } else {
        this.pageConfig.lng = position.lng
        this.pageConfig.lat = position.lat
      }
    },
    // 初始化线下店列表
    async _initStores () {
      await this._getCurrentPosition()
      const response = await api.fetchStoreList({...this.pageConfig, page: 1})
      this._handleResponse(response)
    },
    // 初始化右边栏菜单
    _initSideBar () {
      // TODO: 这里使用 Promise.all method 同时加载分类和区域数据，避免数据阻塞
      Promise.all([getStoreCategory(), getArea()]).then(values => {
        // 店铺类型
        const cates = {id: 'category_id', title: '店铺类型', type: 0, content: values[0]}
        // 店铺所在区域
        const areas = {id: 'area_id', title: '店铺位置', type: 1, content: values[1]}
        this.menuData = [cates, areas]
      })
    },
    // 展开右边菜单栏
    expandSideBar () {
      if (this.isCateSideBarExpanded) return
      this.isCateSideBarExpanded = true
      this.$nextTick(() => {
        this.$refs.sideBar.expand()
      })
    },
    // 下拉刷新线下店列表
    async refresh (cb) {
      const response = await api.fetchStoreList({...this.pageConfig, page: 1})
      this._handleResponse(response)
      cb()
    },
    // 上拉加载更多线下店列表
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.has_next) return cb()
      const response = await api.fetchStoreList({...this.pageConfig, page: ++this.pageConfig.page})
      this._handleResponse(response, true)
    },
    // 搜过关键词
    async search (keywords) {
      // update pageConfig keywords filed
      this.pageConfig.keywords = keywords
      this.sidebarValues = {}
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keywords, this.values, this.$route.path)
      this.$wx.updateShareData('mall', {
        link
      })
      const response = await api.fetchStoreList({...this.pageConfig, page: 1})
      this._handleResponse(response)
      this.$nextTick(() => { this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce') })
    },
    // 筛选完成之后请求所选条件线下店列表
    async filter (values) {
      // update pageConfig category_id && area_id
      // 重置传回至侧边栏的值为空，表示不用初始化
      this.sidebarValues = {}
      // 将values赋值给data里的values，用于用户点击查询时重新拼接url
      this.values = values
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keywords, this.values, this.$route.path)
      this.$wx.updateShareData('mall', {
        link
      })
      this.pageConfig.category_id = values.category_id[0] || ''
      this.pageConfig.area_id = values.area_id.length > 0 ? (values.area_id.length > 2 ? values.area_id[2] : values.area_id[0]) : ''
      const response = await api.fetchStoreList({...this.pageConfig, page: 1})
      this._handleResponse(response)
      this.$nextTick(() => { this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce') })
    }
  },
  // 修改列表页的meta值，false时再次进入页面会重新请求数据。
  beforeRouteLeave (to, from, next) {
    from.meta.keepAlive = false
    next()
  },
  filters: {
    labelFormatter (str = '', length = 24) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-store-list
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  font-family: PingFangSC-Regular
  .store-list-wrap
    font-size: 24px
    .store-list
      .store-item
        position: relative
        display: block
        padding: 30px
        font-size: 0
        .img-wrap
          display: inline-block
          vertical-align: top
          width: 256px
          height: 256px
          margin-right: 30px
          background: $grey4
        .info
          position: relative
          display: inline-block
          vertical-align: top
          width: 404px
          height: 256px
          padding-top: 18px
          .name
            line-height: 42px
            margin-bottom: 10px
            font-size: 30px
            color: $black1
          .subtitle
            display: block
            line-height: 37px
            margin-bottom: 46px
            font-size: 26px
            color: $black2
            font-weight: 300
            {ellipse}
          .distance
            absolute: right 0 bottom 30px
            text-align: right
            height: 33px
            line-height: 33px
            font-size: 24px
            color: $grey2
            font-weight: 300
          .tag
            absolute: left 0 bottom 30px
            &>span
              padding: 4px 8px
              font-size: 22px
              color: $grey3
              border: 1.4px solid $grey2
              display: inline-block
  .btn-switch-stores-mode
    width: 130px
    height: 130px
    fixed: right 22px bottom 22px
    &>a
      display: block
</style>
