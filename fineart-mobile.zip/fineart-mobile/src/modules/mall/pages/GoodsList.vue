<template>
  <div :class="classes">
    <!-- 头部搜索框 -->
    <fine-art-search class="goods-list-search-bar"
                     @search="search"
                     @filter="expandCateSideBar" ref="refSearch"></fine-art-search>
    <!-- 商品列表容器 -->
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="goods"
      :has-data="hasData"
      :has-more="has_next">
      <div class="goods-list-wrap">
        <div class="goods-list">
          <div
            class="goods-item"
            v-for="(good, index) in goods"
            :key="index"
            @click="goToDetail(good.id, good.store_id)">
            <div class="img-wrap"><img :src="good.thumbnail" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ good.name }}</p>
              <p class="tags">{{ good.subtitle }}</p>
              <p class="price">&yen;{{ good.price_norm }}</p>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
    <!-- 右侧边栏 -->
    <fine-art-cate-side-bar ref="sidebar" @on-change="filter"
                            :menu-data="menuData" :sidebar-values = "sidebarValues"
                            v-model="isCateSideBarExpanded"></fine-art-cate-side-bar>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, makeNewLink, resolveUrlQuery } from '@/common/js/utils'
import { getGoodsCategory } from '@/common/js/loadScript'

import api from 'modules/mall/api'

import { FineArtCateSideBar, FineArtSearch, FineArtScroller } from 'components'

export default {
  name: `${COMPONENT_PREFIX}PageGoodsList`,
  data () {
    return {
      // 右边分类菜单栏展开与否，默认不展开
      isCateSideBarExpanded: false,
      // 商品列表数据
      goods: [],
      pageConfig: {
        // 商品列表当前所加载分页
        page: 1,
        // 关键词
        keywords: '',
        category_id: '',
        attribute: 1,
        sort: 'default'
      },
      // 当前配置条件下是否还有下一页数据
      has_next: true,
      // 右边分类栏菜单栏列表数据
      menuData: [],
      // 路由中带有的侧边栏搜索值
      sidebarValues: {},
      // 侧边栏返回的values值
      values: {}
    }
  },
  created () {
    let searchParams = this.$route.query
    // 当路由里带有搜索指，初始化相关页面搜索值
    if (Object.keys(searchParams).length !== 0) {
      if (searchParams.keywords) {
        this.pageConfig.keywords = searchParams.keywords
        delete searchParams['keywords']
      }
      this.pageConfig = {...this.pageConfig, ...resolveUrlQuery(searchParams)}
      this.sidebarValues = searchParams
    }
    this._initGoods()
    this._initCateSideMenus()
    // 初始化分享链接
    const link = makeNewLink(this.pageConfig.keywords, searchParams, this.$route.path, 2)
    this.$wx.updateShareData('mall', {
      link
    })
    this.$nextTick(() => {
      this.$refs.refSearch.setSearchValue(this.pageConfig.keywords)
    })
  },
  activated () {
    this.$store.commit('MODIFY_PAGE_NAME', '商品')
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-goods-list`
    },
    hasData () {
      return this.goods.length > 0
    }
  },
  methods: {
    goToDetail (id, store) {
      this.$router.push({path: `/goods-detail/${id}/${store}`})
    },
    focus () {
      this.$refs.searchInput.focus()
    },
    // 展开右边菜单栏
    expandCateSideBar () {
      if (this.isCateSideBarExpanded) return
      this.isCateSideBarExpanded = true
      this.$nextTick(() => {
        this.$refs.sidebar.expand()
      })
    },
    // 处理 goods 接口返回的数据
    _handleResponse (response, isConcat = false) {
      if (isConcat) {
        this.goods = [...this.goods, ...response.data]
      } else {
        this.goods = response.data
      }
      this.pageConfig.page = response.current_page
      this.has_next = response.has_next
    },
    // 请求初始化 goods 数据
    async _initGoods () {
      const response = await api.fetchGoodsList(this.pageConfig)
      this._handleResponse(response)
    },
    // 请求初始化右边栏分类菜单
    async _initCateSideMenus () {
      // 获取到的原始分类列表
      const _cates = await getGoodsCategory()
      // 分类列表
      const cates = {id: 'category_id', title: '商品分类', type: 1, content: _cates}
      // 商品属性
      const attr = [{
        label: '产品型',
        value: '100'
      }, {
        label: '服务型',
        value: '200'
      }]
      const attrs = {id: 'attribute', title: '商品属性', type: 0, content: attr}
      // 排序方式
      const sortWays = [{
        label: '综合排序',
        value: 'default'
      }, {
        label: '价格降序',
        value: 'price_desc'
      }, {
        label: '价格升序',
        value: 'price_asc'
      }]
      const sort = {id: 'sort', title: '排序方式', type: 0, content: sortWays}
      this.menuData = [cates, attrs, sort]
    },
    // 搜索
    async search (keywords) {
      this.sidebarValues = {}
      // 拼接新的url，用于微信分享
      const link = makeNewLink(keywords, this.values, this.$route.path)
      this.$wx.updateShareData('mall', {
        link
      })
      this.pageConfig = {...this.pageConfig, keywords, page: 1}
      const response = await api.fetchGoodsList(this.pageConfig)
      this._handleResponse(response)
      this.$nextTick(() => { this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce') })
    },
    // 加在更多商品列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.has_next) return cb()
      // 请求加载更多商品数据
      const response = await api.fetchGoodsList({...this.pageConfig, page: this.pageConfig.page + 1})
      this._handleResponse(response, true)
    },
    // 刷新当前商品列表数据
    async refresh (cb) {
      const response = await api.fetchGoodsList({...this.pageConfig, page: 1})
      this._handleResponse(response)
      cb()
    },
    // 选择完成分类菜单
    async filter (values) {
      // 重置传回至侧边栏的值为空，表示不用初始化
      this.sidebarValues = {}
      // 将values赋值给data里的values，用于用户点击查询时重新拼接url
      this.values = values
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keywords, this.values, this.$route.path)
      this.$wx.updateShareData('mall', {
        link
      })
      // 更新当前商品搜索请求提交参数
      this.pageConfig.attribute = values.attribute[0] || ''
      this.pageConfig.category_id = values.category_id.length > 0 ? (values.category_id.length > 2 ? values.category_id[2] : values.category_id[0]) : ''
      this.pageConfig.sort = values.sort[0] || 'default'
      const response = await api.fetchGoodsList({...this.pageConfig, page: 1})
      this._handleResponse(response)
      this.$nextTick(() => { this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce') })
    }
  },
  // 修改列表页的meta值，false时再次进入页面会重新请求数据。
  beforeRouteLeave (to, from, next) {
    from.meta.keepAlive = false
    next()
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-goods-list
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  font-family: PingFangSC-Regular
  .goods-list-scroller
    .goods-list-wrap
      padding: 0 22px
      overflow-y: hidden
      .goods-list
        display: flex
        flex-wrap: wrap
        margin-right: -18px
        .goods-item
          width: 344px
          margin: 0 18px 28px 0
          .img-wrap
            width: 100%
            height: 344px
            margin-bottom: 20px
            background: $grey4
          .desc
            padding-left: 8px
            font-size: 0
            .name
              line-height: 40px
              margin-bottom: 4px
              font-size: 28px
              color: $black1
              font-weight: 300
              {ellipse}
            .tags
              padding-right: 60px
              line-height: 33px
              margin-bottom: 8px
              font-size: 24px
              color: $grey3
              font-weight: 300
              {ellipse}
            .price
              line-height: 37px
              font-size: 26px
              color: $orange
</style>
