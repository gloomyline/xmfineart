<template>
  <div :class="classes">
    <!-- tab 与 搜索 -->
    <div class="sub-nav">
      <!--tab bar -->
      <div class="tab-bar">
        <h3 class="name is-active" >产品</h3>
        <h3 class="name" @click="handlerTab()">服务</h3>
      </div>
      <!-- search-box -->
      <div class="search-box">
        <div class="search-btn icon-search" @click="openSearch"></div>
        <div class="divider"></div>
        <div class="btn-filter" @click="expandCateSideBar">
          <span class="label">筛选</span>
          <span class="icon icon-screen"></span>
        </div>
      </div>
    </div>
    <!-- 分割线 -->
    <div class="fy-divider"></div>
    <!-- 产品列表 -->
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      @refresh="refreshProduct"
      @load-more="loadMoreProduct"
      :list="product.data"
      :has-data="hasProductData"
      :has-more="product.has_next">
      <div class="goods-list-wrap">
        <ul class="goods-list">
          <router-link tag="li" :to="`/groupon/detail/${item.id}`" class="goods-item" v-for="(item ,index) in product.data" :key="index">
            <div class="img-wrap"><img :src="item.thumbnail" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ item.name }}</p>
              <div class="info">
                <span class="price">{{ item.price }}</span>
                <!-- 按需求隐藏 -->
                <!--<span class="number">已团<em>{{ item.total }}</em>{{ item.unit }}</span>-->
              </div>
            </div>
          </router-link>
        </ul>
      </div>
    </fine-art-scroller>
    <div v-transfer-dom>
      <groupon-search v-model="isShowed" @search-key="searchKey" ref="groupSearch"></groupon-search>
    </div>
    <!-- 右侧边栏 -->
    <fine-art-cate-side-bar class="fy-side-bar" ref="sidebar" @on-change="filter"
                            :menu-data="menuData" :sidebar-values = "sidebarValues"
                            v-model="isCateSideBarExpanded"></fine-art-cate-side-bar>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, makeNewLink, isObjectValueEqual, formatSidebarValue } from '@/common/js/utils'
import api from 'modules/mall/api'
import { FineArtScroller, FineArtCateSideBar, GrouponSearch } from '@/components'
import { getGrouponCategory } from '@/common/js/loadScript'
import {mapMutations} from 'vuex'

export default {
  name: 'grouponProduct',
  data () {
    return {
      isCateSideBarExpanded: false,
      isShowed: false,
      product: {
        data: [],
        has_next: false
      },
      productConfig: {
        page: 1,
        attribute: 100,
        category_id: '',
        keyword: ''
      },
      menuData: [],
      whichType: 'product',
      // 路由中带有的侧边栏搜索值
      sidebarValues: {},
      // 侧边栏返回的values值
      values: {},
      searchValue: {
        keywords: '',
        sidebarValue: {
        },
        pageName: 'group/100'
      }
    }
  },
  components: {
    FineArtScroller,
    FineArtCateSideBar,
    GrouponSearch
  },
  computed: {
    hasProductData () {
      return this.product.data.length > 0
    },
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-groupon-product`
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(async (vm) => {
      const searchValue = vm.$store.state.mall.searchValue
      const values = searchValue.sidebarValues
      if (!isObjectValueEqual(vm.searchValue, searchValue)) {
        // 重置查询值
        vm.searchValue = searchValue
        vm.productConfig.keyword = searchValue.keywords
        vm.values = values
        vm.$refs.groupSearch.setKeywords(vm.productConfig.keyword)
        // 初始化侧边栏
        vm.sidebarValues = formatSidebarValue(values)
        if (values && values.category_id) {
          vm.productConfig.category_id = values.category_id.length > 0 ? (values.category_id.length > 2 ? values.category_id[2] : values.category_id[0]) : ''
        }
        const response = await vm.fetchListData({...vm.productConfig, page: 1})
        vm.product = response
        vm.productConfig.page = response.current_page
      }
    })
  },
  activated () {
    this.$nextTick(() => {
      this.whichType = 'product'
      this.$forceUpdate()
    })
  },
  async created () {
    this._initCateSideMenus()
  },
  methods: {
    ...mapMutations({
      setSearchValue: 'mall/MALL_SET_GROUP_ON_SEARCH_VALUE'
    }),
    handlerTab () {
      this.$router.push({path: '/groupon/200'})
    },
    // 展开右边菜单栏
    expandCateSideBar () {
      if (this.isCateSideBarExpanded) return
      this.isCateSideBarExpanded = true
      this.$nextTick(() => {
        this.$refs.sidebar.expand()
      })
    },
    // 打开搜索框
    openSearch () {
      if (this.isCateSideBarExpanded) return
      this.isShowed = true
    },
    // 获取列表数据
    async fetchListData ({ page, keyword, attribute, category_id }) {
      const response = await api.fetchGrouponList({ page, keyword, attribute, category_id })
      return response
    },
    // 产品 刷新
    async refreshProduct (cb) {
      const response = await this.fetchListData({...this.productConfig, page: 1})
      this.product = response
      this.productConfig.page = response.current_page
      cb()
    },
    // 产品 加载更多
    async loadMoreProduct (cb) {
      if (!this.product.has_next) return cb()
      const response = await this.fetchListData({...this.productConfig, page: this.productConfig.page + 1})
      this.product.data = [...this.product.data, ...response.data]
      this.productConfig.page = response.current_page
      this.product.has_next = response.has_next
    },
    // 请求初始化右边栏分类菜单
    async _initCateSideMenus () {
      const _cates = await getGrouponCategory()
      const cates = {id: 'category_id', title: '商品分类', type: 1, content: _cates}
      this.menuData = [cates]
    },
    // 选择完成分类菜单
    async filter (values) {
      // 重置传回至侧边栏的值为空，表示不用初始化
      this.sidebarValues = {}
      // 将values赋值给data里的values，用于用户点击查询时重新拼接url
      this.values = values
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.productConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('mall', {
        link
      })
      this.productConfig.category_id = values.category_id.length > 0 ? (values.category_id.length > 2 ? values.category_id[2] : values.category_id[0]) : ''
      const response = await this.fetchListData({...this.productConfig, page: 1})
      this.product = response
      this.productConfig.page = response.current_page
      // 设置查询值至状态管理器，以供同级路由使用
      this.searchValue = {keywords: this.productConfig.keyword, sidebarValues: values}
      this.setSearchValue({keywords: this.productConfig.keyword, sidebarValues: values})
    },
    async searchKey (values) {
      this.productConfig.keyword = values
      this.sidebarValues = {}
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.productConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('mall', {
        link
      })
      const response = await this.fetchListData({...this.productConfig, page: 1})
      this.product = response
      this.productConfig.page = response.current_page
      // 设置查询值至状态管理器，以供同级路由使用
      this.searchValue = {keywords: this.productConfig.keyword, sidebarValues: this.values}
      this.setSearchValue({keywords: this.productConfig.keyword, sidebarValues: this.values})
    }
  }
}
</script>

<style lang="stylus" scoped>
.{$cls_prefix}-page-groupon-product
  position: relative
  font-family: PingFangSC-Regular
  .sub-nav
    display: flex
    width: 100%
    height: 80px
    .tab-bar
      display: flex
      justify-content: space-between
      width: 50%
      height: 80px
      padding: 0 75px 0 60px
    .name
       position: relative
       height: 80px
       color: $black2
       font-size: 30px
       line-height: 80px
       &.is-active
         color: $orange
         &:after
           content: ''
           absolute: left bottom
           width: 100%
           height: 6px
           background-color: $orange
    .search-box
      display: flex
      justify-content: flex-end
      align-items: center
      width: 50%
      height: 80px
      padding: 20px 30px 20px 0
      background-color: $white
      .divider
        width: 2px
        height: 25px
        border-left: 2px solid $grey
      .search-btn
        width: 30px
        height: 80px
        margin: 0 45px
        &.icon-search
          background: url('../../../assets/imgs/mall/icon-tgsearch.png') center center no-repeat
          background-size: 28px auto
      .btn-filter
        display: flex
        align-items: center
        height: 40px
        margin: 0 15px 0 45px
        .label
          font-size: 26px
          color: $black2
          margin-right: 10px
        .icon-screen
          display: inline-block
          width: 34px
          height: 40px
          background: url('../../../assets/imgs/mall/icon-tgscreen.png') center center no-repeat
          background-size: 34px auto
  .goods-list-scroller
    top: 194px
    .goods-list-wrap
      overflow: hidden
      padding: 30px 22px
      .goods-list
        display: flex
        flex-wrap: wrap
        margin-right: -20px
        .goods-item
          width: 344px
          margin: 0 18px 40px 0
          .img-wrap
            width: 100%
            height: 344px
            margin-bottom: 20px
            background: $grey4
          .desc
            font-size: 0
            padding: 0 10px
            .name
              line-height: 40px
              margin-bottom: 12px
              font-size: 28px
              color: $black1
              {ellipse}
            .info
              display: flex
              justify-content: space-between
              align-items: center
              .price
                line-height: 37px
                font-size: 26px
                color: $orange
              .number
                line-height: 37px
                font-size: 24px
                color: $grey3
                &>em
                  color: $orange
</style>
