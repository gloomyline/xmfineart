<template>
  <div :class="classes">
    <!-- 商品轮播图 -->
    <swiper
      :auto="true"
      :loop="true"
      :interval="5000"
      :duration="500"
      dots-position="center"
      :aspect-ratio="420/750">
      <swiper-item
        v-for="(item, index) in goodDetail.goods_medias" :key="index">
        <img :src="item" width="100%">
      </swiper-item>
    </swiper>
    <!-- 返回商品列表 -->
    <div class="btn-back-to-goods" @click="goBack"></div>
    <!-- 商品基本信息 -->
    <div class="good-basic-info">
      <h3 class="name">{{ goodDetail.name }}</h3>
      <p class="sub-title">{{ goodDetail.subtitle }}</p>
      <div class="price">
        <p class="discount" v-if="goodDetail.price_discount"><em>&yen;</em><span class="price-count">{{ goodDetail.price_discount }}</span></p>
        <p class="normal" :class="{'is-discounted': !!goodDetail.price_discount}"><em>&yen;</em><span class="price-count">{{ goodDetail.price_norm }}</span></p>
      </div>
      <group class="good-count">
        <x-number title="数量" width="31px" :min="1" :max="goodStock" v-model="count" :fillable="isFillable"></x-number>
      </group>
    </div>
    <div class="divider"></div>
    <!-- 前往商家 -->
    <group class="store-link-wrap">
      <!-- 推广店只显示店名，不点击跳转 -->
      <cell
        v-if="goodDetail.goods_type === '300'"
        class="store-link"
        :title="goodDetail.store_name"></cell>
      <!-- 其余点击跳转到店铺页面 -->
      <cell
        v-else
        class="store-link"
        :title="goodDetail.store_name"
        :link="`/store-detail/${goodDetail.store_id}`"
        is-link></cell>
    </group>
    <!-- 商品更多信息，详情、评论入口 -->
    <div class="more-info">
      <tab :line-width="2" :value="0" custom-bar-width="80px">
        <tab-item class="introduction">详情</tab-item>
        <tab-item class="evaluation" disabled @click.native="showEvaluationList">评价</tab-item>
      </tab>
      <div class="introduction-content" v-html="goodDetail.introduction"></div>
    </div>
    <!-- 底部菜单栏，收藏、购物车入口、加入购物车 -->
    <div class="bottom-bar fy-1px-t">
      <div class="favorite fy-1px-r" @click="toggleFavorite">
        <div class="icon-wrap">
          <span class="icon fy-icon-sel-collection" v-if="goodDetail.has_collected"></span>
          <span class="icon fy-icon-star-rough" v-else></span>
        </div>
        <p class="label" :class="{'origin': goodDetail.has_collected}">{{ collectText }}</p>
      </div>
      <div class="cart" @click="goCart">
        <span class="icon fy-icon-cart"></span>
        <p class="label">购物车</p>
        <badge :text="goodsCountInCart" v-if="goodsCountInCart > 0"></badge>
      </div>
      <div class="btn-add-to-cart" @click="addToCart">加入购物车</div>
    </div>
    <!-- 商品评价列表面板 -->
    <transition name="slide-left">
      <div class="evaluation-list-panel" v-show="isEvaluationShow">
        <scroller
          v-if="evaluations.length > 0"
          ref="scroller"
          height="-48"
          v-model="status"
          lock-x scrollbar-y
          use-pulldown use-pullup
          :pulldown-config="pulldownCfg"
          @on-pulldown-loading="refresh"
          @on-pullup-loading="loadMore"
          class="evaluation-list-scroller">
          <!-- 商品评价卡片列表 -->
          <ul class="evaluation-list">
            <!-- 用户评价卡片 -->
            <li class="evaluation-item fy-1px-b" v-for="(item) in evaluations" :key="item.id">
              <!-- 评价用户的信息，头像、昵称 -->
              <div class="user-info">
                <div class="user-avatar">
                  <img v-if="!!item.avatar" :src="item.avatar" width="100%" height="100%">
                  <span v-else class="fy-icon-default-avatar"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span></span>
                </div>
                <p class="user-name">{{ item.nickname }}</p>
              </div>
              <!-- 产品星级 -->
              <div class="evaluation-level" :class="{'not-full': item.score < 90}">
                <rater :value="item.score | starFormatter" disabled star="<span class='fy-icon-sel-collection'></span>" :margin="9" :font-size="14"></rater>
              </div>
              <!-- 评价内容 -->
              <div class="evaluation-content">
                <!-- 评价文字内容 -->
                <p class="user-evaluation">{{ item.content }}</p>
                <!-- 评价图片列表 -->
                <div class="evaluation-img" v-if="item.images && item.images.length > 0">
                  <ul class="evaluation-img-list">
                    <li class="evaluation-img-item" v-for="(imgUrl, index) in item.images" :key="index"><img :src="imgUrl" width="100%" height="100%" @click="previewImage(item.images_big,index)"></li>
                  </ul>
                </div>
              </div>
              <!-- 商家回复 -->
              <p class="store-reply" v-if="item.reply">
                商家回复：
                <span v-html="item.reply"></span>
              </p>
              <!-- 评价时间 -->
              <p class="evaluation-time">{{ item.created_at }}</p>
            </li>
          </ul>
          <div slot="pullup" class="xs-plugin-pullup-container xs-plugin-pullup-up text-center">
            <span class="nothing-text"  v-show="status.pullupStatus === 'default' && !has_next">—— END ——</span>
            <span
              class="pullup-arrow"
              v-show="status.pullupStatus === 'down' || status.pullupStatus === 'up'"
              :class="{'rotate': status.pullupStatus === 'up'}">↑</span>
            <span v-show="status.pullupStatus === 'loading'"><spinner type="ios-small"></spinner></span>
          </div>
        </scroller>
        <fine-art-empty v-else></fine-art-empty>
        <div class="btn-close" @click="isEvaluationShow = false"><span class="fy-icon-off"></span></div>
      </div>
    </transition>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtEmpty, FineArtLoginTip } from 'components'
import api from 'modules/mall/api'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}PageGoodsDetail`,
  data () {
    return {
      // 商品详情信息
      goodDetail: {},
      // 选购的商品数量
      count: 1,
      // 当前评价面板的显示状态
      isEvaluationShow: false,
      // 评价列表数据
      evaluations: [],
      // 评价列表数据当前分页配置
      pageCfg: {
        // 评价当前分页
        page: 1,
        // 商品 id
        goods_id: null,
        // 提供商品的 store id
        store_id: null
      },
      // 评价是否还有下一页啊
      has_next: true,
      // 评价 scroller 上拉下拉状态
      status: {
        pullupStatus: 'default',
        pulldownStatus: 'default'
      },
      // scroller 的下拉配置
      pulldownCfg: {
        content: '下拉刷新',
        upContent: '松开进行加载',
        downContent: '下拉刷新',
        loadingContent: '加载中...'
      },
      isFillable: true,
      loginTipModal: false
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '商品详情')
    this._initGoodDetail()
  },
  props: ['id', 'store_id'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-goods-detail`
    },
    collectText () {
      return this.goodDetail.has_collected ? '已关注' : '关注商品'
    },
    goodStock () {
      return Number.parseInt(this.goodDetail.stock)
    },
    goodsCountInCart () {
      return this.$store.state.mall.cartGoodsCount
    },
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  // 从详情页返回列表页时把列表页的keepAlive值设置为true
  beforeRouteLeave (to, from, next) {
    if (to.path === '/goods-list') {
      to.meta.keepAlive = true
    } else {
      to.meta.keepAlive = false
    }
    next()
  },
  methods: {
    goBack () {
      document.referrer === '' ? this.$router.push({ path: '/goods-list' }) : this.$router.go(-1)
    },
    _updateShare () {
      const vm = this
      this.$wx.updateShareData('mall', {
        title: vm.goodDetail.name,
        desc: vm.goodDetail.subtitle
      })
    },
    _updatePageCfg () {
      this.pageCfg.goods_id = this.goodDetail.id
      this.pageCfg.store_id = this.store_id
    },
    async _initGoodDetail () {
      this.goodDetail = await api.fetchGoodsDetail({ goods_id: this.id, store_id: this.store_id })
      this._updatePageCfg()
      if (this.isLogin) {
        // 更新 store mall 模块中购物车商品种类数量
        this.$store.dispatch('mall/fetchCartGoodsCount')
      }
      this._updateShare()
    },
    async _initEvaluations () {
      const response = await api.fetchGoodsComments({...this.pageCfg, page: 1})
      this.has_next = response.has_next
      this.evaluations = response.data
      this.pageCfg.page = response.current_page
    },
    async showEvaluationList () {
      // 等待评价列表数据初始完成，才显示评价列表面板
      await this._initEvaluations()
      this.isEvaluationShow = true
    },
    async toggleFavorite () {
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      const response = await api.collectGoods({
        goods_id: this.goodDetail.id,
        store_id: this.goodDetail.store_id
      })
      if (response === 200) {
        this.goodDetail.has_collected = !this.goodDetail.has_collected
        if (this.goodDetail.has_collected) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
      }
    },
    async addToCart () {
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      if (this.count === 0) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_CART_ADD_ZERO'], type: 'text' })
      } else {
        // 添加入购物车
        const responseResult = await api.addToCart({
          goodsId: this.goodDetail.id,
          storeId: this.goodDetail.store_id,
          num: this.count
        })
        if (responseResult.code === 200) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_CART_ADD_OK'], type: 'success' })
          // 更新 store mall 模块中购物车商品种类数量
          this.$store.dispatch('mall/fetchCartGoodsCount')
        }
      }
    },
    // 去购物车
    goCart () {
      if (!this.isLogin) {
        this.loginTipModal = true
      } else {
        this.$router.push({ path: '/mall-cart' })
      }
    },
    // 评价 scroller 下拉刷新回调
    async refresh () {
      await this._initEvaluations()
      this.$nextTick(() => {
        const timer = setTimeout(() => {
          this.$refs.scroller.donePulldown()
          this.$refs.scroller.enablePullup()
          clearTimeout(timer)
        }, 10)
      })
    },
    // 评价 scroller 上拉加载更多回调
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.has_next) {
        this.$refs.scroller.donePullup()
        return
      }
      const response = api.fetchGoodsComments({...this.pageCfg, page: this.pageCfg.page + 1})
      this.has_next = response.next
      this.evaluations = [...this.evaluations, response.data]
      this.pageCfg.page = response.current_page
      this.$nextTick(() => {
        this.$refs.scroller.donePullup()
      })
    },
    previewImage (images, index) {
      this.$wx.previewImage(
        {
          current: images[index], // 当前显示图片的http链接
          urls: images // 需要预览的图片http链接列表
        }
      )
    }
  },
  filters: {
    starFormatter (score) {
      return Math.round(score / 20)
    }
  },
  components: {
    FineArtEmpty,
    FineArtLoginTip
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-goods-detail
  position: relative
  color: $black1
  .vux-swiper
    background: $grey4
  .btn-back-to-goods
    absolute: left 30px top 30px
    width: 56px
    height: 56px
    border-radius: 50%
    bg-img('../../../assets/imgs/mall/icon-go-back')
    background-size: cover
  .good-basic-info
    padding: 0 30px
    .name
      padding-top: 30px
      margin-bottom: 10px
      line-height: 48px
      font-size: 34px
    .sub-title
      line-height: 37px
      margin-bottom: 2px
      font-size: 26px
      color: $grey3
      font-weight: 300
    .price
      font-size: 0
      .normal, .discount
        display: inline-block
        vertical-align: top
        height: 64px
        line-height: 64px
        font-size: 36px
        color: $orange
        font-family: PingFangSC-Regular
      .normal.is-discounted
        margin-left: 20px
        font-size: 24px
        color: $grey3
        text-decoration: line-through
    .good-count
      .weui-cells
        margin-top: 20px
        &:after
          border: none
        &:before
          border-top: 2px solid $grey
        p
          color: $black2
          font-size: 26px
          line-height: 37px
        .weui-cell
          padding: 30px 0
          &:before
            border: none
        [class^="vux-number"]
          text-align: center
          box-sizing: border-box
          padding: 0 5px!important
          height: 52px!important
          line-height: 52px!important
        .vux-number-selector svg
          fill: $grey2
        .vux-number-input
          font-size: 30px
          font-weight: 500
          width: 80px!important
  .divider
    width: 100%
    height: 20px
    background-color: $grey5
  .store-link-wrap
    .weui-cells
      margin-top: 0
      &:before
        display: none
      .weui-cell
        height: 88px
        line-height: 88px
        font-size: 28px
        &:before
          border-top: 2px solid $grey
        .vux-label
          font-size: 28px
  .more-info
    .introduction, .evaluation, .vux-tab
      height: 80px
      line-height: 80px
    .introduction
      position: relative
      &:after
        content: ' '
        absolute: right top 22px
        width: 1px
        height: 40px
        border-right: 1px solid $grey
        background-color: $grey
    .evaluation
      &.vux-tab-item.vux-tab-disabled
        color: $black1
    .introduction-content
      line-height: 48px
      font-size: 26px
      color: $black2
      padding: 30px 0 120px 0
      img
        display: block
        max-width: 100%
        margin: 0 auto
        & + br
          display: none
      p
        padding: 0 30px
  .bottom-bar
    fixed: left bottom
    width: 100%
    height: 88px
    font-size: 0
    background-color: $white
    .favorite, .cart, .btn-add-to-cart
      display: inline-block
      vertical-align: top
      height: 100%
      text-align: center
    .favorite
      width: 192px
      .icon-wrap
        padding-top: 14px
        margin-bottom: 6px
        font-size: 32px
        .fy-icon-sel-collection
          color: $orange
      .label
        font-size: 20px
        color: $black2
        &.origin
          color: $orange
      .fy-icon-sel-collection
        color: $yellow
    .cart
      position: relative
      width: 192px
      padding-top: 12px
      .icon
        font-size: 36px
        color: $grey3
      .label
        margin-top: 6px
        font-size: 20px
        color: $black2
      .vux-badge
        absolute: top 8px right 50%
        margin-right: -36px
    .btn-add-to-cart
      width: (750 - 192 * 2)px
      height: 100%
      line-height: 88px
      font-size: 28px
      color: $white
      background-color: $orange
  .evaluation-list-panel
    fixed: left top 94px
    bottom: 0
    width: 100%
    background-color: $white
    &.slide-left-enter-active
      transition: all 0.8s ease-out
    &.slide-left-leave-active
      transition: all .5s ease-in
    &.slide-left-enter, &.slide-left-leave-to
      transform: translate3d(100%, 0, 0)
      opacity: 0.6
    .btn-close
      absolute: right top
      padding: 30px
      font-size: 0
      .fy-icon-off
        font-size: 32px
        color: $grey3
    .evaluation-list-scroller
      .evaluation-list
        padding-top: 20px
        .evaluation-item
          position: relative
          padding: 0 30px 21px 30px
          .user-info
            padding-top: 20px
            margin-bottom: 20px
            font-size: 0
            .user-avatar, .user-name
              display: inline-block
              vertical-align: top
            .user-avatar
              width: 70px
              height: 70px
              margin-right: 22px
              font-size: 70px
              background: $grey4
              border-radius: 50%
              &>img
                border-radius: 50%
            .user-name
              height: 70px
              line-height: 70px
              font-size: 26px
              color: $black2
          .evaluation-level
            absolute: right 30px top 20px
            .fy-icon-sel-collection
              color: $yellow
            &.not-full
              right: 12px
            .vux-rater-box
              display: none
              &.is-active
                display: inline-block
          .evaluation-content
            margin-bottom: 20px
            .user-evaluation
              line-height: 37px
              margin-bottom: 20px
              font-size: 26px
              color: $black
            .evaluation-img
              overflow: hidden
              .evaluation-img-list
                margin-bottom: -20px
                margin-right: -16px
                font-size: 0
                .evaluation-img-item
                  display: inline-block
                  vertical-align: top
                  height: 160px
                  width: 160px
                  border: 2px solid $grey
                  margin-right: 16px
                  margin-bottom: 20px
          .store-reply
            width: 100%
            margin-bottom: 17px
            line-height: 33px
            padding: 16px 17px
            font-size: 24px
            color: $black2
            background-color: $grey4
          .evaluation-time
            line-height: 33px
            font-size: 24px
            font-weight: 300
            color: $black2
      .nothing-text
        color: $grey
        font-size: 26px
        padding: 30px 0
        display: block
</style>
