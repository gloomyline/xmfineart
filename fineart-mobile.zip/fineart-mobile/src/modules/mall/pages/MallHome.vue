<template>
  <div :class="classes">
    <div class="mall-home-swiper-wrap">
      <swiper v-model="currentSwiperIndex"
        class="mall-home-swiper"
        dots-class="mall-home-swiper-dots"
        dots-position="center"
        :auto="true"
        :loop="true"
        :interval="5000"
        :duration="500"
        :aspect-ratio="360/750">
        <swiper-item
          class="mall-home-swiper-item"
          v-for="(ad, index) in ads"
          :key="index">
          <a class="architecture-item-link" :href="ad.link_url">
            <img :src="ad.image_url" width="100%" height="100%">
          </a>
        </swiper-item>
      </swiper>
    </div>
    <div class="mall-home-nav">
      <router-link class="mall-home-nav-item goods" to="/groupon">
        <div class="icon icon-mall-home-groupon"></div>
        <p class="name">团购</p>
      </router-link>
      <router-link class="mall-home-nav-item store" to="/store">
        <div class="icon icon-mall-home-store"></div>
        <p class="name">同城建材</p>
      </router-link>
      <router-link class="mall-home-nav-item cart" to="/goods-list">
        <div class="icon icon-mall-home-goods"></div>
        <p class="name">产品/服务</p>
      </router-link>
      <div class="mall-home-nav-item cart" @click="toResourceHome()">
        <div class="icon icon-mall-home-resource"></div>
        <p class="name">品牌库</p>
      </div>
    </div>
    <div class="mall-home-divider"></div>
    <!--推荐商品-->
    <div class="mall-home-recommend-goods">
      <h3 class="cTitle">
        <div class="line"></div>
        <div class="eNum">ONE</div>
        <div class="line"></div>
      </h3>
      <router-link :to="{path: '/goods-list'}">
      <div class="header-img icon-mall-home-goods-bg">
        <div class="mask">
          <div class="yellow-line"></div>
          <div class="title">推荐商品</div>
          <div class="sub-des">品质材料和服务在线市场</div>
          <div class="go-to-detail">
            <div class="arrow"></div>
          </div>
        </div>
      </div>
      </router-link>
      <cube-scroll
        ref="scrollerGoods"
        class="x-scroller"
        direction="horizontal"
        :data="recommendGoods"
        :options="scrollerOption">
        <div class="goods-list">
          <router-link
            class="goods-item"
            v-for="(goods, index) in recommendGoods" :key="index"
            :to="`/goods-detail/${goods.object_id}/${goods.store_id}`">
            <div class="img-goods">
              <img :src="goods.thumbnail" width="100%" @load="onRefresh('scrollerGoods')">
            </div>
            <p class="name-goods">{{ goods.name | labelFormatter(10) }}</p>
          </router-link>
        </div>
      </cube-scroll>
    </div>
    <div class="mall-home-divider"></div>
    <!--预告商品-->
    <div class="mall-home-pre-goods">
      <h3 class="cTitle">
        <div class="line"></div>
        <div class="eNum">TWO</div>
        <div class="line"></div>
      </h3>
      <router-link :to="{path: '/fore-show'}">
        <div class="header-img icon-mall-home-pre-bg">
          <div class="mask">
            <div class="yellow-line"></div>
            <div class="title">新品预告</div>
            <div class="sub-des">建筑行业新科技 </div>
            <div class="go-to-detail">
              <div class="arrow"></div>
            </div>
          </div>
        </div>
      </router-link>
      <cube-scroll
        ref="scrollerFore"
        class="x-scroller"
        direction="horizontal"
        :data="recommendFore"
        :options="scrollerOption">
        <div class="goods-list">
          <router-link
            class="goods-item"
            v-for="(fore, index) in recommendFore"
            :key="index"
            :to="`/fore-show-detail/${fore.object_id}`">
            <div class="img-goods">
              <img :src="fore.thumbnail" width="100%" @load="onRefresh('scrollerFore')">
            </div>
            <p class="name-goods">{{ fore.name | labelFormatter(10) }}</p>
          </router-link>
        </div>
      </cube-scroll>
    </div>
    <div class="mall-home-divider"></div>
    <!--优秀店铺-->
    <div class="mall-home-excellent-store">
      <h3 class="cTitle">
        <div class="line"></div>
        <div class="eNum">THREE</div>
        <div class="line"></div>
      </h3>
      <h3 class="sub-des">严选行业优秀店铺</h3>
      <cube-scroll
        ref="scrollerStore"
        class="x-scroller"
        direction="horizontal"
        :data="recommendStore"
        :options="scrollerOption">
        <div class="store-list">
          <router-link class="store-item"
           v-for="(store, index) in recommendStore" :key="index"
           :to="`/store-detail/${store.object_id}`">
            <img class="bg-img" :src="store.thumbnail" @load="onRefresh('scrollerStore')"/>
            <div class="store-info">
              <div class="name">{{ store.name }}</div>
              <div class="subtitle">{{ store.subtitle }}</div>
              <div class="go-to-detail">
                <div class="arrow"></div>
              </div>
            </div>
          </router-link>
        </div>
      </cube-scroll>
    </div>
    <p class="end-bar">END</p>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtLoginTip } from '@/components'
import { Scroll } from 'cube-ui'
import api from 'modules/mall/api'

export default {
  name: `${COMPONENT_PREFIX}PageMallHome`,
  data () {
    return {
      currentSwiperIndex: 0,
      ads: [],
      recommendGoods: [],
      recommendFore: [],
      recommendStore: [],
      loginTipModal: false,
      scrollerOption: {
        eventPassthrough: 'vertical'
      }
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.$store.commit('MODIFY_PAGE_NAME', '斐艺购')
    this.fetchAds()
    this.fetchRecommendGoods()
    this.fetchRecommendFore()
    this.initRecommendStore()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-mall-home`
    },
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  methods: {
    toResourceHome () {
      window.location = '/resource.html#/?isSelectMode=1'
    },
    async fetchAds () {
      this.ads = await api.fetchAdsList()
    },
    onRefresh (refName) {
      this.$refs[refName].refresh()
    },
    async fetchRecommendGoods () {
      this.recommendGoods = await api.fetchRecommend({ position: 100 })
    },
    async fetchRecommendFore () {
      this.recommendFore = await api.fetchRecommend({ position: 300 })
    },
    async initRecommendStore () {
      this.recommendStore = await api.fetchRecommend({ position: 200 })
    },
    goToCart () {
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      this.$router.push('/mall-cart')
    }
  },
  filters: {
    defaultStoreImg (src) {
      return src || require('assets/imgs/mall/img-store-default.png')
    },
    labelFormatter (str = '', length = 18) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtLoginTip,
    'cube-scroll': Scroll
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-mall-home
  color: $black1
  font-family: PingFangSC-Regular
  .title
    font-size: 34px
    font-weight: 500
    line-height: 48px
  .mall-home-swiper-wrap
    background: $grey4
    margin-bottom: 20px
    .mall-home-swiper
      .mall-home-swiper-dots
        a>i
          width: 26px
          height: 5px
          margin-right: 8px
          background-color: $grey3
          &.active
            background-color: $orange
          &:last-child
            margin: 0
          &:before
            display: none
  .mall-home-nav
    display: flex
    justify-content: space-between
    padding: 20px 39px
    margin-bottom: 20px
    .mall-home-nav-item
      display: block
      padding: 0 20px
      .icon
        inline-icon(88px, 88px)
        display: block
        margin-bottom: 26px
        margin-left:  auto
        margin-right: auto
        &.icon-mall-home-groupon
          bg-img('../../../assets/imgs/mall/icon-mall-home-groupon')
        &.icon-mall-home-store
          bg-img('../../../assets/imgs/mall/icon-mall-home-store')
        &.icon-mall-home-goods
          bg-img('../../../assets/imgs/mall/icon-mall-home-goods')
        &.icon-mall-home-resource
          bg-img('../../../assets/imgs/mall/icon-mall-home-resource')
      .name
        line-height: 30px
        text-align: center
        font-size: 22px
        color: $black2
  .mall-home-divider
    width: 100%
    height: 20px
    background-color: $grey4
  .mall-home-recommend-goods, .mall-home-pre-goods
    padding: 0 30px
    .cTitle
      padding: 30px 0 30px 0
      text-align: center
      .line
        width: 16px;
        height: 4px;
        background: $grey3
        display: inline-block
        margin-bottom: 8px
      .eNum
        height: 42px
        font-size: 30px
        font-weight: 500
        color: $grey3
        line-height: 42px
        display: inline-block
    .header-img
      inline-icon(690px, 300px)
      &.icon-mall-home-pre-bg
        bg-img('../../../assets/imgs/mall/icon-mall-home-pre-bg')
      &.icon-mall-home-goods-bg
        bg-img('../../../assets/imgs/mall/icon-mall-home-goods-bg')
      .mask
        width: 690px
        height: 300px
        background: rgba(156,156,156,0.3)
        text-align: center
        .yellow-line
          width: 60px
          height: 6px
          background: $orange
          border-radius: 1px
          display: inline-block
          margin-top: 50px
        .title
          height: 53px
          font-size: 38px
          font-weight: 600
          color: $white
          line-height: 53px
          margin-top: 20px
        .sub-des
          font-size: 24px
          font-weight: 400
          color: $white
          line-height: 33px
          margin-top: 10px
        .go-to-detail
          width: 47px
          height: 47px
          border: 1px solid $white
          margin-top: 20px
          display: inline-block
          text-align: center
          position relative
          .arrow
            width: 16px
            height: 16px
            border-top: 3px solid $white
            border-right: 3px solid $white
            transform: rotate(45deg)
            position: absolute
            left: 12px
            top: 14px
    .x-scroller
      margin: 30px 0
      font-size: 0
      .goods-list
        position: relative
        display: flex
        .goods-item
          display: inline-block
          vertical-align: top
          width: 180px
          height: 266px
          margin-right: 30px
          &:last-child
            margin-right: 0
          .img-goods
            height: 180px
            width: 180px
            background: $grey4
            margin-bottom: 20px
          .name-goods
            width: 100%
            font-size: 24px
            font-weight: 300
            color: $black
            line-height: 33px
            text-align: center
  .mall-home-excellent-store
    padding: 0 30px
    .cTitle
      padding: 30px 0 0px 0
      text-align: center
      .line
        width: 16px;
        height: 4px;
        background: $grey3
        display: inline-block
        margin-bottom: 8px
      .eNum
        height: 42px
        font-size: 30px
        font-weight: 500
        color: $grey3
        line-height: 42px
        display: inline-block
    .sub-des
      height: 37px
      font-size: 26px
      font-weight: 400
      color: $grey3
      line-height: 37px
      text-align: center
      margin-top: 10px
      margin-bottom: 30px
    .x-scroller
      margin-bottom: 40px
    .store-list
      display: flex
      .store-item
        position: relative
        min-width: 334px
        width: 334px
        height: 334px
        margin-right: 30px
        &:last-child
          margin-right: 0
        .bg-img
          width: 100%
        .store-info
          display: flex
          width: 100%
          height: 100%
          padding: 20px
          absolute: top left
          align-items: center
          flex-direction: column
          justify-content: center
          background: rgba(48,58,88,0.4)
          .name
            width: 100%
            color: $white
            font-size: 28px
            font-weight: 600
            line-height: 44px
            text-align: center
            {ellipse}
          .subtitle
            color: $white
            font-size: 24px
            line-height: 33px
            margin-top: 10px
          .go-to-detail
            width: 47px
            height: 47px
            border: 1px solid $white
            margin-top: 20px
            display: inline-block
            text-align: center
            position relative
            .arrow
              width: 16px
              height: 16px
              border-top: 3px solid $white
              border-right: 3px solid $white
              transform: rotate(45deg)
              position: absolute
              left: 12px
              top: 14px
  .end-bar
    color: $grey
    font-size: 26px
    line-height: 37px
    margin-bottom: 9px
    display: flex
    align-items: center
    justify-content: center
    &:before, &:after
      content: ''
      height: 2px
      width: 40px
      display: block
      margin: 0 12px
      border-top: 1px solid $grey
  .cube-scroll-content
    display: inline-block
    position: relative
</style>
