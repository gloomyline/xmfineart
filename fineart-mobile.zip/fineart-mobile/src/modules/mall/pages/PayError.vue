<template>
  <div :class="classes">
    <div class="icon icon-error"></div>
    <div class="error-content">
      <p>支付错误</p>
      <p>{{ message }}</p>
      <p>请联系：<span class="orange">0592-5709233</span></p>
    </div>
      <!--按钮-->
   <x-button type="primary" @click.native="goToPage('member.html#/my-order')">订单列表</x-button>
   <x-button type="primary" plain @click.native="goToPage('index.html')">返回首页</x-button>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import * as MSG from 'assets/data/message.js'

export default{
  name: `${COMPONENT_PREFIX}PagePayError`,
  data () {
    return {
      code: '',
      message: ''
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-pay-error`
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.code = this.$route.params.code
    this.message = MSG[this.code]
  },
  methods: {
    goToPage (path) {
      window.location = path
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-pay-error
  padding: 30px
  padding-top: 156px
  text-align: center
  .icon-error
    inline-icon(104px, 104px)
    bg-img('../../../assets/imgs/mall/icon-pay-error')
  .error-content
    color: $black2
    font-size: 30px
    line-height: 60px
    margin: 87px 0 109px 0
    .orange
      color: $orange
</style>
