<template>
  <div :class="classes">
    <!--预告新品详情轮播图-->
    <swiper
      :auto="true"
      :loop="true"
      :interval="5000"
      :duration="500"
      dots-position="center"
      :aspect-ratio="420/750">
      <swiper-item
        v-for="(item, index) in foreShowDetail.images" :key="index">
        <img :src="item" width="100%" height="100%">
      </swiper-item>
    </swiper>
    <!-- 返回预告商品列表 -->
    <div class="btn-back-to-goods" @click="goBack"></div>
    <!--预告新品详情基本信息-->
    <div class="fore-show-detail-basic-info">
      <h3 class="name">{{ foreShowDetail.name }}</h3>
      <p class="sub-title">{{ foreShowDetail.subtitle }}</p>
      <div class="subscribe">
        {{ foreShowDetail.reservations }}<span class="const-text">人已预约</span>
      </div>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--详情矩形-->
    <div class="detailRec fy-1px-b">详情</div>
    <!--详情富文本-->
    <div class="fore-goods-grid">
       <div class="fore-goods-detail-intro" v-html="foreShowDetail.introduction"></div>
    </div>
    <!--底部立即预约按钮-->
    <a class="subAtonceButton" @click="changeIsReservation(foreShowDetail.my_reservation_status)">
      <span v-if="!foreShowDetail.my_reservation_status">立即预约</span>
      <span v-else>取消预约</span>
    </a>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>
<script>
import {COMPONENT_PREFIX, COLLECT_MESSAGE_DURATION} from '@/assets/data/constants'
import { FineArtLoginTip } from '@/components'
import { hyphenCase } from '@/common/js/utils'
import * as MSG from 'assets/data/message.js'
import api from 'modules/mall/api'

export default {
  name: `${COMPONENT_PREFIX}PageForeShowDetail`,
  data () {
    return {
      isReservation: false,
      foreShowDetail: {},
      apiProcessing: false, // API请求处理中
      loginTipModal: false
    }
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '新品详情')
    this.initForeShow()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-fore-show-detail`
    },
    isLogin () {
      return this.$store.state.isLogin
    }
  },
  // 从详情页返回列表页时把列表页的keepAlive值设置为true
  beforeRouteLeave (to, from, next) {
    if (to.path === '/fore-show') {
      to.meta.keepAlive = true
    } else {
      to.meta.keepAlive = false
    }
    next()
  },
  methods: {
    goBack () {
      document.referrer === '' ? this.$router.push({ path: '/fore-show' }) : this.$router.go(-1)
    },
    async changeIsReservation (reservation_status) {
      // 判断是否登录
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }

      if (this.apiProcessing) {
        return false
      }
      this.apiProcessing = true

      let params = {id: this.id, operation: reservation_status ? 200 : 100}
      this.result = await api.fetchForeShowReservation(params)
      if (this.result.code === 200) {
        this.foreShowDetail.my_reservation_status = !this.foreShowDetail.my_reservation_status
        // 提示预约成功或取消预约成功
        if (this.foreShowDetail.my_reservation_status) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_FORE_SHOW_RESERVATION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['MALL_FORE_SHOW_CANCEL_RESERVATION_SUCCESS'], type: 'success' })
        }
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    },
    async initForeShow () {
      this.foreShowDetail = await api.fetchForeShowDetail(this.id)
      const vm = this
      this.oldShare = this.$wx.shareData
      this.$wx.updateShareData('mall', {
        title: vm.foreShowDetail.name,
        desc: vm.foreShowDetail.subtitle
      })
    }
  },
  components: {
    FineArtLoginTip
  }
}
</script>
<style lang="stylus">
  .{$cls_prefix}-page-fore-show-detail
    position: relative
    color: $black1
    font-family: PingFangSC-Regular
    .btn-back-to-goods
      absolute: left 30px top 30px
      width: 56px
      height: 56px
      border-radius: 50%
      bg-img('../../../assets/imgs/mall/icon-go-back')
      background-size: cover
    .fore-show-detail-basic-info
      font-size: 0
      padding: 30px
      .name
        font-size: 34px
        line-height: 48px
        margin-bottom: 10px
      .sub-title
        font-size: 26px
        color: $grey3
        line-height: 37px
        font-weight: 300
        margin-bottom: 30px
      .subscribe
        font-size: 34px
        line-height: 48px
        color: $orange
        font-weight: 500
        .const-text
          font-size: 26px
          color: $black2
          line-height: 37px
          margin-left: 7px
          font-weight: 400
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .detailRec
      height: 80px
      line-height: 80px
      font-size: 28px
      color: $black1
      text-align: center
    .fore-goods-grid
      position: relative
      min-height: 250px
      padding-bottom: 88px
      .fore-goods-detail-intro
        line-height: 48px
        font-size: 26px
        color: $black2
        overflow: hidden
        margin: 0 auto
        img
          max-width: 100%
    .subAtonceButton
      position: fixed
      bottom: 0
      width: 100%
      height: 88px
      color: white
      font-size: 30px
      line-height: 88px
      text-align: center
      background-color: $orange
</style>
