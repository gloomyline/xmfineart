<template>
  <div :class="classes">
    <!-- 页面头部栏 -->
    <groupon-head class="page-head" title="团购名单"></groupon-head>
    <!-- 团购名单列表 -->
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      :height="-94/75"
      @refresh="refresh"
      @load-more="loadMore"
      :list="roster.data"
      :has-data="hasData"
      :has-more="roster.has_next">
      <!-- 团购统计 -->
      <p class="groupon-total">
        <span class="number">{{ roster.total }}人</span>
        <span class="text">参与团购</span>
      </p>
      <div class="roster-list-wrap">
        <div class="applicant-item fy-1px-b" v-for="(item, index) in roster.data" :key="index">
          <div class="applicant-person-info">
            <div class="avatar-wrap">
              <img :src="item.avatar" width="100%" height="100%"/>
            </div>
            <div class="info-wrap">
              <p class="name-tel">
                <span class="name">{{ item.name }}</span>
                <span class="tel">{{ item.mobile }}</span>
              </p>
            </div>
          </div>
          <div class="apply-detail">
            <div class="applicant-word" v-if="item.remark">{{ item.remark }}</div>
            <div class="num-time">
              <span class="num">需求量
                <em>{{ item.num }}</em>
              </span>
              <span class="time">{{ item.created_at }}</span>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { GrouponHead, FineArtScroller } from '@/components'
import api from '@/modules/mall/api'

export default {
  data () {
    return {
      name: `${COMPONENT_PREFIX}PageGrouponRoster`,
      roster: {
        data: [],
        total: 0,
        has_next: false
      },
      pageConfig: {
        page: 1,
        groupon_id: this.id
      }
    }
  },
  props: ['id'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-groupon-roster`
    },
    hasData () {
      return this.roster.total > 0
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.initGrouponApplyList()
  },
  methods: {
    async initGrouponApplyList () {
      this.roster = await api.fetchGrouponApplyList(this.pageConfig)
    },
    refresh () {
      this.pageConfig.page = 1
      this.initGrouponApplyList()
    },
    async loadMore (cb) {
      if (!this.roster.has_next) return cb()
      this.pageConfig.page += 1
      const res = await api.fetchGrouponApplyList(this.pageConfig)
      this.roster.data = [ ...this.roster.data, ...res.data ]
      this.roster.has_next = res.has_next
      this.roster.total = res.total
    }
  },
  filters: {
  },
  components: {
    GrouponHead,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-groupon-roster
  font-family: PingFangSC-Regular
  .groupon-total
    display: flex
    padding: 30px
    font-size: 26px
    line-height: 37px
    align-items: center
    justify-content: center
    .number
      color: $orange
    .text
      color: $grey3
    &:before, &:after
      display: block
      margin: 0 40px
      content: ''
      width: 81px
      height: 0
      border-top: 2px solid $grey
  .roster-list-wrap
    position: relative
    padding: 0 30px
    .applicant-item
      padding: 25px 0
      position: relative
      &:first-child
        padding-top: 0
      &:last-child::after
        display: none
      .applicant-person-info
        height: 80px
        display: flex
        justify-content: space-between
        .avatar-wrap
          width: 80px
          height: 80px
          border-radius: 50%
          background: $grey4
          overflow: hidden
        .info-wrap
          width: 580px
          display: flex
          justify-content: space-between
          .name-tel
            text-align: left
            display: flex
            flex-direction: column
            justify-content: space-between
            .name
              color: $black1
              font-size: 30px
              line-height: 42px
              font-weight: 500
              display: inline-block
            .tel
              color: $grey2
              font-size: 26px
              line-height: 37px
              display: inline-block
      .apply-detail
        width: 100%
        padding-left: 110px
        display: flex
        align-items: last
        flex-direction: column
        .applicant-word
          margin-top: 20px
          padding: 20px
          color: $black2
          font-size: 26px
          line-height: 37px
          background: $grey4
          border-radius: 10px
        .num-time
          display: flex
          font-size: 24px
          line-height: 33px
          margin-top: 20px
          align-items: center
          justify-content: space-between
          .num
            color: $black2
            em
              color: $orange
          .time
            color: $grey3
</style>
