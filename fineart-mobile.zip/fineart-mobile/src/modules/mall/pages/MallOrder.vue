<template>
  <div :class="classes">
    <div class="orderTrans"  v-if="showStep === '1'">
      <!--装饰线-->
      <div class="decorate-line-wrap">
      </div>
      <!--买家信息-->
      <div class="buyer-info" v-if="addressStatus === '1'" @click="goChangeAddr()">
        <div class="name">{{ address.name }}</div>
        <div class="phone-address">
          <div class="phone">{{ address.mobile }}</div>
          <div class="address">{{ address.address_desc }}</div>
        </div>
        <div class="more-info-icon" >
          <i class="fy-icon-arrow-right"></i>
        </div>
      </div>
      <!-- 无默认收货地址情况 -->
      <div class="buyer-info" @click="goChangeAddr()" v-if="addressStatus === '2'">
        <div class="add-addr-text">选择地址</div>
        <div class="more-info-icon">
          <i class="fy-icon-arrow-right"></i>
        </div>
      </div>
      <!-- 无地址情况 -->
      <div class="buyer-info" @click="goAddAddr" v-if="addressStatus === '3'">
        <div class="add-addr-text">添加地址</div>
        <div class="more-info-icon">
          <i class="fy-icon-arrow-right"></i>
        </div>
      </div>
      <!--灰色线-->
      <div class="divider"></div>
      <!--所购买商品信息-->
      <div class="selected-product">
        <div class="selected-item fy-1px-b" v-for="(item, index) in goods.data" :key="index">
          <router-link class="product-detail" :to="`/goods-detail/${item.mall_goods_id}/${item.mall_store_id}`">
            <div class="img-wrap">
              <img :src="item.thumbnail_cdn" width="80%" height="80%">
            </div>
            <div class="detail">
              <div class="name">{{ item.name | labelFormatter(28) }}</div>
              <div class="price-count">
                <div class="price">&yen;{{ item.price_discount ? item.price_discount : item.price_norm }}</div>
                <div class="count">
                  <div class="count-num">x{{ item.number }}</div>
                </div>
              </div>
            </div>
          </router-link>
        </div>
      </div>
      <!--灰色线-->
      <div class="divider"></div>
      <!--总计和运费-->
      <div class="all-count-and-ship">
        <div class="all-count">
          <span class="const-text">合计金额</span>
          <span class="price">&yen;{{ goods.price_total }}</span>
        </div>
        <div class="ship">
          <span class="const-text">运费</span>
          <span class="price">&yen;{{ goods.freight }}</span>
        </div>
      </div>
      <!--底部栏-->
      <div class="bottom-bar fy-1px-t">
        <div class="all-count">
          实付：<span class="price">&yen;{{ goods.price_pay }}</span>
        </div>
        <div class="go-to-payment">
          <div>
            <span class="const-text" @click="goPay()">去付款</span>
          </div>
        </div>
      </div>
      <!--灰色区-->
      <div class="grey-area"></div>
    </div>
    <!-- 选择地址弹出区 -->
    <div class="adressTrans" v-if="showStep ==='2'">
      <fine-art-my-address
        :pageType="pageType"
        @selected-address="selectAddress"
        @handle-add="goAddAddr"></fine-art-my-address>
    </div>
    <!-- 添加地址 -->
    <fine-art-address-add v-if="showStep === '3'" @before-close="goChangeAddr()"></fine-art-address-add>
  </div>
</template>
<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, fetchWXCodeForPay } from '@/common/js/utils'
import { FineArtScroller, FineArtMyAddress, FineArtAddressAdd } from 'components'
import api from 'modules/mall/api/index.js'
import memberApi from 'modules/member/api/index.js'
import * as MSG from 'assets/data/message.js'

export default{
  name: `${COMPONENT_PREFIX}PageCheckBill`,
  data () {
    return {
      cartIds: [],
      address: {},
      addressList: [],
      addressStatus: '1', // 1=>有默认地址 2=>无默认地址，有地址列表 3=>无地址列表
      goods: {},
      showStep: '1', // 1=>显示订单页面 2=>显示地址列表 3=> 添加地址
      pageType: 1 // 只进行地址的选择
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.initPage()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-check-bill`
    },
    goodsLength () {
      return this.goods.data.length
    }
  },
  methods: {
    async initPage () {
      this.$store.commit('MODIFY_PAGE_NAME', '确认订单')
      this.cartIds = this.$store.state.mall.cartItemIdArr
      let defaultAddr = await memberApi.addressFetchDefault()
      if (defaultAddr) {
        this.address = defaultAddr
        this.addressStatus = '1'
      } else {
        this.addressList = await memberApi.addressFetchList()
        if (this.addressList.length > 0) {
          this.addressStatus = '2'
        } else {
          this.addressStatus = '3'
        }
      }
      this.goods = await api.cartCheckout(this.cartIds)
    },
    async goPay () {
      if (this.address.id === undefined) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG.MALL_ORDER_ADDRESS_NO, type: 'warn' })
      }
      let res = await api.orderAdd(this.cartIds, this.address.id)
      if (res.code === 200) {
        fetchWXCodeForPay(res.results.code)
      }
    },
    // 显示地址列表
    goChangeAddr () {
      this.$store.commit('MODIFY_PAGE_NAME', '我的收货地址')
      this.showStep = '2'
    },
    goAddAddr () {
      this.$store.commit('MODIFY_PAGE_NAME', '添加收货地址')
      this.showStep = '3'
    },
    // 选择地址
    selectAddress (seletedAddressItem) {
      this.$store.commit('MODIFY_PAGE_NAME', '确认订单')
      this.address = seletedAddressItem
      this.showStep = '1'
      this.addressStatus = '1'
    }
  },
  filters: {
    labelFormatter (str = '', length = 28) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtScroller,
    FineArtMyAddress,
    FineArtAddressAdd
  }
}
</script>

<style lang="stylus">
  .{$cls_prefix}-page-check-bill
    position: relative
    margin-bottom: 88px
    font-family: PingFangSC-Regular
    .decorate-line-wrap
      height: 12px
      background-image: url("../../../assets/imgs/mall/icon-check-bill-decorate-line@2x.png")
      background-repeat: no-repeat
      background-size: cover
    .buyer-info
      display: flex
      flex-direction: row
      align-items: baseline
      justify-content: left
      position: relative
      margin: 30px
      .add-addr-text
        font-size: 28px
        height: 40px
        line-height: 40px
        color: $black1
        width: 90%
      .name
        width: 90px
        font-size: 28px
        height: 40px
        line-height: 40px
        color: $black1
        margin-right: 20px
        {ellipse}
      .phone-address
        font-size: 28px
        line-height: 40px
        color: $black1
        width: 70%
        .address
          font-size: 24px
          line-height: 33px
          color: $grey3
          margin-top: 14px
      .more-info-icon
        font-size: 0
        display: flex
        height: 40px
        align-items: center
        absolute: right top
        .fy-icon-arrow-right
          font-size: 24px
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .selected-product
      padding: 0 30px
      .fy-1px-b:last-child::after
        display: none
      .selected-item
        padding: 30px 0
        display: flex
        justify-content: left
        flex-direction: row
        .product-detail
          display: flex
          justify-content: left
          flex-direction: row
          position: relative
          .img-wrap
            height: 160px
            width: 160px
            background: $grey4
            img
              height: 160px
          .detail
            .name
              font-size: 28px
              line-height: 40px
              color: $black2
            .price-count
              .price
                font-size: 26px
                line-height: 37px
                color: $black1
                position: absolute
                bottom: 22px
              .count
                position: absolute
                bottom: 22px
                right: 50px
                .count-num
                  font-size: 26px
                  line-height: 37px
                  color: $grey3
    .all-count-and-ship
      padding: 30px
      .all-count
        position: relative
      .ship
        position: relative
      .const-text
        font-size: 24px
        line-height: 33px
        color: $black1
        vertical-align: top
      .price
        font-size: 24px
        line-height: 33px
        color: $black2
        position: absolute
        right: 0
    .bottom-bar
      position: fixed
      bottom: 0
      width: 100%
      height: 88px
      font-size: 0
      background-color: $white
      .all-count,.go-to-payment
        display: inline-block
        vertical-align: top
        text-align: center
        line-height: 88px
      .all-count
        width: 66%
        font-size: 28px
        color: $black2
        text-align: right
        padding-right: 30px
        .price
          font-size: 28px
          color: $orange
      .go-to-payment
        width: 34%
        background-color: $orange
        .const-text
          font-size: 28px
          color: $white
    .grey-area
      width: 100%
      height: 100%
      background-color: $grey4
</style>
