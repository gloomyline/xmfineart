<template>
  <div :class="classes">
    <!-- 页面头部栏 -->
    <groupon-head class="page-head" title="团购详情"></groupon-head>
    <!-- 团购信息 -->
    <cube-scroll class="groupon-detail-scroll" ref="scroller">
      <div class="groupon-detail" v-if="grouponDetail.name">
        <div class="name">{{ grouponDetail.name }}</div>
        <div class="sub-title">{{ grouponDetail.subtitle }}</div>
        <div class="price">
          <span class="text">团购价：</span>
          <span class="number">{{ grouponDetail.price }}</span>
        </div>
        <div class="groupon-img">
          <div class="img-wrap" v-for="(img, index) in grouponDetail.image" :key="index">
            <img :src="img.url" @load="onRefresh"/>
          </div>
        </div>
        <div class="groupon-introduction" v-html="grouponDetail.introduction"></div>
        <div class="group-apply-wrap">
          <router-link  class="apply-member-avatar"
                        v-if="hasApplication"
                        :to="`/groupon/roster/${id}`">
            <div class="img-wrap" v-for="(val, index) in grouponDetail.applicant" :key="index">
              <img :src="val.avatar" height="100%" width="100%"/>
            </div>
            <div class="img-wrap goToRoster">
              <span class="fy-icon-arrow-right"></span>
            </div>
          </router-link >
          <p class="total">
            <span class="member-total">已有{{ grouponDetail.applicant_num }}人参与，</span>
            <span class="groupon-total">已团{{ grouponDetail.total }}{{ grouponDetail.unit }}</span>
          </p>
        </div>
        <div class="groupon-contact">
          <span class="text">团购发布者</span>
          <span class="name-mobile">{{ grouponDetail.contact_name }}（{{ grouponDetail.contact_mobile }}）</span>
        </div>
        <p class="end-bar">END</p>
      </div>
    </cube-scroll>
    <!-- 底部栏 -->
    <div class="bottom-bar fy-1px-t" v-if="grouponDetail.name">
      <router-link class="buy-now"
                   v-if="grouponDetail.mall_goods_id"
                   :to="`/goods-detail/${grouponDetail.mall_goods_id}/${grouponDetail.mall_store_id}`">立即购买</router-link>
      <div class="apply"
           :class="{'full': !grouponDetail.mall_goods_id}"
           @click="applyGroupon">参与团购</div>
    </div>
    <!-- 参与团购弹窗 -->
    <transition name="fade">
      <groupon-apply
        class="group-apply-modal"
        v-if="showApplyModal"
        @close-modal="showApplyModal = false"
        @submit-apply="submitApply"></groupon-apply>
    </transition>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { GrouponHead, GrouponApply, FineArtLoginTip } from '@/components'
import { Scroll } from 'cube-ui'
import * as MSG from 'assets/data/message.js'
import api from '@/modules/mall/api'

export default {
  data () {
    return {
      name: `${COMPONENT_PREFIX}PageGrouponDetail`,
      // 团购详情
      grouponDetail: {},
      // 团购商品弹窗
      showApplyModal: false,
      // 登陆弹窗
      loginTipModal: false
    }
  },
  props: ['id'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-groupon-detail`
    },
    isLogin () {
      return this.$store.state.isLogin
    },
    hasApplication () {
      if (!this.grouponDetail.applicant) return
      return this.grouponDetail.applicant.length > 0
    }
  },
  created () {
    this.$wx.updateShareData('mall', {})
    this.initGrouponDetail()
  },
  methods: {
    // 获取团购详情数据
    async initGrouponDetail () {
      this.grouponDetail = await api.fetchGrouponDetail({ id: this.id })
      this.$nextTick(() => {
        this.$refs.scroller.refresh()
      })
    },
    onRefresh () {
      this.$refs.scroller.refresh()
    },
    // 参与团购
    applyGroupon () {
      // 判断是否登录
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      this.showApplyModal = true
    },
    async submitApply (param) {
      const response = await api.grouponApply({ mall_groupon_id: this.id, ...param })
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', {msg: MSG['MALL_GROUPON_APPLY_SUCCESS'], type: 'success'})
        this.showApplyModal = false
        this.initGrouponDetail()
      }
    }
  },
  components: {
    GrouponHead,
    GrouponApply,
    FineArtLoginTip,
    'cube-scroll': Scroll
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-groupon-detail
  font-family: PingFangSC-Regular
  .groupon-detail-scroll
    width: 100%
    fixed: top 94px left
  .groupon-detail
    padding: 30px
    .groupon-img
      padding: 30px 0
      display: flex
      flex-direction: column
      align-items: center
      .img-wrap
        font-size: 0
        max-width: 690px
        overflow: hidden
        position: relative
        img
          max-width: 690px
        &:last-child
          margin-bottom: 0
    .name
      color: $black1
      padding-top: 12px
      margin-bottom: 16px
      line-height: 56px
      font-size: 40px
      font-weight: 500
    .sub-title
      line-height: 40px
      margin-bottom: 34px
      font-size: 28px
      color: $black2
    .price
      font-size: 28px
      height: 40px
      line-height: 40px
      .text
        color: $grey2
      .number
        color: $orange
    .groupon-introduction
      color: $black2
      font-size: 28px
      line-height: 46px
      margin-bottom: 50px
    .group-apply-wrap
      display: flex
      flex-direction: column
      align-items: center
      .apply-member-avatar
        display: flex
        flex-wrap: wrap
        align-items: center
        padding-bottom: 30px
        padding-right: 35px
        .img-wrap
          width: 84px
          height: 84px
          overflow: hidden
          background: $grey4
          margin-right: -35px
          border-radius: 50%
          border: 5px solid $white
          &.goToRoster
            position: relative
            background: #7c776d
            .fy-icon-arrow-right
              width: 74px
              height: 74px
              color: $white
              font-size: 32px
              display: block
              border-radius: 50%
              &:before
                z-index: 1
                absolute: top 50% left 50%
                transform: translate(-50%, -50%)
      .total
        display: flex
        font-size: 24px
        line-height: 33px
        align-items: center
        margin-bottom: 23px
        .member-total
          color: $grey3
        .groupon-total
          color: $orange
    .groupon-contact
      width: 100%
      padding: 20px
      font-size: 24px
      line-height: 33px
      background: $grey5
      border-radius: 6px
      display: flex
      justify-content: space-between
      .text
        color: $grey3
      .name-mobile
        color: $black2
    .end-bar
      color: $grey
      font-size: 26px
      line-height: 37px
      padding: 23px
      margin-bottom: 182px
      display: flex
      align-items: center
      justify-content: center
      &:before, &:after
        content: ''
        height: 2px
        width: 40px
        display: block
        margin: 0 12px
        border-top: 1px solid $grey
  .bottom-bar
    fixed: left bottom
    display: flex
    width: 100%
    height: 88px
    font-size: 0
    background: $white
    z-index: 3
    .buy-now
      width: 375px
      line-height: 88px
      color: #F7B52C
      font-size: 30px
      text-align: center
      background: #FDF0D5
    .apply
      width: 375px
      line-height: 88px
      color: $white
      font-size: 30px
      text-align: center
      background: $orange
      &.full
        width: 750px
  .fade-enter-active, .fade-leave-active
    transition: opacity .5s
  .fade-enter, .fade-leave-active
    opacity: 0
</style>
