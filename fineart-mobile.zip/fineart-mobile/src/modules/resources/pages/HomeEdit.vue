<template>
  <group :class="classes">
    <div class="logo-wrap">
      <span class="span-label">{{logoTip}}</span>
      <!-- 上传图片 -->
      <div class="logo">
        <img :src="detail.logo_cdn">
        <!-- 上传图片 -->
        <fine-art-upload class="upload-logo" :width="110" :height="110"
                         :max-size="ossImage.max_size"
                         :data="ossImage.data"
                         :action="ossImage.host"
                         :format="ossImage.format"
                         :accept="ossImage.accept"
                         :beforeUpload="beforeUploadImage"
                         :on-success="successImage">
        </fine-art-upload>
      </div>
      <i class="icon-arrow"></i>
    </div>
    <!--分割线-->
    <div class="fy-divider"></div>
    <div class="info">
      <x-input :title="nameTip" :placeholder="`请填写${nameTip}`" text-align="right" :show-clear="false" v-model="detail.name"></x-input>
      <x-textarea title="一句话介绍" placeholder="请填写介绍" autosize :rows="1" text-align="right" :show-clear="false" class="intro-textarea" v-model="detail.subtitle"></x-textarea>
      <h3 class="box-label"><span class="span-label">{{tipTxt}}简介</span></h3>
      <x-textarea :placeholder="`请填写${tipTxt}简介`" text-align="right" :show-clear="false" class="detail-textarea" v-model="detail.introduction"></x-textarea>
      <div class="tag-wrap">
        <h3 class="box-label" @click="isShowTag = true">
          <span class="span-label">标签</span>
          <span class="span-placeholder">请选择</span>
          <i class="icon-arrow"></i>
        </h3>
        <ul class="tag-list">
          <li class="tag" v-for="(item, index) in tagList" :key="index">{{item.tag || item.name}}</li>
        </ul>
      </div>
    </div>
    <!--分割线-->
    <div class="fy-divider"></div>
    <div class="other-info">
      <h3 class="box-label" @click="isShowAddress = true">
        <span class="span-label">地区</span>
        <span class="span-placeholder" v-if="!areaVal">请选择</span>
        <span class="span-name" v-if="areaVal">{{areaVal}}</span>
        <i class="icon-arrow"></i>
      </h3>
      <h3 class="box-label fy-1px-b">
        <span class="span-label">类型</span>
        <span class="span-name">{{detail.mode_desc}}</span>
      </h3>
      <fine-art-category title="分类" :data-list="resourceCate" v-model="cateVal" @choice-cate="getCate"></fine-art-category>
      <popup-radio v-if="$route.params.mode === '100' || $route.params.mode === '500'" title="性别" :options="genderList" v-model="detail.gender" placeholder="请选择"></popup-radio>
      <!-- 收费标准 -->
      <popup-picker
        title="收费标准"
        v-model="designArray"
        show-name
        :columns="2"
        v-if="$route.params.mode === '100' || $route.params.mode === '200' || $route.params.mode === '500'"
        placeholder="请选择"
        :data="resourceDesignPrice"
        @on-change="onPriceChange"
        is-link></popup-picker>
    </div>
    <x-button type="primary" class="save-btn" @click.native="saveForm">提交</x-button>
    <!--标签弹窗-->
    <div v-transfer-dom>
      <dynamic-tag v-model="isShowTag" :type="100" @choose="choiceTag" :tags="detail.tags"></dynamic-tag>
    </div>
    <div v-transfer-dom>
      <resource-operate v-model="isOperate"></resource-operate>
    </div>
    <div v-transfer-dom>
      <fine-art-address v-model="isShowAddress"
                        :lng="detail.lng"
                        :lat="detail.lat"
                        @save-edit="changeHandler"></fine-art-address>
    </div>
  </group>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import { FineArtUpload, FineArtCategory, DynamicTag, FineArtEmpty, ResourceOperate, FineArtAddress } from 'components'
import api from 'modules/resources/api'
import * as MSG from 'assets/data/message.js'
import { getResourceCategory, find } from '@/common/js/loadScript'

export default {
  name: 'HomeEdit',
  data () {
    return {
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      resourceCate: [],
      isShowTag: false,
      genderList: [{
        key: '200',
        value: '男'
      }, {
        key: '300',
        value: '女'
      }],
      isOperate: false,
      detail: {},
      commonRule: {
        name: [
          { required: true, message: '请填写姓名' }
        ],
        subtitle: [
          { required: true, message: '请填写一句话介绍' }
        ],
        sys_area_id: [
          { required: true, message: '请选择地址' }
        ]
      },
      personRule: {
        gender: [
          { required: true, message: '请选择性别' }
        ],
        introduction: [
          { required: true, message: '请填写个人简介' }
        ]
      },
      companyRule: {
        introduction: [
          { required: true, message: '请填写公司简介' }
        ]
      },
      // 地区
      areaVal: '',
      // 分类
      cateVal: '',
      // 标签列表
      tagList: [],
      designArray: [],
      isShowAddress: false
    }
  },
  components: {
    FineArtUpload,
    FineArtCategory,
    DynamicTag,
    FineArtEmpty,
    ResourceOperate,
    FineArtAddress
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-home-edit`
    },
    // 收费标准
    resourceDesignPrice () {
      return this.$store.state.resource.resourceDesignPrice
    },
    tipTxt () {
      const mode = this.$route.params.mode
      if (mode === '100' || mode === '500') {
        return '个人'
      } else {
        return '公司'
      }
    },
    nameTip () {
      const mode = this.$route.params.mode
      if (mode === '100' || mode === '500') {
        return '姓名'
      } else {
        return '公司名称'
      }
    },
    logoTip () {
      const mode = this.$route.params.mode
      if (mode === '100' || mode === '500') {
        return '个人头像'
      } else {
        return '公司LOGO'
      }
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '编辑资料')
    this.init()
  },
  methods: {
    async init () {
      const response = await getResourceCategory()
      this.resourceCate = find(response, Number(this.$route.params.mode)).children
      this.detail = await api.fetchResourceDetail({
        resource_id: this.$route.params.id,
        resource_mode: this.$route.params.mode
      })
      this.areaVal = Object.values(this.detail.area_line).join(' / ')
      this.cateVal = Object.values(this.detail.category_line).join(' / ')
      this.tagList = this.detail.tags
      this.detail.introduction = this.detail.introduction.replace(/<br \/>|<br>/g, '\r\n')
      this.$set(this.designArray, 0, this.detail.design_price)
    },
    // 图片上传之前
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'resource_logo', this.ossImage)
    },
    // 图片上传成功
    async successImage (res) {
      this.detail.logo_cdn = res.results.file_url_cdn
      this.detail.logo = res.results.file_url
    },
    // 选中收费标准
    onPriceChange () {
      this.detail.design_price = this.designArray[0]
    },
    // 标签选择
    choiceTag (tag) {
      this.tagList = tag
      this.detail.tags = tag
    },
    async saveForm () {
      const mode = this.$route.params.mode
      let rules = false
      if (mode === '100' || mode === '500') {
        rules = await validate(this.detail, {...this.personRule, ...this.commonRule})
      } else {
        rules = await validate(this.detail, {...this.companyRule, ...this.commonRule})
      }
      if (!rules) return
      if (this.detail.tags.length === 0) {
        this.detail.tags[0] = 0
      } else {
        this.detail.tags = this.detail.tags.map(item => item.id)
      }
      const params = this.resetData(this.detail)
      const response = await api.resourceHomeEdit(this.detail.id, this.detail.mode, params)
      if (response.code === 200) {
        const vm = this
        this.$store.commit('ADD_MESSAGE', {
          msg: MSG['RESOURCE_EDIT_SUCCESS'],
          type: 'success',
          cb () {
            vm.$store.dispatch('resource/fetchDetail', {
              resource_id: vm.$route.params.id,
              resource_mode: vm.$route.params.mode
            })
            vm.goToDetail(vm.$route.params.id, vm.$route.params.mode)
          }})
      }
    },
    // 前往主页详情
    goToDetail (id, mode) {
      let page = ''
      switch (mode) {
      case '100':
        page = `/person-home/${id}`
        break
      case '200':
        page = `/company-home/${id}`
        break
      case '300':
        page = `/supplier-home/${id}`
        break
      case '400':
        page = `/brand-home/${id}`
        break
      case '500':
        page = `/decorator-home/${id}`
        break
      }
      this.$router.push({path: page})
    },
    resetData (obj) {
      let resetObj = {
        logo: obj.logo || '',
        name: obj.name || '',
        introduction: obj.introduction || '',
        subtitle: obj.subtitle || '',
        resource_category_id: obj.resource_category_id || '',
        address: obj.address || '',
        sys_area_id: obj.sys_area_id || '',
        'tags[]': obj.tags,
        lng: obj.lng || '',
        lat: obj.lat || ''
      }
      const mode = this.$route.params.mode
      if (mode === '100' || mode === '500') {
        resetObj.gender = obj.gender || ''
        resetObj.design_price = obj.design_price || ''
      }
      if (mode === '200') {
        resetObj.design_price = obj.design_price || ''
      }
      return resetObj
    },
    getAddress (area) {
      this.detail.sys_area_id = area[area.length - 1]
    },
    getCate (cate) {
      this.detail.resource_category_id = cate[cate.length - 1]
    },
    // 地图改变位置
    changeHandler (val) {
      this.detail.lng = val.point[0]
      this.detail.lat = val.point[1]
      this.detail.address = val.address
      this.areaVal = `${val.province} / ${val.city} / ${val.district}`
      this.detail.sys_area_id = val.area_id
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-home-edit
  color: $black1
  .weui-cell
    height: 98px
    padding-left: 0
    padding-right: 0
    .weui-label, .vux-label
      color: $grey3
    &.intro-textarea
      display: flex
      align-items: center
      height: auto
      min-height: 98px
      .weui-cell__bd
        height: 100%
        margin-right: -12px
        padding-right: 0 !important
        .weui-textarea
          display: inline-block
          height: 100%
          text-align: right
          padding: 0
          background-color: rgba(0, 0, 0, 0)
    &.detail-textarea
      height: 234px
      padding-top: 0
      padding-bottom: 30px
      .weui-cell__bd
        width: 100%
        height: 204px
        padding: 30px
        border: 1.4px solid $grey
        .weui-textarea
          width: 100%
          height: 100%
          outline: none
          padding: 0
          border: none
          line-height: 40px
          background-color: rgba(0, 0, 0, 0)
          border-radius: 4px
  .fy-divider
    width: 100%
    height: 20px
    background-color: $grey5
  .box-label
    height: 98px
    padding: 30px 0
  .span-label
    color: $grey3
    line-height: 40px
    font-size: 28px
  .logo-wrap
    position: relative
    display: flex
    justify-content: space-between
    align-items: center
    padding: 30px 75px 30px 30px
    .logo
      position: relative
      width: 110px
      height: 110px
      border-radius: 50%
      &>img
        display: block
        width: 110px
        height: 110px
        border-radius: 50%
      .upload-logo
        absolute: top left
        .upload-box
          absolute: top left
          display: flex
          justify-content: center
          align-items: center
          width: 100%
          height: 100%
          font-size: 42px
          color: $white
          background-color: rgba(0, 0, 0, 0.4)
          border-radius: 50%
    .icon-arrow
      absolute: top 50% right 24px
      width: 18px
      height: 18px
      border-width: 2px 2px 0 0
      border-color: $grey2
      border-style: solid
      transform: translateY(-50%) rotate(45deg)
  .info
    padding: 0 30px
    .tag-wrap
      .box-label
        position: relative
        display: flex
        align-items: center
        justify-content: space-between
        padding: 28px 30px 20px 0
        .span-placeholder
          color: $grey2
          font-size: 28px
          line-height: 40px
        .icon-arrow
          absolute: top 44px right
          width: 18px
          height: 18px
          border-width: 2px 2px 0 0
          border-color: $grey2
          border-style: solid
          transform: rotate(45deg)
      .tag-list
        display: flex
        margin-bottom: 30px
        .tag
          margin-right: 10px
          color: $orange
          text-align: center
          font-size: 20px
          background-color: rgba(247, 181, 44, 0.1)
          border-radius: 6px
          text-middle: 5px 14px
  .other-info
    padding: 0 30px
    .box-label
      position: relative
      display: flex
      justify-content: space-between
      align-items: center
      padding: 28px 30px 28px 0
      .span-name
        color: $black1
        font-size: 28px
        line-height: 40px
      .span-placeholder
        color: $grey2
        font-size: 28px
        line-height: 40px
      .icon-arrow
        absolute: top 44px right
        width: 18px
        height: 18px
        border-width: 2px 2px 0 0
        border-color: $grey2
        border-style: solid
        transform: rotate(45deg)
  .case-title
    display: flex
    justify-content: space-between
    align-items: center
    height: 90px
    padding: 0 30px
    .name
      position: relative
      height: 90px
      color: $orange
      font-size: 28px
      line-height: 90px
      &:after
        content: ''
        absolute: left bottom
        width: 100%
        height: 4px
        background-color: $orange
    .more
      color: $grey3
      font-size: 24px
  .case-list
    width: 100%
    .case-item
      position: relative
      .edit-btn
        absolute: right 30px top 40px
        display: flex
        justify-content: space-between
        align-items: center
        width: 32px
        height: 42px
        padding: 0
        margin: 0
        border: none
        &>span
          display: inline-block
          width: 6px
          height: 6px
          background-color: $black2
        border-radius: 50%
      .case-wrap
        display: flex
        padding: 30px 30px
        .case-img
          width: 160px
          height: 160px
          margin-right: 30px
          border-radius: 6px
          &>img
            display: block
            width: 100%
            height: 100%
            border-radius: 6px
        .case-content
          flex: 1 0 auto
          .case-name
            margin-bottom: 20px
            padding-top: 10px
            line-height: 42px
            font-size: 30px
            color: $black1
            {ellipse}
            &.is-edit
              max-width: 420px
              {ellipse}
          .case-subtitle
            margin-bottom: 10px
            font-size: 24px
            line-height: 33px
            color: $grey3
            {ellipse}
            &.area
              padding-left: 30px
              background: url('../../../assets/imgs/resource/icon-address@2x.png') 0 center no-repeat
              background-size: auto 21px
  .case-empty
    width: 100%
    padding: 64px 0 80px 0
    text-align: center
    .fy-icon-addcase
      margin-bottom: 30px
      font-size: 108px
    .empty-title
      font-size: 28px
      margin-bottom: 30px
    .empty-text
      color: $black2
      line-height: 48px
      font-size: 24px
      &>a
        color: $orange
  .save-btn
    width: 690px
    margin-top: 30px
    margin-bottom: 30px
.weui-cell_radio.weui-check__label
  height: 98px
  padding: 0 30px
  font-size: 28px
  border-bottom: 1px solid $grey
</style>
