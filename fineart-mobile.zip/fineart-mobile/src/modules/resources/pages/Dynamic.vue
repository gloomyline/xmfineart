<template>
  <div :class="classes">
  <cube-scroll ref="scroller"
               class="dynamic-scroller"
               :options="scrollOptions"
               :data="dynamic.data"
               @pulling-down="init"
               @pulling-up="loadMore">
      <resource-head :id="$route.params.id"></resource-head>
      <ul class="dynamic-list" v-if="hasData">
        <li class="dynamic fy-1px-b" v-for="(item, index) in dynamic.data" :key="index">
          <h3 class="year">{{item.date[0]}}</h3>
          <div class="time-address">
            <div class="time">{{item.date[2]}}<span class="month">/{{item.date[1]}}月</span></div>
            <div class="address" v-if="item.area">{{item.area}}</div>
          </div>
          <div class="dynamic-content">
            <div class="text">{{item.introduction}}</div>
            <div class="pics" v-if="item.images && item.images.length !== 0">
              <ul class="pics-list">
                <li class="pic"
                    v-for="(img, indexImg) in item.images" :key="indexImg"
                    :class="{'is-one': item.images.length === 1}">
                  <img v-if="item.images.length !== 1" :src="img" alt="" @load="onRefresh" @click="previewImage(item.images_big, indexImg)">
                  <img v-else :src="item.images_big[0]" alt="" @load="onRefresh" @click="previewImage(item.images_big, indexImg)">
                </li>
              </ul>
            </div>
            <div class="tag-like">
              <ul class="tag-list">
                <li class="tag" v-for="(tag, indexTag) in item.tags" :key="indexTag">{{tag.name}}</li>
                <li class="tag delete" v-if="isMaster" @click="handleDelShow(item.id, index)">删除</li>
              </ul>
              <div class="give-like" :class="{'is-active': item.like_status}" @click="handleLike(item)">
                <span class="icon icon-like"></span>
                <span class="number" v-if="item.like_num">{{item.like_num}}</span>
              </div>
            </div>
          </div>
        </li>
      </ul>
    <fine-art-empty class="dynamit-empty" v-else>
      <div>TA暂时没有动态哦～～</div>
    </fine-art-empty>
    </cube-scroll>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
    <!--删除确认-->
    <div v-transfer-dom>
      <confirm v-model="delModal"
               confirm-text="删除"
               cancel-text="取消"
               @on-confirm="handleDel()">
        <p>确定删除吗？</p>
      </confirm>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtEmpty, FineArtScroller, ResourceHead, FineArtLoginTip } from 'components'
import api from 'modules/resources/api'
import * as MSG from 'assets/data/message.js'
import { Scroll } from 'cube-ui'
export default {
  name: `${COMPONENT_PREFIX}Dynamic`,
  data () {
    return {
      dynamic: {
        data: [],
        current_page: 1,
        has_next: false
      },
      loginTipModal: false,
      delModal: false,
      // 要删除的动态id
      delId: {}
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-dynamic`
    },
    hasData () {
      return this.dynamic.data.length > 0
    },
    isLogin () {
      return this.$store.state.isLogin
    },
    isMaster () {
      return this.$store.state.resource.resourceDetail.is_master
    },
    scrollOptions () {
      if (this.hasData) {
        return {
          pullDownRefresh: {
            threshold: 60,
            txt: '加载成功'
          },
          pullUpLoad: {
            threshold: 30,
            txt: {
              more: '加载完成',
              noMore: '-- END --'
            }
          }
        }
      } else {
        return {
          pullDownRefresh: {
            threshold: 60,
            txt: '加载成功'
          },
          pullUpLoad: false
        }
      }
    }
  },
  components: {
    FineArtEmpty,
    FineArtLoginTip,
    FineArtScroller,
    ResourceHead,
    'cube-scroll': Scroll
  },
  created () {
    this.init()
  },
  methods: {
    async init () {
      const response = await api.fetchFeedList({resource_id: this.$route.params.id})
      this._handleResponse(response)
      this.$nextTick(() => {
        this.onRefresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    onRefresh () {
      this.$refs.scroller && this.$refs.scroller.refresh()
    },
    // 处理 接口返回的数据
    _handleResponse (response, isConcat = false) {
      let arrList = []
      const date = new Date()
      let year = String(date.getFullYear())
      if (isConcat) {
        arrList = [...this.dynamic.data, ...response.data]
      } else {
        arrList = response.data
      }
      for (let key in arrList) {
        arrList[key].date = arrList[key].publish_date.split('.')
        arrList[key].like_num = Number(arrList[key].like_num)
        if (arrList[key].date[0] === year) {
          arrList[key].date[0] = ''
        } else {
          year = arrList[key].date[0]
        }
      }
      this.dynamic.data = arrList
      this.dynamic.current_page = response.current_page
      this.dynamic.has_next = response.has_next
    },
    // 加载更多
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.dynamic.has_next) return this.$refs.scroller.forceUpdate()
      // 请求加载更多
      const response = await api.fetchFeedList({resource_id: this.$route.params.id, page: this.dynamic.current_page + 1})
      this._handleResponse(response, true)
      this.$nextTick(() => {
        this.$refs.scroller.forceUpdate()
      })
    },
    // 点赞作品
    async handleLike (item) {
      if (!this.isLogin) {
        this.loginTipModal = true
        return
      }
      const response = await api.handleResourceLike({object_type: 300, object_id: item.id})
      if (response.code === 200) {
        item.like_status = !item.like_status
        if (item.like_status) {
          item.like_num += 1
        } else {
          item.like_num -= 1
        }
        const MESSAGE_TEXT = !item.like_status ? 'RESOURCE_PRODUCTION_CANCEL_LIKE_SUCCESS' : 'RESOURCE_PRODUCTION_LIKE_SUCCESS'
        this.$store.commit('ADD_MESSAGE', {msg: MSG[MESSAGE_TEXT], type: 'success'})
      }
    },
    handleDelShow (id, index) {
      this.delModal = true
      this.delId.id = id
      this.delId.index = index
    },
    async handleDel () {
      const response = await api.handleFeedDel({id: this.delId.id})
      if (response.code === 200) {
        this.dynamic.data.splice(this.delId.index, 1)
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DELETE_SUCCESS'], type: 'success'})
      }
    },
    // 预览图片
    previewImage (images, index) {
      this.$wx.previewImage(
        {
          current: images[index], // 当前显示图片的http链接
          urls: images // 需要预览的图片http链接列表
        }
      )
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-dynamic
  fixed: left top 94px
  bottom: 0
  width: 100%
  color: $black2
  font-family: PingFangSC-Regular
  .cube-pullup-wrapper
    .before-trigger
      font-size: 26px
      color: $grey
  .cube-pulldown-wrapper
    .after-trigger
      .cube-pulldown-loaded
        font-size: 26px
        color: $grey
  .dynamic-list
    padding-top: 90px
    .dynamic
      display: flex
      flex-wrap: wrap
      padding: 40px 28px 40px 28px
      .year
        width: 100%
        color: $black1
        font-size: 44px
        font-weight: 500
        line-height: 62px
        margin-bottom: 18px
        &:empty
          display: none
      .time-address
        width: 136px
        .time
          margin-bottom: 10px
          font-weight: 500
          font-size: 40px
          line-height: 56px
          color: $black1
          .month
            font-size: 24px
            color: $black1
        .address
          padding-left: 37px
          font-size: 22px
          line-height: 30px
          color: $black1
          background: url('../../../assets/imgs/resource/icon-address@2x.png') 0 5px no-repeat
          background-size: auto 20px
      .dynamic-content
        width: 554px
        .text
          margin-bottom: 30px
          font-size: 28px
          line-height: 40px
          color: $black1
        .pics
          overflow: hidden
          width: 100%
          margin-bottom: 20px
          .pics-list
            display: flex
            flex-wrap: wrap
            margin-right: -10px
            .pic
              width: 178px
              height: 178px
              margin: 0 10px 10px 0
              border-radius: 10px
              &>img
                display: block
                width: 100%
                height: 100%
                border-radius: 10px
              &.is-one
                width: 100%
                height: auto
                &>img
                  display: block
                  width: 100%
                  height: auto
                  border-radius: 10px

        .tag-like
          display: flex
          justify-content: space-between
          .tag-list
            display: flex
            .tag
              height: 38px
              margin-right: 10px
              padding: 0 14px
              font-size: 20px
              color: $grey3
              line-height: 38px
              background-color: $grey5
              border-radius: 6px
              &.delete
                color: $violet
                font-size: 22px
                background-color: transparent
          .give-like
            display: flex
            height: 40px
            margin-right: 10px
            .number
              color: $grey2
              font-size: 22px
              line-height: 30px
              margin-top: -10px
              &:empty
                display: none
            .icon
              display: inline-block
              width: 40px
              height: 40px
              margin-right: 6px
              &.icon-like
                background: url('../../../assets/imgs/resource/icon-give-like@2x.png') center center no-repeat
                background-size: 40px auto
            &.is-active
              .number
                color: $orange
              .icon-like
                background: url('../../../assets/imgs/resource/icon-give-like-orange@2x.png') center center no-repeat
                background-size: 40px auto
  .dynamit-empty
    padding-top: 170px
</style>
