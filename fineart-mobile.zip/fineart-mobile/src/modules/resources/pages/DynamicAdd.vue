<template>
  <div :class="classes">
    <group class="form-box">
      <x-textarea class="detail-textarea" placeholder="这一刻的心情…" v-model="dynamic.introduction"></x-textarea>
      <div class="upload-picture-wrap">
        <ul class="show-pic">
          <li class="pic" v-for="(img, index) in ossImageThumb" :key="index">
            <img :src="img" alt="">
            <i class="icon fy-icon-off" @click="deleteImage(index)"></i>
          </li>
          <li class="pic upload" v-show="ossImageThumb.length < 9">
            <fine-art-upload :width="214" :height="214"
                             :max-size="ossImage.max_size"
                             :data="ossImage.data"
                             :action="ossImage.host"
                             :format="ossImage.format"
                             :accept="ossImage.accept"
                             :beforeUpload="beforeUploadImage"
                             :on-success="successImage">
              <div class="upload-box"></div>
            </fine-art-upload>
          </li>
        </ul>
      </div>
      <ul class="add-tags">
        <li class="tag icon-tag-origin" v-for="(item, index) in tagList" :key="index">{{item.tag}}</li>
        <li class="tag icon-tag" @click="chooseTag">添加标签</li>
      </ul>
      <ul class="add-address">
        <li class="address" :class="[Object.values(address).length === 0 ? 'icon-address' : 'icon-address-orange']" @click="chooseAddress">{{addressText}}</li>
      </ul>
      <ul class="choose-home" v-if="!$route.params.id">
        <li class="choose" :class="[Object.values(home).length === 0 ? 'icon-release' : 'icon-release-orange']" @click="isShowHome = true">{{homeText}}</li>
      </ul>
      <x-button type="primary" class="save-btn" @click.native="releaseDynamic">发布</x-button>
    </group>
    <div v-transfer-dom>
      <dynamic-tag v-model="isShowTag" @choose="getTag"></dynamic-tag>
    </div>
    <div v-transfer-dom>
      <resource-position v-model="isShowPosition" @choose="getAddress"></resource-position>
    </div>
    <div v-transfer-dom>
      <resource-choose-home v-if="!$route.params.id" v-model="isShowHome" @choose="getHome"></resource-choose-home>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import { Popup } from 'vux'
import api from 'modules/resources/api'
import { DynamicTag, FineArtUpload, ResourcePosition, ResourceChooseHome } from 'components'
import * as MSG from '@/assets/data/message.js'
import { findValue, getArea } from '@/common/js/loadScript.js'

export default {
  name: 'ResourceAddProduction',
  components: {
    Popup,
    FineArtUpload,
    DynamicTag,
    ResourcePosition,
    ResourceChooseHome
  },
  data () {
    return {
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      ossImageThumb: [],
      isShowTag: false,
      isShowPosition: false,
      isShowHome: false,
      tagList: [],
      address: {},
      home: {},
      dynamic: {
        resource_id: this.$route.params.id,
        introduction: '',
        lng: '',
        lat: '',
        address: '',
        sys_area_id: '',
        tags: [],
        images: []
      },
      dynamicRule: {
        introduction: [
          { required: true, message: '请填写动态详情' }
        ],
        resource_id: [
          { required: true, message: '请选择要发布的主页' }
        ]
      }
    }
  },
  computed: {
    addressText () {
      return this.address && this.address.name ? this.address.name : '添加位置'
    },
    homeText () {
      return this.home.name ? this.home.name : '发布到...'
    },
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-dynamic-add`
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '发布动态')
  },
  methods: {
    deleteImage (index) {
      this.ossImageThumb.splice(index, 1)
      this.dynamic.images.splice(index, 1)
    },
    // 图片上传之前
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'feed_image', this.ossImage)
    },
    // 图片上传成功
    successImage (res) {
      this.ossImageThumb.push(res.results.file_url_cdn)
      this.dynamic.images.push(res.results.file_url)
    },
    chooseTag () {
      this.isShowTag = !this.isShowTag
    },
    chooseAddress () {
      this.isShowPosition = !this.isShowPosition
    },
    getTag (tag) {
      this.tagList = tag
      this.dynamic.tags = this.tagList.map(item => item.id)
      if (this.dynamic.tags.length === 0) {
        this.dynamic.tags[0] = 0
      }
    },
    async getAddress (value) {
      this.address = value

      if (Object.keys(value).length === 0) {
        this.dynamic.lng = ''
        this.dynamic.lat = ''
        this.dynamic.address = ''
        this.dynamic.sys_area_id = ''
        return
      }
      this.dynamic.lng = value.location.lng
      this.dynamic.lat = value.location.lat
      this.dynamic.address = value.name
      const areaList = await getArea()
      const areaId = findValue(areaList, value.city)
      this.dynamic.sys_area_id = areaId[areaId.length - 1]
    },
    async releaseDynamic () {
      const rules = await validate(this.dynamic, this.dynamicRule)
      if (!rules) return
      const response = await api.handleFeedAdd(this.dynamic)
      const vm = this
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', {
          msg: MSG['RESOURCE_RELEASE_SUCCESS'],
          type: 'success',
          cb () {
            const mode = vm.$route.params.mode || vm.home.mode
            const id = vm.$route.params.id || vm.home.id
            vm.goToDetail(id, mode)
          }
        })
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: response.msg})
      }
    },
    getHome (item) {
      this.home = item
      this.dynamic.resource_id = item.id
    },
    // 前往主页详情
    goToDetail (id, mode) {
      let page = ''
      switch (mode) {
      case '100':
        page = `/person-home/${id}/dynamic`
        break
      case '200':
        page = `/company-home/${id}/dynamic`
        break
      case '300':
        page = `/supplier-home/${id}/dynamic`
        break
      case '400':
        page = `/brand-home/${id}/dynamic`
        break
      case '500':
        page = `/decorator-home/${id}/dynamic`
        break
      }
      this.$router.push({path: page})
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-dynamic-add
  color: $black1
  .form-box
    padding: 0 30px 30px 30px
    .weui-cells
      margin-top: 0
      &.vux-no-group-title
        margin-top: 0
      .weui-cell
        padding: 0
        height: 100px
        .weui-label
          color: $black2
        &.detail-textarea:after
          display: none !important
        &.vux-x-textarea
          height: 255px
          padding: 30px 0
          .weui-cell__bd
            height: 100%
            .weui-textarea-counter
              display: none
            .weui-textarea
              height: 100%
    .upload-picture-wrap
      overflow: hidden
      margin-bottom: 16px
      .show-pic
        display: flex
        flex-flow: wrap
        margin-right: -24px
        .pic
          overflow: hidden
          position: relative
          width: 214px
          height: 214px
          margin-right: 24px
          margin-bottom: 26px
          border-radius: 6px
          &>img
            absolute: left 50% top 50%
            width: 100%
            height: auto
            border-radius: 6px
            transform: translate(-50%, -50%)
          .icon
            absolute: right top
            width: 40px
            height: 40px
            text-align: center
            color: $white
            font-size: 18px
            line-height: 40px
            background-color: rgba(67, 67, 67, 0.7)
            border-radius: 0 6px 0 6px
      .upload-box
        width: 214px
        height: 214px
        background: $greyF9 url('../../../assets/imgs/mall/icon-tgupload.png') center center no-repeat
        background-size: 122px auto
        border-radius: 6px
    .add-tags
      display: flex
      flex-wrap: wrap
      margin-bottom: 30px
      .tag
        padding: 0 16px 0 46px
        margin: 0 10px 10px 0
        height: 46px
        line-height: 46px
        color: $grey3
        font-size: 22px
        background-color: $grey5
        border-radius: 25px
        &.icon-tag
          background-image: url('../../../assets/imgs/resource/icon-tag@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 20px
        &.icon-tag-origin
          color: $black2
          background-image: url('../../../assets/imgs/resource/icon-tag-orange@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 20px
    .add-address
      display: flex
      margin-bottom: 30px
      .address
        padding: 0 16px 0 46px
        height: 46px
        line-height: 46px
        color: $grey3
        font-size: 22px
        background-color: $grey5
        border-radius: 25px
        &.icon-address
          background-image: url('../../../assets/imgs/resource/icon-address-grey@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 22px
        &.icon-address-orange
          color: $black2
          background-image: url('../../../assets/imgs/resource/icon-address-orange@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 22px
    .choose-home
      display: flex
      .choose
        padding: 0 16px 0 46px
        height: 46px
        line-height: 46px
        color: $grey3
        font-size: 22px
        background-color: $grey5
        border-radius: 25px
        &.icon-release
          background-image: url('../../../assets/imgs/resource/icon-release-grey.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 30px
        &.icon-release-orange
          color: $black2
          background-image: url('../../../assets/imgs/resource/icon-release-orange.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 30px
  .save-btn
    margin-top: 30px
</style>
