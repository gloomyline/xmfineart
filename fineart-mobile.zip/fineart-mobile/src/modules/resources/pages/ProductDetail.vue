<template>
  <div :class="classes">
    <!-- 文章信息 -->
    <div class="article-info">
      <h1 class="article-title">{{ productDetail.title }}</h1>
      <div class="information">
        <router-link :to="`/brand-home/${productDetail.resource_id}`" class="thumbnail">
          <img :src="productDetail.resource_logo_cdn" :alt="productDetail.title">
        </router-link>
        <div class="info-wrap">
          <h3 class="name">{{ productDetail.resource_name }}</h3>
          <p class="subtitle">{{ productDetail.resource_subtitle }}</p>
        </div>
        <div class="follow-box" v-if="false">
          <x-button @click.native="handleFollow" :class="{'is-active': productDetail.collection}" >
            <span v-if="productDetail.collection"><span class="fy-icon-sel-follow"></span>已关注</span>
            <span v-else><span class="fy-icon-nor-follow"></span>关注TA</span>
          </x-button>
        </div>
      </div>
    </div>
    <!-- 文章内容 -->
    <div class="introduction" v-html="productDetail.introduction"></div>
    <div class="product-img">
      <img :src="item" v-for="(item, index) in productDetail.image_urls_cdn" :key="index">
    </div>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, COLLECT_MESSAGE_DURATION } from '@/assets/data/constants'
import { FineArtLoginTip } from '@/components'
import { hyphenCase } from '@/common/js/utils'
import { mapMutations, mapState } from 'vuex'
import api from 'modules/resources/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}ProductDetail`,
  props: {
    id: {
      type: String,
      required: true
    }
  },
  data () {
    return {
      productDetail: {},
      apiProcessing: false, // API请求处理中
      loginTipModal: false
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-product-detail`
    },
    ...mapState(['isLogin'])
  },
  created () {
    this.modifyPageName('产品详情')
    this.initPage()
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    async initPage () {
      this.productDetail = await api.fetchProductDetail(this.id)
      const vm = this
      this.$wx.updateShareData('resource', {
        title: vm.productDetail.title,
        desc: vm.productDetail.introduction
      })
    },
    async handleFollow () {
      // 判断是否登录
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }

      if (this.apiProcessing) {
        return false
      }
      this.apiProcessing = true
      this.result = await api.updateCollectionStatus(this.productDetail.resource_id)
      if (this.result.code === 200) {
        this.productDetail.collection = !this.productDetail.collection
        // 提示关注成功或取消关注成功
        if (this.productDetail.collection) {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_COLLECTION_SUCCESS'], type: 'success' })
        } else {
          this.$store.commit('ADD_MESSAGE', { msg: MSG['GLOBAL_CANCEL_COLLECTION_SUCCESS'], type: 'success' })
        }
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    }
  },
  components: {
    FineArtLoginTip
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-product-detail
  padding: 30px
  color: $black1
  .article-title
    margin-bottom: 30px
    font-size: 36px
    font-weight: 600
  .information
    display: flex
    margin-bottom: 40px
    .thumbnail
      width: 80px
      height: 80px
      margin-right: 24px
      box-shadow: 2px 4px 12px rgba(0, 0, 0, 0.12)
      &>img
        display: block
        width: 100%
        height: 100%
    .info-wrap
      width: 450px
      .name
        margin-bottom: 20px
        color: $black2
        font-size: 26px
      .subtitle
        color: $grey3
        font-size: 24px
    .follow-box
      display: flex
      flex-direction: column
      justify-content: space-around
      button
        font-size: 16px
        color: $black1
        width: 160px
        height: 60px
      .is-active
        color: $orange
        background:#FDF2DA
        border: 1px solid $orange
  .introduction
    font-size: 28px
    margin-bottom: 20px
    line-height: 52px
    color: $black2
    img
      max-width: 100%
  .product-img
    font-size: 28px
    img
      max-width: 100%
      margin-bottom: 20px
</style>
