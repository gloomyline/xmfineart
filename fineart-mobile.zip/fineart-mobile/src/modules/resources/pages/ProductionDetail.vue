<template>
  <div :class="classes">
    <!-- 作品详情 -->
    <div class="production-detail-wrap">
      <p class="production-title">{{ productionDetail.title }}</p>
      <div @click="goToDetail(productionDetail.resource_id, productionDetail.resource_mode)" class="resource-info-wrap">
        <div class="avatar-wrap">
          <img :src="productionDetail.resource_logo"/>
        </div>
        <div class="resource-info">
          <p class="name-area">
            <span class="name">{{ productionDetail.resource_name }}</span>
            <span class="area" v-if="areaString">
              <i class="fy-icon-grlocation"></i>
              {{ areaString }}
            </span>
          </p>
          <p class="created-at">{{ productionDetail.created_at }}</p>
        </div>
      </div>
      <div class="production-category-list">
        <span class="category-item"
              :key="index"
              v-for="(item, index) in categoryList">{{ item.name }}</span>
      </div>
      <div class="production-introduction" v-html="productionDetail.introduction"></div>
      <div class="production-image-list">
        <div class="img-wrap"  v-for="(item, index) in productionDetail.image_list" :key="index">
          <img :src="item.url_original_cdn"/>
        </div>
      </div>
    </div>
    <!-- 底部控制栏 -->
    <ul class="bottom-bar fy-1px-t">
      <li class="collect" @click="handleCollectStatus" :class="{'is-active': productionDetail.collection_status}">
        <span class="fy-icon-sel-collection" v-if="productionDetail.collection_status"></span>
        <span class="fy-icon-star-rough" v-else></span>
        {{ productionDetail.collect_num }}
      </li>
      <li class="like" @click="handleLikeStatus" :class="{'is-active': productionDetail.like_status}">
        <span class="fy-icon-like"></span>
        {{ productionDetail.like_num }}
      </li>
    </ul>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, COLLECT_MESSAGE_DURATION } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtLoginTip } from '@/components'
import api from 'modules/resources/api/index.js'
import * as MSG from 'assets/data/message.js'

export default {
  name: `${COMPONENT_PREFIX}PageProductionDetail`,
  data () {
    return {
      productionDetail: {
        like_num: 0,
        collect_num: 0,
        like_status: false,
        collection_status: false
      },
      apiProcessing: false, // API请求处理中
      loginTipModal: false
    }
  },
  props: ['portfolio_id'],
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-production-detail`
    },
    isLogin () {
      return this.$store.state.isLogin
    },
    // 作品分类
    categoryList () {
      if (this.productionDetail.category_list) {
        return this.productionDetail.category_list.filter(item => item.name)
      }
    },
    // 作品所属资源所在地
    areaString () {
      if (this.productionDetail.area_line) {
        return Object.values(this.productionDetail.area_line).join('')
      }
      return false
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '作品详情')
    this.initPage()
  },
  methods: {
    async initPage () {
      this.productionDetail = await api.fetchProductionDetail({ portfolio_id: this.portfolio_id })
      // TODO： 微信分享
    },
    // 前往主页详情
    goToDetail (id, mode) {
      let page = ''
      switch (mode) {
      case '100':
        page = `/person-home/${id}`
        break
      case '200':
        page = `/company-home/${id}`
        break
      case '300':
        page = `/supplier-home/${id}`
        break
      case '400':
        page = `/brand-home/${id}`
        break
      case '500':
        page = `/decorator-home/${id}`
        break
      }
      this.$router.push({path: page})
    },
    // 点赞
    async handleLikeStatus () {
      // 判断是否登录
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }
      if (this.apiProcessing) return false

      this.apiProcessing = true
      const result = await api.handleResourceLike({ object_type: '200', object_id: this.portfolio_id })

      if (result.code === 200) {
        this.productionDetail.like_status = !this.productionDetail.like_status
        if (this.productionDetail.like_status) {
          this.productionDetail.like_num = Number(this.productionDetail.like_num) + 1
        } else {
          this.productionDetail.like_num = Number(this.productionDetail.like_num) - 1
        }
        const MESSAGE_TEXT = !this.productionDetail.like_status ? 'RESOURCE_PRODUCTION_CANCEL_LIKE_SUCCESS' : 'RESOURCE_PRODUCTION_LIKE_SUCCESS'
        this.$store.commit('ADD_MESSAGE', {msg: MSG[MESSAGE_TEXT], type: 'success'})
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    },
    // 收藏
    async handleCollectStatus () {
      // 判断是否登录
      if (!this.isLogin) {
        this.loginTipModal = true
        return false
      }

      if (this.apiProcessing) return false

      this.apiProcessing = true

      const result = await api.handleResourceCollect({ object_type: '200', object_id: this.portfolio_id })
      if (result.code === 200) {
        this.productionDetail.collection_status = !this.productionDetail.collection_status
        if (this.productionDetail.collection_status) {
          this.productionDetail.collect_num = Number(this.productionDetail.collect_num) + 1
        } else {
          this.productionDetail.collect_num = Number(this.productionDetail.collect_num) - 1
        }
        const MESSAGE_TEXT = !this.productionDetail.collection_status ? 'RESOURCE_PRODUCTION_CANCEL_COLLECT_SUCCESS' : 'RESOURCE_PRODUCTION_COLLECT_SUCCESS'
        this.$store.commit('ADD_MESSAGE', {msg: MSG[MESSAGE_TEXT], type: 'success'})
        setTimeout(() => {
          this.apiProcessing = false
        }, COLLECT_MESSAGE_DURATION)
      }
    }
  },
  components: {
    FineArtLoginTip
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-production-detail
  .production-detail-wrap
    padding-bottom: 88px
    .production-title
      padding: 30px 30px 0 30px
      font-size: 36px
      line-height: 50px
      font-weight: 600
    .resource-info-wrap
      padding: 30px 0
      margin: 0 30px
      display: flex
      border-bottom: 1px solid $grey
      .avatar-wrap
        width: 70px
        height: 70px
        background: $grey4
        border-radius: 50%
        overflow: hidden
        &>img
          display: block
          width: 70px
          height: 70px
          border-radius: 50%
      .resource-info
        margin-left: 20px
        display: flex
        height: 70px
        flex-direction: column
        justify-content: space-around
        .name-area
          color: $black1
          display: flex
          align-items: center
          .name
            font-size: 28px
          .area
            display: flex
            font-size: 22px
            margin-left: 20px
            .fy-icon-grlocation
              background: url("../../../assets/imgs/house/icon-grlocation@2x.png")
              inline-icon(16px,16px)
              margin-right: 10px
        .created-at
          color: $grey3
          font-size: 24px
    .production-category-list
      padding: 30px 30px 0 30px
      display: flex
      .category-item
        font-size: 20px
        line-height: 28px
        padding: 5px 15px
        margin-right: 10px
        background: $greyF1
        border-radius: 4px
    .production-introduction
      padding: 20px 30px
      font-size: 28px
      line-height: 50px
    .production-image-list
      display: flex
      flex-direction: column
      .img-wrap
        width: 100%
        font-size: 0
        margin-bottom: 30px
        background: $grey4
        img
          width: 100%
  .bottom-bar
    fixed: bottom left
    padding: 25px 0
    width: 750px
    height: 88px
    display: flex
    background: $white
    .collect, .like
      width: 375px
      display: flex
      color: $grey2
      font-size: 28px
      align-items: center
      justify-content: center
      &.is-active
        color: $orange
        .fy-icon-like
          background-image: url("../../../assets/imgs/house/icon-grthumbssel@2x.png")
    .collect
      border-right: 1px solid $grey
    .fy-icon-sel-collection
      color: $orange
    .fy-icon-sel-collection,.fy-icon-star-rough
      font-size: 36px
      margin-right: 10px
    .fy-icon-star-rough:before
      color: $grey2
    .fy-icon-like
      background-image: url("../../../assets/imgs/house/icon-grthumbs@2x.png")
      inline-icon(36px,36px)
      margin-right: 10px
</style>
