<template>
  <div :class="classes">
    <cube-scroll
      ref="scroller"
      :options="scrollOptions"
      :data="production.data"
      @pulling-down = "init"
      @pulling-up="loadMore"
      class="production-scroll">
      <resource-head :id="$route.params.id"></resource-head>
      <div class="page-wrap">
        <!--发布作品-->
        <div class="release-group" v-if="isMaster">
          <img :src="logoUrl" alt="" class="logo">
          <x-button type="primary" class="release-btn" :link="`/production-add/${$route.params.id}/${mode}`"><span class="icon-release"></span>发布作品</x-button>
        </div>
        <ul class="product-list" v-if="hasData">
          <li  class="product-item" :class="{'fy-1px-b': index !== production.data.length - 1}"
              v-for="(item, index) in production.data" :key="index">
            <div class="product-detail">
              <div class="product-logo">
                <img :src="item.resource_logo" :alt="item.resource_name">
              </div>
              <div class="detail">
                <div class="text">
                  <h3 class="name" :class="{'is-edit': isMaster}">{{item.resource_name}}</h3>
                  <span class="area">{{item.area_line | areaFormatter}}</span>
                </div>
                <h4 class="time">{{item.created_at}}</h4>
              </div>
              <!-- 编辑/删除 -->
              <x-button type="default" plain class="edit-btn" v-if="isMaster" @click.native="operateProduction(item.id, index)">
                <span></span><span></span><span></span>
              </x-button>
            </div>
            <router-link :to="`/production-detail/${item.id}`" tag="div" class="product-pics">
              <swiper v-model="item.currentSwiperIndex"
                      class="product-pics-swiper"
                      dots-class="product-pics-swiper-dots"
                      dots-position="center"
                      :show-dots="false"
                      :aspect-ratio="750/750">
                <swiper-item
                  v-for="(img, imgIndex) in item.image_list"
                  :key="imgIndex"
                  class="product-pics-swiper-item">
                  <img :src="img.url_original_cdn" width="100%" @load="onRefresh">
                </swiper-item>
              </swiper>
              <div class="dots" v-if="item.image_list.length !== 1">{{item.currentSwiperIndex + 1}}/{{item.image_list.length}}</div>
            </router-link>
            <div class="product-info">
              <router-link :to="`/production-detail/${item.id}`" tag="div" class="info-wrap">
                <h3 class="product-info-name">{{item.title}}</h3>
                <div class="product-info-intro" v-if="item.introduction">{{item.introduction | labelFormatter(46)}}</div>
              </router-link>
              <ul class="product-info-tags-list" v-if="item.category_list[0].id && item.category_list.length !== 0">
                <li class="tag"
                    v-for="(tag, index) in item.category_list"
                    :key="index" v-if="tag.id">{{tag.name}}</li>
              </ul>
              <div class="attention-give-like">
                <div class="attention" :class="{'is-active': item.collection_status}" @click="handleCollect(item)">
                  <span class="icon icon-attention"></span>
                  <span class="number" v-if="Number(item.collect_num)">{{item.collect_num}}</span>
                </div>
                <div class="give-like" :class="{'is-active': item.like_status}" @click="handleLike(item)">
                  <span class="icon icon-like"></span>
                  <span class="number" v-if="Number(item.like_num)">{{item.like_num}}</span>
                </div>
              </div>
            </div>
          </li>
        </ul>
        <fine-art-empty v-else></fine-art-empty>
      </div>
    </cube-scroll>
    <!--登录提醒-->
    <div v-transfer-dom>
      <fine-art-login-tip v-model="loginTipModal"></fine-art-login-tip>
    </div>
    <div v-transfer-dom>
      <resource-operate v-model="isOperate" @delete="handleDel" @edit="handleEdit"></resource-operate>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import * as MSG from 'assets/data/message.js'
import { FineArtEmpty, FineArtScroller, ResourceOperate, ResourceHead, FineArtLoginTip } from 'components'
import api from 'modules/resources/api'
import { Scroll } from 'cube-ui'
export default {
  name: `${COMPONENT_PREFIX}Production`,
  data () {
    return {
      isOperate: false,
      isShowed: false,
      loginTipModal: false,
      production: {
        data: [],
        has_next: false,
        current_page: 1
      },
      delId: {}
    }
  },
  components: {
    FineArtEmpty,
    FineArtScroller,
    ResourceOperate,
    ResourceHead,
    FineArtLoginTip,
    'cube-scroll': Scroll
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-production`
    },
    logoUrl () {
      return this.$store.state.resource.resourceDetail.logo_cdn
    },
    isMaster () {
      return this.$store.state.resource.resourceDetail.is_master
    },
    mode () {
      return this.$store.state.resource.resourceDetail.mode
    },
    isLogin () {
      return this.$store.state.isLogin
    },
    hasData () {
      return this.production.data.length > 0
    },
    scrollOptions () {
      if (this.hasData) {
        return {
          pullDownRefresh: {
            threshold: 60,
            txt: '加载成功'
          },
          pullUpLoad: {
            threshold: 30,
            txt: {
              more: '加载完成',
              noMore: '-- END --'
            }
          }
        }
      } else {
        return {
          pullDownRefresh: {
            threshold: 60,
            txt: '加载成功'
          },
          pullUpLoad: false
        }
      }
    }
  },
  created () {
    this.init()
  },
  methods: {
    async init () {
      const res = await api.fetchProductionList({
        resource_id: this.$route.params.id
      })
      const arr = this.resetArray(res.data)
      this.production.data = [...arr]
      this.production.current_page = res.current_page
      this.production.has_next = res.has_next
      this.$nextTick(() => {
        this.onRefresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    onRefresh () {
      this.$refs.scroller && this.$refs.scroller.refresh()
    },
    resetArray (arr) {
      for (let i = 0, max = arr.length; i < max; i++) {
        arr[i].currentSwiperIndex = 0
      }
      return arr
    },
    // 关注作品
    async handleCollect (item) {
      if (!this.isLogin) {
        this.loginTipModal = true
        return
      }
      const response = await api.handleResourceCollect({object_type: 200, object_id: item.id})
      if (response.code === 200) {
        item.collection_status = !item.collection_status
        item.collect_num = Number(item.collect_num)
        if (item.collection_status) {
          item.collect_num += 1
        } else {
          item.collect_num -= 1
        }
        const MESSAGE_TEXT = !item.collection_status ? 'RESOURCE_PRODUCTION_CANCEL_COLLECT_SUCCESS' : 'RESOURCE_PRODUCTION_COLLECT_SUCCESS'
        this.$store.commit('ADD_MESSAGE', {msg: MSG[MESSAGE_TEXT], type: 'success'})
      }
    },
    // 点赞作品
    async handleLike (item) {
      if (!this.isLogin) {
        this.loginTipModal = true
        return
      }
      const response = await api.handleResourceLike({object_type: 200, object_id: item.id})
      if (response.code === 200) {
        item.like_status = !item.like_status
        item.like_num = Number(item.like_num)
        if (item.like_status) {
          item.like_num += 1
        } else {
          item.like_num -= 1
        }
        const MESSAGE_TEXT = !item.like_status ? 'RESOURCE_PRODUCTION_CANCEL_LIKE_SUCCESS' : 'RESOURCE_PRODUCTION_LIKE_SUCCESS'
        this.$store.commit('ADD_MESSAGE', {msg: MSG[MESSAGE_TEXT], type: 'success'})
      }
    },
    // 作品 加载更多
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.production.has_next) {
        return this.$refs.scroller && this.$refs.scroller.forceUpdate()
      }
      const response = await api.fetchProductionList({ resource_id: this.$route.params.id, page: this.production.current_page + 1 })
      const arr = this.resetArray(response.data)
      this.production.data = [...this.production.data, ...arr]
      this.production.current_page = response.current_page
      this.production.has_next = response.has_next
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    operateProduction (id, index) {
      this.isOperate = true
      this.delId.id = id
      this.delId.index = index
    },
    // 编辑作品
    handleEdit () {
      this.$router.push({path: `/production-add/${this.$route.params.id}/${this.mode}/${this.delId.id}`})
    },
    // 删除作品
    async handleDel (cb) {
      const response = await api.fetchPortfolioDel({portfolio_id: this.delId.id})
      if (response.code === 200) {
        cb()
        this.production.data.splice(this.delId.index, 1)
        this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DELETE_SUCCESS'], type: 'success'})
      }
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    },
    areaFormatter (area) {
      if (Object.values(area).length === 0) return ''
      return Object.values(area).pop()
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-production
  width: 100%
  color: $black1
  font-family: PingFangSC-Regular
  .production-scroll
    fixed: left top 94px
    right: 0
    bottom: 0
  .page-wrap
    padding-top: 90px
  .cube-pullup-wrapper
    padding-bottom: 94px
    .before-trigger
      font-size: 26px
      color: $grey
  .cube-pulldown-wrapper
    .after-trigger
      .cube-pulldown-loaded
        font-size: 26px
        color: $grey
  .product-list
    width: 100%
    .product-item
      .product-detail
        display: flex
        padding: 30px
        .product-logo
          width: 70px
          height: 70px
          margin-right: 20px
          border-radius: 50%
          &>img
            width: 70px
            height: 70px
            border-radius: 50%
        .detail
          flex: 1 0 auto
          .text
            display: flex
            align-items: center
            .name
              margin-right: 20px
              max-width: 480px
              color: $black1
              font-size: 28px
              line-height: 40px
              {ellipse}
              &.is-edit
                max-width: 392px
            .area
              padding-left: 30px
              font-size: 22px
              color: $black1
              background: url('../../../assets/imgs/resource/icon-address@2x.png') 0 center no-repeat
              background-size: auto 22px
          .time
            color: $grey3
            font-size: 24px
        .edit-btn
          display: flex
          justify-content: space-between
          align-items: center
          width: 32px
          height: 70px
          padding: 0
          margin: 0
          border: none
          &>span
            display: inline-block
            width: 6px
            height: 6px
            background-color: $black2
            border-radius: 50%
      .product-pics
        position: relative
        width: 100%
        margin-bottom: 30px
        background-color: $grey5
        .product-pics-swiper-item img
          absolute: left 50% top 50%
          transform: translate(-50%, -50%)
        .dots
          absolute: right 20px bottom 20px
          width: 80px
          font-size: 24px
          text-align: center
          color: $white
          background-color: rgba(51, 51, 51, 0.3)
          border-radius: 19px
          -webkit-transform: translateZ(0)
          text-middle: 5px
      .product-info
        padding: 0 30px 40px 30px
        .info-wrap
          display: block
        &-name
          margin-bottom: 14px
          font-size: 36px
          line-height: 40px
          color: $black1
          font-weight: 600
          {ellipse}
        &-intro
          margin-bottom: 20px
          font-size: 28px
          line-height: 40px
          color: $black1
        &-tags-list
          display: flex
          flex-wrap: wrap
          margin-bottom: 20px
          .tag
            padding: 5px 14px
            margin-right: 10px
            color: $grey3
            font-size: 20px
            background-color: $greyF1
            border-radius: 4px
      .attention-give-like
        display: flex
        justify-content: flex-end
        padding-right: 10px
        .attention
          margin-right: 66px
        .attention, .give-like
          display: flex
          height: 40px
        .number
          margin-top: -10px
          color: $grey2
          font-size: 22px
          line-height: 30px
          &:empty
            display: none
        .icon
          display: inline-block
          width: 40px
          height: 40px
          margin-right: 6px
          &.icon-attention
            background: url('../../../assets/imgs/resource/icon-attention@2x.png') center center no-repeat
            background-size: 40px auto
          &.icon-like
            background: url('../../../assets/imgs/resource/icon-give-like@2x.png') center center no-repeat
            background-size: 40px auto
        .is-active
          .number
            color: $orange
          .icon-attention
            background: url('../../../assets/imgs/resource/icon-attention-orange@2x.png') center center no-repeat
            background-size: 40px auto
          .icon-like
            background: url('../../../assets/imgs/resource/icon-give-like-orange@2x.png') center center no-repeat
            background-size: 40px auto
  .release-group
    display: flex
    justify-content: space-between
    align-items: center
    padding: 38px 30px 20px 30px
    .logo
      width: 70px
      height: 70px
      border-radius: 50%
    .release-btn
      width: 594px
      height: 66px
      margin: 0
      font-size: 26px
      line-height: 66px
      border-radius: 35px
      box-shadow: 0 2px 12px 0 rgba(247, 181, 44, 0.54)
      .icon-release
        display: inline-block
        width: 26px
        height: 26px
        margin-right: 16px
        vertical-align: middle
        background: url('../../../assets/imgs/resource/icon-release-edit@2x.png') center center no-repeat
        background-size: auto 26px
</style>
