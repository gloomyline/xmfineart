<template>
  <div :class="classes">
    <router-view></router-view>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'

export default {
  name: `${COMPONENT_PREFIX}HomeEdit`,
  data () {
    return {
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-person-detail`
    }
  },
  beforeDestroy () {
    this.$store.commit('resource/RESOURCE_CLEAR_DETAIL')
  }
}
</script>
