<template>
  <div :class="classes">
    <!-- 头部搜索框 -->
    <fine-art-search @search="search"
                     @filter="expandCateSideBar" ref="refSearch"></fine-art-search>
    <!-- 资源列表容器 -->
    <fine-art-scroller
      ref="scroller"
      class="resource-list-scroller"
      :list="resources.data"
      @refresh="refresh"
      @load-more="loadMore"
      :has-data="hasData"
      :has-more="resources.has_next">
      <div class="resource-list-wrap">
        <div class="resource-list">
          <div class="resource-item fy-1px-b"
               v-for="(resource, index) in resources.data"
               :key="index"
               @click="goToDetail(resource.id, resource.mode)">
            <div class="img-wrap fy-1px"><img :src="resource.logo" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ resource.name }}</p>
              <p class="subtitle">{{ resource.subtitle }}</p>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
    <!-- 右侧边栏 -->
    <fine-art-cate-side-bar ref="sidebar" @on-change="filter"
                            :menu-data="menuData" :sidebar-values="sidebarValues"
                            v-model="isCateSideBarExpanded"></fine-art-cate-side-bar>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, makeNewLink, resolveUrlQuery } from '@/common/js/utils'
import { getResourceCategory, getArea } from '@/common/js/loadScript'
import { FineArtCateSideBar, FineArtSearch, FineArtScroller } from 'components'
import api from 'modules/resources/api'
import { mapMutations } from 'vuex'

export default {
  name: `${COMPONENT_PREFIX}ResourceHome`,
  data () {
    return {
      // 右边分类菜单栏展开与否，默认不展开
      isCateSideBarExpanded: false,
      // 资源列表数据
      resources: [],
      pageConfig: {
        // 资源列表当前所加载分页
        page: 1,
        mode: '',
        // 关键词
        keyword: '',
        category_id: '',
        area_id: '',
        foreign: 0, // 是否只看国外，0：否；1：是
        order: 'default'
      },
      // 右边分类栏菜单栏列表数据
      menuData: [],
      // 路由中带有的侧边栏搜索值
      sidebarValues: {},
      // 侧边栏返回的values值
      values: {}
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-resource-home`
    },
    hasData () {
      return this.resources.total > 0
    }
  },
  created () {
    let searchParams = this.$route.query
    // 当路由里带有搜索指，初始化相关页面搜索值
    if (Object.keys(searchParams).length !== 0) {
      if (searchParams.keywords) {
        this.pageConfig.keyword = searchParams.keywords
        delete searchParams['keywords']
      }
      if (searchParams.isSelectMode) {
        this.pageConfig.mode = 400
        delete searchParams['isSelectMode']
      }
      let searchParamsObj = resolveUrlQuery(searchParams, 2)
      let pageConfigObj = {}
      for (let key in searchParamsObj) {
        if (searchParamsObj[key].indexOf('-') > -1) {
          const value = searchParamsObj[key].split('-')
          if (key === 'category_id') {
            pageConfigObj.category_id = value[1]
            pageConfigObj.mode = value[0]
          } else {
            pageConfigObj[key] = value[1]
          }
        } else {
          if (key === 'category_id') {
            pageConfigObj.mode = searchParamsObj[key]
          } else {
            pageConfigObj[key] = searchParamsObj[key]
          }
        }
      }
      this.pageConfig = {...this.pageConfig, ...pageConfigObj}
      this.sidebarValues = searchParams
    }
    this._initCateSideMenus()
    this.fetchResourceList()
    // 初始化分享链接
    const link = makeNewLink(this.pageConfig.keyword, searchParams, this.$route.path, 2)
    this.$wx.updateShareData('resource', {
      link
    })
    this.$nextTick(() => {
      this.$refs.refSearch.setSearchValue(this.pageConfig.keyword)
    })
  },
  activated () {
    this.modifyPageName('斐艺资源')
  },
  methods: {
    // 修改页面名称
    ...mapMutations({
      modifyPageName: 'MODIFY_PAGE_NAME'
    }),
    // 前往主页详情
    goToDetail (id, mode) {
      let page = ''
      switch (mode) {
      case '100':
        page = `/person-home/${id}`
        break
      case '200':
        page = `/company-home/${id}`
        break
      case '300':
        page = `/supplier-home/${id}`
        break
      case '400':
        page = `/brand-home/${id}`
        break
      case '500':
        page = `/decorator-home/${id}`
        break
      }
      this.$router.push({path: page})
    },
    // 展开右边菜单栏
    expandCateSideBar () {
      if (this.isCateSideBarExpanded) return
      this.isCateSideBarExpanded = true
      this.$nextTick(() => {
        this.$refs.sidebar.expand()
      })
    },
    // 请求初始化右边栏分类菜单
    async _initCateSideMenus () {
      // 获取到的原始分类列表
      Promise.all([getResourceCategory(), getArea()]).then(values => {
        // 资源分类
        const cates = {id: 'category_id', title: '资源类型', type: 1, content: values[0]}
        // 资源所在区域
        const areas = {id: 'area_id', title: '地区', type: 1, content: values[1]}
        // 其他地区
        const foreign = [{
          label: '只看国外',
          value: '1'
        }]
        const otherAreas = {id: 'foreign', title: '其他地区', type: 0, content: foreign}
        this.menuData = [cates, areas, otherAreas]
      })
    },
    // 搜索
    async search (keyword) {
      this.pageConfig.page = 1
      this.pageConfig.keyword = keyword
      this.sidebarValues = {}
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('resource', {
        link
      })
      await this.fetchResourceList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    // 刷新当前资源列表数据
    async refresh (cb) {
      this.pageConfig.page = 1
      this.fetchResourceList()
      cb()
    },
    // 选择完成分类菜单
    async filter (values) {
      // 重置传回至侧边栏的值为空，表示不用初始化
      this.sidebarValues = {}
      // 将values赋值给data里的values，用于用户点击查询时重新拼接url
      this.values = values
      // 拼接新的url，用于微信分享
      const link = makeNewLink(this.pageConfig.keyword, this.values, this.$route.path)
      this.$wx.updateShareData('resource', {
        link
      })
      this.pageConfig.mode = values.category_id[0] || ''
      this.pageConfig.area_id = values.area_id.length > 0 ? (values.area_id.length > 2 ? values.area_id[2] : values.area_id[0]) : ''
      this.pageConfig.category_id = values.category_id.length > 0 ? (values.category_id.length > 2 ? values.category_id[2] : '') : ''
      this.pageConfig.foreign = values.foreign[0] || '0'
      this.pageConfig.page = 1
      await this.fetchResourceList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    async fetchResourceList () {
      this.resources = await api.fetchResourceList(this.pageConfig)
    },
    // 加在更多资源列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.resources.has_next) return cb()

      this.pageConfig.page = this.resources.current_page + 1
      // 资源列表分页
      let dataList = await api.fetchResourceList(this.pageConfig)
      for (let index in dataList.data) {
        this.resources.data.push(dataList.data[index])
      }
      this.resources.current_page = dataList.current_page
      this.resources.has_next = dataList.has_next
    }
  },
  components: {
    FineArtSearch,
    FineArtScroller,
    FineArtCateSideBar
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-resource-home
  fixed: left top 94px
  width: 100%
  height: 100%
  color: $black1
  .resource-list-wrap
    overflow: hidden
    padding: 0 30px
    .resource-list
      width: 100%
      .resource-item
        display: flex
        align-items: center /* 图片块和描述块垂直居中对齐 */
        width: 100%
        height: 220px
        font-size: 0
        .img-wrap
          flex: 0 0 160px
          width: 160px
          height: 160px
          margin-right: 30px
        .desc
          flex: 1
          max-width: 500px
          font-size: 0
          .name
            line-height: 42px
            margin-bottom: 20px
            font-size: 30px
            font-weight: 500
            color: $black1
            {ellipse}
          .subtitle
            line-height: 42px
            font-size: 24px
            color: $grey3
            {ellipse}
</style>
