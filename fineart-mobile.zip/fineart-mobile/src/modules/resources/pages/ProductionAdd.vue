<template>
  <div :class="classes">
    <group class="form-box">
      <x-input
        placeholder='作品标题'
        :show-clear="false" v-model="portfolio.title"></x-input>
      <x-textarea class="detail-textarea" placeholder="作品描述" v-model="portfolio.introduction"></x-textarea>
      <div class="upload-picture-wrap">
        <ul class="show-pic">
          <li class="pic" v-for="(img, index) in ossImageThumb" :key="index">
            <img :src="img" alt="">
            <i class="icon fy-icon-off" @click="deleteImage(index)"></i>
          </li>
          <li class="pic upload" v-show="ossImageThumb.length < 9">
            <fine-art-upload :width="214" :height="214"
                             :max-size="ossImage.max_size"
                             :data="ossImage.data"
                             :action="ossImage.host"
                             :format="ossImage.format"
                             :accept="ossImage.accept"
                             :beforeUpload="beforeUploadImage"
                             :on-success="successImage">
              <div class="upload-box"></div>
            </fine-art-upload>
          </li>
        </ul>
      </div>
      <ul class="add-tags">
        <li class="tag icon-tag-origin" v-for="(tag, index) in tagList" :key="index">{{tag.label || tag.name}}</li>
        <li class="tag icon-tag" @click="chooseTag">添加标签</li>
      </ul>
      <ul class="add-address">
        <li class="address" :class="[Object.values(address).length === 0 ? 'icon-address' : 'icon-address-orange']" @click="chooseAddress">{{addressText}}</li>
      </ul>
      <x-button type="primary" class="save-btn" @click.native="releasePortfolio">发布</x-button>
    </group>
    <div v-transfer-dom>
      <resource-choose-tag v-model="isShowTag" @choose="getTag"></resource-choose-tag>
    </div>
    <div v-transfer-dom>
      <resource-position v-model="isShowPosition" @choose="getAddress"></resource-position>
    </div>
  </div>
</template>

<script>
import { Popup } from 'vux'
import api from 'modules/resources/api'
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase, validate } from '@/common/js/utils'
import * as MSG from '@/assets/data/message.js'
import { findValue, getArea } from '@/common/js/loadScript.js'
import { FineArtUpload, ResourceChooseTag, ResourcePosition } from 'components'

export default {
  name: `${COMPONENT_PREFIX}ProductionAdd`,
  components: {
    Popup,
    FineArtUpload,
    ResourceChooseTag,
    ResourcePosition
  },
  data () {
    return {
      // 上传图片参数
      ossImage: {
        format: ['jpg', 'jpeg', 'png'],
        accept: 'jpg,jpeg,png',
        max_size: 0,
        host: '',
        data: {}
      },
      ossImageThumb: [],
      isShowTag: false,
      isShowPosition: false,
      tagList: [],
      address: {},
      portfolio: {
        resource_id: this.$route.params.id,
        title: '',
        introduction: '',
        lng: '',
        lat: '',
        address: '',
        sys_area_id: '',
        category_id: '',
        image_url: []
      },
      portfolioRule: {
        title: [
          { required: true, message: '请填写作品标题' }
        ],
        introduction: [
          { required: true, message: '请填写作品描述' }
        ],
        image_url: [
          { required: true, type: 'array', min: 1, message: '请上传作品图片' },
          { type: 'array', min: 1, max: 9, message: '请上传1~9作品图片' }
        ],
        category_id: [
          { required: true, type: 'array', min: 2, message: '请选择标签' }
        ]
      }
    }
  },
  computed: {
    addressText () {
      return this.address && this.address.name ? this.address.name : '添加位置'
    },
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-production-add`
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '发布作品')
    if (this.$route.params.item_id) {
      this.init()
    }
  },
  methods: {
    async init () {
      const response = await api.fetchProductionDetail({portfolio_id: this.$route.params.item_id})
      this.portfolio = {
        portfolio_id: response.id,
        title: response.title,
        introduction: response.introduction,
        lng: response.lng || '',
        lat: response.lat || '',
        address: response.address || '',
        sys_area_id: response.sys_area_id || '',
        category_id: response.category_list.map(item => item.id),
        image_url: response.image_list.map(item => item.url)
      }
      this.tagList = response.category_list
      this.ossImageThumb = response.image_list.map(item => item.url_cdn)
    },
    deleteImage (index) {
      this.ossImageThumb.splice(index, 1)
      this.portfolio.image_url.splice(index, 1)
    },
    // 图片上传之前
    async beforeUploadImage (file) {
      this.ossImage = await api.ossParamsCreate(file, 'portfolio_image', this.ossImage)
    },
    // 图片上传成功
    successImage (res) {
      this.ossImageThumb.push(res.results.file_url_cdn)
      this.portfolio.image_url.push(res.results.file_url)
    },
    chooseTag () {
      this.isShowTag = !this.isShowTag
    },
    chooseAddress () {
      this.isShowPosition = !this.isShowPosition
    },
    getTag (tag) {
      this.tagList = tag
      if (this.tagList.length === 2) {
        this.portfolio.category_id = [tag[0].value, tag[1].value]
      }
    },
    async getAddress (value) {
      this.address = value
      if (Object.values(value).length === 0) {
        this.portfolio.lng = ''
        this.portfolio.lat = ''
        this.portfolio.address = ''
        this.portfolio.sys_area_id = ''
        return
      }
      const areaList = await getArea()
      const areaId = findValue(areaList, value.city)
      this.portfolio.sys_area_id = areaId[areaId.length - 1]
      this.portfolio.lng = value.location.lng
      this.portfolio.lat = value.location.lat
      this.portfolio.address = value.name
    },
    async releasePortfolio () {
      const rules = await validate(this.portfolio, this.portfolioRule)
      if (!rules) return
      let response
      if (this.$route.params.item_id) {
        response = await api.handlePortfolioEdit(this.portfolio)
      } else {
        response = await api.fetchPortfolioAdd(this.portfolio)
      }
      const vm = this
      if (response.code === 200) {
        this.$store.commit('ADD_MESSAGE', {
          msg: MSG['RESOURCE_PRODUCT_RELEASE_SUCCESS'],
          type: 'success',
          cb () {
            vm.goToDetail(vm.$route.params.id, vm.$route.params.mode)
          }
        })
      } else {
        this.$store.commit('ADD_MESSAGE', {msg: response.msg})
      }
    },
    // 前往主页详情
    goToDetail (id, mode) {
      let page = ''
      switch (mode) {
      case '100':
        page = `/person-home/${id}/production`
        break
      case '200':
        page = `/company-home/${id}/production`
        break
      case '300':
        page = `/supplier-home/${id}/production`
        break
      case '400':
        page = `/brand-home/${id}/production`
        break
      case '500':
        page = `/decorator-home/${id}/production`
        break
      }
      this.$router.push({path: page})
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-production-add
  color: $black1
  .form-box
    padding: 0 30px 30px 30px
    .weui-cells
      margin-top: 0
      &.vux-no-group-title
        margin-top: 0
      .weui-cell
        padding: 0
        height: 100px
        .weui-label
          color: $black2
        &.detail-textarea:after
          display: none !important
        &.vux-x-textarea
          height: 160px
          padding: 30px 0
          .weui-cell__bd
            height: 100%
            .weui-textarea-counter
              display: none
            .weui-textarea
              height: 100%
    .upload-picture-wrap
      overflow: hidden
      margin-bottom: 16px
      .show-pic
        display: flex
        flex-flow: wrap
        margin-right: -24px
        .pic
          overflow: hidden
          position: relative
          width: 214px
          height: 214px
          margin-right: 24px
          margin-bottom: 26px
          border-radius: 6px
          &>img
            absolute: top 50% left 50%
            width: 100%
            border-radius: 6px
            transform: translate(-50%, -50%)
          .icon
            absolute: right top
            width: 40px
            height: 40px
            text-align: center
            color: $white
            font-size: 18px
            line-height: 40px
            background-color: rgba(67, 67, 67, 0.7)
            border-radius: 0 6px 0 6px
      .upload-box
        width: 214px
        height: 214px
        background: $greyF9 url('../../../assets/imgs/mall/icon-tgupload.png') center center no-repeat
        background-size: 122px auto
        border-radius: 6px
    .add-tags
      display: flex
      flex-wrap: wrap
      margin-bottom: 30px
      .tag
        padding: 0 16px 0 46px
        margin: 0 10px 10px 0
        height: 46px
        line-height: 46px
        color: $grey3
        font-size: 22px
        background-color: $grey5
        border-radius: 25px
        &.icon-tag
          background-image: url('../../../assets/imgs/resource/icon-tag@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 20px
        &.icon-tag-origin
          color: $black2
          background-image: url('../../../assets/imgs/resource/icon-tag-orange@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 20px
    .add-address
      display: flex
      .address
        padding: 0 16px 0 46px
        height: 46px
        line-height: 46px
        color: $grey3
        font-size: 22px
        background-color: $grey5
        border-radius: 25px
        &.icon-address
          background-image: url('../../../assets/imgs/resource/icon-address-grey@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 20px
        &.icon-address-orange
          color: $black2
          background-image: url('../../../assets/imgs/resource/icon-address-orange@2x.png')
          background-position: 14px center
          background-repeat: no-repeat
          background-size: auto 20px
  .save-btn
    margin-top: 40px
  .mask-tag
    fixed: top right
    bottom: 0
    left: 0
    background-color: rgba(51, 51, 51, 0.5)
    z-index: 501
</style>
