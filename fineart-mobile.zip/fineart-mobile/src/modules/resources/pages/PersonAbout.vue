<template>
  <div :class="classes">
    <cube-scroll
      :options="scrollOptions"
      @pulling-up="loadMore"
      ref="scroller">
      <resource-head :id="$route.params.id"></resource-head>
      <div class="page-wrap">
        <!-- 装修师 -->
        <div class="decorator" v-if="mode === '500'">
          <h3 class="about-title">资质级别</h3>
          <span class="grade">{{resourceDetail.grade_desc}}</span>
        </div>
        <div class="decorator" v-if="mode === '500'">
          <h3 class="about-title">口碑评分</h3>
          <!-- 星级 -->
          <div class="rater-level">
            <rater :value="resourceDetail.score | starFormatter" disabled star="<span class='fy-icon-sel-collection'></span>" :margin="9" :font-size="14" active-color="#FFD374"></rater>
          </div>
        </div>
        <!-- 简介 -->
        <div class="intro">
          <h3 class="about-title">简介</h3>
          <div class="intro-text fy-1px-b" v-html="resourceDetail.introduction"></div>
        </div>
        <!-- 标签 -->
        <div class="tag-box fy-1px-b" v-if="resourceDetail.tags && resourceDetail.tags.length !== 0">
          <h3 class="about-title">标签</h3>
          <ul class="tag-list">
            <li class="tag-item" v-for="(item, index) in resourceDetail.tags" :key="index">{{item.name}}</li>
          </ul>
        </div>
        <!-- 基本信息 -->
        <div class="info fy-1px-b">
          <h3 class="about-title">基本信息</h3>
          <ul class="info-box">
            <li class="info-item">
              <span class="info-title">地区</span>
              <span class="info-con">{{area}}</span>
            </li>
            <li class="info-item">
              <span class="info-title">类型</span>
              <span class="info-con">{{resourceDetail.mode_desc}}</span>
            </li>
            <li class="info-item">
              <span class="info-title">分类</span>
              <span class="info-con">{{category}}</span>
            </li>
            <li class="info-item" v-if="resourceDetail.gender_desc">
              <span class="info-title">性别</span>
              <span class="info-con">{{resourceDetail.gender_desc}}</span>
            </li>
            <li class="info-item" v-if="resourceDetail.design_price_desc">
              <span class="info-title">收费</span>
              <span class="info-con">{{resourceDetail.design_price_desc}}</span>
            </li>
          </ul>
        </div>
        <!-- 工作经验 -->
        <div class="experience" v-if="mode === '100'">
          <h3 class="about-title experience-title">
            <span>工作经验</span>
            <!-- 编辑/删除 -->
            <x-button type="default" plain class="edit-btn" v-if="resourceDetail.is_master" @click.native="showWorksModal('')">
              <span></span><span></span><span></span>
            </x-button>
          </h3>
          <ul class="experience-list">
            <li class="experience-item" v-for="(item, index) in experience" :key="index" @click="showWorksModal(item)">
              <p class="time">{{item.start_date}}-{{item.end_date}}</p>
              <p class="company">
                <span class="name">{{item.company}}</span>
                <em>/</em>
                <span class="position">{{item.job}}</span>
              </p>
              <x-button type="default" plain class="edit-btn" v-if="resourceDetail.is_master"><span class="fy-icon-arrow-right"></span></x-button>
            </li>
          </ul>
        </div>
        <!--分割线-->
        <div class="fy-divider"></div>
        <!--参与记录-->
        <div class="case-title fy-1px-b">
          <div class="tab-bar">
            <h3 class="name" :class="{'is-active': tabSelected === 0}" @click="changeTag(0)">参与案例</h3>
            <h3 class="name" :class="{'is-active': tabSelected === 4}" v-if="mode === '400'" @click="changeTag(4)">产品系列</h3>
            <h3 class="name" :class="{'is-active': tabSelected === 3}" v-if="mode === '300'" @click="changeTag(3)">代理品牌</h3>
          </div>
          <!-- 暂时隐藏 -->
          <span class="more" v-if="false">案例分布></span>
        </div>
        <div class="cases" v-show="tabSelected === 0">
          <!--案例列表-->
          <ul class="case-list" v-if="resourceCaseList.data.length !== 0">
            <li class="case-item fy-1px-b" v-for="( item, index ) in resourceCaseList.data" :key="index">
              <!-- 编辑/删除 -->
              <x-button type="default" plain class="edit-btn" v-if="resourceDetail.is_master" @click.native="operate(item.id, index)">
                <span></span><span></span><span></span>
              </x-button>
              <!-- 案例详情 -->
              <a class="case-wrap" :href="`/building.html#/building-detail/${item.building_id}#${item.resource_id}`">
                <div class="case-img" :style="{backgroundImage: `url(${item.building_thumbnail})`}"></div>
                <div class="case-content">
                  <h3 class="case-name" :class="{'is-edit': resourceDetail.is_master}">{{ item.building_name}}</h3>
                  <p class="case-subtitle service-type">{{ item.service_type }}</p>
                  <p class="case-subtitle area" v-if="item.building_sys_area">{{ item.building_sys_area }}</p>
                </div>
              </a>
            </li>
          </ul>
          <!-- 编辑案例为空时 -->
          <div class="case-empty" v-if="resourceDetail.is_master && resourceCaseList.data.length === 0">
            <span class="fy-icon-addcase"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span></span>
            <p class="empty-title">如何添加案例</p>
            <p class="empty-text">打开 [斐艺建筑] -> 搜索建筑 -> 点击 [我有参与]<br>如果没有找到你要的建筑，可以自己添加建筑<br>现在就去看看[<a href="/building.html">斐艺建筑</a>]</p>
          </div>
          <fine-art-empty v-if="!resourceDetail.is_master && resourceCaseList.data.length === 0"></fine-art-empty>
        </div>
        <!-- 产品系列 -->
        <div class="works" v-show="tabSelected === 3 || tabSelected === 4" v-if="mode === '400' || mode === '300'">
          <x-button type="primary" class="add-btn" v-show="resourceDetail.is_master" @click.native="showProductModal('')"><span class="icon-release"></span>添加{{mode === '300' ? '代理品牌' : '产品'}}</x-button>
          <ul class="case-list">
            <li class="case-item fy-1px-b" v-for="( item, index ) in brandList.data" :key="index">
              <!-- 编辑/删除 -->
              <x-button type="default" plain class="edit-btn" v-if="resourceDetail.is_master" @click.native="operate(item.id, index)">
                <span></span><span></span><span></span>
              </x-button>
              <!-- 产品系列详情 -->
              <div class="case-wrap" @click="goToDetail(item.id)">
                <div class="case-img" :style="{backgroundImage: `url(${item.thumbnail_cdn})`}"></div>
                <div class="case-content">
                  <h3 class="case-name" :class="{'is-edit': resourceDetail.is_master}">{{ item.title }}</h3>
                  <p class="case-intro">{{item.introduction | labelFormatter(34)}}</p>
                </div>
              </div>
            </li>
          </ul>
          <fine-art-empty v-if="brandList.data.length === 0"></fine-art-empty>
        </div>
      </div>
    </cube-scroll>
    <div v-transfer-dom>
      <resource-operate v-model="isOperate" @edit="showModal" @delete="handleDel"></resource-operate>
    </div>
    <!-- 编辑案例 -->
    <div v-transfer-dom>
      <resource-case v-model="isShowCase"
                     :case="delId.id"
                     :mode-name="mode_desc"
                     @save-refresh="refreshList"></resource-case>
    </div>
    <!-- 编辑代理品牌 -->
    <div v-transfer-dom>
      <resource-collect title="编辑代理品牌" v-model="collectShowed"
                        :resource-mode="mode"
                        :item-id="delId.id"
                        :resource-id="resourceDetail.id"
                        @save-refresh="refreshList"></resource-collect>
    </div>
    <!-- 编辑工作经历 -->
    <div v-transfer-dom>
      <resource-works v-model="worksShowed"
                      :experience="experienceDetail"
                      @delete-work="deleteWorks"
                      @save-refresh="refreshExperienceList"></resource-works>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import api from 'modules/resources/api'
import * as MSG from 'assets/data/message.js'
import { Scroll } from 'cube-ui'
import { FineArtEmpty, ResourceOperate, ResourceCase, ResourceCollect, ResourceHead, ResourceWorks } from 'components'

export default {
  name: `${COMPONENT_PREFIX}PersonAbout`,
  data () {
    return {
      isOperate: false,
      // 标签列表
      tagList: [],
      // 工作经验
      experience: [],
      // 案例列表
      resourceCaseList: {
        data: [],
        current_page: 1,
        has_next: false
      },
      // 删除
      delId: {
        id: false
      },
      mode_desc: '',
      isShowCase: false,
      // tab切换
      tabSelected: 0,
      // 品牌/供应商的列表
      brandList: {
        data: [],
        current_page: 1,
        has_next: false
      },
      // 编辑 品牌/供应商的列表项
      collectShowed: false,
      // 编辑工作经验
      worksShowed: false,
      // 选中编辑的工作经历
      experienceDetail: {}
    }
  },
  components: {
    'cube-scroll': Scroll,
    FineArtEmpty,
    ResourceOperate,
    ResourceCase,
    ResourceCollect,
    ResourceHead,
    ResourceWorks
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-person-about`
    },
    resourceDetail () {
      return this.$store.state.resource.resourceDetail
    },
    mode () {
      return this.resourceDetail.mode
    },
    area () {
      if (this.resourceDetail.area_line) {
        return Object.values(this.resourceDetail.area_line).join('')
      }
    },
    category () {
      if (this.resourceDetail.category_line) {
        return Object.values(this.resourceDetail.category_line).join(' > ')
      }
    },
    scrollOptions () {
      if (this.resourceCaseList.data.length === 0 && this.tabSelected === 0) {
        return {
          pullDownRefresh: false,
          pullUpLoad: false
        }
      } else if (this.brandList.data.length === 0 && this.tabSelected !== 0) {
        return {
          pullDownRefresh: false,
          pullUpLoad: false
        }
      } else {
        return {
          pullDownRefresh: false,
          pullUpLoad: {
            threshold: 30,
            txt: {
              more: '加载完成',
              noMore: '-- END --'
            }
          }
        }
      }
    }
  },
  created () {
    this.fetchExperienceList()
    this.getResourceCaseList()
  },
  methods: {
    async fetchExperienceList () {
      this.experience = await api.fetchExperienceList({
        resource_id: this.$route.params.id,
        type: 200
      })
    },
    // 切换tab
    changeTag (index) {
      this.tabSelected = index
      // 品牌
      if (index === 4 && this.brandList.data.length === 0) {
        this.getResourceProductList()
      }
      // 供应商
      if (index === 3 && this.brandList.data.length === 0) {
        this.getResourceAgentBrandList()
      }
    },
    // 案例列表
    async getResourceCaseList () {
      this.resourceCaseList = await api.getResourceCaseList({
        resource_id: this.$route.params.id
      })
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.refresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    // 品牌列表
    async getResourceProductList () {
      this.brandList = await api.getResourceProductList({
        resource_id: this.$route.params.id
      })
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.refresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    // 供应商 -- 代理品牌
    async getResourceAgentBrandList () {
      this.brandList = await api.getResourceAgentBrandList({
        resource_id: this.$route.params.id
      })
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.refresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    // 参与案例 加载更多
    loadMore () {
      if (this.tabSelected === 0) {
        this.loadMoreCase()
      }
      // 供应商
      if (this.tabSelected === 3) {
        this.loadMoreSupplier()
      }
      // 品牌
      if (this.tabSelected === 4) {
        this.loadMoreBrand()
      }
    },
    // 案例 -- 加载更多
    async loadMoreCase () {
      // 没有更多数据，不再加载更多
      if (!this.resourceCaseList.has_next) {
        return this.$refs.scroller.forceUpdate()
      }
      const response = await api.getResourceCaseList({ resource_id: this.$route.params.id, page: this.resourceCaseList.current_page + 1 })
      this.resourceCaseList.data = [...this.resourceCaseList.data, ...response.data]
      this.resourceCaseList.current_page = response.current_page
      this.resourceCaseList.has_next = response.has_next
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.refresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    // 品牌 -- 加载更多
    async loadMoreBrand () {
      // 没有更多数据，不再加载更多
      if (!this.brandList.has_next) {
        return this.$refs.scroller.forceUpdate()
      }
      const response = await api.getResourceProductList({ resource_id: this.$route.params.id, page: this.brandList.current_page + 1 })
      this.brandList.data = [...this.brandList.data, ...response.data]
      this.brandList.current_page = response.current_page
      this.brandList.has_next = response.has_next
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.refresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    // 供应商 -- 加载更多
    async loadMoreSupplier () {
      // 没有更多数据，不再加载更多
      if (!this.brandList.has_next) {
        return this.$refs.scroller.forceUpdate()
      }
      const response = await api.getResourceAgentBrandList({ resource_id: this.$route.params.id, page: this.brandList.current_page + 1 })
      this.brandList.data = [...this.brandList.data, ...response.data]
      this.brandList.current_page = response.current_page
      this.brandList.has_next = response.has_next
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.refresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    operate (id, index) {
      this.isOperate = true
      this.delId.id = id
      this.delId.index = index
      if (this.tabSelected === 0) {
        this.mode_desc = this.resourceDetail.name + '：' + this.resourceDetail.mode_desc
      }
    },
    async handleDel (cb) {
      // 案例删除
      if (this.tabSelected === 0) {
        const response = await api.resourceCaseDelete(this.delId.id)
        if (response.code === 200) {
          cb()
          this.resourceCaseList.data.splice(this.delId.index, 1)
          this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DELETE_SUCCESS'], type: 'success'})
        }
      }
      // 供应商删除
      if (this.tabSelected === 3) {
        const response = await api.resourceAchievementDelete(this.delId.id)
        if (response.code === 200) {
          cb()
          this.brandList.data.splice(this.delId.index, 1)
          this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DELETE_SUCCESS'], type: 'success'})
        }
      }
      // 品牌删除
      if (this.tabSelected === 4) {
        const response = await api.resourceProductDelete(this.delId.id)
        if (response.code === 200) {
          cb()
          this.brandList.data.splice(this.delId.index, 1)
          this.$store.commit('ADD_MESSAGE', {msg: MSG['RESOURCE_DELETE_SUCCESS'], type: 'success'})
        }
      }
      this.$nextTick(() => {
        this.$refs.scroller && this.$refs.scroller.refresh()
        this.$refs.scroller && this.$refs.scroller.forceUpdate()
      })
    },
    showModal (cb) {
      if (this.tabSelected === 0) {
        this.isShowCase = true
      } else {
        this.collectShowed = true
      }
      cb()
    },
    refreshList () {
      if (this.tabSelected === 0) {
        this.getResourceCaseList()
      }
      if (this.tabSelected === 4) {
        this.getResourceProductList()
      }
      if (this.tabSelected === 3) {
        this.getResourceAgentBrandList()
      }
    },
    goToDetail (id) {
      if (this.tabSelected === 4) {
        this.$router.push({path: `/product-detail/${id}`})
      }
      if (this.tabSelected === 3) {
        this.$router.push({path: `/agent-brand-detail/${id}`})
      }
    },
    // 编辑 品牌/供应商
    showProductModal () {
      this.delId.id = false
      this.collectShowed = true
    },
    showWorksModal (experience) {
      if (!this.resourceDetail.is_master) return
      if (experience) {
        this.experienceDetail = experience
      } else {
        this.experienceDetail = {
          resource_id: this.resourceDetail.id
        }
      }
      this.worksShowed = true
    },
    // 删除工作经历
    async deleteWorks (id) {
      this.result = await api.resourceExperienceDelete(id)
      if (this.result.code === 200) {
        this.$store.commit('ADD_MESSAGE', { msg: MSG['RESOURCE_EXPERIENCE_DELETE_SUCCESS'], type: 'success' })
        this.fetchExperienceList()
      }
    },
    // 刷新工作经历列表
    refreshExperienceList () {
      this.fetchExperienceList()
    }
  },
  filters: {
    labelFormatter (str, length) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    },
    starFormatter (score) {
      return Math.round(score / 20)
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-person-about
  fixed: left top 94px
  bottom: 0
  width: 100%
  color: $black1
  font-family: PingFangSC-Regular
  .fy-divider
    width: 100%
    height: 20px
    background-color: $grey5
  .page-wrap
    padding-top: 90px
  .about-title
    font-size: 28px
    color: $black2
    line-height: 40px
    font-weight: 600
    &.experience-title
      display: flex
      justify-content: space-between
      .edit-btn
        display: flex
        justify-content: space-between
        align-items: center
        width: 32px
        height: 42px
        padding: 0
        margin: 0
        border: none
        &>span
          display: inline-block
          width: 6px
          height: 6px
          background-color: $black2
          border-radius: 50%
  .decorator
    display: flex
    align-items: center
    padding: 30px 30px 0 30px
    overflow: hidden
    .about-title
      margin-right: 20px
    .grade
      color: $black2
      font-size: 26px
      line-height: 37px
    .rater-level
      height: 40px
      .vux-rater-box
        vertical-align: top
  .intro
    padding: 30px 30px 0 30px
    .intro-text
      padding: 17px 0 30px 0
      color: $grey3
      font-size: 26px
      line-height: 45px
      word-break: break-all
  .tag-box
    padding: 30px 30px
    .tag-list
      display: flex
      flex-wrap: wrap
      padding-top: 20px
      .tag-item
        height: 38px
        padding: 0 14px
        margin-right: 10px
        color: $grey3
        font-size: 20px
        background-color: $greyF2
        border-radius: 6px
        text-middle: 5px 14px
  .info
    padding: 30px 30px 10px 30px
    .info-box
      padding-top: 26px
      .info-item
        margin-bottom: 20px
        font-size: 26px
        line-height: 37px
        .info-title
          margin-right: 33px
          color: $black2
        .info-con
          color: $grey3
  .experience
    padding: 30px 30px 0 30px
    .experience-list
      padding-top: 26px
      .experience-item
        position: relative
        margin-bottom: 30px
        .edit-btn
          absolute: top 50% right 0
          display: flex
          justify-content: space-between
          align-items: center
          width: 32px
          height: 42px
          padding: 0
          margin: 0
          border: none
          transform: translateY(-50%)
          &>span
            font-size: 24px
            color: $grey
        .time
          margin-bottom: 20px
          font-size: 24px
          line-height: 33px
          color: $grey3
        .company
          display: flex
          align-items: center
          &>em
            margin: 0 20px
            color: $grey6
            font-size: 24px
            line-height: 33px
          .name
            color: $black2
            font-size: 26px
            line-height: 37px
          .position
            color: $grey3
            font-size: 24px
            line-height: 33px
  .case-title
    display: flex
    justify-content: space-between
    align-items: center
    height: 90px
    padding: 0 30px
    .tab-bar
      display: flex
      .name
        position: relative
        height: 90px
        color: $black2
        font-size: 28px
        line-height: 90px
        margin-right: 80px
        &.is-active
          color: $orange
          &:after
            content: ''
            absolute: left bottom 2px
            width: 100%
            height: 4px
            background-color: $orange
    .more
      color: $grey3
      font-size: 24px
  .case-list
    width: 100%
    .case-item
      position: relative
      .edit-btn
        absolute: right top 40px
        display: flex
        justify-content: space-between
        align-items: center
        width: 92px
        height: 42px
        padding: 0 30px
        margin: 0
        border: none
        &>span
          display: inline-block
          width: 6px
          height: 6px
          background-color: $black2
          border-radius: 50%
      .case-wrap
        display: flex
        padding: 30px 30px
        .case-img
          flex-shrink: 0
          width: 160px
          height: 160px
          margin-right: 30px
          border-radius: 6px
          background-position: center center
          background-repeat: no-repeat
          background-size: cover
        .case-content
          flex: 1 0 auto
          .case-name
            max-width: 420px
            margin-bottom: 20px
            padding-top: 10px
            line-height: 42px
            font-size: 30px
            color: $black1
            {ellipse}
            &.is-edit
              max-width: 420px
              {ellipse}
          .case-subtitle
            margin-bottom: 10px
            font-size: 24px
            line-height: 33px
            color: $grey3
            {ellipse}
            &.area
              padding-left: 30px
              background: url('../../../assets/imgs/resource/icon-address@2x.png') 0 center no-repeat
              background-size: auto 21px
          .case-intro
            overflow: hidden
            width: 446px
            height: 84px
            font-size: 24px
            line-height:42px
            color: $grey3
  .add-btn
    width: 594px
    height: 66px
    margin: 30px auto
    font-size: 26px
    line-height: 66px
    border-radius: 35px
    box-shadow: 0 2px 12px 0 rgba(247, 181, 44, 0.54)
    .icon-release
      display: inline-block
      width: 26px
      height: 26px
      margin-right: 16px
      vertical-align: middle
      background: url('../../../assets/imgs/resource/icon-release-edit@2x.png') center center no-repeat
      background-size: auto 26px
  .case-empty
    width: 100%
    padding: 64px 0 80px 0
    text-align: center
    .fy-icon-addcase
      margin-bottom: 30px
      font-size: 108px
    .empty-title
      font-size: 28px
      margin-bottom: 30px
    .empty-text
      color: $black2
      line-height: 48px
      font-size: 24px
      &>a
        color: $orange
  .cube-pullup-wrapper
    color: $grey
    font-size: 26px
</style>
