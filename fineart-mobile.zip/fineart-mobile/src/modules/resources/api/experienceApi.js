export default function (cls) {
  /**
   * 获取工作经历列表
   *
   * @param resource_id {Integer} 资源ID
   * @param type {Integer} 资源经历类别
   * @returns {Promise<*|default.props.results|{type, default}|Array>}
   */
  cls.prototype.fetchExperienceList = async function ({ resource_id, type }) {
    const response = await cls.request({
      url: 'resource/experience/list/${resource_id}/${type}',
      params: {
        resource_id,
        type
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }

  /**
   * 资源详情 - 添加工作经历
   *
   * @param resource_id {Integer} 资源ID
   * @param type {Integer} 资源经历类别
   * @param company {String} 公司名称
   * @param job {String} 工作职务
   * @param start_date {String} 开始日期
   * @param end_date {String} 结束日期
   * @returns {Promise<*>}
   */
  cls.prototype.resourceAddExperience = async function ({resource_id, type, company, job, start_date, end_date}) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/experience/add/${resource_id}/${type}',
      params: {
        resource_id,
        type
      },
      data: {
        company,
        job,
        start_date,
        end_date
      }
    })
    return response
  }

  /**
   * 资源详情 - 编辑工作经历
   *
   * @param id {Integer} 工作经历ID
   * @param company {String} 公司名称
   * @param job {String} 工作职务
   * @param start_date {String} 开始日期
   * @param end_date {String} 结束日期
   * @returns {Promise<*>}
   */
  cls.prototype.resourceEditExperience = async function ({id, company, job, start_date, end_date}) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/experience/edit/${id}',
      params: {
        id
      },
      data: {
        company,
        job,
        start_date,
        end_date
      }
    })
    return response
  }

  /**
   * 删除资源个人工作经历
   *
   * @param id {Integer} 工作经历ID
   * @returns {Promise<*>}
   */
  cls.prototype.resourceExperienceDelete = async function (id) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/experience/delete/${id}',
      params: {
        id
      }
    })
    return response
  }
}
