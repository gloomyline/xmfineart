import {BaseApi} from '@/common/js/BaseApi'
import caseApi from './caseApi.js'
import experienceApi from './experienceApi.js'
import resourceHomeApi from './resourceHomeApi.js'
import ossApi from 'modules/member/api/ossApi.js'
import productionApi from './productionApi.js'
import dynamicApi from './dynamicApi.js'

class ResourceApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    ResourceApi.updateToken(ResourceApi.readTokenFromLocalStorage())
    caseApi(ResourceApi)
    experienceApi(ResourceApi)
    resourceHomeApi(ResourceApi)
    ossApi(ResourceApi)
    productionApi(ResourceApi)
    dynamicApi(ResourceApi)
  }
}

const _instance = new ResourceApi()

export default _instance
