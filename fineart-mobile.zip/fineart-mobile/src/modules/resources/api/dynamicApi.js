export default function (cls) {
  /**
   * [v3.1]标签-我的标签列表
   * @param object_type  资源对象 300 - 资源动态
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleDynamicTagList = async function ({ object_type }) {
    const response = await cls.request({
      url: '/resource/member/tag/list/${object_type}',
      params: {
        object_type
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * [v3.1]标签-新增
   * @param object_type  资源对象 300 - 资源动态
   * @param tag  标签名, 必须，最长32个字符
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleAddDynamicTag = async function ({ object_type, tag }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/member/tag/add',
      data: {
        object_type,
        tag
      }
    })
    return response
  }
  /**
   * [v3.1] 动态-资源所属动态列表
   * @param resource_id  资源id
   * @param page
   * @returns {Promise<*|Object>}
   */
  cls.prototype.fetchFeedList = async function ({ resource_id, page = 1 }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/feed/list',
      data: {
        resource_id,
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * [v3.1] 动态-发布动态
   * @param resource_id  资源id
   * @param introduction 动态详情
   * @param lng
   * @param lat
   * @param address
   * @param sys_area_id
   * @param tags
   * @param images
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleFeedAdd = async function ({ resource_id, introduction, lng, lat, address, sys_area_id, tags, images }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/member/feed/add',
      data: {
        resource_id,
        introduction,
        lng,
        lat,
        address,
        sys_area_id,
        'tags[]': tags,
        'images[]': images
      }
    })
    return response
  }
  /**
   * [v3.1] 动态-删除
   * @param id
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleFeedDel = async function ({ id }) {
    const response = await cls.request({
      url: '/resource/member/feed/del/${id}',
      params: {
        id
      }
    })
    return response
  }
  /**
   * [v3.1] 获取待绑定的资源主页列表
   * @returns {Promise<*|Object>}
   */
  cls.prototype.fetchHomeModeList = async function () {
    const response = await cls.request({
      url: 'resource/member/index'
    })
    if (response.code === 200) {
      return response.results
    }
  }
}
