export default function (cls) {
  /**
   * [v3.1]获取我的资源作品列表
   * @param {Number} 资源ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchProductionList = async function ({ resource_id, page = 1 }) {
    const response = await cls.request({
      url: '/resource/portfolio/list/${resource_id}',
      params: {
        resource_id
      },
      query: {
        page
      }
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * [v3.1]获取指定资源作品详情
   * @param portfolio_id 资源作品ID
   * @returns {Promise<*|Object>}
   */
  cls.prototype.fetchProductionDetail = async function ({ portfolio_id }) {
    const response = await cls.request({
      url: `/resource/portfolio/detail/${portfolio_id}`
    })
    if (response.code === 200) {
      return response.results
    }
  }
  /**
   * [v3.1]资源作品 =>点赞/取消点赞
   * @param object_type 资源类型 100=资源，200=资源作品, 300=动态
   * @param object_id 资源对象Id
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleResourceLike = async function ({ object_type, object_id }) {
    const response = await cls.request({
      url: `/resource/member/like/${object_type}/${object_id}`
    })
    return response
  }
  /**
   * [v3.1]资源作品/资源 => 收藏/取消收藏
   * @param object_type 对象类型 100=资源，200=资源作品, 300=动态
   * @param object_id 对象ID
   * @returns {Promise<*|Object>}
   */
  cls.prototype.handleResourceCollect = async function ({ object_type, object_id }) {
    const response = await cls.request({
      url: `/resource/collect/${object_type}/${object_id}`
    })
    return response
  }
  /**
   * [v3.1]获取发布作品
   * @param {Number} 资源ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchPortfolioAdd = async function ({ resource_id, title, introduction, lng, lat, address, sys_area_id, category_id, image_url }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/member/portfolio/add/${resource_id}',
      params: {
        resource_id
      },
      data: {
        title,
        introduction,
        lng,
        lat,
        address,
        sys_area_id,
        'category_id[]': category_id,
        'image_url[]': image_url
      }
    })
    return response
  }
  /**
   * [v3.1]删除我的资源作品
   * @param {Number} 资源ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.fetchPortfolioDel = async function ({ portfolio_id }) {
    const response = await cls.request({
      url: '/resource/member/portfolio/delete/${portfolio_id}',
      params: {
        portfolio_id
      }
    })
    return response
  }
  /**
   * [v3.1]编辑我的资源作品
   * @param {Number} 资源ID
   * @returns {Promise<*|Array>}
   */
  cls.prototype.handlePortfolioEdit = async function ({ portfolio_id, title, introduction, lng, lat, address, sys_area_id, category_id, image_url }) {
    const response = await cls.request({
      method: 'post',
      url: '/resource/member/portfolio/edit/${portfolio_id}',
      params: {
        portfolio_id
      },
      data: {
        title,
        introduction,
        lat,
        lng,
        address,
        sys_area_id,
        'category_id[]': category_id,
        'image_url[]': image_url
      }
    })
    return response
  }
}
