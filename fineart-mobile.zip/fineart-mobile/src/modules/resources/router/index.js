import Vue from 'vue'
import VueRouter from 'vue-router'
// 斐艺资源首页
import ResourceHome from 'modules/resources/pages/ResourceHome.vue'
import AchievementDetail from 'modules/resources/pages/AchievementDetail.vue'
import AgentBrandDetail from 'modules/resources/pages/AgentBrandDetail.vue'
import ProductDetail from 'modules/resources/pages/ProductDetail.vue'

// V3.1
import HomeDetail from 'modules/resources/pages/HomeDetail.vue'
import Production from 'modules/resources/pages/Production.vue'
import PersonAbout from 'modules/resources/pages/PersonAbout.vue'
import ProductionDetail from 'modules/resources/pages/ProductionDetail.vue'
import Dynamic from 'modules/resources/pages/Dynamic.vue'
import DynamicAdd from 'modules/resources/pages/DynamicAdd.vue'
import HomeEdit from 'modules/resources/pages/HomeEdit.vue'
import ProductionAdd from 'modules/resources/pages/ProductionAdd.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'ResourceHome',
    component: ResourceHome,
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/achievement-detail/:id',
    name: 'AchievementDetail',
    component: AchievementDetail,
    props: true
  },
  {
    path: '/agent-brand-detail/:id',
    name: 'AgentBrandDetail',
    component: AgentBrandDetail,
    props: true
  },
  {
    path: '/product-detail/:id',
    name: 'ProductDetail',
    component: ProductDetail,
    props: true
  },
  //  v3.1
  // mode = 100 个人主页
  {
    path: '/person-home/:id',
    name: 'PersonHome',
    component: HomeDetail,
    props: true,
    redirect: {
      name: 'PersonAbout'
    },
    children: [
      {
        path: 'production',
        name: 'PersonProduction',
        component: Production
      },
      {
        path: 'about',
        name: 'PersonAbout',
        component: PersonAbout
      },
      {
        path: 'dynamic',
        name: 'PersonDynamic',
        component: Dynamic
      }
    ]
  },
  // mode = 400 品牌主页
  {
    path: '/brand-home/:id',
    name: 'BrandHome',
    component: HomeDetail,
    props: true,
    redirect: {
      name: 'BrandAbout'
    },
    children: [
      {
        path: 'production',
        name: 'BrandProduction',
        component: Production
      },
      {
        path: 'about',
        name: 'BrandAbout',
        component: PersonAbout
      },
      {
        path: 'dynamic',
        name: 'BrandDynamic',
        component: Dynamic
      }
    ]
  },
  // mode = 300 供应商主页
  {
    path: '/supplier-home/:id',
    name: 'SupplierHome',
    component: HomeDetail,
    props: true,
    redirect: {
      name: 'SupplierAbout'
    },
    children: [
      {
        path: 'production',
        name: 'SupplierProduction',
        component: Production
      },
      {
        path: 'about',
        name: 'SupplierAbout',
        component: PersonAbout
      },
      {
        path: 'dynamic',
        name: 'SupplierDynamic',
        component: Dynamic
      }
    ]
  },
  // mode = 200 公司主页
  {
    path: '/company-home/:id',
    name: 'CompanyHome',
    component: HomeDetail,
    props: true,
    redirect: {
      name: 'CompanyAbout'
    },
    children: [
      {
        path: 'production',
        name: 'CompanyProduction',
        component: Production
      },
      {
        path: 'about',
        name: 'CompanyAbout',
        component: PersonAbout
      },
      {
        path: 'dynamic',
        name: 'CompanyDynamic',
        component: Dynamic
      }
    ]
  },
  // mode = 500 设计师主页
  {
    path: '/decorator-home/:id',
    name: 'DecoratorHome',
    component: HomeDetail,
    props: true,
    redirect: {
      name: 'DecoratorAbout'
    },
    children: [
      {
        path: 'production',
        name: 'DecoratorProduction',
        component: Production
      },
      {
        path: 'about',
        name: 'DecoratorAbout',
        component: PersonAbout
      },
      {
        path: 'dynamic',
        name: 'DecoratorDynamic',
        component: Dynamic
      }
    ]
  },
  {
    path: '/home-edit/:mode/:id',
    name: 'HomeEdit',
    component: HomeEdit
  },
  {
    path: '/dynamic-add/:id?/:mode?',
    name: 'DynamicAdd',
    component: DynamicAdd,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/production-add/:id/:mode/:item_id?',
    name: 'ProductionAdd',
    component: ProductionAdd,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: '/production-detail/:portfolio_id',
    name: 'ProductionDetail',
    component: ProductionDetail,
    props: true
  }
]

export default new VueRouter({ routes })
