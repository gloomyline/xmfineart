<template>
  <div :class="classes">
    <fine-art-head :title="pageName" v-show="pageHeadShow"></fine-art-head>
    <page :class="{'no-show': !pageHeadShow}">
      <router-view></router-view>
      <jump-top></jump-top>
    </page>
  </div>
</template>

<script>
import { FineArtHead, JumpTop, Page } from 'components'
import { LOADING_TEXT, COMPONENT_PREFIX } from 'assets/data/constants.js'

import { hyphenCase } from '@/common/js/utils'

export default {
  name: `${COMPONENT_PREFIX}Home`,
  components: {
    FineArtHead,
    JumpTop,
    Page
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-home`
    },
    globalMessage () {
      return this.$store.state.message
    },
    isLoading () {
      return this.$store.state.isLoading
    },
    pageName () {
      return this.$store.state.pageName
    },
    pageHeadShow () {
      return this.$store.state.pageHeadStatus
    }
  },
  watch: {
    globalMessage (newVal) {
      // 如果 toast 已显示，则不再显示 toast，也就是说同时只允许一个全局 toast 显示
      if (this.$vux.toast.isVisible()) return
      const message = newVal
      const text = message.msg
      const type = message.type
      const position = message.position
      const cb = message.cb
      this.$vux.toast.show({
        text,
        type,
        position,
        onHide () {
          cb && cb()
        }
      })
    },
    isLoading (newVal) {
      const loadingStatus = this.$vux.loading.isVisible()
      if (loadingStatus === undefined) {
        this.$vux.loading.hide()
      }
      if (newVal && !loadingStatus) { // false ->(change) true, show loading
        this.$vux.loading.show({ text: LOADING_TEXT })
      } else if (!newVal && loadingStatus) { // true ->(change) false, hide loading
        this.$vux.loading.hide()
      }
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-home
  font-family: PingFangSC, Microsoft Yahei
  .no-show
    padding-top: 0
</style>
