<template>
  <div :class="classes">
    <div class="content">
      <p class="tip-text">微信扫一扫或长按识别二维码</p>
      <p class="tip-text">或搜索微信公众号"斐艺平台"即可关注我们</p>
      <div class="qr-box">
        <span>微信公众号：斐艺平台</span>
        <img class="qr-img" src="../../../assets/imgs/home/qr-wechat.png">
      </div>
      <p class="tip-text">或打电话给我们</p>
      <a class="mobile-wrap" href="tel:15259268926">15259268926</a>
      <a class="mobile-wrap" href="tel:0592-5217662">0592-5217662</a>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils.js'

export default {
  name: `${COMPONENT_PREFIX}PageFocusUs`,
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-focus-us`
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '官方微信')
    this.$wx.updateShareData('index', {})
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-focus-us
  absolute: left top 0
  width: 100%
  height: 100%
  padding-top: 94px
  .content
    width: 100%
    height: 100%
    padding: 80px 76px 0
    background-image: url("../../../assets/imgs/home/img-focus-page-bg.png")
    background-size: cover
    display: flex
    text-align: center
    align-items: center
    flex-direction: column
    .tip-text
      color: $white
      font-size: 24px
      line-height: 40px
    .qr-box
      margin: 30px auto 40px
      width: 470px
      height: 520px
      padding: 40px
      background: $white
      border-radius: 16px
      box-shadow:0 2px 40px 0px rgba(35, 92, 108, .32)
      span
        color: $black2
        font-size: 26px
      .qr-img
        width: 350px
        height: 350px
        margin: 20px
    .mobile-wrap
      width: 470px
      line-height: 66px
      color: $white
      font-size: 28px
      margin-top: 26px
      border-radius: 33px
      background: rgba($white, .2036)
</style>
