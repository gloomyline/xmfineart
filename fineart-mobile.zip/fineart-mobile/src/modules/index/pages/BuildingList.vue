<template>
  <div :class="classes">
    <fine-art-scroller
      ref="scroller"
      class="building-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="buildings.data"
      :has-data="hasData"
      :has-more="buildings.has_next">
      <div class="building-list-wrap">
        <div class="building-list">
          <div
            :key="index"
            class="building-item fy-1px-b"
            v-for="(building, index) in buildings.data"
            @click="goDetail(building.id)">
            <div class="img-wrap">
              <img :src="building.thumbnail" width="100%" height="100%">
            </div>
            <div class="info">
              <p class="name">{{ building.name }}</p>
              <p class="tag">
                <span>{{ building.category[building.building_category_id] }}</span>
              </p>
              <div class="position">
                <i class="fy-icon-location"></i>
                <div class="attr-value">{{ building.area_desc }}</div>
                <span class="distance" >{{building.distance}}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
    <!-- 不显示的地图容器 -->
    <div class="map" id="map"></div>
    <!--建筑地图跳转悬浮按钮-->
    <div class="go-to-building-map" v-if="buildings.data && buildings.data.length > 0">
      <div @click="toBuildingMap"><img src="../../../assets/imgs/building/icon-go-to-map@3x.png" width="64" height="64"></div>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, USER_CURRENT_POSITION, POSITION_ACTIVE_TIME } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtCateSideBar, FineArtSearch, FineArtScroller } from 'components'
import api from 'modules/building/api'

export default {
  name: `${COMPONENT_PREFIX}PageBuildingList`,
  data () {
    return {
      // 建筑列表数据
      buildings: [],
      pageConfig: {
        // 建筑列表当前所加载分页
        page: 1,
        // 关键词
        keyword: '',
        category_id: '',
        foreign: 0, // 是否只看国外，0：否；1：是
        area_id: 1, // 1 => 中国所有区域， 值为空表示所有区域，包括国内，国内
        lng: null,
        lat: null,
        sort: 'distance_asc'
      },
      // 当前配置条件下是否还有下一页数据
      has_next: true
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-building-list`
    },
    hasData () {
      return this.buildings.total > 0
    }
  },
  props: [
    'keyword'
  ],
  watch: {
    keyword () {
      this.pageConfig.keyword = (this.keyword === 'undefined' ? '' : this.keyword)
      this.refresh()
    }
  },
  created () {
    this.pageConfig.keyword = (this.keyword === 'undefined' ? '' : this.keyword)
    this.fetchBuildingList()
  },
  methods: {
    toBuildingMap () {
      window.location = `/building.html#/building-map/0/0/0`
    },
    // 获取用户当前地理位置
    async _getCurrentPosition () {
      let position = this.$localStorage.get(USER_CURRENT_POSITION)
      if (!position) {
        try {
          await this.$fMap.createMap('map')
          // 用户当前地理位置
          position = await this.$fMap.geoLocation()
          // 存储获取到的用户的地理位置
          this.$localStorage.set(USER_CURRENT_POSITION, position, POSITION_ACTIVE_TIME + Date.now())
          this.pageConfig.lng = position.lng
          this.pageConfig.lat = position.lat
        } catch (e) {
          // console.log(e)
          window.location.reload()
        }
      } else {
        this.pageConfig.lng = position.lng
        this.pageConfig.lat = position.lat
      }
    },
    goDetail (id) {
      window.location = `/building.html#/building-detail/${id}`
    },
    focus () {
      this.$refs.searchInput.focus()
    },
    // 搜索
    async search (keyword) {
      this.pageConfig.page = 1
      this.pageConfig.keyword = keyword
      // 关键词为空，只看国内区域的建筑数据
      this.pageConfig.area_id = keyword ? '' : 1
      await this.fetchBuildingList()
      this.$nextTick(() => {
        this.$refs.scroller.scroll.scrollTo(0, 0, 10, 'bounce')
      })
    },
    // 加在更多建筑列表数据
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.buildings.has_next) return

      this.pageConfig.page = this.buildings.current_page + 1
      // 建筑列表分页
      let dataList = await api.fetchBuildingList(this.pageConfig)
      for (let index in dataList.data) {
        this.buildings.data.push(dataList.data[index])
      }
      this.buildings.current_page = dataList.current_page
      this.buildings.has_next = dataList.has_next
    },
    // 刷新当前建筑列表数据
    async refresh () {
      this.pageConfig.page = 1
      this.fetchBuildingList()
    },
    async fetchBuildingList () {
      await this._getCurrentPosition()
      this.buildings = await api.fetchBuildingList({...this.pageConfig, page: 1})
    }
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-building-list
  width: 100%
  height: 100%
  color: $black1
  .building-list-scroller
    top: 304px
    .building-list-wrap
      .building-list
        .building-item
          padding: 30px 0 33px 0
          margin: 0 30px 0 30px
          display: flex
          flex-direction: row
          justify-content: left
          position: relative
          .img-wrap
            width: 200px
            height: 200px
            background: $grey5
            img
              min-height: 200px
              min-width: 200px
          .info
            position: relative
            margin-left: 30px
            flex-grow: 2
            .name
              width: 450px
              color: $black1
              margin: 22px 0
              font-size: 30px
              line-height: 42px
              background: transparent
              {ellipse}
            .tag
              font-size: 0
              margin-bottom: 22px
              span
                display: inline-block
                padding: 4px 8px
                font-size: 24px
                color: $grey3
                border: 1.4px solid $grey2
            .position
              color: $grey3
              font-size: 24px
              line-height:33px
              display: flex
              align-items: center
              .fy-icon-location
                margin-right: 7px
                vertical-align: baseline
              .attr-value
                display: inline-block
                width: 350px
                {ellipse}
              .distance
                position: absolute
                right: 0
                color: $grey2
  .go-to-building-map
    width: 130px
    height: 130px
    fixed: right 22px bottom 22px
    &>a
      display: block
</style>
