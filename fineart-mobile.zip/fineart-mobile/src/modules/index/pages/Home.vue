<template>
  <div :class="classes">
    <div class="home-head">
      <div class="member-btn" @click.stop="memberClickHandler"></div>
      <div class="global-search" @click="toGlobalSearch()">
        <span class="search-text">搜索</span>
        <span class="search icon-search"></span>
      </div>
      <swiper v-model="currentSwiperIndex"
              class="home-swiper"
              dots-class="home-swiper-dots"
              dots-position="center"
              :show-dots="false"
              :auto="true"
              :loop="true"
              :interval="5000"
              :duration="500"
              :aspect-ratio="530/750">
        <swiper-item class="home-swiper-item" v-for="(item, index) in adImg" :key="index">
          <a class="architecture-item-link" :href="item.link_url">
            <img :src="item.image_url" width="100%" height="100%">
          </a>
        </swiper-item>
      </swiper>
      <div class="swiper-indicators text-center">
            <span
              :class="{'indicator':true,'active':i === currentSwiperIndex}"
              v-for="(item, i) in adImg"
              v-if="item"
              :key="i"></span>
      </div>
    </div>
    <!--分割线 -->
    <div class="fy-divider"></div>
    <!--精选功能-->
    <div class="product">
      <h3 class="box-title">精选功能</h3>
      <ul class="list">
        <li class="item map">
          <a href="map.html">
            <h3 class="title">斐艺地图</h3>
            <h4 class="subtitle">建筑滴滴&nbsp;精确查找</h4>
          </a>
        </li>
        <li class="item mall">
          <a href="mall.html">
            <h3 class="title">斐艺购</h3>
            <h4 class="subtitle">建筑商城&nbsp;一应俱全</h4>
          </a>
        </li>
      </ul>
    </div>
    <!--分割线 -->
    <div class="fy-divider"></div>
    <!--个人服务-->
    <div class="service">
      <h3 class="box-title">个人服务</h3>
      <div class="list-wrap">
        <ul class="list">
          <li class="item" v-for="(service, index) in services" :key="index" @click="to(service.link)">
            <img :src="service.picture" :alt="service.name">
            <span>{{ service.name }}</span>
          </li>
        </ul>
      </div>
    </div>
    <!--分割线 -->
    <div class="fy-divider"></div>
    <!-- 企业服务 -->
    <div class="business">
      <h3 class="box-title">企业服务</h3>
      <div class="list-wrap">
        <scroller ref="scroller" height="1.6rem" lock-y :scrollbar-x="false">
          <ul class="list">
            <router-link to="/expect" tag="li" class="item technology">
              <div class="box-divider"></div>
              <h3 class="title">产品技术分享</h3>
              <span class="subtitle">Product technology</span>
            </router-link>
            <a @click.prevent="goToBuilding" tag="li" class="item data">
              <div class="box-divider"></div>
              <h3 class="title">建筑大数据</h3>
              <span class="subtitle">Building data</span>
            </a>
          </ul>
        </scroller>
      </div>
    </div>
    <fine-art-foot-nav :is-choose="0"></fine-art-foot-nav>
    <transition name="slide">
      <div class="member-menu-wrap" v-show="isMemberExpanded" @touchmove="preventScroll($event)">
        <side-bar @slide-left="isMemberExpanded = false" @click-handler="changeHandler" :status="isMemberExpanded"></side-bar>
      </div>
    </transition>
    <div class="mask" v-show="isMaskShow" @touchend="memberClickHandler"></div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants.js'
import { hyphenCase } from '@/common/js/utils.js'

import { FineArtFootNav, SideBar } from 'components'

import api from 'modules/index/api'

export default {
  name: `${COMPONENT_PREFIX}PageNewHome`,
  components: {
    FineArtFootNav,
    SideBar
  },
  data () {
    return {
      currentSwiperIndex: 0,
      adImg: [],
      isMemberExpanded: false, // 会员中心是否处于展开状态
      services: [
        {
          name: '美宅设计',
          link: 'house.html',
          picture: require('../../../assets/imgs/home/mz-design.png')
        },
        {
          name: '美宅施工',
          link: 'house.html#/construct',
          picture: require('../../../assets/imgs/home/mz-work.png')
        },
        {
          name: '改造升级',
          link: 'index.html#/expect',
          picture: require('../../../assets/imgs/home/update.png')
        },
        {
          name: '同城建材',
          link: 'mall.html#/store',
          picture: require('../../../assets/imgs/home/building.png')
        }
        /* ,{
          name: '柠檬家',
          link: 'mall.html#/store-detail/4',
          picture: require('../../../assets/imgs/home/lemon.png')
        } */
      ]
    }
  },
  created () {
    this.$wx.updateShareData('index', {})
    this.$store.commit('MODIFY_PAGE_HEAD_STATUS', false)
    this._initData()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-new-home`
    },
    isMaskShow () {
      return this.isMemberExpanded
    }
  },
  beforeDestroy () {
    this.$store.commit('MODIFY_PAGE_HEAD_STATUS', true)
  },
  methods: {
    toGlobalSearch () {
      this.$router.push('/global-search/goods-list/undefined')
    },
    to (link) {
      window.location = link
    },
    goToBuilding () {
      window.location = 'building.html'
    },
    // toggle 会员中心左边栏菜单展开、关闭
    memberClickHandler (e) {
      this.isMemberExpanded = !this.isMemberExpanded
      e.preventDefault()
    },
    // 左边栏以及导航栏弹窗弹出时，阻止弹窗触发滚动事件
    preventScroll (e) {
      e.preventDefault()
      return false
    },
    changeHandler (value) {
      this.isMemberExpanded = value
    },
    _initData () {
      this.initAdsList()
      const foreLength = 2
      if (foreLength <= 2) return
      const foreWidth = (300 + 20) / 2
      const margin = 20 / 2
      const newGoodsListWidth = (foreWidth * foreLength - margin) * (window.devicePixelRatio / 2)
      this.$nextTick(() => {
        this.$refs.scroller.$el.querySelector('.list').style.width = newGoodsListWidth + 'px'
      })
    },
    async initAdsList () {
      this.adImg = await api.fetchAdsList(511)
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-new-home
  padding-bottom: 88px
  .mask
    fixed: top left
    right: 0
    bottom: 0
    z-index: 1
    background-color: rgba(33, 33, 33, 0.6)
  .member-menu-wrap
    fixed: left top
    bottom: 0
    width: 460px
    z-index: 2
    &.slide-enter-active
      transition: all 0.8s ease
    &.slide-leave-active
      transition all .6s cubic-bezier(1, .4, .71, 1.52)
    &.slide-enter, &.slide-leave-to
      transform: translate3d(-460px, 0, 0)
    .member-menu
      width: 100%
      height: 100%
      background-color: $white
  .fy-divider
    width: 100%
    height: 20px
    background-color: $grey5
  .member-btn
    absolute: left 30px top 30px
    width: 60px
    height: 60px
    background: url('../../../assets/imgs/home/icon-my.png') center center no-repeat
    background-size: 60px auto
    border-radius: 50%
    z-index: 2
  .global-search
    absolute: right 30px top 30px
    width: 200px
    height: 60px
    padding: 0 20px
    background: rgba(255,255,255,0.3)
    border-radius: 40px
    z-index: 1
    display: flex
    align-items: center
    justify-content: space-between
    .search-text
      font-size: 26px
      color: $white
      padding-left: 10px
      background-color: transparent
    .search
      inline-icon(34px, 34px)
      bg-img('../../../assets/imgs/map/icon-search')
  .box-title
    padding: 32px 0 0 32px
    color: $grey3
    font-size: 26px
  .home-head
    position: relative
    padding: 0
    .swiper-indicators
      absolute: left 50% bottom 14px
      transform: translateX(-50%)
      .indicator
        display: inline-block
        width: 26px
        height: 6px
        margin-right: 8px
        background-color: rgba(255, 255, 255, 0.7)
        &.active
          background-color: $orange
        &:last-child
          margin: 0
  .product
    .list
      display: flex
      justify-content: space-between
      padding: 31px 30px 50px 30px
      .item
        width: 334px
        height: 170px
        padding: 36px 0 0 36px
        &.map
          background: url('../../../assets/imgs/home/bg-map.png') 0 0 no-repeat
          background-size: 100% auto
        &.mall
          background: url('../../../assets/imgs/home/bg-mall.png') 0 0 no-repeat
          background-size: 100% auto
        &>a
          display: block
          color: $white
        .title
          margin-bottom: 11px
          font-size: 30px
          line-height: 40px
          font-weight: 600
          color: $white
        .subtitle
          color: rgba(255, 255, 255, 0.8)
          font-size: 22px
  .service
    .list-wrap
      overflow: hidden
      padding: 50px 90px
      .list
        display: flex
        flex-flow: wrap
        margin-right: -139px
        .item
          margin: 0 139px 50px 0
          &>img
            display: block
            width: 94px
            height: 94px
            margin-bottom: 17px
          &>span
            display: block
            text-align: center
            font-size: 22px
            color: $black2
  .business
    .list-wrap
      padding: 36px 30px 54px 30px
      .list
        .item
          position: relative
          float: left
          width: 300px
          height: 120px
          padding: 26px 0 0 60px
          margin-right: 20px
          border-radius: 20px
          &:last-child
            margin-right: 0
          &.technology
            background: $green url('../../../assets/imgs/home/icon-technology.png') right 29px no-repeat
            background-size: 78px auto
          &.data
            background: $purple2 url('../../../assets/imgs/home/icon-data.png') 216px 24px no-repeat
            background-size: 72px auto
          .title
            font-size: 26px
            line-height: 37px
            color: $white
          .subtitle
            display: block
            font-size: 23px
            font-family: STSongti-SC-Bold
            font-weight: bold
            line-height: 32px
            color: rgba(255, 255, 255, 0.5)
          .box-divider
            absolute: left 30px top 32px
            width: 6px
            height: 54px
            background-color: $white
</style>
