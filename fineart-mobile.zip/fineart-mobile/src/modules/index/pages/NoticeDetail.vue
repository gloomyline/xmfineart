<template>
  <div :class="classes">
    <h3 class="title">{{ notice.title }}</h3>
    <h4 class="date">{{ notice.date }}</h4>
    <p class="content" v-html="notice.content"></p>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils.js'

import api from 'modules/index/api'

export default {
  name: `${COMPONENT_PREFIX}PageNoticeDetail`,
  data () {
    return {
      notice: {}
    }
  },
  created () {
    this.$wx.updateShareData('index', {})
    this.$store.commit('MODIFY_PAGE_NAME', '公告详情')
    this._initData()
  },
  props: {
    id: {
      type: String,
      required: true
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-notice-detail`
    }
  },
  methods: {
    async _initData () {
      // 请求获取指定id的公告详情数据
      const _notice = await api.fetchNoticeDetail(this.id)
      // format 接口返回数据
      const date = (_notice.created_at.split(' ')[0]).replace(/-/g, '.')
      this.notice = {..._notice, date}
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-notice-detail
  padding: 0 30px
  .title
    line-height: 50px
    padding-top: 45px
    margin-bottom: 18px
    font-size: 32px
    color: $black1
  .date
    line-height: 37px
    margin-bottom: 20px
    font-size: 26px
    color: $grey3
  .content
    line-height: 50px
    font-size: 28px
    color: $black2
  img
    width: 100%
</style>
