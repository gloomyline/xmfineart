<template>
  <div :class="classes">
    <fine-art-scroller
      ref="scroller"
      class="resource-list-scroller"
      :list="resources.data"
      @refresh="refresh"
      @load-more="loadMore"
      :has-data="hasData"
      :has-more="resources.has_next">
      <div class="resource-list-wrap">
        <div class="resource-list">
          <div class="resource-item fy-1px-b"
               v-for="(resource, index) in resources.data"
               :key="index"
               @click="goToDetail(resource.id, resource.mode)">
            <div class="img-wrap fy-1px"><img :src="resource.logo" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ resource.name }}</p>
              <p class="subtitle">{{ resource.subtitle }}</p>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'
import { FineArtCateSideBar, FineArtSearch, FineArtScroller } from 'components'
import api from 'modules/resources/api'

export default {
  name: `${COMPONENT_PREFIX}ResourceHome`,
  data () {
    return {
      // 资源列表数据
      resources: [],
      pageConfig: {
        // 资源列表当前所加载分页
        page: 1,
        mode: '',
        // 关键词
        keyword: '',
        category_id: '',
        area_id: '',
        foreign: 0, // 是否只看国外，0：否；1：是
        order: 'default'
      }
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-resource-home`
    },
    hasData () {
      return this.resources.total > 0
    }
  },
  props: [
    'keyword'
  ],
  watch: {
    keyword () {
      this.pageConfig.keyword = (this.keyword === 'undefined' ? '' : this.keyword)
      this.refresh()
    }
  },
  created () {
    this.pageConfig.keyword = (this.keyword === 'undefined' ? '' : this.keyword)
    this.fetchResourceList()
  },
  methods: {
    // 前往主页详情
    goToDetail (id, mode) {
      let page = ''
      switch (mode) {
      case '100':
        page = `/person-home/${id}`
        break
      case '200':
        page = `/company-home/${id}`
        break
      case '300':
        page = `/supplier-home/${id}`
        break
      case '400':
        page = `/brand-home/${id}`
        break
      }
      window.location = `/resource.html#${page}`
    },
    // 刷新当前资源列表数据
    async refresh () {
      this.pageConfig.page = 1
      this.fetchResourceList()
    },
    async fetchResourceList () {
      this.resources = await api.fetchResourceList(this.pageConfig)
    },
    // 加在更多资源列表数据
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.resources.has_next) return

      this.pageConfig.page = this.resources.current_page + 1
      // 资源列表分页
      let dataList = await api.fetchResourceList(this.pageConfig)
      for (let index in dataList.data) {
        this.resources.data.push(dataList.data[index])
      }
      this.resources.current_page = dataList.current_page
      this.resources.has_next = dataList.has_next
    }
  },
  components: {
    FineArtSearch,
    FineArtScroller,
    FineArtCateSideBar
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-resource-home
  width: 100%
  height: 100%
  color: $black1
  .resource-list-scroller
    top: 304px
  .resource-list-wrap
    overflow: hidden
    padding: 0 30px
    .resource-list
      width: 100%
      .resource-item
        display: flex
        align-items: center /* 图片块和描述块垂直居中对齐 */
        width: 100%
        height: 220px
        font-size: 0
        .img-wrap
          flex: 0 0 160px
          width: 160px
          height: 160px
          margin-right: 30px
        .desc
          flex: 1
          max-width: 500px
          font-size: 0
          .name
            line-height: 42px
            margin-bottom: 20px
            font-size: 30px
            font-weight: 500
            color: $black1
            {ellipse}
          .subtitle
            line-height: 42px
            font-size: 24px
            color: $grey3
            {ellipse}
</style>
