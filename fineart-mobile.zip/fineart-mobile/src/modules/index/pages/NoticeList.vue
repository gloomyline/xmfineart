<template>
  <div :class="classes">
  <!-- 商品列表容器 -->
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :height="-96/75"
      :list="notices"
      :has-data="hasData"
      :has-more="has_next">
      <div class="list-wrap">
        <ul class="notice-list">
          <li class="notice-item fy-1px-b" v-for="(notice, index) in notices" :key="index">
            <router-link class="notice-link" :to="`/notice-detail/${notice.id}`">
              <h4 class="create-at">
                <span class="date">{{ notice.date }}</span>
                <span class="year">{{ notice.year }}</span>
              </h4>
              <h3 class="title">{{ notice.title }}</h3>
              <div class="content">{{ notice.digest }}</div>
            </router-link>
          </li>
        </ul>
      </div>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils.js'
import { FineArtScroller, FineArtEmpty } from 'components'
import api from 'modules/index/api'

export default {
  name: `${COMPONENT_PREFIX}PageNoticeList`,
  data () {
    return {
      // 当前页码
      current_page: 1,
      // 是否有下一页
      has_next: true,
      // 公告列表数据
      notices: []
    }
  },
  created () {
    this.$wx.updateShareData('index', {})
    this.$store.commit('MODIFY_PAGE_NAME', '公告列表')
    this._initData()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-notice-list`
    }
  },
  methods: {
    // 格式化接口返回的数据
    parseNoticesData (data) {
      this.current_page = data.current_page
      this.has_next = data.has_next
      // 接口返回的公告列表数据
      const notices = data.data
      // 构造含有 date 和 year 属性的成员新的数组，并赋值给 vm 上 data 中 notices
      return notices.map(notice => {
        const regHtml = notice.content.replace(/<\/?.+?>/g, '')
        const content = regHtml.replace(/ /g, '')
        // 公告内容摘录
        const digest = content.length > 54 ? `${content.slice(0, 54)}...` : content
        const createAt = notice.created_at
        // 年月日
        const dateArr = (createAt.split(' ')[0]).split('-')
        // 月日
        const date = `${dateArr[1]}.${dateArr[2]}`
        const year = dateArr[0]
        return {...notice, digest, date, year}
      })
    },
    // 加载第一页公告列表数据
    async _initData () {
      // 接口返回的 results page = 1
      const noticesData = await api.fetchNoticeList()
      this.notices = this.parseNoticesData(noticesData)
    },
    // 加载更多公告列表数据
    async loadMore (cb) {
      // 没有更多数据，不再加载更多
      if (!this.has_next) return cb()
      // 请求加载更多公告数据
      const noticesData = await api.fetchNoticeList(this.current_page + 1)
      // 将加载到的公告数据与之前的公告数据合并
      this.notices = [...this.notices, ...this.parseNoticesData(noticesData)]
    },
    // 刷新当前公告列表数据
    async refresh () {
      await this._initData()
    }
  },
  components: {
    FineArtScroller,
    FineArtEmpty
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-notice-list
  .list-wrap
    .notice-list
      padding: 0 30px
      .notice-item
        .notice-link
          display: block
          padding: 40px 0
          width: 100%
          color: $black1
          .create-at
            margin-bottom: 10px
            font-size: 0
            .date, .year
              display: inline-block
              vertical-align: top
            .date
              margin-right: 10px
              font-size: 28px
              color: $black2
            .year
              font-size: 24px
              color: $grey3
          .title
            line-height: 42px
            margin-bottom: 20px
            font-size: 30px
          .content
            line-height: 32px
            font-size: 24px
            font-weight: 300
            color: $black2
  .xs-plugin-pullup-container
    position: absolute
    bottom: -40px
    width: 100%
    height: 40px
    .rotate
      display: inline-block
      transform: rotate(-180deg)
    .pullup-arrow
      font-size: 25px
      color: $black2
      transition: all linear 0.2s
</style>
