<template>
  <div :class="classes">
    <div class="question-block" v-for="(questionBlock, index) in questions" :key="index">
      <h3 class="title">{{ questionBlock.name }}</h3>
      <section class="definition" v-for="(question, i) in questionBlock.data" :key="i">
        <h4 class="question">{{ question.question }}</h4>
        <div class="answer" v-html="question.answer"></div>
      </section>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils.js'

import api from 'modules/index/api'

export default {
  name: `${COMPONENT_PREFIX}PageCommonFaq`,
  data () {
    return {
      questions: []
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '常见问题')
    this._initData()
    // 更新微信分享内容
    this.$wx.updateShareData('index', {})
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-common-faq`
    }
  },
  methods: {
    async _initData () {
      this.questions = await api.fetchCommonFaqList()
    }
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-common-faq
  padding: 0 30px
  color: $black1
  .title
    padding-top: 35px
    margin-bottom: 45px
    line-height: 50px
    font-size: 36px
    font-weight: 500
  .question
    line-height: 42px
    margin-bottom: 24px
    font-size: 30px
    color: $orange
  .answer
    line-height: 44px
    font-size: 26px
    margin-bottom: 30px
    img
      max-width: 100%
</style>
