<template>
  <div :class="classes">
    <h3 class="title">联系我们</h3>
    <h4 class="sub-title">欢迎关注我们的微信公众号</h4>
    <div class="qrs">
      <div class="fine-art-qr qr-wrap">
        <div class="qr"><img :src="fineArtQr" width="100%" height="100%"></div>
        <p class="name">斐艺平台</p>
      </div>
      <div class="mz-qr qr-wrap">
        <div class="qr"><img :src="mzQr" width="100%" height="100%"></div>
        <p class="name">斐艺美宅</p>
      </div>
    </div>
    <div class="contact-ways">
      客服电话：0592-5217662<br/>
      客服手机号：15259268926<br/>
      客服邮箱：kefu@xmfineart.cn<br/>
      联系地址：厦门市湖里区泗水道597号海富中心A座1301
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils.js'

export default {
  name: `${COMPONENT_PREFIX}PageContactUs`,
  data () {
    return {
      fineArtQr: require('assets/imgs/home/fy-qrcode.png'),
      mzQr: require('assets/imgs/home/mz-qrcode.png')
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-contact-us`
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '联系我们')
    this.$wx.updateShareData('index', {})
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-contact-us
  padding: 76px 35px 0 35px
  text-align: center
  .title
    line-height: 45px
    margin-bottom: 10px
    font-size: 32px
    font-weight: 500
    color: $black1
  .sub-title
    line-height: 37px
    margin-bottom: 70px
    font-size: 26px
    color: $black2
  .qrs
    font-size: 0
    margin-bottom: 177px
    .qr-wrap
      display: inline-block
      vertical-align: top
      width: 330px
      height: 418px
      padding-top: 20px
      margin-right: 20px
      box-shadow: 0 4px 14px 0 rgba(0, 0, 0, 0.1)
      &:last-child
        margin-right: 0
      .qr
        width: 290px
        height: 290px
        margin: 0 auto 24px auto
      .name
        line-height: 40px
        font-size: 28px
        color: $black1
  .contact-ways
    line-height: 45px
    font-size: 24px
    color: $grey3
</style>
