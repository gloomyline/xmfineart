<template>
  <div class="expectation">
    <div class="picture">
      <img src="../../../assets/imgs/expectation.png" alt="敬请期待">
      <span class="text">敬请期待</span>
    </div>
    <fine-art-foot-nav></fine-art-foot-nav>
  </div>
</template>

<script>
import { FineArtFootNav } from 'components'
export default {
  name: 'Expectation',
  data () {
    return {
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '斐艺平台')
    this.$wx.updateShareData('index', {})
  },
  components: {
    FineArtFootNav
  }
}
</script>

<style lang="stylus" scoped>
.expectation
  .picture
    fixed: top 199px left 50%
    transform: translateX(-50%)
    &>img
      display: block
      width: 552px
      margin-bottom: 90px
    .text
      display: block
      color: $grey2
      font-size: 28px
      line-height: 40px
      text-align: center
</style>
