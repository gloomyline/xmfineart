<template>
  <div :class="classes">
    <div class="header">
        <router-link to="/"><div class="arrow"></div></router-link>
        <span class="text">搜索</span>
    </div>
    <div class="search-wrap">
      <div class="search">
      <div class="icon icon-search"></div>
      <form action="javascript: void(0)">
        <input placeholder="请输入关键字" ref="inputEle" class="search-input" v-model="keyword" type="search" @keyup.13="search(seletedIndex)">
      </form>
      </div>
      <router-link to="/"><div class="cancel">取消</div></router-link>
    </div>
    <!--灰色线-->
    <div class="divider"></div>
    <!--子路由tab-->
    <div class="router-tabs">
      <tab :line-width="2" custom-bar-width="40px" default-color="#333" active-color="#F7B52C">
        <tab-item  :selected=" id == seletedIndex" v-for="(item, id) in tagList" :key="id" @on-item-click="search(id)">
          <div>
            {{ item.tagName }}
          </div>
        </tab-item>
      </tab>
    </div>
    <!-- 子路由 -->
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils.js'

export default {
  name: `${COMPONENT_PREFIX}GlobalSearch`,
  data () {
    return {
      tagList: [
        {tagName: '商品', id: 0},
        {tagName: '同城建材', id: 1},
        {tagName: '资源', id: 2},
        {tagName: '建筑', id: 3}
      ],
      keyword: ''
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-global-search`
    },
    seletedIndex () {
      return this.$route.meta.tabIndex
    }
  },
  methods: {
    search (id) {
      this.$refs.inputEle.blur()
      if (!this.keyword) {
        this.keyword = undefined
      }
      switch (id) {
      case 0:
        this.$router.push(`/global-search/goods-list/${this.keyword}`)
        break
      case 1:
        this.$router.push(`/global-search/store-list/${this.keyword}`)
        break
      case 2:
        this.$router.push(`/global-search/resource-list/${this.keyword}`)
        break
      case 3:
        this.$router.push(`/global-search/building-list/${this.keyword}`)
        break
      }
    }
  },
  created () {
    this.$wx.updateShareData('index', {
      title: this.keyword
    })
    this.$store.commit('MODIFY_PAGE_HEAD_STATUS', false)
    // 获取来自路由参数里的关键字
    this.keyword = this.$route.params.keyword === 'undefined' ? '' : this.$route.params.keyword
  }
}
</script>
<style lang="stylus">
  .{$cls_prefix}-page-global-search
    .header
      height: 88px
      text-align: center
      border-bottom: 1.4px solid $grey
      position: relative
      .arrow
        width: 24px
        height: 24px
        border-top: 3px solid $grey3
        border-left: 3px solid $grey3
        transform: rotate(-45deg)
        position: absolute
        left: 41px
        top: 31px
      .text
        font-size: 30px
        font-weight:400
        color: $black1
        line-height: 88px
    .search-wrap
      height: 107px
      position: relative
      .search
        position: absolute
        left: 30px
        top: 24px
        width: 604px
        height: 60px
        background: rgba(246,246,246,1)
        border-radius: 34px
        .search-input
          padding: 0
          border: none
          outline: none
          width: 300px
          height: 37px
          font-size: 26px
          font-weight: 400
          color: $black1
          background-color: transparent
          position: absolute
          left: 77px
          top: 12px
          caret-color: $orange
        .search-input::placeholder
          font-size: 26px
          font-weight: 400
          color: $grey2
          line-height: 37px
        .icon.icon-search
          position: absolute
          left: 28px
          top: 16px
          inline-icon(28px,28px)
          bg-img('../../../assets/imgs/icon-search')
      .cancel
        height: 40px
        font-size: 28px
        font-weight:400
        color: $grey2
        line-height: 40px
        position: absolute
        right: 30px
        top: 36px
    .divider
      width: 100%
      height: 20px
      background-color: $grey4
    .router-tabs
      font-size: 28px
      line-height: 40px
      margin-bottom: 20px
      .moreIcon
        text-align: center
        vertical-align: center
      .img-wrap
        padding-top: 8px
        .icon
          max-width: 36px
</style>
