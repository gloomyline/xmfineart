<template>
  <div :class="classes">
    <fine-art-scroller
      class="store-list-scroller"
      ref="scroller"
      :has-data="hasData"
      :list="stores"
      :has-more="has_next"
      @refresh="refresh"
      @load-more="loadMore">
      <div class="store-list-wrap">
        <div class="store-list">
          <div
            :key="item.id"
            class="store-item fy-1px-b"
            v-for="item in stores"
            @click="goToDetail(item.id)">
            <div class="img-wrap"><img :src="item.thumbnail" width="100%" height="100%"></div>
            <div class="info">
              <p class="name">{{ item.name | labelFormatter(24)}}</p>
              <span class="subtitle">{{ item.subtitle }}</span>
              <p class="distance">{{ item.distance }}</p>
              <p class="tag">
                <span v-if="item.category_line">{{ item.category_line }}</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
    <!-- 不显示的地图容器 -->
    <div class="map" id="map"></div>
    <div class="btn-switch-stores-mode" v-if="stores && stores.length > 0">
      <div @click="toStoreMap"><img src="../../../assets/imgs/mall/img-map-mode-bg.png" width="100%" height="100%"></div>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX, USER_CURRENT_POSITION, POSITION_ACTIVE_TIME } from '@/assets/data/constants'
import {hyphenCase} from '@/common/js/utils'
import {FineArtCateSideBar, FineArtSearch, FineArtScroller} from 'components'

import api from 'modules/mall/api'

export default {
  name: `${COMPONENT_PREFIX}PageStoreList`,
  data () {
    return {
      // 线下店列表
      stores: [],
      // 线下店列表数据是否还有下一页
      has_next: false,
      // 右侧边菜单栏闭合、展开状态，默认闭合
      isCateSideBarExpanded: false,
      // 构造的右边栏列表数据
      menuData: [],
      // 请求线下店列表表单数据
      pageConfig: {
        // 当前分页
        page: 1,
        // 用户所在经度
        lng: null,
        // 用户所在纬度
        lat: null,
        // 搜索关键词
        keywords: '',
        // 分类 id
        category_id: '',
        // 地区 id
        area_id: 1,
        // 排序方式： 距离升序
        sort: 'distance_asc',
        is_representative: ''
      }
    }
  },
  props: [
    'keyword'
  ],
  watch: {
    keyword () {
      this.pageConfig.keywords = (this.keyword === 'undefined' ? '' : this.keyword)
      this.refresh()
    }
  },
  created () {
    this.pageConfig.keywords = (this.keyword === 'undefined' ? '' : this.keyword)
    this._initStores()
  },
  beforeDestroy () {
    this.$fMap.destory()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-store-list`
    },
    hasData () {
      return this.stores.length > 0
    }
  },
  methods: {
    toStoreMap () {
      window.location = `/mall.html#/store-map/0/0/0`
    },
    goToDetail (id) {
      window.location = `/mall.html#/store-detail/${id}`
    },
    // 处理搜索线下店接口的返回数据
    _handleResponse (res, isConcat = false) {
      this.stores = isConcat ? [...this.stores, ...res.data] : res.data
      this.has_next = res.has_next
      this.page = res.current_page
    },
    // 获取用户当前地理位置
    async _getCurrentPosition () {
      let position = this.$localStorage.get(USER_CURRENT_POSITION)
      if (!position) {
        try {
          await this.$fMap.createMap('map')
          // 用户当前地理位置
          position = await this.$fMap.geoLocation()
          // 存储获取到的用户的地理位置
          this.$localStorage.set(USER_CURRENT_POSITION, position, POSITION_ACTIVE_TIME + Date.now())
          this.pageConfig.lng = position.lng
          this.pageConfig.lat = position.lat
        } catch (e) {
          // console.log(e)
          window.location.reload()
        }
      } else {
        this.pageConfig.lng = position.lng
        this.pageConfig.lat = position.lat
      }
    },
    // 初始化线下店列表
    async _initStores () {
      await this._getCurrentPosition()
      const response = await api.fetchStoreList({...this.pageConfig, page: 1})
      this._handleResponse(response)
    },
    // 下拉刷新线下店列表
    async refresh () {
      const response = await api.fetchStoreList({...this.pageConfig, page: 1})
      this._handleResponse(response)
    },
    // 上拉加载更多线下店列表
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.has_next) return
      const response = await api.fetchStoreList({...this.pageConfig, page: ++this.pageConfig.page})
      this._handleResponse(response, true)
    }
  },
  filters: {
    labelFormatter (str = '', length = 24) {
      return str.length > length ? `${str.substring(0, length)}...` : str
    }
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-store-list
  width: 100%
  height: 100%
  color: $black1
  .store-list-scroller
    top: 304px
  .store-list-wrap
    font-size: 24px
    .store-list
      .store-item
        position: relative
        display: block
        padding: 30px
        font-size: 0
        .img-wrap
          display: inline-block
          vertical-align: top
          width: 256px
          height: 256px
          margin-right: 30px
          background: $grey4
        .info
          position: relative
          display: inline-block
          vertical-align: top
          width: 404px
          height: 256px
          padding-top: 18px
          .name
            line-height: 42px
            margin-bottom: 10px
            font-size: 30px
            color: $black1
          .subtitle
            display: block
            line-height: 37px
            margin-bottom: 46px
            font-size: 26px
            color: $black2
            font-weight: 300
            {ellipse}
          .distance
            absolute: right 0 bottom 30px
            text-align: right
            height: 33px
            line-height: 33px
            font-size: 24px
            color: $grey2
            font-weight: 300
          .tag
            absolute: left 0 bottom 30px
            &>span
              padding: 4px 8px
              font-size: 22px
              color: $grey3
              border: 1.4px solid $grey2
              display: inline-block
  .btn-switch-stores-mode
    width: 130px
    height: 130px
    fixed: right 22px bottom 22px
    &>a
      display: block
</style>
