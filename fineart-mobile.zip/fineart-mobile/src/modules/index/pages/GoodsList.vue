<template>
  <div :class="classes">
    <fine-art-scroller
      ref="scroller"
      class="goods-list-scroller"
      @refresh="refresh"
      @load-more="loadMore"
      :list="goods"
      :has-data="hasData"
      :has-more="has_next">
      <div class="goods-list-wrap">
        <div class="goods-list">
          <div
            class="goods-item"
            v-for="(good, index) in goods"
            :key="index"
            @click="goToDetail(good.id, good.store_id)">
            <div class="img-wrap"><img :src="good.thumbnail" width="100%" height="100%"></div>
            <div class="desc">
              <p class="name">{{ good.name }}</p>
              <p class="tags">{{ good.subtitle }}</p>
              <p class="price">&yen;{{ good.price_norm }}</p>
            </div>
          </div>
        </div>
      </div>
    </fine-art-scroller>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from '@/assets/data/constants'
import { hyphenCase } from '@/common/js/utils'

import api from 'modules/mall/api'

import { FineArtCateSideBar, FineArtSearch, FineArtScroller } from 'components'

export default {
  name: `${COMPONENT_PREFIX}PageGoodsList`,
  data () {
    return {
      // 商品列表数据
      goods: [],
      pageConfig: {
        // 商品列表当前所加载分页
        page: 1,
        // 关键词
        keywords: '',
        category_id: '',
        attribute: 1,
        sort: 'default'
      },
      // 当前配置条件下是否还有下一页数据
      has_next: true
    }
  },
  props: [
    'keyword'
  ],
  watch: {
    keyword () {
      this.pageConfig.keywords = (this.keyword === 'undefined' ? '' : this.keyword)
      this.refresh()
    }
  },
  created () {
    this.pageConfig.keywords = (this.keyword === 'undefined' ? '' : this.keyword)
    this._initGoods()
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-goods-list`
    },
    hasData () {
      return this.goods.length > 0
    }
  },
  methods: {
    goToDetail (id, store) {
      window.location = `/mall.html#/goods-detail/${id}/${store}`
    },
    focus () {
      this.$refs.searchInput.focus()
    },
    // 处理 goods 接口返回的数据
    _handleResponse (response, isConcat = false) {
      if (isConcat) {
        this.goods = [...this.goods, ...response.data]
      } else {
        this.goods = response.data
      }
      this.pageConfig.page = response.current_page
      this.has_next = response.has_next
    },
    // 请求初始化 goods 数据
    async _initGoods () {
      const response = await api.fetchGoodsList(this.pageConfig)
      this._handleResponse(response)
    },
    // 加在更多商品列表数据
    async loadMore () {
      // 没有更多数据，不再加载更多
      if (!this.has_next) return
      // 请求加载更多商品数据
      const response = await api.fetchGoodsList({...this.pageConfig, page: this.pageConfig.page + 1})
      this._handleResponse(response, true)
    },
    // 刷新当前商品列表数据
    async refresh () {
      const response = await api.fetchGoodsList({...this.pageConfig, page: 1})
      this._handleResponse(response)
    }
  },
  components: {
    FineArtCateSideBar,
    FineArtSearch,
    FineArtScroller
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-goods-list
  width: 100%
  height: 100%
  color: $black1
  .goods-list-scroller
    top: 304px
    .goods-list-wrap
      padding: 0 22px
      overflow-y: hidden
      .goods-list
        display: flex
        flex-wrap: wrap
        margin-right: -18px
        margin-top: 30px
        .goods-item
          width: 344px
          margin: 0 18px 28px 0
          .img-wrap
            width: 100%
            height: 344px
            margin-bottom: 20px
            background: $grey4
          .desc
            padding-left: 8px
            font-size: 0
            .name
              line-height: 40px
              margin-bottom: 4px
              font-size: 28px
              color: $black1
              font-weight: 300
              {ellipse}
            .tags
              padding-right: 60px
              line-height: 33px
              margin-bottom: 8px
              font-size: 24px
              color: $grey3
              font-weight: 300
              {ellipse}
            .price
              line-height: 37px
              font-size: 26px
              color: $orange
</style>
