<template>
  <div :class="classes">
    <div class="content">
      <div class="img-wrap"><img :src="imgSrc" width="100%" height="100%"></div>
      <p class="desc">斐艺平台(Fine Art)，建筑“滴滴”，专注于连接建筑行业优质资源，是一个以数据化驱动的平台型公司。</p>
      <p class="desc">连接建筑各方资源，进行系统整合，建立全面专业的资源数据库，输出设计/建造/开发的能力。</p>
      <p class="desc">容纳建筑行业多种应用场景，使众多应用场景发生在一个平台上，提高效率，从而优化整个建筑行业。</p>
      <em class="key-word">愿景</em>
      <p class="desc">优化建筑行业供需方服务的数据化驱动科技公司</p>
      <em class="key-word">使命</em>
      <p class="desc">让建筑更简单</p>
    </div>
  </div>
</template>

<script>
import { COMPONENT_PREFIX } from 'assets/data/constants'
import { hyphenCase } from '@/common/js/utils.js'

export default {
  name: `${COMPONENT_PREFIX}PageAboutUs`,
  data () {
    return {
      imgSrc: require('assets/imgs/home/img-about-us.png')
    }
  },
  computed: {
    classes () {
      return `${hyphenCase(COMPONENT_PREFIX)}-page-about-us`
    }
  },
  created () {
    this.$store.commit('MODIFY_PAGE_NAME', '关于我们')
    this.$wx.updateShareData('index', {})
  }
}
</script>

<style lang="stylus">
.{$cls_prefix}-page-about-us
  padding: 0 30px
  .content
    font-size: 0
    padding-top: 30px
    .img-wrap
      width: 692px
      height: 300px
      margin-bottom: 40px
    .desc
      line-height: 44px
      margin-bottom: 48px
      font-size: 26px
      color: $black2
    .key-word
      display: inline-block
      color: $black1
      font-size: 26px
      line-height: 44px
      margin-bottom: 0
      font-weight: 600
</style>
