/*
* @Author: Alan
* @Date:   2018-09-06 20:15:17
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-10 14:29:31
*/
import Vue from 'vue'
import Router from 'vue-router'

import Home from 'modules/index/pages/Home.vue'
import AboutUs from 'modules/index/pages/AboutUs.vue'
import CommonFaq from 'modules/index/pages/CommonFaq.vue'
import NoticeList from 'modules/index/pages/NoticeList.vue'
import NoticeDetail from 'modules/index/pages/NoticeDetail.vue'
import ContactUs from 'modules/index/pages/ContactUs.vue'
import ErrorPage from 'components/Error.vue'
import GlobalSearch from 'modules/index/pages/GlobalSearch.vue'
import Expectation from 'modules/index/pages/Expectation.vue'
import GoodsList from 'modules/index/pages/GoodsList.vue'
import StoreList from 'modules/index/pages/StoreList.vue'
import ResourceList from 'modules/index/pages/ResourceList.vue'
import BuildingList from 'modules/index/pages/BuildingList.vue'
import FocusUs from 'modules/index/pages/FocusUs.vue'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/about-us',
      name: 'AboutUs',
      component: AboutUs
    },
    {
      path: '/common-faq',
      name: 'CommonFaq',
      component: CommonFaq
    },
    {
      path: '/notice-list',
      name: 'NoticeList',
      component: NoticeList
    },
    {
      path: '/notice-detail/:id',
      name: 'NoticeDetail',
      component: NoticeDetail,
      props: true
    },
    {
      path: '/contact-us',
      name: 'ContactUs',
      component: ContactUs
    },
    {
      path: '/expect',
      name: 'Expectation',
      component: Expectation
    },
    {
      path: '/error',
      name: 'ErrorPage',
      component: ErrorPage,
      props: (route) => ({ query: route.query.code })
    },
    {
      path: '/global-search',
      name: 'GlobalSearch',
      component: GlobalSearch,
      children: [
        {
          path: 'goods-list/:keyword',
          component: GoodsList,
          props: true,
          meta: {
            tabIndex: 0
          }
        },
        {
          path: 'store-list/:keyword',
          component: StoreList,
          props: true,
          meta: {
            tabIndex: 1
          }
        },
        {
          path: 'resource-list/:keyword',
          component: ResourceList,
          props: true,
          meta: {
            tabIndex: 2
          }
        },
        {
          path: 'building-list/:keyword',
          component: BuildingList,
          props: true,
          meta: {
            tabIndex: 3
          }
        }
      ]
    },
    {
      path: '/focus-us',
      name: FocusUs,
      component: FocusUs
    }
  ]
})
