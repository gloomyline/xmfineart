import {BaseApi} from '@/common/js/BaseApi'
import homeApi from './homeApi.js'

class IndexApi extends BaseApi {
  constructor () {
    super()
    this._init()
  }

  _init () {
    IndexApi.updateToken(IndexApi.readTokenFromLocalStorage())
    homeApi(IndexApi)
  }
}

const _instance = new IndexApi()
export default _instance
