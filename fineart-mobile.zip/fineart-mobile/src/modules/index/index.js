/*
* @Author: Alan
* @Date:   2018-09-06 20:11:35
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-10 14:21:30
*/
// import flexible mobile layout
import 'amfe-flexible'
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import router from './router'
import store from '@/store'
import App from './index.vue'
import { VueMap } from '@/common/js/Map'
import { TOAST_DURATION, SHARE_DATA } from 'assets/data/constants.js'
import { VueLocalStorage } from '@/common/js/LocalStorage'
import { WXPlugin } from '@/common/js/vue-wx.js'
import { goLogin } from '@/common/js/utils'

// common style files
import '@/common/styles/index.styl'

// vux components register
import {
  Badge,
  Cell,
  Confirm,
  CheckIcon,
  Group,
  LoadingPlugin,
  Rater,
  Scroller,
  Swiper,
  SwiperItem,
  Swipeout,
  SwipeoutItem,
  SwipeoutButton,
  Spinner,
  Tab,
  TabItem,
  ToastPlugin,
  XButton,
  XNumber,
  XInput,
  XTextarea,
  TransferDom
} from 'vux'
import {API_ADDRESS} from 'assets/data/constants'
Vue.directive('transfer-dom', TransferDom)
Vue.component('badge', Badge)
Vue.component('cell', Cell)
Vue.component('check-icon', CheckIcon)
Vue.component('group', Group)
Vue.component('rater', Rater)
Vue.component('scroller', Scroller)
Vue.component('swiper', Swiper)
Vue.component('swiper-item', SwiperItem)
Vue.component('spinner', Spinner)
Vue.component('tab', Tab)
Vue.component('tab-item', TabItem)
Vue.component('x-button', XButton)
Vue.component('x-input', XInput)
Vue.component('x-number', XNumber)
Vue.component('confirm', Confirm)
Vue.component('swipeout', Swipeout)
Vue.component('swipeout-item', SwipeoutItem)
Vue.component('swipeout-button', SwipeoutButton)
Vue.component('x-textarea', XTextarea)

// Toast default opts
const toastOpts = {
  position: 'bottom',
  width: '160px',
  time: TOAST_DURATION * 1000,
  type: 'text'
}
Vue.use(ToastPlugin, toastOpts)
// Loading plugin
Vue.use(LoadingPlugin)
// vue map plugin
Vue.use(VueMap)
Vue.use(VueLocalStorage)
// router global hook
router.beforeEach((to, from, next) => {
  const user = Vue.localStorage.getUser()
  if (user && user.isLogin && user.token) {
    if (Object.keys(store.state.memberProfile).length === 0) {
      store.dispatch('fetchAccountProfile')
    }
  }
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // this route requires auth, check if logged in
    // if not, break route change, open login modal.
    const user = Vue.localStorage.getUser()
    if (user && user.isLogin) { // user status is valid, go to corresponding path
      next()
    } else { // not login or is out of date
      goLogin()
    }
  } else {
    next() // 确保一定要调用 next()
  }
})

// wx js sdk
Vue.use(WXPlugin, { shareData: SHARE_DATA.index })
// 使用 vue wx 插件更新页面的分享内容
router.afterEach((to) => {
  const location = window.location
  const pageLink = location.href.replace(location.hash, '')
  const _link = `${pageLink}#${to.path}`
  const link = `${API_ADDRESS}/sys/wechat/share?url=${encodeURIComponent(_link)}`
  Vue.wx.updateShareData('index', { link })
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  router,
  template: '<App/>',
  components: { App }
})
