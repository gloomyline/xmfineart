/*
* @Author: Alan
* @Date:   2018-09-18 17:19:49
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 17:30:29
*/
import * as types from './mutation-types.js'

export default {
  [types.INCREMENT] (state) {
    ++state.count
  },
  [types.ADD] (state, { delta }) {
    state.count += state.delta
  },
  [types.SEND_REQUEST] (state) { // 发起请求，开始加载
    state.isLoading = true
  },
  [types.REQUEST_SUCCEED] (state) { // 请求成功，结束加载
    state.isLoading = false
  },
  [types.REQUEST_FAILED] (state) { // 请求失败，结束加载
    state.isLoading = false
  },
  [types.LOGIN] (state) {
    state.isLogin = true
  },
  [types.LOGOUT] (state) {
    state.isLogin = false
    // TODO: 清空用户在 store 中缓存的数据
    state.mall.cartGoodsCount = 0
  },
  [types.ADD_MESSAGE] (state, { msg, type = 'text', position, cb }) {
    // 没传值时，默认类型为text的在底部，成功警告等其余类型的显示在中间
    position = position || (type === 'text' ? 'bottom' : 'default')

    state.message = {
      msg,
      type,
      cb,
      position,
      timestamp: Date.now()
    }
  },
  [types.SAVE_MEMBER_PROFILE] (state, { response }) {
    state.memberProfile = response
  },
  [types.CLEAR_MEMBER_PROFILE] (state) {
    state.memberProfile = {}
  },
  [types.MODIFY_PAGE_NAME] (state, name) {
    state.pageName = name
  },
  [types.MODIFY_PAGE_HEAD_STATUS] (state, val) {
    state.pageHeadStatus = val
  }
}
