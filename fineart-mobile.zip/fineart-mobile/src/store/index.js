/*
* @Author: Alan
* @Date:   2018-09-18 15:42:10
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 19:01:32
*/
import Vue from 'vue'
import Vuex from 'vuex'

// global state, getters, actions, mutations
import state from './state.js'
import mutations from './mutations.js'
import * as getters from './getters.js'
import * as actions from './actions.js'

// modules
import home from './modules/home'
import house from './modules/house'
import discovery from './modules/discovery'
import map from './modules/map'
import mall from './modules/mall'
import member from './modules/member'
import building from './modules/building'
import resource from './modules/resource'

// plugins
import logger from './plugins/logger.js'
import createHttpInterceptor from './plugins/httpInterceptor.js'

Vue.use(Vuex)

const httpInterceptor = createHttpInterceptor()

const plugins = [httpInterceptor]
if (process.env.NODE_ENV === 'development') {
  plugins.push(logger)
}

export default new Vuex.Store({
  // global state
  state,
  // global getters
  getters,
  // global actions
  actions,
  // global plugins
  plugins,
  // global mutations
  mutations,
  modules: { home, house, discovery, map, mall, member, building, resource }
})
