/*
* @Author: Alan
* @Date:   2018-09-18 17:01:25
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 17:14:32
*/
import createLogger from 'vuex/dist/logger.js'

// not log mutations by adding the type of them
const blacklistedMutation = []

export default createLogger({
  // auto-expand logged mutations
  collapsed: true,
  // return `true` if a mutation should be logged
  // `mutation` is a `{ type, payload }`
  filter (mutation, stateBefore, stateAfter) {
    // 仅 log 黑名单中不存在的 mutation 的 type
    return blacklistedMutation.indexOf(mutation.type) === -1
  },
  // transform the state before logging it
  // for example return only a specific sub-tree
  transformer (state) {
    return state
  },
  // mutations are logged in the format of `{ type, payload }`
  // we can format it any way we want
  mutationTransformer (mutation) {
    return mutation.type
  }
  // implementation of the `console` API, default `console`
  // logger: console
})
