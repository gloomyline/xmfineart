/*
* @Author: Alan
* @Date:   2018-09-18 18:00:00
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 18:53:49
*/
import axios from 'axios'
import { LOGIN_FIRST_PLZ } from 'assets/data/message.js'
import { MESSAGE_DURATION } from 'assets/data/constants.js'
import { LocalStorage } from '@/common/js/LocalStorage'
import { goLogin } from '@/common/js/utils'

const ls = new LocalStorage()

export default function createHttpInterceptor (opts = {}) {
  /* eslint-disable no-unused-vars */
  let blacklistedUrl = [
    '/sys/notice',
    '/account/wechat/login/mob'
    // TODO: disable intercepting all of list requests in module mall
    // '/search'
  ]
  blacklistedUrl = opts.blacklistedUrl ? [...blacklistedUrl, ...opts.blacklistedUrl] : blacklistedUrl
  return (store) => {
    axios.interceptors.request.use(config => {
      // if the url of request is in the black list, do not intercept it
      for (let i = 0, length = blacklistedUrl.length; i < length; ++i) {
        const reg = new RegExp(blacklistedUrl[i])
        if (reg.test(config.url)) {
          return config
        }
      }
      store.commit('SEND_REQUEST')
      return config
    }, error => {
      return Promise.reject(error)
    })

    axios.interceptors.response.use(response => {
      store.commit('REQUEST_SUCCEED')
      // 拦截所有的请求响应，处理 token 失效过期不合法，用户登录状态过期未登录情况
      if (response.data.code === 401) {
        // 处理请求响应结果
        ls.setUser({ token: null, isLogin: false, expired: parseInt(Date.now() / 1000) })
        store.commit('ADD_MESSAGE', {
          msg: LOGIN_FIRST_PLZ,
          type: 'warn',
          cb () {
            setTimeout(() => {
              goLogin()
            }, MESSAGE_DURATION)
          }
        })
      } else if (response.data.code !== 200) {
        store.commit('ADD_MESSAGE', { msg: response.data.msg, type: 'cancel' })
      }
      return response
    }, error => {
      store.commit('REQUEST_FAILED')
      return Promise.reject(error)
    })
  }
}
