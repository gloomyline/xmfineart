/*
* @Author: Alan
* @Date:   2018-09-18 17:41:27
* @Last Modified by:   Alan
* @Last Modified time: 2018-09-18 17:43:19
*/

// import * as types from '@/store/mutation-types.js'

const state = {}

const getters = {}

const actions = {}

const mutations = {}

export default {
  state,
  getters,
  actions,
  mutations
}
