/**
 * @comment: resource 模块的 store
 * @author: alan_wang
 * @date: 10/10/2018
 * @time: 11:25:23
 */
import api from 'modules/resources/api'
import * as types from '@/store/mutation-types.js'
const state = {
  resourceDetail: {},
  resourceDesignPrice: [
    {value: '', name: '不设置'},
    {value: '100', name: '100元/m²内'},
    {value: '200', name: '100~200元/m²'},
    {value: '300', name: '200~400元/m²'},
    {value: '400', name: '400~600元/m²'},
    {value: '500', name: '600~800元/m²'},
    {value: '600', name: '800元/m²以上'}
  ]
}
const getters = {}
const actions = {
  async fetchDetail ({ commit }, { resource_id, resource_mode }) {
    const response = await api.fetchResourceDetail({
      resource_id,
      resource_mode
    })
    commit('RESOURCE_GET_DETAIL', {data: response})
  }
}
const mutations = {
  [types.RESOURCE_GET_DETAIL] (state, data) {
    state.resourceDetail = data.data
  },
  [types.RESOURCE_CLEAR_DETAIL] (state) {
    state.resourceDetail = {}
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
