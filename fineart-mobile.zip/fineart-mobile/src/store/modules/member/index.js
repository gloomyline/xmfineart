/**
 * @comment: 会员中心 memberCenter 模块的 store
 * @author: alan_wang
 * @date: 10/10/2018
 * @time: 11:25:23
 */

import * as types from '@/store/mutation-types.js'

const state = {
  expressCompany: {
    'SF': '顺丰',
    'HTKY': '百世快递',
    'ZTO': '中通',
    'STO': '申通',
    'YTO': '圆通',
    'YD': '韵达',
    'YZPY': '邮政平邮',
    'EMS': 'EMS',
    'HHTT': '天天',
    'JD': '京东',
    'QFKD': '全峰',
    'GTO': '国通',
    'UC': '优速',
    'DBL': '德邦',
    'FAST': '快捷',
    'AMAZON': '亚马逊',
    'ZJS': '宅急送'
  },
  isMember: false, // 是否处于会员中心实例 false--否 true--是
  grouponName: ''
}
const getters = {}
const actions = {}
const mutations = {
  [types.MODIFY_IS_MEMBER] (state) {
    state.isMember = true
  },
  [types.MODIFY_GROUPON_NAME] (state, val) {
    state.grouponName = val
  }
}
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
