/*
* @Author: fyfy
* @Date:   2018-09-07 11:40:22
* @Last Modified by:   fyfy
* @Last Modified time: 2018-09-07 11:40:36
*/
'use strict'
module.exports = {
  NODE_ENV: '"test"'
}
